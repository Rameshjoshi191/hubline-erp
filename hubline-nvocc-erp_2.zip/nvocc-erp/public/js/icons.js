// Inline SVG icon set (24x24 stroke icons) and brand graphics. No external assets, so it works under the strict CSP and offline.
const P = {
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  package: '<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 12.5l9 5 9-5M3 17l9 5 9-5"/>',
  container: '<rect x="2" y="6" width="20" height="12" rx="1.5"/><path d="M6 6v12M10 6v12M14 6v12M18 6v12"/>',
  report: '<rect x="5" y="3.5" width="14" height="17.5" rx="2"/><path d="M9 3.5h6v3H9zM9 12h6M9 16h4"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-6 6.5-6s6.5 2.5 6.5 6"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18.2 14.3c1.9.8 3.3 2.7 3.3 5.7"/>',
  contract: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
  percent: '<path d="M19 5L5 19"/><circle cx="7" cy="7" r="2.6"/><circle cx="17" cy="17" r="2.6"/>',
  building: '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M9 8h2M13 8h2M9 12h2M13 12h2M10 21v-4h4v4"/>',
  tag: '<path d="M3 12V4a1 1 0 0 1 1-1h8l9 9-9 9z"/><circle cx="7.5" cy="7.5" r="1.3"/>',
  invoice: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  wallet: '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10h18M16 15h2"/><path d="M6 6l9-3 2 3"/>',
  ledger: '<path d="M4 4h12a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3z"/><path d="M8 9h7M8 13h7"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  chart: '<path d="M4 20V4M4 20h16"/><path d="M8 16v-5M12 16V8M16 16v-3"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
  anchor: '<circle cx="12" cy="5" r="2"/><path d="M12 7v14M5 12H3a9 9 0 0 0 18 0h-2M8 11h8"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.2 3.4 3.2 14.6 0 18M12 3c-3.2 3.4-3.2 14.6 0 18"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>',
  logout: '<path d="M9 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h4M16 8l4 4-4 4M20 12H9"/>',
  alert: '<path d="M12 3.5l9.5 16.5h-19z"/><path d="M12 10v4.5M12 17.5h.01"/>',
  trend: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
  coins: '<circle cx="12" cy="12" r="9"/><path d="M15 9.6c0-1.3-1.3-2.1-3-2.1s-3 .8-3 2.1c0 3 6 1.6 6 4.6 0 1.3-1.3 2.1-3 2.1s-3-.8-3-2.1M12 6v1.5M12 16.7V18"/>',
  pen: '<path d="M4 20h4L19.2 8.8a2.8 2.8 0 0 0-4-4L4 16z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  ship: '<path d="M3 17l1.6 3h14.8L21 17z"/><path d="M5 17V11h14v6M9 11V7h6v4M12 7V4"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.5h.01"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
};

export function icon(name, size = 18) {
  return `<svg class="ico" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || P.info}</svg>`;
}

// Brand mark: a container stack over a wave, on a rounded tile.
export function logoMark(size = 36) {
  return `<svg class="logo-mark" viewBox="0 0 40 40" width="${size}" height="${size}" aria-hidden="true">
    <defs><linearGradient id="lgm" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#22b8cf"/><stop offset="1" stop-color="#1c64b8"/></linearGradient></defs>
    <rect width="40" height="40" rx="10" fill="url(#lgm)"/>
    <rect x="8" y="10" width="9" height="7" rx="1.2" fill="#fff"/><rect x="18.5" y="10" width="9" height="7" rx="1.2" fill="#fff" opacity=".85"/>
    <rect x="13" y="18.5" width="9" height="7" rx="1.2" fill="#fff" opacity=".7"/><rect x="23.5" y="18.5" width="9" height="7" rx="1.2" fill="#fff" opacity=".55"/>
    <path d="M6 31c3 0 3-2 6-2s3 2 6 2 3-2 6-2 3 2 6 2 3-2 4-2" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>`;
}

// Login-screen illustration: a container ship at sea.
export function shipScene() {
  const stack = (x, y, cols, rows, palette) => {
    let out = '';
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
      out += `<rect x="${x + c * 26}" y="${y - 14 - r * 15}" width="24" height="13" rx="1.5" fill="${palette[(r * 3 + c) % palette.length]}"/>`
        + `<path d="M${x + c * 26 + 6} ${y - 14 - r * 15 + 1.5}v10M${x + c * 26 + 12} ${y - 14 - r * 15 + 1.5}v10M${x + c * 26 + 18} ${y - 14 - r * 15 + 1.5}v10" stroke="rgba(0,0,0,.16)" stroke-width="1"/>`;
    }
    return out;
  };
  const pal = ['#f59e0b', '#22b8cf', '#ef4444', '#3b82f6', '#10b981', '#e2e8f0', '#f97316'];
  const stars = [[40, 60], [120, 30], [200, 90], [290, 40], [350, 120], [470, 60], [60, 150], [250, 170], [440, 190], [500, 130], [170, 130]].map(([x, y], i) => `<circle cx="${x}" cy="${y}" r="${i % 3 ? 1 : 1.6}" fill="#fff" opacity="${0.35 + (i % 4) * 0.1}"/>`).join('');
  return `<svg class="scene" viewBox="0 0 520 700" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#081d36"/><stop offset=".45" stop-color="#12457a"/><stop offset=".62" stop-color="#3f95b4"/><stop offset="1" stop-color="#0a3556"/></linearGradient>
      <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1c6f97"/><stop offset="1" stop-color="#082b48"/></linearGradient>
    </defs>
    <rect width="520" height="700" fill="url(#sky)"/>${stars}
    <g transform="translate(0 200)">
      <circle cx="400" cy="70" r="46" fill="#ffd27a" opacity=".95"/><circle cx="400" cy="70" r="74" fill="#ffd27a" opacity=".14"/>
      <g fill="#fff" opacity=".16"><ellipse cx="90" cy="40" rx="46" ry="9"/><ellipse cx="130" cy="52" rx="34" ry="7"/><ellipse cx="300" cy="16" rx="40" ry="8"/></g>
      <rect y="228" width="520" height="300" fill="url(#sea)"/>
      <g transform="translate(46 0)">
        ${stack(20, 212, 6, 3, pal)}${stack(240, 212, 3, 2, pal.slice(1))}
        <rect x="196" y="150" width="34" height="62" rx="2" fill="#f1f5f9"/><rect x="200" y="156" width="26" height="6" fill="#0b2a4a"/><rect x="200" y="167" width="26" height="4" fill="#94a3b8"/><rect x="200" y="175" width="26" height="4" fill="#94a3b8"/>
        <rect x="206" y="138" width="14" height="12" fill="#e2e8f0"/><rect x="211" y="124" width="4" height="14" fill="#94a3b8"/>
        <path d="M0 212h330l-22 34H26z" fill="#12263f"/><path d="M0 212h330l-3 5H3z" fill="#c0392b"/>
      </g>
      <g fill="none" stroke="#fff" stroke-linecap="round" stroke-width="2"><path opacity=".3" d="M0 262c30 0 30-6 60-6s30 6 60 6 30-6 60-6 30 6 60 6 30-6 60-6 30 6 60 6 30-6 60-6 30 6 60 6 30-6 60-6"/>
        <path opacity=".2" d="M0 296c40 0 40-7 80-7s40 7 80 7 40-7 80-7 40 7 80 7 40-7 80-7 40 7 80 7 40-7 80-7"/><path opacity=".12" d="M0 336c50 0 50-8 100-8s50 8 100 8 50-8 100-8 50 8 100 8 50-8 100-8"/></g>
    </g>
  </svg>`;
}
