import { api, state, esc, $, $$, on, qs, tbl, pageHead, num, int, date, dt, groupBadge, badge, shipBadge, formModal, openModal, confirmBox, toast, opts, can, kv, link, todayStr, addDaysStr, go, debounce, download } from '../core.js';
import { shareBtn, wireShare } from '../share.js';
import { inventoryImport } from './movements.js';
import { icon } from '../icons.js';

const OWNERSHIP = [['COC', 'COC - carrier owned'], ['SOC', 'SOC - shipper owned'], ['LEASED', 'Leased'], ['OWN', 'Own']];
const statusOptions = () => Object.entries(state.lk.container_status).map(([k, v]) => [k, v.label]);
const freeCell = (c) => (c.free_until ? `${date(c.free_until)}<div class="small ${c.overdue ? 'neg' : 'muted'}">${c.overdue ? `${-c.free_days_left} day${c.free_days_left === -1 ? '' : 's'} over` : `${c.free_days_left} day${c.free_days_left === 1 ? '' : 's'} left`}</div>` : '');

const movementFields = (withClock = true) => [
  { name: 'event_type', label: 'Movement / new status', type: 'select', options: statusOptions, noEmpty: true, required: true, span: 2 },
  { name: 'event_date', label: 'Date', type: 'date', required: true }, { name: 'location', label: 'Location / depot', span: 1 },
  ...(withClock ? [{ name: 'free_days', label: 'Free days', type: 'number', min: 0, hint: 'for discharged / delivered only', span: 1 }] : []),
  { name: 'remarks', label: 'Remarks', span: 3 },
];

export async function list(root, _p, query) {
  const f = { q: query.q || '', as_of: todayStr(), group: query.group || '', status: '', type_id: '', ownership: '', location: '', overdue: query.overdue || '' };
  const canW = can('containers', 'write');
  let rows = [];
  root.innerHTML = `${pageHead('Container inventory', 'Where every container is, its status, and free-time exposure', (can('movements', 'write') ? `<button class="btn primary" data-act="import">${icon('upload', 16)} Update from Excel</button>` : '') + (canW ? '<button class="btn" data-act="add">+ Add container</button><button class="btn" data-act="bulk">Bulk add</button><button class="btn" data-act="move" disabled>Log movement for selected</button>' : '') + shareBtn('Share / download'))}
    <div class="grid g4" style="margin-bottom:14px" data-sum></div>
    <div class="toolbar"><input type="text" class="search" placeholder="Search container no., location, booking…" data-f="q" value="${esc(query.q || '')}">
      <label class="muted small">As at <input type="date" data-f="as_of" value="${f.as_of}"></label>
      <select data-f="group"><option value="">All groups</option><option value="EMPTY" ${f.group === 'EMPTY' ? 'selected' : ''}>Empty</option><option value="LADEN" ${f.group === 'LADEN' ? 'selected' : ''}>Laden</option><option value="OUT_OF_SERVICE">Out of service</option></select>
      <select data-f="status"><option value="">Any status</option>${statusOptions().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="type_id"><option value="">All types</option>${opts.types().map(([v, l]) => `<option value="${v}">${esc(l.split(' - ')[0])}</option>`).join('')}</select>
      <select data-f="ownership"><option value="">Any ownership</option>${OWNERSHIP.map(([v, l]) => `<option value="${v}">${esc(v)}</option>`).join('')}</select>
      <select data-f="location" data-loc><option value="">All locations</option></select>
      <label class="muted small"><input type="checkbox" data-f="overdue" ${f.overdue ? 'checked' : ''}> Past free time only</label>
      <span class="grow"></span><a class="btn" href="#/inventory-report">Daily report</a></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root), moveBtn = $('[data-act=move]', root);
  const selected = new Set();
  const paint = () => {
    out.innerHTML = tbl({ rows, empty: 'No containers match these filters.', cols: [
      ...(canW ? [{ label: '', render: (c) => `<input type="checkbox" data-sel="${c.id}" ${selected.has(c.id) ? 'checked' : ''}>` }] : []),
      { label: 'Container', render: (c) => `<b>${link((state.me.is_agent ? '#/track/' : '#/containers/') + c.id, c.container_no)}</b>` }, { label: 'Type', key: 'type_code' },
      { label: 'Ownership', render: (c) => `${esc(c.ownership)}${c.owner_name ? `<div class="muted small">${esc(c.owner_name)}</div>` : ''}` },
      { label: 'Status', render: (c) => `${groupBadge(c.group, c.status_label)}` }, { label: 'Location', render: (c) => esc(c.location || '') },
      { label: 'Since', render: (c) => `${date(c.last_date)}<div class="muted small">${c.days_in_status} day${c.days_in_status === 1 ? '' : 's'}</div>` },
      { label: 'Booking / HBL', render: (c) => c.shipment_id ? `${link('#/shipments/' + c.shipment_id, c.booking_no)}<div class="muted small">${esc(c.hbl_no || '')}</div>` : '' },
      { label: 'Free time until', render: freeCell }] });
    if (moveBtn) { moveBtn.disabled = !selected.size; moveBtn.textContent = selected.size ? `Log movement for ${selected.size} selected` : 'Log movement for selected'; }
  };
  async function load() {
    const all = (await api('GET', '/containers' + qs({ as_of: f.as_of }))).rows;
    const q = f.q.trim().toUpperCase();
    rows = all.filter((c) => (!q || c.container_no.includes(q) || (c.location || '').toUpperCase().includes(q) || (c.booking_no || '').toUpperCase().includes(q) || (c.hbl_no || '').toUpperCase().includes(q))
      && (!f.group || c.group === f.group) && (!f.status || c.status === f.status) && (!f.type_id || String(c.type_id) === String(f.type_id))
      && (!f.ownership || c.ownership === f.ownership) && (!f.location || c.location === f.location) && (!f.overdue || c.overdue));
    selected.clear();
    const locSel = $('[data-loc]', root), curLoc = f.location;
    const locs = [...new Set(all.map((c) => c.location).filter(Boolean))].sort();
    locSel.innerHTML = `<option value="">All locations</option>${locs.map((l) => `<option ${l === curLoc ? 'selected' : ''}>${esc(l)}</option>`).join('')}`;
    const c = { EMPTY: 0, LADEN: 0, OUT_OF_SERVICE: 0, over: 0 };
    for (const x of all) { c[x.group]++; if (x.overdue) c.over++; }
    $('[data-sum]', root).innerHTML = [['Total', all.length, ''], ['Empty', c.EMPTY, ''], ['Laden', c.LADEN, ''], ['Past free time', c.over, c.over ? 'neg' : '']]
      .map(([k, v, cls]) => `<div class="card stat"><div class="k">${k}</div><div class="v ${cls}">${v}</div><div class="s">as at ${date(f.as_of)}</div></div>`).join('');
    paint();
  }
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.type === 'checkbox' ? (e.target.checked ? '1' : '') : e.target.value; reload(); } });
  on(root, 'change', '[data-sel]', (_e, el) => { const id = Number(el.dataset.sel); el.checked ? selected.add(id) : selected.delete(id); moveBtn.disabled = !selected.size; moveBtn.textContent = selected.size ? `Log movement for ${selected.size} selected` : 'Log movement for selected'; });

  on(root, 'click', '[data-act=add]', async () => {
    const r = await formModal({ title: 'Add container to inventory', fields: [
      { name: 'container_no', label: 'Container number', required: true, span: 2, placeholder: 'e.g. HLSU1234567', hint: 'validated with the ISO 6346 check digit' },
      { name: 'type_id', label: 'Type', type: 'select', options: opts.types, noEmpty: true, span: 2, required: true },
      { name: 'ownership', label: 'Ownership', type: 'select', options: OWNERSHIP, noEmpty: true, span: 1 }, { name: 'owner_id', label: 'Owner / lessor', type: 'combo', options: () => opts.parties(), span: 1 },
      { name: 'status', label: 'Initial status', type: 'select', options: statusOptions, noEmpty: true, span: 1 }, { name: 'date', label: 'Date', type: 'date', span: 1 },
      { name: 'location', label: 'Location / depot', span: 2 }, { name: 'allow_invalid', label: 'Accept an invalid check digit', type: 'checkbox', span: 2 }, { name: 'remarks', label: 'Remarks', span: 4 }],
      values: { ownership: 'OWN', status: 'EMPTY_AVAILABLE', date: todayStr() }, onSubmit: (v) => api('POST', '/containers', v) });
    if (r) { toast(`${r.container_no} added`, 'ok'); load(); }
  });
  on(root, 'click', '[data-act=bulk]', async () => {
    const res = await formModal({ title: 'Bulk add containers', size: 'wide', intro: '<p class="muted">Paste container numbers separated by spaces, commas or new lines (up to 500). Each number is checked against ISO 6346; duplicates are skipped.</p>', fields: [
      { name: 'numbers', label: 'Container numbers', type: 'textarea', rows: 6, span: 4, required: true },
      { name: 'type_id', label: 'Type', type: 'select', options: opts.types, noEmpty: true, span: 2, required: true }, { name: 'ownership', label: 'Ownership', type: 'select', options: OWNERSHIP, noEmpty: true },
      { name: 'owner_id', label: 'Owner / lessor', type: 'combo', options: () => opts.parties() },
      { name: 'status', label: 'Initial status', type: 'select', options: statusOptions, noEmpty: true }, { name: 'date', label: 'Date', type: 'date' }, { name: 'location', label: 'Location / depot', span: 2 },
      { name: 'allow_invalid', label: 'Accept invalid check digits', type: 'checkbox', span: 2 }],
      values: { ownership: 'OWN', status: 'EMPTY_AVAILABLE', date: todayStr() }, submitLabel: 'Add containers', onSubmit: (v) => api('POST', '/containers/bulk', v) });
    if (res && res.created) {
      const h = openModal({ title: 'Bulk add result', size: 'narrow', body: `<p><b>${res.created.length}</b> added.</p>${res.skipped.length ? `<div class="alert warn"><b>${res.skipped.length} skipped</b> (already exist): ${esc(res.skipped.map((x) => x.number).join(', '))}</div>` : ''}${res.invalid.length ? `<div class="alert bad"><b>${res.invalid.length} rejected:</b><br>${res.invalid.map((x) => esc(x.number + ' - ' + x.reason)).join('<br>')}</div>` : ''}`, footer: '<button class="btn primary" data-close>OK</button>' });
      await h.done; load();
    }
  });
  on(root, 'click', '[data-act=move]', async () => {
    const r = await formModal({ title: `Log movement - ${selected.size} container${selected.size === 1 ? '' : 's'}`, fields: movementFields(), values: { event_date: todayStr(), event_type: 'GATED_IN_FULL' }, submitLabel: 'Record movement',
      onSubmit: (v) => api('POST', '/container-events/bulk', { ...v, container_ids: [...selected] }) });
    if (r) { toast('Movement recorded', 'ok'); load(); }
  });
  on(root, 'click', '[data-act=import]', async () => { const r = await inventoryImport(); if (r) load().catch((e) => toast(e.message, 'bad')); });
  wireShare(root, () => ({ kind: 'containers', params: { as_of: f.as_of, q: f.q, group: f.group, status: f.status, type_id: f.type_id, ownership: f.ownership, location: f.location, overdue: f.overdue }, title: 'Share container inventory', what: 'the container inventory with the filters you have chosen', defaultSubject: 'Container inventory' }));
  await load();
}

export async function detail(root, { id }) {
  const c = await api('GET', `/containers/${id}`);
  const canW = can('containers', 'write');
  root.innerHTML = `${pageHead(`${esc(c.container_no)} ${groupBadge(c.group, c.status_label || c.status)}`, `${esc(c.type_code)} &middot; ${esc(c.ownership)}${c.owner_name ? ' &middot; ' + esc(c.owner_name) : ''}`,
    canW ? '<button class="btn primary" data-act="move">Log movement</button><button class="btn" data-act="edit">Edit</button>' : '', '<a href="#/containers">Containers</a> /')}
    ${c.overdue ? `<div class="alert bad"><b>Free time expired</b> on ${date(c.free_until)} &mdash; ${-c.free_days_left} day(s) over. Detention/demurrage may be accruing.</div>` : ''}
    <div class="split"><div class="card"><div class="card-h"><h2>Movement history</h2></div>${tbl({ rows: c.events, compact: true, cols: [
      { label: 'Date', render: (e) => date(e.event_date) }, { label: 'Movement', render: (e) => esc(e.label) + (e.free_days != null ? `<div class="muted small">${e.free_days} free days</div>` : '') }, { label: 'Location', render: (e) => esc(e.location || '') },
      { label: 'Reference', render: (e) => `${e.shipment_id ? link('#/shipments/' + e.shipment_id, e.booking_no) : ''}${e.consol_no ? `<div class="muted small">${esc(e.consol_no)}</div>` : ''}` },
      { label: 'Remarks', render: (e) => `<span class="small">${esc(e.remarks || '')}</span><div class="muted small">${esc(e.username || '')}</div>` },
      ...(canW ? [{ label: '', render: (e) => `<button class="btn sm ghost" data-delev="${e.id}" title="Delete this movement">&#10005;</button>` }] : [])] })}</div>
    <div><div class="card"><div class="card-h"><h2>Details</h2></div><div class="card-b">${kv([['Status', esc(c.status_label)], ['Location', esc(c.location)], ['Since', `${date(c.last_date || c.last_event_date)} (${c.days_in_status ?? 0} days)`], ['Type', esc(c.type_code) + ` (${c.teu} TEU)`],
      ['Ownership', esc(c.ownership)], ['Owner / lessor', esc(c.owner_name)], ['Condition', esc(c.condition)], ['Free time', c.free_until ? `${c.free_days} days from ${date(c.clock_from)}, until ${date(c.free_until)}` : ''], ['Remarks', esc(c.remarks)]])}</div></div>
    <div class="card"><div class="card-h"><h2>Shipments</h2></div>${tbl({ rows: c.shipments, compact: true, empty: 'Never used on a shipment.', cols: [{ label: 'Booking', render: (s) => link('#/shipments/' + s.id, s.booking_no) + `<div class="muted small">${esc(s.hbl_no || '')}</div>` }, { label: 'Cargo', key: 'cargo_type' }, { label: 'Status', render: (s) => shipBadge(s.status) }] })}</div></div></div>`;
  on(root, 'click', '[data-act=move]', async () => {
    const r = await formModal({ title: `Log movement - ${c.container_no}`, fields: movementFields(), values: { event_date: todayStr(), location: c.location }, submitLabel: 'Record movement', onSubmit: (v) => api('POST', `/containers/${id}/events`, v) });
    if (r) { toast('Movement recorded', 'ok'); go(`#/containers/${id}`); }
  });
  on(root, 'click', '[data-act=edit]', async () => {
    const r = await formModal({ title: `Edit ${c.container_no}`, values: c, fields: [
      { name: 'type_id', label: 'Type', type: 'select', options: opts.types, noEmpty: true, span: 2 }, { name: 'ownership', label: 'Ownership', type: 'select', options: OWNERSHIP, noEmpty: true },
      { name: 'owner_id', label: 'Owner / lessor', type: 'combo', options: () => opts.parties() }, { name: 'condition', label: 'Condition', type: 'select', noEmpty: true, options: [['SOUND', 'Sound'], ['DAMAGED', 'Damaged'], ['UNDER_REPAIR', 'Under repair']], span: 2 },
      { name: 'active', label: 'Active in inventory', type: 'checkbox', span: 2 }, { name: 'remarks', label: 'Remarks', type: 'textarea', rows: 2, span: 4 }], onSubmit: (v) => api('PUT', `/containers/${id}`, v) });
    if (r) { toast('Saved', 'ok'); go(`#/containers/${id}`); }
  });
  on(root, 'click', '[data-delev]', async (_e, el) => {
    if (!(await confirmBox('Delete this movement record? The container status will be recalculated from the remaining history.', { danger: true, ok: 'Delete movement' }))) return;
    try { await api('DELETE', `/container-events/${el.dataset.delev}`); go(`#/containers/${id}`); } catch (e) { toast(e.message, 'bad'); }
  });
}

// ------------------------------------------------------------------ daily inventory report
export async function report(root, _p, query) {
  let day = query.date || todayStr();
  async function draw() {
    const r = await api('GET', `/reports/container-inventory?date=${day}`);
    const T = r.totals;
    const stCols = r.statuses;
    const kpi = (k, v, cls = '') => `<div class="card stat"><div class="k">${k}</div><div class="v ${cls}">${v}</div></div>`;
    const SHORT = { EMPTY_AVAILABLE: 'Available', ALLOCATED: 'Allocated', RELEASED_SHIPPER: 'At shipper', GATED_IN_FULL: 'Gated in', ON_BOARD: 'On board', DISCHARGED: 'Discharged', DELIVERED_FULL: 'Delivered', EMPTY_RETURNED: 'Returned', DAMAGED: 'Damaged' };
    root.innerHTML = `${pageHead('Daily container inventory report', `${esc(state.lk.settings.company_name)} &middot; as at ${date(r.date)}`, `<button class="btn" data-act="print">Print</button>${shareBtn('Share / download')}<button class="btn primary" data-act="xlsx">${icon('sheet', 16)} Export Excel</button>`)}
      <div class="toolbar no-print"><button class="btn" data-act="prev">&larr; Previous day</button><input type="date" value="${day}" data-date><button class="btn" data-act="next">Next day &rarr;</button><button class="btn ghost" data-act="today">Today</button></div>
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr));margin-bottom:16px">
        ${kpi('Opening', T.opening)}${kpi('In', T.in ? '+' + T.in : 0)}${kpi('Out', T.out ? '-' + T.out : 0)}${kpi('Closing', T.closing)}${kpi('Empty', T.empty)}${kpi('Laden', T.laden)}${kpi('Out of service', T.out_of_service, T.out_of_service ? 'neg' : '')}${kpi('TEU', num(T.teu_closing))}</div>
      <div class="card"><div class="card-h"><h2>Summary by container type</h2><span class="muted small">opening ${date(r.prev_date)} &rarr; closing ${date(r.date)}</span></div>
        ${tbl({ rows: r.types, compact: true, empty: 'No containers in inventory on this date.', cols: [{ label: 'Type', render: (t) => `<b>${esc(t.type_code)}</b>` }, { label: 'Open', num: true, key: 'opening' }, { label: 'In', num: true, key: 'in' }, { label: 'Out', num: true, key: 'out' }, { label: 'Close', num: true, render: (t) => `<b>${t.closing}</b>` },
          { label: 'Empty', num: true, key: 'empty' }, { label: 'Laden', num: true, key: 'laden' }, { label: 'O.O.S.', num: true, key: 'out_of_service' }, ...stCols.map((s) => ({ label: SHORT[s] || r.status_labels[s], num: true, render: (t) => t[s] || '<span class="muted">·</span>' }))],
          foot: `<tr><td>Total</td><td class="num">${T.opening}</td><td class="num">${T.in}</td><td class="num">${T.out}</td><td class="num">${T.closing}</td><td class="num">${T.empty}</td><td class="num">${T.laden}</td><td class="num">${T.out_of_service}</td>${stCols.map((s) => `<td class="num">${T[s] || 0}</td>`).join('')}</tr>` })}</div>
      <div class="grid g2"><div class="card"><div class="card-h"><h2>By location / depot</h2></div>${tbl({ rows: r.locations, compact: true, empty: 'None', cols: [{ label: 'Location', key: 'location' }, { label: 'Total', num: true, render: (l) => `<b>${l.total}</b>` }, { label: 'Empty', num: true, key: 'empty' }, { label: 'Laden', num: true, key: 'laden' }, { label: 'O.O.S.', num: true, key: 'out_of_service' },
          { label: 'Types', render: (l) => `<span class="small muted">${Object.entries(l.by_type).map(([t, n]) => `${esc(t)} ${n}`).join(' &middot; ')}</span>` }] })}</div>
        <div class="card"><div class="card-h"><h2>Idle empties</h2><span class="muted small">days since last movement</span></div><div class="card-b">${tbl({ compact: true, rows: [r.idle], cols: [{ label: '0-7', num: true, key: 'd0_7' }, { label: '8-14', num: true, key: 'd8_14' }, { label: '15-30', num: true, key: 'd15_30' }, { label: '31-60', num: true, key: 'd31_60' }, { label: '60+', num: true, render: (x) => x.d60_plus ? `<span class="neg">${x.d60_plus}</span>` : 0 }] })}</div>
          <div class="card-h" style="border-top:1px solid var(--line)"><h2>Free time alert</h2><span class="muted small">past or within 3 days of expiry</span></div>
          ${tbl({ rows: r.detention, compact: true, empty: 'No containers near the end of free time.', cols: [{ label: 'Container', render: (c) => link('#/containers/' + c.id, c.container_no) }, { label: 'Location', render: (c) => esc(c.location || '') }, { label: 'Free until', render: freeCell }] })}</div></div>
      <div class="card"><div class="card-h"><h2>Movements on ${date(r.date)}</h2><span class="muted small">${r.movements.length} recorded</span></div>${tbl({ rows: r.movements, compact: true, empty: 'No movements were recorded on this date.', cols: [
        { label: 'Container', render: (m) => `<b>${esc(m.container_no)}</b>` }, { label: 'Type', key: 'type_code' }, { label: 'Movement', key: 'label' }, { label: 'Location', render: (m) => esc(m.location || '') }, { label: 'Booking / HBL', render: (m) => esc([m.booking_no, m.hbl_no].filter(Boolean).join(' / ')) }, { label: 'Remarks', render: (m) => `<span class="small">${esc(m.remarks || '')}</span>` }] })}</div>
      <div class="card"><div class="card-h"><h2>Container list (${r.rows.length})</h2></div>${tbl({ rows: r.rows, compact: true, cols: [
        { label: 'Container', render: (c) => `<b>${esc(c.container_no)}</b>` }, { label: 'Type', key: 'type_code' }, { label: 'Own.', key: 'ownership' }, { label: 'Status', render: (c) => esc(c.status_label) }, { label: 'Location', render: (c) => esc(c.location || '') },
        { label: 'Since', render: (c) => `${date(c.last_date)} (${c.days_in_status}d)` }, { label: 'Booking / HBL', render: (c) => esc([c.booking_no, c.hbl_no].filter(Boolean).join(' / ')) }, { label: 'Free until', render: freeCell }] })}</div>`;
  }
  const rerender = () => draw().catch((e) => toast(e.message, 'bad'));
  on(root, 'click', '[data-act=prev]', () => { day = addDaysStr(day, -1); rerender(); });
  on(root, 'click', '[data-act=next]', () => { day = addDaysStr(day, 1); rerender(); });
  on(root, 'click', '[data-act=today]', () => { day = todayStr(); rerender(); });
  on(root, 'click', '[data-act=print]', () => window.print());
  on(root, 'click', '[data-act=xlsx]', () => download(`/reports/container-inventory?date=${day}&format=xlsx`));
  root.addEventListener('change', (e) => { if (e.target.matches('[data-date]') && e.target.value) { day = e.target.value; rerender(); } });
  wireShare(root, () => ({ kind: 'inventory', params: { date: day }, title: 'Share inventory report', what: `the container inventory report as at ${day}`, defaultSubject: `Container inventory report - ${day}` }));
  await draw();
}
