import { api, state, esc, $, $$, on, qs, tbl, pageHead, money, num, date, badge, docBadge, formModal, openModal, confirmBox, toast, opts, can, kv, link, go, debounce, signed, docType, todayStr, addDaysStr, download, balancesHtml } from '../core.js';
import { shareModal } from '../share.js';

const TYPES = [['INV', 'Invoice'], ['DN', 'Debit note'], ['CN', 'Credit note'], ['BILL', 'Vendor bill'], ['COMM', 'Agency commission']];
const partyRoleFor = { INV: 'customer', DN: null, CN: null, BILL: null, COMM: 'agent' };
const typeBadge = (t) => badge(docType(t), { INV: 'info', DN: 'info', CN: 'warn', BILL: 'warn', COMM: 'warn' }[t] || '');
const isDebit = (t) => t === 'INV' || t === 'DN';

// ================================================================== documents list
export async function documents(root, _p, query) {
  const canW = can('finance', 'write');
  const f = { side: query.side || '', type: '', status: query.status || '', party_id: '', q: '', from: '', to: '', open: query.open || '' };
  root.innerHTML = `${pageHead('Invoices & notes', 'Sales invoices, debit / credit notes and vendor bills', canW ? `<a class="btn primary" href="#/documents/new?type=INV">+ Invoice</a><a class="btn" href="#/documents/new?type=DN">+ Debit note</a><a class="btn" href="#/documents/new?type=CN">+ Credit note</a><a class="btn" href="#/documents/new?type=BILL">+ Vendor bill</a>` : '')}
    <div class="tabs">${[['', 'All'], ['receivable', 'Receivable (invoices, debit &amp; credit notes)'], ['payable', 'Payable (bills &amp; commission)']].map(([v, l]) => `<a data-side="${v}" class="${f.side === v ? 'on' : ''}">${l}</a>`).join('')}</div>
    <div class="toolbar"><input type="text" class="search" placeholder="Search number, party, shipment, reference…" data-f="q">
      <select data-f="type"><option value="">All types</option>${TYPES.map(([v, l]) => `<option value="${v}">${l}</option>`).join('')}</select>
      <select data-f="status"><option value="">Any status</option>${['DRAFT', 'POSTED', 'CANCELLED'].map((s) => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${s[0] + s.slice(1).toLowerCase()}</option>`).join('')}</select>
      <select data-f="party_id"><option value="">All parties</option>${opts.parties().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <label class="muted small">From <input type="date" data-f="from"></label><label class="muted small">to <input type="date" data-f="to"></label>
      <label class="muted small"><input type="checkbox" data-f="open" ${f.open ? 'checked' : ''}> Unpaid only</label></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/documents' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'No documents match.', rowAttr: (r) => `data-go="#/documents/${r.id}"`, cols: [
      { label: 'Document', render: (r) => `<b>${esc(r.doc_no || 'Draft')}</b><div class="muted small">${typeBadge(r.doc_type)}</div>` }, { label: 'Party', render: (r) => `${esc(r.party_name)}${r.party_ref ? `<div class="muted small">ref ${esc(r.party_ref)}</div>` : ''}` },
      { label: 'Date', render: (r) => date(r.doc_date) }, { label: 'Due', render: (r) => r.due_date ? `<span class="${r.overdue ? 'neg' : ''}">${date(r.due_date)}</span>` : '' }, { label: 'Shipment', render: (r) => esc(r.hbl_no || r.booking_no || '') },
      { label: 'Total', num: true, render: (r) => `${money(r.total)} <span class="muted small">${esc(r.currency)}</span>` },
      { label: 'Outstanding', num: true, render: (r) => r.outstanding == null ? '' : Math.abs(r.outstanding) < 0.005 ? '<span class="muted">paid</span>' : `<b class="${r.overdue ? 'neg' : ''}">${money(r.outstanding)}</b>` },
      { label: 'Status', render: (r) => docBadge(r.status) }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.type === 'checkbox' ? (e.target.checked ? '1' : '') : e.target.value; reload(); } });
  on(root, 'click', '[data-side]', (_e, el) => { f.side = el.dataset.side; $$('[data-side]', root).forEach((a) => a.classList.toggle('on', a === el)); load(); });
  await load();
}

// ================================================================== single document (view / editor)
export async function doc(root, { id }, query) {
  if (id === 'new') return editor(root, null, query);
  const d = await api('GET', `/documents/${id}`);
  if (query.edit === '1' && d.status === 'DRAFT') return editor(root, d, query);
  const canW = can('finance', 'write');
  const acts = [];
  if (canW && d.status === 'DRAFT') acts.push('<button class="btn primary" data-act="post">Post</button>', '<a class="btn" href="#/documents/' + id + '?edit=1">Edit</a>', '<button class="btn danger" data-act="del">Delete</button>');
  if (canW && d.status === 'POSTED') {
    if (d.outstanding > 0.004) acts.push(`<button class="btn primary" data-act="settle">${isDebit(d.doc_type) ? 'Record receipt' : d.doc_type === 'CN' ? 'Record refund' : 'Record payment'}</button>`, '<button class="btn" data-act="net">Net against another document</button>');
    acts.push('<button class="btn danger" data-act="cancel">Cancel</button>');
    if (d.doc_type === 'INV') acts.push(`<a class="btn" href="#/documents/new?type=CN&party_id=${d.party_id}&shipment_id=${d.shipment_id || ''}&currency=${d.currency}">Issue credit note</a>`);
  }
  acts.push(`<a class="btn" href="#/print/doc/${id}">Print</a>`);
  root.innerHTML = `${pageHead(`${esc(d.doc_no || 'Draft ' + d.label.toLowerCase())} ${docBadge(d.status)}`, `${esc(d.label)} &middot; ${link('#/parties/' + d.party_id, d.party_name)}`, acts.join(''), '<a href="#/documents">Documents</a> /')}
    ${d.status === 'POSTED' && d.outstanding != null ? `<div class="alert ${d.outstanding < 0.005 ? 'ok' : new Date(d.due_date) < new Date(todayStr()) ? 'bad' : 'info'}">${d.outstanding < 0.005 ? 'Fully settled.' : `<b>${money(d.outstanding)} ${esc(d.currency)}</b> outstanding${d.due_date ? `, due ${date(d.due_date)}` : ''}.`}</div>` : ''}
    <div class="grid g2"><div class="card"><div class="card-h"><h2>Details</h2></div><div class="card-b">${kv([['Party', link('#/parties/' + d.party_id, d.party_name)], ['Document date', date(d.doc_date)], ['Due date', date(d.due_date)], ['Currency', esc(d.currency)],
      d.currency !== state.lk.settings.base_currency ? ['Exchange rate', `1 ${esc(d.currency)} = ${num(d.fx_rate)} ${esc(state.lk.settings.base_currency)}`] : null, [d.doc_type === 'BILL' ? 'Vendor invoice no.' : 'Reference', esc(d.party_ref)], ['Narration', esc(d.narration)]])}</div></div>
      <div class="card"><div class="card-h"><h2>Shipment</h2></div><div class="card-b">${d.shipment_id ? kv([['Booking', link('#/shipments/' + d.shipment_id, d.booking_no)], ['HBL', esc(d.hbl_no)], ['Route', `${esc(d.pol_name || '?')} &rarr; ${esc(d.pod_name || '?')}`], ['Vessel / voyage', esc([d.vessel, d.voyage].filter(Boolean).join(' / '))], ['Goods', esc(d.shipment_commodity)]]) : '<span class="muted">Not linked to a shipment.</span>'}</div></div></div>
    <div class="card"><div class="card-h"><h2>Lines</h2></div>${tbl({ rows: d.lines, compact: true, cols: [{ label: 'Charge', render: (l) => esc(l.charge_code || '') }, { label: 'Description', key: 'description' }, { label: 'Qty', num: true, render: (l) => num(l.qty) }, { label: 'Rate', num: true, render: (l) => money(l.rate) },
      { label: 'Amount', num: true, render: (l) => money(l.amount) }, { label: 'VAT %', num: true, render: (l) => num(l.vat_rate) }, { label: 'VAT', num: true, render: (l) => money(l.vat_amount) }],
      foot: `<tr><td colspan="4"></td><td class="num">${money(d.subtotal)}</td><td>Subtotal</td><td></td></tr><tr><td colspan="4"></td><td class="num"></td><td>VAT</td><td class="num">${money(d.vat_amount)}</td></tr><tr><td colspan="4"></td><td class="num" colspan="3"><b>Total ${money(d.total)} ${esc(d.currency)}</b></td></tr>` })}</div>
    ${d.allocations.length ? `<div class="card"><div class="card-h"><h2>Settlements applied</h2></div>${tbl({ rows: d.allocations, compact: true, cols: [{ label: 'Date', render: (a) => date(a.alloc_date) }, { label: 'Applied', render: (a) => a.to_ref ? `This document settled ${esc(a.to_ref)}` : `${esc(a.from_type === 'PAYMENT' ? 'Payment' : 'Document')} ${esc(a.from_ref || '')}` }, { label: 'Amount', num: true, render: (a) => `${money(a.amount)} ${esc(a.currency)}` },
      ...(canW ? [{ label: '', render: (a) => `<button class="btn sm ghost" data-unalloc="${a.id}">Remove</button>` }] : [])] })}</div>` : ''}`;
  const refresh = () => go(`#/documents/${id}`);
  const guard = async (fn, msg, back) => { try { await fn(); if (msg) toast(msg, 'ok'); back ? go(back) : refresh(); } catch (e) { toast(e.message, 'bad'); } };
  on(root, 'click', '[data-act=post]', async () => { if (await confirmBox('Post this document? It gets its number and appears on statements of account. Posted documents cannot be edited.', { ok: 'Post' })) guard(async () => { const r = await api('POST', `/documents/${id}/post`); toast(`Posted as ${r.doc_no}`, 'ok'); }); });
  on(root, 'click', '[data-act=del]', async () => { if (await confirmBox('Delete this draft?', { danger: true, ok: 'Delete' })) guard(() => api('DELETE', `/documents/${id}`), 'Draft deleted', '#/documents'); });
  on(root, 'click', '[data-act=cancel]', async () => {
    const r = await formModal({ title: `Cancel ${d.doc_no}`, size: 'narrow', submitLabel: 'Cancel document', intro: '<p class="muted">The document is removed from the party\'s statement. If it has been paid or netted, cancel those settlements first.</p>', fields: [{ name: 'reason', label: 'Reason', span: 4, required: true }], onSubmit: (v) => api('POST', `/documents/${id}/cancel`, v) });
    if (r) { toast('Document cancelled', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-act=settle]', async () => { const r = await paymentModal({ direction: isDebit(d.doc_type) ? 'RECEIPT' : 'PAYMENT', party_id: d.party_id, currency: d.currency, doc_id: d.id }); if (r) { toast('Recorded', 'ok'); refresh(); } });
  on(root, 'click', '[data-act=net]', async () => {
    const items = (await api('GET', `/parties/${d.party_id}/open-items?currency=${d.currency}`)).filter((o) => o.kind === 'DOC' && o.id !== d.id && isDebit(o.type) !== isDebit(d.doc_type));
    if (!items.length) return toast('No opposite documents to net against for this party and currency.', 'bad');
    const max = (x) => Math.min(x.outstanding, d.outstanding);
    const r = await formModal({ title: `Net ${d.doc_no}`, size: 'narrow', submitLabel: 'Net', intro: `<p class="muted">Offset this document (${money(d.outstanding)} ${esc(d.currency)} outstanding) against an opposite document for the same party.</p>`,
      fields: [{ name: 'other', label: 'Net against', type: 'select', noEmpty: true, required: true, options: items.map((x) => [x.id, `${x.ref} - ${money(x.outstanding)} ${x.currency} outstanding`]), span: 4 }, { name: 'amount', label: 'Amount', type: 'number', required: true, min: 0, span: 2 }, { name: 'date', label: 'Date', type: 'date', span: 2 }],
      values: { date: todayStr(), amount: max(items[0]) }, onSubmit: (v) => { const dr = isDebit(d.doc_type); return api('POST', '/allocations/net', { from_doc_id: dr ? Number(v.other) : d.id, to_doc_id: dr ? d.id : Number(v.other), amount: v.amount, date: v.date }); } });
    if (r) { toast('Netted', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-unalloc]', async (_e, el) => { if (await confirmBox('Remove this settlement? The amount becomes outstanding again.', { danger: true, ok: 'Remove' })) guard(() => api('DELETE', `/allocations/${el.dataset.unalloc}`), 'Removed'); });
}

// ================================================================== editor
async function editor(root, d, query) {
  const type = d ? d.doc_type : (query.type || 'INV');
  const shipments = await api('GET', '/shipments?limit=800');
  const shipOpts = shipments.map((s) => [s.id, `${s.booking_no}${s.hbl_no ? ' / ' + s.hbl_no : ''} - ${s.customer_name || '?'} (${s.pol_name || '?'} > ${s.pod_name || '?'})`]);
  const partyOpts = opts.parties(partyRoleFor[type]);
  const chargeOpts = state.lk.charge_codes;
  const cur0 = d ? d.currency : (query.currency || (query.party_id ? (state.lk.parties.find((p) => p.id === Number(query.party_id)) || {}).currency : '') || 'USD');
  const lines0 = d ? d.lines : [{ description: '', qty: 1, rate: '', vat_rate: 0 }];
  const label = d ? d.label : TYPES.find(([t]) => t === type)[1];
  root.innerHTML = `${pageHead(d ? `Edit draft ${esc(label.toLowerCase())}` : `New ${esc(label.toLowerCase())}`, isDebit(type) ? 'Increases what the party owes us' : 'Reduces what the party owes us / increases what we owe', '', '<a href="#/documents">Documents</a> /')}
    <div class="alert bad hidden" data-err></div>
    <div class="card"><div class="card-b"><div class="form-grid" data-head>
      <label class="f s2"><span>${type === 'BILL' ? 'Vendor / supplier' : type === 'COMM' ? 'Agent' : 'Customer / party'} <b class="req">*</b></span><input type="text" name="party" list="dl_party" autocomplete="off" placeholder="Type to search…"><datalist id="dl_party">${partyOpts.map(([, t]) => `<option value="${esc(t)}">`).join('')}</datalist></label>
      <label class="f s2"><span>Shipment <em class="hint">(optional - needed for shipment profit)</em></span><input type="text" name="shipment" list="dl_ship" autocomplete="off" placeholder="Booking / HBL / customer…"><datalist id="dl_ship">${shipOpts.map(([, t]) => `<option value="${esc(t)}">`).join('')}</datalist></label>
      <label class="f"><span>Document date</span><input type="date" name="doc_date" value="${esc(d ? d.doc_date : todayStr())}"></label>
      <label class="f"><span>Due date <em class="hint">(blank = automatic)</em></span><input type="date" name="due_date" value="${esc(d ? d.due_date || '' : '')}"></label>
      <label class="f"><span>Currency</span><select name="currency">${opts.currencies().map(([v]) => `<option ${v === cur0 ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
      <label class="f"><span>${type === 'BILL' ? 'Vendor invoice no.' : 'Reference'}</span><input type="text" name="party_ref" value="${esc(d ? d.party_ref || '' : '')}"></label>
      <label class="f s4"><span>Narration</span><input type="text" name="narration" value="${esc(d ? d.narration || '' : '')}"></label></div></div></div>
    <div class="card"><div class="card-h"><h2>Lines</h2><button class="btn sm" data-act="suggest" title="Fill from the tariff for the chosen shipment">Fill from tariff</button><button class="btn sm" data-act="addline">+ Add line</button></div>
      <div class="tbl-wrap"><table class="t compact"><thead><tr><th style="width:24%">Charge</th><th>Description</th><th class="num" style="width:90px">Qty</th><th class="num" style="width:120px">Rate</th><th class="num" style="width:80px">VAT %</th><th class="num" style="width:120px">Amount</th><th></th></tr></thead><tbody data-lines></tbody></table></div>
      <div class="card-b" style="display:flex;justify-content:flex-end"><table style="min-width:280px"><tr><td class="muted">Subtotal</td><td class="num" data-sub></td></tr><tr><td class="muted">VAT</td><td class="num" data-vat></td></tr><tr><td><b>Total</b></td><td class="num" data-tot style="font-size:18px;font-weight:700"></td></tr></table></div></div>
    <div class="toolbar"><button class="btn primary" data-act="save" data-post="1">Save &amp; post</button><button class="btn" data-act="save">Save as draft</button><a class="btn ghost" href="${d ? '#/documents/' + d.id : '#/documents'}">Cancel</a></div>`;
  const head = $('[data-head]', root), body = $('[data-lines]', root), err = $('[data-err]', root);
  const partyLabel = (id) => (partyOpts.find(([v]) => String(v) === String(id)) || [, ''])[1];
  if (d) { head.querySelector('[name=party]').value = partyLabel(d.party_id); const s = shipOpts.find(([v]) => v === d.shipment_id); if (s) head.querySelector('[name=shipment]').value = s[1]; }
  else {
    if (query.party_id) head.querySelector('[name=party]').value = partyLabel(query.party_id);
    if (query.shipment_id) { const s = shipOpts.find(([v]) => String(v) === String(query.shipment_id)); if (s) head.querySelector('[name=shipment]').value = s[1]; }
  }
  // Choosing a shipment on a customer document pre-fills the billing customer when the party is still blank.
  const fillPartyFromShipment = () => {
    if (type !== 'INV' && type !== 'DN' && type !== 'CN') return;
    const pf = head.querySelector('[name=party]'); if (pf.value.trim()) return;
    const sh = shipments.find((s) => shipOpts.some(([v, l]) => v === s.id && l === head.querySelector('[name=shipment]').value.trim()));
    if (sh && sh.customer_id) pf.value = partyLabel(sh.customer_id);
  };
  if (!d) fillPartyFromShipment();
  head.querySelector('[name=shipment]').addEventListener('change', fillPartyFromShipment);
  const lineRow = (l) => `<tr data-line><td><select name="charge"><option value="">—</option>${chargeOpts.map((c) => `<option value="${c.id}" data-vat="${c.vat_rate}" data-name="${esc(c.name)}" ${String(c.id) === String(l.charge_code_id) ? 'selected' : ''}>${esc(c.code)} - ${esc(c.name)}</option>`).join('')}</select></td>
    <td><input type="text" name="description" value="${esc(l.description || '')}"></td><td><input type="number" step="any" min="0" name="qty" value="${l.qty ?? 1}" class="num"></td><td><input type="number" step="any" min="0" name="rate" value="${l.rate ?? ''}" class="num"></td>
    <td><input type="number" step="any" min="0" max="100" name="vat" value="${l.vat_rate ?? 0}" class="num"></td><td class="num" data-amt></td><td><button class="btn sm ghost" data-rmline title="Remove line">&#10005;</button></td></tr>`;
  lines0.forEach((l) => body.insertAdjacentHTML('beforeend', lineRow(l)));
  const totals = () => {
    let sub = 0, vat = 0;
    $$('[data-line]', body).forEach((tr) => { const q = Number(tr.querySelector('[name=qty]').value) || 0, r = Number(tr.querySelector('[name=rate]').value) || 0, v = Number(tr.querySelector('[name=vat]').value) || 0; const a = Math.round(q * r * 100) / 100; sub += a; vat += Math.round(a * v) / 100; tr.querySelector('[data-amt]').textContent = money(a); });
    $('[data-sub]', root).textContent = money(sub); $('[data-vat]', root).textContent = money(vat); $('[data-tot]', root).textContent = money(sub + vat);
  };
  totals();
  body.addEventListener('input', totals);
  body.addEventListener('change', (e) => { if (e.target.name === 'charge') { const o = e.target.selectedOptions[0]; const tr = e.target.closest('tr'); if (o && o.value) { const desc = tr.querySelector('[name=description]'); if (!desc.value) desc.value = o.dataset.name; tr.querySelector('[name=vat]').value = o.dataset.vat; totals(); } } });
  on(root, 'click', '[data-act=addline]', () => { body.insertAdjacentHTML('beforeend', lineRow({ qty: 1, vat_rate: 0 })); totals(); });
  on(root, 'click', '[data-rmline]', (_e, el) => { if ($$('[data-line]', body).length > 1) { el.closest('tr').remove(); totals(); } });
  const shipId = () => { const t = head.querySelector('[name=shipment]').value.trim(); if (!t) return ''; const m = shipOpts.find(([, l]) => l === t); if (!m) throw new Error('Choose the shipment from the suggestions, or clear the field.'); return m[0]; };
  on(root, 'click', '[data-act=suggest]', async () => {
    try {
      const sid = shipId(); if (!sid) throw new Error('Choose a shipment first.');
      const lines = await api('GET', `/documents/suggest?shipment_id=${sid}&rate_type=${type === 'BILL' ? 'BUY' : 'SELL'}&currency=${head.querySelector('[name=currency]').value}`);
      if (!lines.length) return toast('No matching tariff found for this shipment\'s route, cargo and container types.', 'bad');
      if ($$('[data-line]', body).every((tr) => !tr.querySelector('[name=description]').value && !tr.querySelector('[name=rate]').value)) body.innerHTML = '';
      lines.forEach((l) => body.insertAdjacentHTML('beforeend', lineRow(l))); totals(); toast(`${lines.length} line(s) added from the tariff - review before saving`, 'ok');
    } catch (e) { toast(e.message, 'bad'); }
  });
  on(root, 'click', '[data-act=save]', async (_e, el) => {
    err.classList.add('hidden');
    try {
      const pt = head.querySelector('[name=party]').value.trim(); const pm = partyOpts.find(([, l]) => l === pt);
      if (!pm) throw new Error(`Choose the ${type === 'BILL' ? 'vendor' : 'party'} from the suggestions.`);
      const payload = { doc_type: type, party_id: pm[0], shipment_id: shipId() || null, doc_date: head.querySelector('[name=doc_date]').value, due_date: head.querySelector('[name=due_date]').value || null, currency: head.querySelector('[name=currency]').value,
        party_ref: head.querySelector('[name=party_ref]').value, narration: head.querySelector('[name=narration]').value,
        lines: $$('[data-line]', body).map((tr) => ({ charge_code_id: tr.querySelector('[name=charge]').value || null, description: tr.querySelector('[name=description]').value, qty: tr.querySelector('[name=qty]').value, rate: tr.querySelector('[name=rate]').value, vat_rate: tr.querySelector('[name=vat]').value })) };
      el.disabled = true;
      let docId = d ? d.id : null;
      if (d) await api('PUT', `/documents/${d.id}`, payload); else docId = (await api('POST', '/documents', payload)).id;
      if (el.dataset.post) { const r = await api('POST', `/documents/${docId}/post`); toast(`Posted as ${r.doc_no}`, 'ok'); } else toast('Draft saved', 'ok');
      go(`#/documents/${docId}`);
    } catch (e) { err.textContent = e.message; err.classList.remove('hidden'); window.scrollTo(0, 0); el.disabled = false; }
  });
}

// ================================================================== payments
export async function payments(root, _p, query) {
  const canW = can('finance', 'write');
  const f = { direction: query.direction || '', q: '' };
  root.innerHTML = `${pageHead('Receipts & payments', 'Money received from customers and agents, and paid to vendors and carriers', canW ? '<button class="btn primary" data-new="RECEIPT">+ Receipt</button><button class="btn" data-new="PAYMENT">+ Payment</button>' : '')}
    <div class="tabs">${[['', 'All'], ['RECEIPT', 'Receipts'], ['PAYMENT', 'Payments']].map(([v, l]) => `<a data-dir="${v}" class="${f.direction === v ? 'on' : ''}">${l}</a>`).join('')}</div>
    <div class="toolbar"><input type="text" class="search" placeholder="Search number, party, reference…" data-f="q"></div><div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  let rows = [];
  const load = async () => {
    rows = await api('GET', '/payments' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'Nothing recorded yet.', rowAttr: (r) => `data-pay="${r.id}"`, cols: [
      { label: 'Number', render: (r) => `<b>${esc(r.pay_no)}</b><div class="muted small">${r.direction === 'RECEIPT' ? 'Receipt' : 'Payment'}</div>` }, { label: 'Date', render: (r) => date(r.pay_date) }, { label: 'Party', key: 'party_name' },
      { label: 'Method / reference', render: (r) => esc([r.method, r.reference].filter(Boolean).join(' / ')) }, { label: 'Amount', num: true, render: (r) => `<b>${money(r.amount)}</b> ${esc(r.currency)}` },
      { label: 'Unapplied', num: true, render: (r) => r.status === 'CANCELLED' ? '' : r.unallocated > 0.004 ? `<span class="badge warn">${money(r.unallocated)}</span>` : '<span class="muted">—</span>' },
      { label: 'Status', render: (r) => r.status === 'CANCELLED' ? badge('Cancelled', 'bad') : badge('Posted', 'ok') }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { if (e.target.dataset.f) { f.q = e.target.value; reload(); } });
  on(root, 'click', '[data-dir]', (_e, el) => { f.direction = el.dataset.dir; $$('[data-dir]', root).forEach((a) => a.classList.toggle('on', a === el)); load(); });
  on(root, 'click', '[data-new]', async (_e, el) => { const r = await paymentModal({ direction: el.dataset.new }); if (r) { toast(`${r.pay_no} recorded`, 'ok'); load(); } });
  on(root, 'click', '[data-pay]', async (e, el) => { if (e.target.closest('a')) return; if (await viewPayment(el.dataset.pay)) load(); });
  await load();
}

async function viewPayment(id) {
  const p = await api('GET', `/payments/${id}`);
  const canW = can('finance', 'write');
  const h = openModal({ title: `${p.pay_no} - ${p.direction === 'RECEIPT' ? 'Receipt' : 'Payment'}`, size: '', body: `${p.status === 'CANCELLED' ? '<div class="alert bad">Cancelled</div>' : ''}${kv([['Party', esc(p.party_name)], ['Date', date(p.pay_date)], ['Amount', `<b>${money(p.amount)} ${esc(p.currency)}</b>`], ['Method', esc(p.method)], ['Reference', esc(p.reference)], ['Bank', esc(p.bank)], ['Narration', esc(p.narration)], ['Unapplied', money(p.unallocated)]])}
    <h3 style="margin:14px 0 6px">Applied to</h3>${tbl({ rows: p.allocations, compact: true, empty: 'Not applied to any document yet.', cols: [{ label: 'Document', render: (a) => link('#/documents/' + a.to_doc_id, a.doc_no) }, { label: 'Date', render: (a) => date(a.alloc_date) }, { label: 'Amount', num: true, render: (a) => money(a.amount) }] })}`,
    footer: `<button class="btn" data-close>Close</button>${canW && p.status === 'POSTED' && p.unallocated > 0.004 ? '<button class="btn primary" data-alloc>Apply to documents</button>' : ''}${canW && p.status === 'POSTED' ? '<button class="btn danger" data-cancel>Cancel</button>' : ''}` });
  let changed = false;
  h.el.addEventListener('click', async (e) => {
    if (e.target.closest('[data-alloc]')) { h.close(); const r = await paymentModal({ existing: p }); if (r) { toast('Applied', 'ok'); } return; }
    if (e.target.closest('[data-cancel]')) {
      const reason = await formModal({ title: `Cancel ${p.pay_no}`, size: 'narrow', submitLabel: 'Cancel it', intro: '<p class="muted">All applications to invoices/bills are removed and those documents become outstanding again.</p>', fields: [{ name: 'reason', label: 'Reason', required: true, span: 4 }], onSubmit: (v) => api('POST', `/payments/${id}/cancel`, v) });
      if (reason) { changed = true; toast('Cancelled', 'ok'); h.close(true); }
    }
  });
  const res = await h.done;
  return res || changed;
}

// Receipt / payment dialog with allocation table. existing = a payment to apply further.
export async function paymentModal({ direction, party_id, currency, doc_id, existing } = {}) {
  const ex = existing || null;
  direction = ex ? ex.direction : direction;
  const canParties = opts.parties();
  const h = openModal({ title: ex ? `Apply ${ex.pay_no}` : direction === 'RECEIPT' ? 'New receipt (money in)' : 'New payment (money out)', size: 'wide',
    body: `<div class="alert bad hidden" data-err></div><div class="form-grid" data-head>
      <label class="f s2"><span>${direction === 'RECEIPT' ? 'Received from' : 'Paid to'} <b class="req">*</b></span><input type="text" name="party" list="dl_pp" autocomplete="off" ${ex ? 'disabled' : ''}><datalist id="dl_pp">${canParties.map(([, t]) => `<option value="${esc(t)}">`).join('')}</datalist></label>
      <label class="f"><span>Date</span><input type="date" name="pay_date" value="${todayStr()}"></label>
      <label class="f"><span>Currency</span><select name="currency" ${ex ? 'disabled' : ''}>${opts.currencies().map(([v]) => `<option>${v}</option>`).join('')}</select></label>
      <label class="f"><span>${ex ? 'Available to apply' : 'Amount'} <b class="req">*</b></span><input type="number" step="any" min="0" name="amount" ${ex ? 'disabled' : ''}></label>
      <label class="f"><span>Method</span><input type="text" name="method" list="dl_m" placeholder="Bank transfer" ${ex ? 'disabled' : ''}><datalist id="dl_m"><option>Bank transfer</option><option>Cheque</option><option>Cash</option><option>Card</option><option>Set-off</option></datalist></label>
      <label class="f"><span>Reference / cheque no.</span><input type="text" name="reference" ${ex ? 'disabled' : ''}></label><label class="f s2"><span>Bank</span><input type="text" name="bank" ${ex ? 'disabled' : ''}></label>
      <label class="f s4"><span>Narration</span><input type="text" name="narration" ${ex ? 'disabled' : ''}></label></div>
      <h3 style="margin:16px 0 6px">Apply to ${direction === 'RECEIPT' ? 'invoices & debit notes' : 'bills, commission & credit notes'}</h3><div data-open class="muted">Choose a party first.</div>
      <div class="toolbar" style="margin-top:8px"><button class="btn sm" data-auto type="button">Apply oldest first</button><span class="grow"></span><span data-summary class="muted"></span></div>`,
    footer: `<button class="btn" data-close>Cancel</button><button class="btn primary" data-save>${ex ? 'Apply' : 'Record'}</button>` });
  const head = h.$('[data-head]'), err = h.$('[data-err]'), openBox = h.$('[data-open]');
  let items = [], partyId = null;
  const partyByLabel = (t) => (canParties.find(([, l]) => l === t) || [])[0];
  const avail = () => (ex ? ex.unallocated : Number(head.querySelector('[name=amount]').value) || 0);
  const summary = () => {
    const applied = h.$$('[data-alloc]').reduce((a, i) => a + (Number(i.value) || 0), 0);
    h.$('[data-summary]').innerHTML = `Applied <b>${money(applied)}</b> of ${money(avail())} &middot; unapplied ${money(avail() - applied)}`;
    h.$('[data-summary]').className = avail() - applied < -0.005 ? 'neg' : 'muted';
  };
  async function loadItems() {
    const cur = head.querySelector('[name=currency]').value;
    if (!partyId) { openBox.innerHTML = 'Choose a party first.'; return; }
    const all = await api('GET', `/parties/${partyId}/open-items?currency=${cur}`);
    items = all.filter((o) => o.kind === 'DOC' && (direction === 'RECEIPT' ? o.signed > 0 : o.signed < 0)).sort((a, b) => a.date.localeCompare(b.date));
    openBox.innerHTML = tbl({ rows: items, compact: true, empty: `No open ${direction === 'RECEIPT' ? 'invoices or debit notes' : 'bills or credit notes'} in ${cur} for this party - the amount will be kept as unapplied.`, cols: [
      { label: 'Document', render: (o) => `<b>${esc(o.ref)}</b><div class="muted small">${esc(o.shipment || o.description || '')}</div>` }, { label: 'Date', render: (o) => date(o.date) }, { label: 'Due', render: (o) => date(o.due_date) },
      { label: 'Outstanding', num: true, render: (o) => money(o.outstanding) }, { label: 'Apply', num: true, render: (o) => `<input type="number" step="any" min="0" max="${o.outstanding}" data-alloc data-doc="${o.id}" data-out="${o.outstanding}" style="width:120px;text-align:right">` }] });
    summary();
  }
  head.querySelector('[name=party]').addEventListener('change', async (e) => { partyId = partyByLabel(e.target.value.trim()) || null; if (partyId) { const p = state.lk.parties.find((x) => x.id === partyId); if (!existing && p) head.querySelector('[name=currency]').value = p.currency; } loadItems(); });
  head.querySelector('[name=currency]').addEventListener('change', loadItems);
  head.querySelector('[name=amount]').addEventListener('input', summary);
  h.el.addEventListener('input', (e) => { if (e.target.matches('[data-alloc]')) summary(); });
  h.$('[data-auto]').addEventListener('click', () => { let left = avail(); h.$$('[data-alloc]').forEach((i) => { const a = Math.min(left, Number(i.dataset.out)); i.value = a > 0 ? Math.round(a * 100) / 100 : ''; left -= a > 0 ? a : 0; }); summary(); });
  if (ex) { partyId = ex.party_id; head.querySelector('[name=party]').value = (canParties.find(([v]) => v === ex.party_id) || [, ''])[1]; head.querySelector('[name=currency]').value = ex.currency; head.querySelector('[name=amount]').value = ex.unallocated; }
  else if (party_id) { partyId = party_id; head.querySelector('[name=party]').value = (canParties.find(([v]) => v === party_id) || [, ''])[1]; if (currency) head.querySelector('[name=currency]').value = currency; }
  await loadItems();
  if (doc_id) { const i = h.$$('[data-alloc]').find((x) => Number(x.dataset.doc) === doc_id); if (i) { i.value = i.dataset.out; head.querySelector('[name=amount]').value = i.dataset.out; summary(); } }
  h.$('[data-save]').addEventListener('click', async () => {
    err.classList.add('hidden');
    const btn = h.$('[data-save]'); btn.disabled = true;
    try {
      if (!partyId) throw new Error('Choose the party from the suggestions.');
      const allocations = h.$$('[data-alloc]').filter((i) => Number(i.value) > 0).map((i) => ({ doc_id: Number(i.dataset.doc), amount: Number(i.value) }));
      let r;
      if (ex) { if (!allocations.length) throw new Error('Enter an amount against at least one document.'); await api('POST', `/payments/${ex.id}/allocate`, { allocations, date: head.querySelector('[name=pay_date]').value }); r = { ok: true }; }
      else r = await api('POST', '/payments', { direction, party_id: partyId, pay_date: head.querySelector('[name=pay_date]').value, currency: head.querySelector('[name=currency]').value, amount: head.querySelector('[name=amount]').value,
        method: head.querySelector('[name=method]').value, reference: head.querySelector('[name=reference]').value, bank: head.querySelector('[name=bank]').value, narration: head.querySelector('[name=narration]').value, allocations });
      h.close(r);
    } catch (e) { err.textContent = e.message; err.classList.remove('hidden'); btn.disabled = false; }
  });
  return h.done;
}

// ================================================================== statement of account
export async function soa(root, _p, query) {
  const s = { party_id: query.party_id || '', from: query.from || addDaysStr(todayStr(), -90), to: query.to || todayStr(), mode: query.mode || 'ledger', currency: '' };
  const parties = opts.parties();
  root.innerHTML = `${pageHead('Statement of account', 'Ledger or open-item statement for any customer, agent, vendor or carrier')}
    <div class="card no-print"><div class="card-b"><div class="form-grid">
      <label class="f s2"><span>Party</span><input type="text" data-p list="dl_soa" autocomplete="off" placeholder="Type to search…"><datalist id="dl_soa">${parties.map(([, t]) => `<option value="${esc(t)}">`).join('')}</datalist></label>
      <label class="f"><span>Statement type</span><select data-f="mode"><option value="ledger" ${s.mode === 'ledger' ? 'selected' : ''}>Full ledger</option><option value="open" ${s.mode === 'open' ? 'selected' : ''}>Open items only</option></select></label>
      <label class="f"><span>Currency</span><select data-f="currency"><option value="">All</option>${opts.currencies().map(([v]) => `<option>${v}</option>`).join('')}</select></label>
      <label class="f" data-fromwrap><span>From</span><input type="date" data-f="from" value="${s.from}"></label><label class="f"><span>To / as at</span><input type="date" data-f="to" value="${s.to}"></label></div></div></div>
    <div data-out></div>`;
  const out = $('[data-out]', root);
  const partyBox = $('[data-p]', root);
  const pre = parties.find(([v]) => String(v) === String(s.party_id)); if (pre) partyBox.value = pre[1];
  async function load() {
    if (!s.party_id) { out.innerHTML = '<div class="empty">Choose a party to see the statement.</div>'; return; }
    $('[data-fromwrap]', root).classList.toggle('hidden', s.mode === 'open');
    const r = await api('GET', '/soa' + qs({ party_id: s.party_id, from: s.from, to: s.to, mode: s.mode, currency: s.currency }));
    out.innerHTML = `<div class="toolbar"><span class="grow"><b>${esc(r.party.name)}</b> <span class="muted">${esc(r.party.code)} &middot; credit ${r.party.credit_days} days</span></span><a class="btn" href="#/print/soa/${s.party_id}${qs({ from: s.from, to: s.to, mode: s.mode, currency: s.currency })}">Print</a><button class="btn" data-x>Export Excel</button></div>
      ${r.currencies.length ? r.currencies.map((c) => `<div class="card"><div class="card-h"><h2>${esc(c.currency)}</h2><span>${s.mode === 'ledger' ? `Opening <b>${signed(c.opening)}</b> &middot; ` : ''}Closing balance <b style="font-size:16px">${signed(c.closing)}</b></span></div>
        ${tbl({ rows: c.rows, compact: true, empty: 'No transactions.', cols: [{ label: 'Date', render: (x) => date(x.date) }, { label: 'Document', render: (x) => x.kind === 'DOC' ? link('#/documents/' + x.id, x.ref) : esc(x.ref) }, { label: 'Type', render: (x) => esc(x.type) },
          { label: 'Shipment', render: (x) => esc(x.shipment || '') }, { label: 'Description', render: (x) => `<span class="small">${esc(x.description || '')}</span>` }, { label: 'Due', render: (x) => date(x.due_date) },
          { label: 'Debit', num: true, render: (x) => x.debit ? money(x.debit) : '' }, { label: 'Credit', num: true, render: (x) => x.credit ? money(x.credit) : '' }, { label: 'Balance', num: true, render: (x) => signed(x.balance) }],
          foot: `<tr><td colspan="6">Totals</td><td class="num">${money(c.total_debit)}</td><td class="num">${money(c.total_credit)}</td><td class="num">${signed(c.closing)}</td></tr>` })}
        <div class="card-b" style="border-top:1px solid var(--line)"><div class="muted small" style="margin-bottom:4px">Ageing of open balance as at ${date(r.to)}</div>${ageingTable(c.ageing)}</div></div>`).join('') : '<div class="empty">No transactions or balance for this party in the selected period.</div>'}`;
  }
  const run = () => load().catch((e) => { out.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; });
  partyBox.addEventListener('change', () => { const m = parties.find(([, l]) => l === partyBox.value.trim()); s.party_id = m ? m[0] : ''; run(); });
  root.addEventListener('change', (e) => { const k = e.target.dataset.f; if (k) { s[k] = e.target.value; run(); } });
  on(root, 'click', '[data-x]', () => download('/soa' + qs({ party_id: s.party_id, from: s.from, to: s.to, mode: s.mode, currency: s.currency, format: 'xlsx' })));
  await run();
}
export const ageingTable = (a) => `<div class="tbl-wrap"><table class="t compact"><thead><tr><th class="num">Not due</th><th class="num">1-30</th><th class="num">31-60</th><th class="num">61-90</th><th class="num">90+</th><th class="num">Unapplied</th><th class="num">Net</th></tr></thead><tbody><tr>${['not_due', 'd1_30', 'd31_60', 'd61_90', 'd90_plus', 'unapplied', 'total'].map((k) => `<td class="num">${signed(a[k])}</td>`).join('')}</tr></tbody></table></div>`;

// ================================================================== ageing
export async function ageing(root) {
  const s = { to: todayStr(), currency: '', role: '' };
  root.innerHTML = `${pageHead('Ageing of balances', 'Who owes us, who we owe, and how overdue it is', `<button class="btn" data-act="share">Share (Excel / PDF / e-mail)</button><button class="btn" data-x>Export Excel</button>`)}
    <div class="toolbar"><label class="muted small">As at <input type="date" data-f="to" value="${s.to}"></label><select data-f="currency"><option value="">All currencies</option>${opts.currencies().map(([v]) => `<option>${v}</option>`).join('')}</select>
      <select data-f="role"><option value="">All parties</option><option value="customer">Customers</option><option value="agent">Agents</option><option value="vendor">Vendors</option><option value="carrier">Carriers</option></select></div>
    <div class="alert info no-print">Positive amounts are owed <b>to us</b>; negative (in brackets) are owed <b>by us</b>. Buckets count days past the due date.</div><div data-out></div>`;
  const out = $('[data-out]', root);
  const cols = [['not_due', 'Not due'], ['d1_30', '1-30'], ['d31_60', '31-60'], ['d61_90', '61-90'], ['d90_plus', '90+'], ['unapplied', 'Unapplied'], ['total', 'Net balance']];
  const load = async () => {
    const r = await api('GET', '/reports/ageing' + qs(s));
    out.innerHTML = r.totals.map((t) => `<div class="card"><div class="card-h"><h2>${esc(t.currency)}</h2><span class="muted">${r.rows.filter((x) => x.currency === t.currency).length} parties</span></div>${tbl({ rows: r.rows.filter((x) => x.currency === t.currency), click: true, rowAttr: (x) => `data-go="#/soa?party_id=${x.party_id}&mode=open"`,
      cols: [{ label: 'Party', render: (x) => `<b>${esc(x.party_name)}</b><div class="muted small mono">${esc(x.party_code)}</div>` }, ...cols.map(([k, l]) => ({ label: l, num: true, render: (x) => signed(x[k]) }))],
      foot: `<tr><td>Total ${esc(t.currency)}</td>${cols.map(([k]) => `<td class="num">${signed(t[k])}</td>`).join('')}</tr>` })}</div>`).join('') || '<div class="empty">No open balances.</div>';
  };
  root.addEventListener('change', (e) => { const k = e.target.dataset.f; if (k) { s[k] = e.target.value; load().catch((x) => toast(x.message, 'bad')); } });
  on(root, 'click', '[data-x]', () => download('/reports/ageing' + qs({ ...s, format: 'xlsx' })));
  on(root, 'click', '[data-act=share]', () => shareModal({ kind: 'ageing', params: { to: s.to, currency: s.currency, role: s.role }, title: 'Share ageing report', what: 'the ageing of balances', defaultSubject: `Ageing of balances - ${s.to}` }));
  await load();
}
