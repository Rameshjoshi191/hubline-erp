import { api, state, esc, $, on, qs, tbl, pageHead, money, num, date, shipBadge, badge, toast, opts, can, link, signed, todayStr, addDaysStr, download, debounce } from '../core.js';

export async function reports(root) {
  const fin = can('finance', 'read');
  const y = todayStr().slice(0, 4);
  const f = { from: `${y}-01-01`, to: todayStr(), agent_id: '', customer_id: '', status: '', group: 'agent' };
  root.innerHTML = `${pageHead('Shipment register & profit', 'Every shipment in the period, with income, expense and profit from posted documents', '<button class="btn primary" data-x>Export register to Excel</button>')}
    <div class="toolbar"><label class="muted small">Sailing from <input type="date" data-f="from" value="${f.from}"></label><label class="muted small">to <input type="date" data-f="to" value="${f.to}"></label>
      <select data-f="agent_id"><option value="">All agents</option>${opts.parties('agent').map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="customer_id"><option value="">All customers</option>${opts.parties('customer').map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="status"><option value="">Any status</option>${['BOOKED', 'CONFIRMED', 'SAILED', 'ARRIVED', 'DELIVERED', 'CLOSED', 'CANCELLED'].map((s) => `<option>${s}</option>`).join('')}</select></div>
    ${fin ? '<div class="card"><div class="card-h"><h2>Profit</h2><select data-f="group" style="width:auto"><option value="agent">by agent</option><option value="customer">by customer</option><option value="lane">by trade lane</option><option value="month">by month</option><option value="shipment">by shipment</option></select></div><div data-profit></div></div>' : ''}
    <div class="card"><div class="card-h"><h2>Shipments</h2><span class="muted small" data-count></span></div><div data-out></div></div>`;
  const load = async () => {
    const rows = await api('GET', '/reports/shipments' + qs(f));
    $('[data-count]', root).textContent = `${rows.length} shipments, ${num(rows.reduce((a, r) => a + r.teu, 0))} TEU`;
    $('[data-out]', root).innerHTML = tbl({ rows, click: true, empty: 'No shipments in this period.', rowAttr: (r) => `data-go="#/shipments/${r.id}"`, cols: [
      { label: 'Booking / HBL', render: (r) => `<b>${esc(r.booking_no)}</b><div class="muted small">${esc(r.hbl_no || '')}</div>` }, { label: 'ETD', render: (r) => date(r.etd) },
      { label: 'Customer', render: (r) => esc(r.customer_name || '') }, { label: 'Agent', render: (r) => esc(r.agent_name || '') }, { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` },
      { label: 'Cargo', render: (r) => badge(r.cargo_type) }, { label: 'TEU', num: true, render: (r) => num(r.teu) }, { label: 'CBM', num: true, render: (r) => num(r.cbm) },
      ...(fin ? [{ label: 'Income', num: true, render: (r) => money(r.income) }, { label: 'Expense', num: true, render: (r) => money(r.expense) }, { label: 'Profit', num: true, render: (r) => signed(r.profit) }] : []), { label: 'Status', render: (r) => shipBadge(r.status) }],
      foot: fin ? `<tr><td colspan="6">Total</td><td class="num">${num(rows.reduce((a, r) => a + r.teu, 0))}</td><td class="num"></td><td class="num">${money(rows.reduce((a, r) => a + r.income, 0))}</td><td class="num">${money(rows.reduce((a, r) => a + r.expense, 0))}</td><td class="num">${signed(rows.reduce((a, r) => a + r.profit, 0))}</td><td></td></tr>` : undefined });
    if (fin) {
      const p = await api('GET', '/reports/profit' + qs(f));
      $('[data-profit]', root).innerHTML = tbl({ rows: p.rows, empty: 'No data.', cols: [{ label: p.group[0].toUpperCase() + p.group.slice(1), render: (r) => `<b>${esc(r.name)}</b>` }, { label: 'Shipments', num: true, key: 'shipments' }, { label: 'TEU', num: true, render: (r) => num(r.teu) },
        { label: `Income (${esc(p.base_currency)})`, num: true, render: (r) => money(r.income) }, { label: 'Expense', num: true, render: (r) => money(r.expense) }, { label: 'Profit', num: true, render: (r) => `<b>${signed(r.profit)}</b>` }, { label: 'Margin', num: true, render: (r) => r.margin == null ? '' : num(r.margin) + '%' }] });
    }
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')), 200);
  root.addEventListener('change', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  on(root, 'click', '[data-x]', () => download('/reports/shipments' + qs({ ...f, format: 'xlsx' })));
  await load();
}
