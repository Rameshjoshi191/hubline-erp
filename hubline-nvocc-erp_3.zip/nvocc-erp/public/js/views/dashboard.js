// Dashboard: what needs attention first, then Equipment, Receivables and Container tracking - each in its own calm panel.
import { api, esc, money, int, num, date, tbl, link, can, state, badge, shipBadge } from '../core.js';
import { icon } from '../icons.js';

const COL = { empty: '#10b981', laden: '#3b82f6', oos: '#ef4444', amber: '#f59e0b', grey: '#94a3b8' };
const seg = (parts) => {
  const total = parts.reduce((a, p) => a + p.v, 0);
  return `<div class="stack" role="img" aria-label="${parts.map((p) => `${p.l} ${p.v}`).join(', ')}">${total ? parts.filter((p) => p.v > 0).map((p) => `<i style="flex:${p.v};background:${p.c}" title="${esc(p.l)}: ${p.v}"></i>`).join('') : ''}</div>`;
};
const legend = (parts) => `<div class="lg">${parts.map((p) => `<span><i style="background:${p.c}"></i>${esc(p.l)} <b>${typeof p.v === 'number' ? int(p.v) : p.v}</b></span>`).join('')}</div>`;
const eta = (d) => (d == null ? '' : d < 0 ? `<span class="neg">${-d} day${d === -1 ? '' : 's'} late</span>` : d === 0 ? '<b>today</b>' : `in ${d} day${d === 1 ? '' : 's'}`);

function actionCentre(actions, title = 'Needs your attention') {
  if (!actions.length) return `<div class="allclear">${icon('check', 20)} <div><b>All clear</b><span>Nothing needs your attention right now.</span></div></div>`;
  return `<div class="card actions"><div class="card-h"><h2>${icon('bell', 16)} ${esc(title)}</h2><span class="badge ${actions.some((a) => a.severity === 'bad') ? 'bad' : 'warn'}">${actions.length}</span></div>
    <div class="act-list">${actions.map((a) => `<a class="act ${a.severity}" href="${esc(a.href)}"><span class="dot"></span><div class="grow"><b>${esc(a.title)}</b><span>${esc(a.detail)}</span></div><em>${int(a.count)}</em>${icon('arrow', 15)}</a>`).join('')}</div></div>`;
}

function equipmentCard(e, isAgent) {
  const parts = [{ l: 'Empty', v: e.empty, c: COL.empty }, { l: 'Laden', v: e.laden, c: COL.laden }, { l: 'Out of service', v: e.out_of_service, c: COL.oos }];
  const max = Math.max(1, ...e.by_type.map((t) => t.total));
  return `<div class="card panel"><div class="card-h"><h2>${icon('container', 16)} Equipment</h2><a class="btn sm" href="${isAgent ? '#/containers' : '#/inventory-report'}">${isAgent ? 'Containers' : 'Inventory report'}</a></div><div class="card-b">
    <div class="big"><b>${int(e.total)}</b><span>containers &middot; ${num(e.teu)} TEU${e.total ? ` &middot; ${e.utilisation}% laden` : ''}</span></div>
    ${seg(parts)}${legend(parts)}
    ${e.overdue || e.expiring ? `<a class="chipline ${e.overdue ? 'bad' : 'warn'}" href="#/containers?overdue=1">${icon('alert', 15)} ${e.overdue ? `<b>${int(e.overdue)}</b> past free time` : ''}${e.overdue && e.expiring ? ' &middot; ' : ''}${e.expiring ? `<b>${int(e.expiring)}</b> expire within 2 days` : ''}</a>` : ''}
    ${e.by_type.length ? `<div class="sub-h">By container type</div>${e.by_type.slice(0, 6).map((t) => `<div class="mini"><span class="nm">${esc(t.type_code)}</span><div class="bar" style="width:${Math.max(4, (t.total / max) * 100)}%">${seg([{ l: 'Empty', v: t.empty, c: COL.empty }, { l: 'Laden', v: t.laden, c: COL.laden }, { l: 'Out of service', v: t.out_of_service, c: COL.oos }])}</div><b>${int(t.total)}</b></div>`).join('')}` : ''}
    ${e.top_locations.length ? `<div class="sub-h">Where they are</div>${e.top_locations.slice(0, 5).map((l) => `<div class="rowline"><span>${icon('pin', 14)} ${esc(l.location)}</span><span><b>${int(l.total)}</b> <span class="muted small">${int(l.empty)} empty</span></span></div>`).join('')}` : ''}
  </div></div>`;
}

function receivablesCard(r, cur) {
  const b = r.buckets;
  const parts = [{ l: 'Not due', v: b.not_due, c: COL.empty }, { l: '1-30 days', v: b.d1_30, c: COL.amber }, { l: '31-60', v: b.d31_60, c: '#f97316' }, { l: '61-90', v: b.d61_90, c: '#ef4444' }, { l: '90+', v: b.d90_plus, c: '#991b1b' }];
  const sh = parts.map((p) => ({ ...p, v: Math.max(0, p.v), lv: p.v }));
  return `<div class="card panel"><div class="card-h"><h2>${icon('coins', 16)} Receivables</h2><a class="btn sm" href="#/ageing">Ageing</a></div><div class="card-b">
    <div class="big"><b>${money(r.total)}</b><span>${esc(cur)} outstanding from customers &amp; agents</span></div>
    ${seg(sh)}<div class="lg">${sh.map((p) => `<span><i style="background:${p.c}"></i>${esc(p.l)} <b>${money(p.lv)}</b></span>`).join('')}</div>
    <div class="two"><div><span>Overdue</span><b class="${r.overdue > 0 ? 'neg' : ''}">${money(r.overdue)}</b></div><div><span>Collected, 30 days</span><b class="pos">${money(r.collected_30d)}</b></div><div><span>We owe</span><b>${money(r.payable)}</b></div></div>
    ${r.top_debtors.length ? `<div class="sub-h">Biggest balances</div>${r.top_debtors.map((d) => `<div class="rowline"><span>${link('#/parties/' + d.party_id, d.name)}</span><span><b>${money(d.outstanding)}</b>${d.overdue > 0 ? ` <span class="neg small">${money(d.overdue)} overdue</span>` : ''}</span></div>`).join('')}` : ''}
    ${r.draft_documents + r.draft_commissions ? `<a class="chipline info" href="#/documents?status=DRAFT">${icon('pen', 15)} <b>${int(r.draft_documents + r.draft_commissions)}</b> draft${r.draft_documents + r.draft_commissions === 1 ? '' : 's'} waiting to be posted</a>` : ''}
  </div></div>`;
}

function trackingCard(t, canTrack) {
  return `<div class="card panel"><div class="card-h"><h2>${icon('map', 16)} Container tracking</h2>${canTrack ? '<a class="btn sm" href="#/track">Enquiry</a>' : ''}</div><div class="card-b">
    <div class="big"><b>${int(t.in_transit_total)}</b><span>on the water${t.arriving_7d ? ` &middot; <b>${int(t.arriving_7d)}</b> arriving within 7 days` : ''}</span></div>
    ${t.in_transit.length ? `<div class="sub-h">Next arrivals</div>${t.in_transit.slice(0, 5).map((x) => `<a class="rowline lnk" href="#/track/${x.id}"><span><b>${esc(x.container_no)}</b> <span class="muted small">${esc(x.vessel || '')}${x.pod_name ? ' &rarr; ' + esc(x.pod_name) : ''}</span></span><span class="small">${x.eta ? date(x.eta) + ' &middot; ' : ''}${eta(x.days_to_eta)}</span></a>`).join('')}`
      : '<div class="muted small" style="margin:12px 0">No containers are at sea right now.</div>'}
    ${t.recent_movements.length ? `<div class="sub-h">Latest movements</div>${t.recent_movements.slice(0, 5).map((m) => `<a class="rowline lnk" href="#/track/${m.container_id}"><span><b>${esc(m.container_no)}</b> <span class="muted small">${esc(m.label)}${m.location ? ' &middot; ' + esc(m.location) : ''}</span></span><span class="muted small">${date(m.event_date)}</span></a>`).join('')}` : ''}
  </div></div>`;
}

const PIPE = [['BOOKED', 'Booked', '#3b82f6'], ['CONFIRMED', 'Confirmed', '#6366f1'], ['SAILED', 'At sea', '#f59e0b'], ['ARRIVED', 'Arrived', '#f97316'], ['DELIVERED', 'Delivered', '#10b981']];
function pipeline(st, title, href) {
  const open = PIPE.reduce((a, [k]) => a + (st[k] || 0), 0);
  return `<div class="card"><div class="card-h"><h2>${icon('package', 16)} ${esc(title)}</h2>${href ? `<a class="btn sm" href="${href}">View all</a>` : ''}</div><div class="card-b">
    ${open ? `<div class="pipe">${PIPE.map(([k, , col]) => (st[k] ? `<i style="flex:${st[k]};background:${col}" title="${st[k]}"></i>` : '')).join('')}</div>` : '<div class="muted">No open shipments.</div>'}
    <div class="pipe-legend">${PIPE.map(([k, l, col]) => `<div><b>${int(st[k] || 0)}</b><i style="background:${col}"></i>${l}</div>`).join('')}</div></div></div>`;
}

export async function dashboard(root) {
  const d = await api('GET', '/dashboard');
  const hour = new Date().getHours(), first = (state.me.full_name || '').split(/\s+/)[0];
  const hello = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  if (d.role === 'agent') {
    const st = Object.fromEntries(d.shipments_by_status.map((x) => [x.status, x.n]));
    root.innerHTML = `<div class="page-head"><div class="grow"><h1>${hello}, ${esc(first)}</h1><p>${esc(d.agent_name)} &middot; ${date(d.today)}${d.locations ? ' &middot; your locations: <b>' + esc(String(d.locations).split(/[\n,;|]+/).filter(Boolean).join(', ')) + '</b>' : ''}</p></div>
        <div class="pill-row">${can('movements', 'write') ? `<a class="btn primary" href="#/movements">${icon('bolt', 16)} Update movements</a>` : ''}${can('bl', 'write') ? `<a class="btn" href="#/bls">${icon('plus', 16)} Booking request</a>` : ''}<a class="btn" href="#/track">${icon('search', 16)} Container enquiry</a></div></div>
      ${actionCentre(d.actions)}
      <div class="dash3 two-col">${equipmentCard(d.equipment, true)}${trackingCard(d.tracking, true)}</div>
      ${pipeline(st, 'Your shipments', '#/bls')}`;
    return;
  }

  const st = Object.fromEntries(d.shipments_by_status.map((x) => [x.status, x.n]));
  const open = PIPE.reduce((a, [k]) => a + (st[k] || 0), 0);
  const e = d.equipment, delta = d.this_month.teu - d.last_month.teu;
  const kpi = (ic, tone, k, v, s, href, cls = '') => `<a href="${href}" class="card kpi"><div class="tile ${tone}">${icon(ic, 22)}</div><div><div class="k">${k}</div><div class="v ${cls}">${v}</div><div class="s">${s}</div></div></a>`;
  root.innerHTML = `<div class="page-head"><div class="grow"><h1>${hello}, ${esc(first)}</h1><p>${esc(state.lk.settings.company_name)} &middot; ${date(d.today)}</p></div>
      <div class="pill-row">${can('shipments', 'write') ? `<a class="btn primary" href="#/shipments?new=1">${icon('plus', 16)} New booking</a>` : ''}${can('movements', 'write') ? `<a class="btn" href="#/movements">${icon('bolt', 16)} Update movements</a>` : ''}<a class="btn" href="#/track">${icon('search', 16)} Container enquiry</a>${can('reports', 'read') ? `<a class="btn" href="#/inventory-report">${icon('report', 16)} Inventory report</a>` : ''}</div></div>
    <div class="grid g4" style="margin-bottom:16px">
      ${kpi('package', 'blue', 'Open shipments', int(open), `${st.BOOKED || 0} booked &middot; ${st.CONFIRMED || 0} confirmed &middot; ${st.SAILED || 0} at sea`, '#/shipments?open=1')}
      ${kpi('ship', 'teal', 'TEU this month', num(d.this_month.teu), `${d.this_month.n} shipments &middot; ${delta >= 0 ? '+' : ''}${num(delta)} vs last month`, '#/reports')}
      ${kpi('container', 'purple', 'Containers', int(e.total), `${int(e.empty)} empty &middot; ${int(e.laden)} laden`, '#/containers')}
      ${kpi('alert', e.overdue ? 'red' : 'green', 'Past free time', int(e.overdue), `${int(e.expiring)} more expire within 2 days`, '#/containers?overdue=1', e.overdue ? 'neg' : '')}</div>
    ${actionCentre(d.actions)}
    <div class="dash3">${equipmentCard(e, false)}${d.receivables ? receivablesCard(d.receivables, d.base_currency) : ''}${trackingCard(d.tracking, can('containers', 'read'))}</div>
    ${pipeline(st, 'Shipment pipeline', '#/shipments')}`;
}
