// Movements: update where containers are - by Excel upload, by pasting numbers, or one at a time. Used by HUB LINE staff and by agents (their own locations only).
import { api, state, esc, $, on, tbl, pageHead, date, badge, toast, can, link, todayStr, opts, int, debounce } from '../core.js';
import { icon } from '../icons.js';
import { importWizard, tilesFor } from '../importui.js';
import { shareBtn, wireShare } from '../share.js';

const isAgent = () => !!(state.me && state.me.is_agent);
const statusList = () => Object.entries(state.lk.container_status).filter(([k, v]) => v.group !== 'CLOSED' || (!isAgent() && k === 'OFF_HIRED')).map(([k, v]) => [k, v.label]);
const ACTION = { CREATE: ['New', 'ok'], MOVE: ['Move', 'info'], LOCATION: ['New location', 'info'], NOCHANGE: ['No change', ''], ERROR: ['Error', 'bad'] };
const parseNumbers = (t) => String(t || '').split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean);

// ---------------------------------------------------------------- the Excel / paste wizard for containers
export async function inventoryImport() {
  const agent = isAgent();
  const staffOpts = [
    { name: 'create_missing', label: 'Add containers that are not in the inventory yet', type: 'checkbox', span: 2, def: 1 },
    { name: 'default_type_id', label: 'Container type when the file has none', type: 'select', options: opts.types, span: 2 },
    { name: 'default_status', label: 'Status when the file has none', type: 'select', options: () => statusList(), empty: 'Empty available (new) / no change', span: 2 },
    { name: 'default_location', label: 'Location when the file has none', span: 1 }, { name: 'default_date', label: 'Date when the file has none', type: 'date', span: 1 },
    { name: 'allow_invalid', label: 'Accept wrong check digits', type: 'checkbox', span: 2 },
  ];
  const agentOpts = [{ name: 'default_location', label: 'Location when the file has none', span: 2, placeholder: state.me.locations ? String(state.me.locations).split(/[\n,;|]+/)[0] : '' }, { name: 'default_date', label: 'Date when the file has none', type: 'date', span: 2 }];
  return importWizard({
    title: agent ? 'Update movements from Excel' : 'Update container inventory from Excel', base: '/inventory', noun: 'containers',
    intro: agent ? 'Upload the movement list from your depot or CFS. Each row needs the container number and what happened (Gate in, Discharged, Delivered, Empty return ...). You can only update containers at your own locations.'
      : 'Upload your stock list or a movement report. Column names, dates and movement words such as <i>Gate in</i>, <i>On board</i> or <i>Empty return</i> are understood automatically. New containers are added, existing ones are moved - nothing is saved until you confirm.',
    options: agent ? agentOpts : staffOpts, optionsTitle: 'When something is missing in the file', defaults: agent ? {} : { create_missing: 1 },
    cols: [
      { label: 'Container', render: (r) => `<b>${esc(r.container_no || r.input || '')}</b><div class="muted small">${esc(r.type_code || '')}</div>` },
      { label: 'Now', render: (r) => (r.exists ? `${esc(r.current_status_label || '')}<div class="muted small">${esc(r.current_location || '')}</div>` : '<span class="muted small">not in inventory</span>') },
      { label: 'Becomes', render: (r) => (r.status_label ? `<b>${esc(r.status_label)}</b><div class="muted small">${esc(r.location || '')}${r.date ? ' &middot; ' + date(r.date) : ''}</div>` : '') },
    ],
    tiles: tilesFor([['create', 'New containers', 'ok'], ['move', 'Movements', 'info'], ['location', 'Location changes', 'info'], ['nochange', 'Unchanged', ''], ['error', 'Errors', 'bad']]),
    saveLabel: (s) => `Save ${int(s.ready)} update${s.ready === 1 ? '' : 's'}`,
    doneHtml: (r) => `<h2>Inventory updated</h2><p class="muted">${[r.created ? `${r.created} new container${r.created === 1 ? '' : 's'} added` : '', r.moved ? `${r.moved} movement${r.moved === 1 ? '' : 's'} recorded` : '', r.relocated ? `${r.relocated} location${r.relocated === 1 ? '' : 's'} updated` : ''].filter(Boolean).join(' &middot; ') || 'Nothing changed'}</p>`,
    nextLinks: agent ? [['Container enquiry', '#/track']] : [['Container inventory', '#/containers'], ['Inventory report', '#/inventory-report']],
  });
}

// ---------------------------------------------------------------- the quick form (also used from the container enquiry page)
export function quickForm({ numbers = '', compact = false, onSaved } = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'quick';
  const locs = [];
  wrap.innerHTML = `<div class="q-step"><span class="q-n">1</span><div class="grow"><label class="f"><span>Container numbers <em class="hint">- paste as many as you like, separated by spaces, commas or new lines</em></span>
      <textarea data-numbers rows="${compact ? 2 : 4}" placeholder="MSKU1234565&#10;TCLU7654321">${esc(numbers)}</textarea></label><div class="muted small" data-count></div></div></div>
    <div class="q-step"><span class="q-n">2</span><div class="grow"><div class="form-grid">
      <label class="f s2"><span>What happened?</span><select data-type>${statusList().map(([k, l]) => `<option value="${k}">${esc(l)}</option>`).join('')}</select></label>
      <label class="f"><span>Date</span><input type="date" data-date value="${todayStr()}"></label>
      <label class="f" data-freewrap><span>Free days <em class="hint">(optional)</em></span><input type="number" min="0" data-free></label>
      <label class="f s2"><span>Location ${isAgent() ? '<em class="hint">- one of your locations</em>' : ''}</span><input type="text" data-loc list="q_locs" autocomplete="off" placeholder="Depot, CFS, terminal or city"><datalist id="q_locs"></datalist></label>
      <label class="f s2"><span>Remarks <em class="hint">(optional)</em></span><input type="text" data-remarks></label></div></div></div>
    <div class="q-result" data-result></div>
    <div class="pill-row" style="margin-top:12px"><button class="btn" data-check>${icon('check', 16)} Check</button><button class="btn primary" data-save disabled>${icon('bolt', 16)} Save movements</button></div>`;
  const q = (s) => wrap.querySelector(s);
  const paintCount = () => { const n = parseNumbers(q('[data-numbers]').value).length; q('[data-count]').textContent = n ? `${n} container${n === 1 ? '' : 's'} recognised` : ''; };
  const paintFree = () => { const st = state.lk.container_status[q('[data-type]').value]; q('[data-freewrap]').style.display = st && st.clock ? '' : 'none'; };
  api('GET', '/locations').then((l) => { q('#q_locs').innerHTML = l.map((x) => `<option value="${esc(x)}"></option>`).join(''); if (isAgent() && l.length === 1 && !q('[data-loc]').value) q('[data-loc]').value = l[0]; }).catch(() => {});
  const body = (preview) => ({ numbers: q('[data-numbers]').value, event_type: q('[data-type]').value, event_date: q('[data-date]').value, location: q('[data-loc]').value.trim(),
    free_days: q('[data-free]').value, remarks: q('[data-remarks]').value.trim(), preview });
  const rowsHtml = (rows) => tbl({ compact: true, rows, cols: [
    { label: 'Container', render: (r) => `<b>${esc(r.container_no || r.input)}</b>` }, { label: 'Now', render: (r) => (r.exists ? `${esc(r.current_status_label || '')}<div class="muted small">${esc(r.current_location || '')}</div>` : '') },
    { label: 'Result', render: (r) => `${badge(...(ACTION[r.action] || [r.action, '']))}${r.messages && r.messages.length ? `<div class="small ${r.level === 'error' ? 'neg' : 'muted'}">${r.messages.map(esc).join('<br>')}</div>` : ''}` }] });
  let checked = false;
  const check = async () => {
    const res = q('[data-result]'); q('[data-save]').disabled = true;
    if (!parseNumbers(q('[data-numbers]').value).length) { res.innerHTML = '<div class="alert bad">Paste at least one container number.</div>'; return; }
    try {
      const r = await api('POST', '/movements/quick', body(true));
      const s = r.summary;
      res.innerHTML = `<div class="alert ${s.error ? (s.ready ? 'warn' : 'bad') : 'ok'}"><b>${s.ready}</b> of ${s.total} will be saved${s.error ? `, <b>${s.error}</b> cannot be saved (see below)` : ''}${s.nochange ? `, ${s.nochange} already up to date` : ''}.</div>${rowsHtml(r.rows)}`;
      q('[data-save]').disabled = !s.ready; checked = true;
    } catch (e) { res.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; }
  };
  const save = async () => {
    q('[data-save]').disabled = true;
    try {
      const r = await api('POST', '/movements/quick', body(false));
      const n = r.result.moved + r.result.relocated;
      q('[data-result]').innerHTML = `<div class="alert ok"><b>${n}</b> movement${n === 1 ? '' : 's'} saved${r.summary.error ? `, ${r.summary.error} could not be saved` : ''}.</div>${r.summary.error ? rowsHtml(r.rows.filter((x) => x.action === 'ERROR')) : ''}`;
      toast(`${n} movement${n === 1 ? '' : 's'} saved`, 'ok');
      if (!r.summary.error) q('[data-numbers]').value = '';
      paintCount(); checked = false;
      if (onSaved) onSaved(r);
    } catch (e) { q('[data-result]').innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; q('[data-save]').disabled = false; }
  };
  wrap.addEventListener('input', (e) => { if (e.target.matches('[data-numbers]')) paintCount(); if (checked) { checked = false; q('[data-save]').disabled = true; } });
  wrap.addEventListener('change', (e) => { if (e.target.matches('[data-type]')) paintFree(); });
  q('[data-check]').addEventListener('click', check);
  q('[data-save]').addEventListener('click', save);
  paintCount(); paintFree();
  return wrap;
}

// ---------------------------------------------------------------- the page
export async function movements(root) {
  const agent = isAgent();
  let mine = '';
  root.innerHTML = `${pageHead('Update movements', agent ? `Keep the containers at your locations up to date. You can update: <b>${esc(String(state.me.locations || '').split(/[\n,;|]+/).filter(Boolean).join(', ') || 'your locations')}</b>`
      : 'Record gate-ins, loading, discharge, delivery and empty returns - from Excel, by pasting numbers, or one at a time',
    `<button class="btn primary" data-act="import">${icon('upload', 16)} Upload Excel</button>${shareBtn('Share movements')}`)}
    <div class="split">
      <div class="card"><div class="card-h"><h2>${icon('bolt', 16)} Quick update</h2><span class="muted small">Several containers, one movement</span></div><div class="card-b" data-quick></div></div>
      <div><div class="card"><div class="card-h"><h2>${icon('sheet', 16)} Update from Excel</h2></div><div class="card-b">
          <p style="margin-top:0">Have a movement report from your depot or terminal? Upload it and we do the rest:</p>
          <ol class="howto"><li>Choose the file (or paste rows)</li><li>We read the columns and movement words</li><li>Check the preview, then save</li></ol>
          <div class="pill-row"><button class="btn primary" data-act="import">${icon('upload', 16)} Upload Excel</button><a class="btn" href="/api/inventory/template">${icon('download', 16)} Template</a></div></div></div>
        <div class="card"><div class="card-h"><h2>Tips</h2></div><div class="card-b small muted">
          <p style="margin-top:0">Words like <b>gate in</b>, <b>on board</b>, <b>discharged</b>, <b>delivered</b>, <b>empty return</b>, <b>available</b> or <b>damaged</b> are understood.</p>
          <p>Uploading the same list again changes nothing - only real differences are saved.</p><p style="margin-bottom:0">Wrong check digits are flagged so typing mistakes never reach the inventory.</p></div></div></div></div>
    <div class="card"><div class="card-h"><h2>Latest movements</h2><label class="muted small"><input type="checkbox" data-mine ${mine ? 'checked' : ''}> only my updates</label></div><div data-recent></div></div>`;
  const recent = async () => {
    const rows = await api('GET', `/movements/recent?limit=40${mine ? '&mine=1' : ''}`);
    $('[data-recent]', root).innerHTML = tbl({ rows, compact: true, empty: 'No movements yet.', cols: [
      { label: 'Date', render: (r) => date(r.event_date) }, { label: 'Container', render: (r) => `<b>${link('#/track/' + r.container_id, r.container_no)}</b><div class="muted small">${esc(r.type_code)}</div>` },
      { label: 'Movement', key: 'label' }, { label: 'Location', render: (r) => esc(r.location || '') }, { label: 'Booking / HBL', render: (r) => esc([r.booking_no, r.hbl_no].filter(Boolean).join(' / ')) },
      { label: 'Updated by', render: (r) => `${esc(r.by_user || '')}${r.by_role === 'agent' ? ' ' + badge('agent', 'info') : ''}<div class="muted small">${esc(r.remarks || '')}</div>` }] });
  };
  $('[data-quick]', root).appendChild(quickForm({ onSaved: () => recent().catch(() => {}) }));
  on(root, 'click', '[data-act=import]', async () => { const r = await inventoryImport(); if (r) recent().catch(() => {}); });
  root.addEventListener('change', (e) => { if (e.target.matches('[data-mine]')) { mine = e.target.checked ? '1' : ''; recent().catch((x) => toast(x.message, 'bad')); } });
  wireShare(root, () => ({ kind: 'movements', params: { from: todayStr() }, title: 'Share today\'s movements', what: 'the movements recorded today' }));
  await recent();
}
