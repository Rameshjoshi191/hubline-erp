// Container enquiry: search by container, booking, HBL, MBL, vessel or place - and follow one container's journey.
import { api, state, esc, $, on, qs, tbl, pageHead, date, groupBadge, badge, shipBadge, toast, can, link, kv, go, num, int, todayStr } from '../core.js';
import { icon } from '../icons.js';
import { shareBtn, wireShare } from '../share.js';
import { quickForm } from './movements.js';
import { openModal } from '../core.js';

const free = (c) => (c.free_until ? `${date(c.free_until)}<div class="small ${c.overdue ? 'neg' : 'muted'}">${c.overdue ? `${-c.free_days_left} day${c.free_days_left === -1 ? '' : 's'} over` : `${c.free_days_left} day${c.free_days_left === 1 ? '' : 's'} left`}</div>` : '');
const eta = (c) => (c.eta ? `${date(c.eta)}${c.days_to_eta != null ? `<div class="small ${c.days_to_eta < 0 ? 'neg' : 'muted'}">${c.days_to_eta < 0 ? `${-c.days_to_eta} day(s) late` : c.days_to_eta === 0 ? 'today' : `in ${c.days_to_eta} day${c.days_to_eta === 1 ? '' : 's'}`}</div>` : ''}` : '');

// ---------------------------------------------------------------- enquiry page
export async function enquiry(root, _p, query) {
  let q = query.q || '';
  root.innerHTML = `${pageHead('Container enquiry', 'Where is it now, where has it been, and when does it arrive?',
    `${can('movements', 'write') ? `<a class="btn primary" href="#/movements">${icon('bolt', 16)} Update movements</a>` : ''}<span data-share-slot></span>`)}
    <form class="card enq" data-form><div class="enq-in">${icon('search', 20)}<textarea name="q" rows="1" placeholder="Container number(s), booking, HBL or MBL number, vessel, or a place such as Jebel Ali" aria-label="Search">${esc(q)}</textarea>
      <button class="btn primary" type="submit">Search</button></div>
      <div class="muted small" style="margin-top:8px">Paste a whole list of container numbers to see them all at once. Try a place name to list everything at that depot.</div></form>
    <div data-out></div>`;
  const out = $('[data-out]', root), ta = $('textarea', root);
  const grow = () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 160) + 'px'; };
  ta.addEventListener('input', grow); grow();
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('form', root).requestSubmit(); } });

  async function search() {
    q = ta.value.trim();
    history.replaceState(null, '', `#/track${qs({ q })}`);
    $('[data-share-slot]', root).innerHTML = '';
    if (!q) return home();
    out.innerHTML = '<div class="boot">Searching…</div>';
    const { rows } = await api('GET', `/track${qs({ q })}`);
    if (!rows.length) { out.innerHTML = `<div class="card"><div class="empty">Nothing found for &ldquo;${esc(q.length > 80 ? q.slice(0, 80) + '…' : q)}&rdquo;.<br><span class="small">Check the number, or search by booking, HBL, vessel or a place.</span></div></div>`; return; }
    $('[data-share-slot]', root).innerHTML = shareBtn('Share results');
    const by = (fn) => rows.filter(fn).length;
    out.innerHTML = `<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));margin-bottom:14px">
        ${[['Found', rows.length, ''], ['Empty', by((r) => r.group === 'EMPTY'), ''], ['Laden', by((r) => r.group === 'LADEN'), ''], ['On the water', by((r) => r.status === 'ON_BOARD'), ''], ['Past free time', by((r) => r.overdue), 'neg']]
          .map(([k, v, c]) => `<div class="card stat"><div class="k">${k}</div><div class="v ${v ? c : ''}">${v}</div></div>`).join('')}</div>
      <div class="card">${tbl({ rows, click: true, rowAttr: (r) => `data-go="#/track/${r.id}"`, cols: [
        { label: 'Container', render: (r) => `<b>${esc(r.container_no)}</b><div class="muted small">${esc(r.type_code)}</div>` },
        { label: 'Status', render: (r) => `${groupBadge(r.group, r.status_label)}<div class="muted small">${esc(r.location || '')}</div>` },
        { label: 'Since', render: (r) => `${date(r.last_date)}<div class="muted small">${r.days_in_status} day${r.days_in_status === 1 ? '' : 's'}</div>` },
        { label: 'Booking / HBL', render: (r) => (r.booking_no ? `${esc(r.booking_no)}<div class="muted small">${esc(r.hbl_no || '')}</div>` : '') },
        { label: 'Vessel', render: (r) => (r.vessel ? `${esc(r.vessel)}<div class="muted small">${esc(r.voyage || '')}</div>` : '') },
        { label: 'Route', render: (r) => (r.pol_name || r.pod_name ? `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` : '') },
        { label: 'ETA', render: eta }, { label: 'Free time until', render: free }] })}</div>`;
  }
  async function home() {
    out.innerHTML = '<div class="boot">Loading…</div>';
    const rows = await api('GET', '/movements/recent?limit=12');
    out.innerHTML = `<div class="card"><div class="card-h"><h2>Latest movements</h2>${can('movements', 'write') ? '<a class="btn sm" href="#/movements">Update movements</a>' : ''}</div>${tbl({ rows, compact: true, click: true, rowAttr: (r) => `data-go="#/track/${r.container_id}"`, empty: 'No movements have been recorded yet.', cols: [
      { label: 'Date', render: (r) => date(r.event_date) }, { label: 'Container', render: (r) => `<b>${esc(r.container_no)}</b>` }, { label: 'Movement', key: 'label' }, { label: 'Location', render: (r) => esc(r.location || '') },
      { label: 'Booking / HBL', render: (r) => esc([r.booking_no, r.hbl_no].filter(Boolean).join(' / ')) }] })}</div>`;
  }
  $('form', root).addEventListener('submit', (e) => { e.preventDefault(); search().catch((x) => { out.innerHTML = ''; toast(x.message, 'bad'); }); });
  wireShare(root, () => ({ kind: 'tracking', params: { q }, title: 'Share tracking results', what: 'these containers and where they are' }));
  if (q) await search(); else await home();
}

// ---------------------------------------------------------------- one container
export async function detail(root, { id }) {
  const d = await api('GET', `/track/${id}`);
  const c = d.container, sh = d.shipment, canW = can('movements', 'write');
  const stateLabel = c.status_label || c.status;
  root.innerHTML = `${pageHead(`${esc(c.container_no)} ${groupBadge(c.group, stateLabel)}`, `${esc(c.type_code)}${c.owner_name ? ' &middot; ' + esc(c.owner_name) : ''}${c.location ? ' &middot; now at <b>' + esc(c.location) + '</b>' : ''}`,
      `${canW ? `<button class="btn primary" data-act="move">${icon('bolt', 16)} Log movement</button>` : ''}${can('containers', 'write') && !state.me.is_agent ? `<a class="btn" href="#/containers/${c.id}">Full record</a>` : ''}`, '<a href="#/track">Container enquiry</a> /')}
    ${c.overdue ? `<div class="alert bad"><b>Free time ended</b> on ${date(c.free_until)} &mdash; ${-c.free_days_left} day(s) over. Detention / demurrage may be accruing.</div>` : ''}
    <div class="card"><div class="card-h"><h2>Journey</h2>${c.days_in_status != null ? `<span class="muted small">${c.days_in_status} day${c.days_in_status === 1 ? '' : 's'} in this status</span>` : ''}</div>
      <div class="card-b"><ol class="journey">${d.journey.map((j) => `<li class="${j.state}"><span class="dot">${j.state === 'todo' ? '' : icon('check', 14)}</span><b>${esc(j.label)}</b>
        <span class="small muted">${j.done ? `${date(j.date)}${j.location ? '<br>' + esc(j.location) : ''}` : j.expected ? `expected ${date(j.expected)}` : ''}</span></li>`).join('')}</ol></div></div>
    <div class="split"><div class="card"><div class="card-h"><h2>Movement history</h2><span class="muted small">${d.events.length} record${d.events.length === 1 ? '' : 's'}</span></div>
        ${tbl({ rows: d.events, compact: true, empty: 'No movements yet.', cols: [
          { label: 'Date', render: (e) => date(e.event_date) }, { label: 'Movement', render: (e) => `<b>${esc(e.label)}</b>${e.free_days != null ? `<div class="muted small">${e.free_days} free days</div>` : ''}` },
          { label: 'Location', render: (e) => esc(e.location || '') }, { label: 'Reference', render: (e) => esc([e.booking_no, e.consol_no].filter(Boolean).join(' / ')) },
          { label: 'Updated by', render: (e) => `<span class="small">${esc(e.full_name || e.username || '')}</span><div class="muted small">${esc(e.remarks || '')}</div>` }] })}</div>
      <div>${sh ? `<div class="card"><div class="card-h"><h2>Current shipment</h2>${shipBadge(sh.status)}</div><div class="card-b">${kv([
          ['Booking', can('shipments', 'read') && !state.me.is_agent ? link('#/shipments/' + sh.id, sh.booking_no) : esc(sh.booking_no)], ['HBL', esc(sh.hbl_no)], ['Master BL', esc(sh.mbl_no)],
          ['Vessel', esc([sh.vessel, sh.voyage].filter(Boolean).join(' / '))], ['Route', `${esc(sh.pol_name || '?')} &rarr; ${esc(sh.pod_name || '?')}`], ['ETD', date(sh.etd)], ['ETA', date(sh.eta)], ['Goods', esc(sh.commodity)],
          state.me.is_agent ? null : ['Agent', esc(sh.agent_name)]])}
          ${can('bl', 'read') ? `<div style="margin-top:12px"><a class="btn sm" href="#/bls/${sh.id}">${icon('contract', 15)} Open bill of lading</a></div>` : ''}</div></div>`
        : '<div class="card"><div class="card-h"><h2>Current shipment</h2></div><div class="empty">Not on a shipment right now.</div></div>'}
        <div class="card"><div class="card-h"><h2>Details</h2></div><div class="card-b">${kv([['Status', esc(stateLabel)], ['Location', esc(c.location)], ['Since', date(c.last_date)], ['Type', `${esc(c.type_code)} (${num(c.teu)} TEU)`],
          ['Ownership', esc(c.ownership)], ['Condition', esc(c.condition)], ['Free time', c.free_until ? `${c.free_days} days from ${date(c.clock_from)}, until ${date(c.free_until)}` : '']])}</div></div></div></div>`;
  on(root, 'click', '[data-act=move]', () => {
    const h = openModal({ title: `Log movement - ${c.container_no}`, size: '', body: '<div data-q></div>' });
    h.$('[data-q]').appendChild(quickForm({ numbers: c.container_no, compact: true, onSaved: (r) => { if (!r.summary.error) setTimeout(() => { h.close(true); go(`#/track/${id}`); }, 700); } }));
  });
}
