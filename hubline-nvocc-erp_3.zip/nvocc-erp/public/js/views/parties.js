import { api, state, esc, $, on, qs, tbl, pageHead, money, date, badge, shipBadge, docBadge, formModal, confirmBox, toast, opts, can, kv, link, go, debounce, balancesHtml, docType } from '../core.js';

export const partyFields = (isAgentDefault = false) => [
  { section: 'Identity' },
  { name: 'name', label: 'Company name', required: true, span: 2 }, { name: 'code', label: 'Code', hint: 'leave blank to auto-number' },
  { name: 'active', label: 'Active', type: 'checkbox' },
  { name: 'is_customer', label: 'Customer', type: 'checkbox' }, { name: 'is_agent', label: 'Agent', type: 'checkbox' },
  { name: 'is_vendor', label: 'Vendor', type: 'checkbox' }, { name: 'is_carrier', label: 'Carrier / shipping line', type: 'checkbox' },
  { section: 'Contact' },
  { name: 'address', label: 'Address', type: 'textarea', rows: 2, span: 2 }, { name: 'city', label: 'City' }, { name: 'country', label: 'Country' },
  { name: 'contact_person', label: 'Contact person', span: 1 }, { name: 'email', label: 'Email', type: 'email', span: 1 }, { name: 'phone', label: 'Phone', span: 1 }, { name: 'tax_no', label: 'Tax / VAT no. (TRN)', span: 1 },
  { section: 'Credit & currency' },
  { name: 'credit_days', label: 'Credit days', type: 'number', min: 0 }, { name: 'credit_limit', label: 'Credit limit', type: 'number', min: 0, hint: '0 = none' },
  { name: 'currency', label: 'Usual currency', type: 'select', options: opts.currencies, noEmpty: true },
  { section: 'Agent details (only if this party is an agent)' },
  { name: 'agent_type', label: 'Agent type', type: 'select', options: [['ORIGIN', 'Origin agent'], ['DESTINATION', 'Destination agent'], ['BOTH', 'Origin & destination']] },
  { name: 'agent_network', label: 'Network / affiliation' }, { name: 'agent_territory', label: 'Territory covered', span: 1 }, { name: 'agent_since', label: 'Agent since', type: 'date' },
  { name: 'notes', label: 'Notes', type: 'textarea', rows: 2, span: 4 },
];

export async function openPartyForm(party = null, defaults = {}) {
  const values = party || { active: 1, credit_days: 30, credit_limit: 0, currency: state.lk.settings.base_currency === 'AED' ? 'USD' : state.lk.settings.base_currency, ...defaults };
  return formModal({ title: party ? `Edit ${party.name}` : 'New party', size: 'wide', fields: partyFields(), values, submitLabel: party ? 'Save' : 'Create',
    onSubmit: async (v) => { const r = party ? await api('PUT', `/parties/${party.id}`, v) : await api('POST', '/parties', v); state.lk = await api('GET', '/lookups'); return r || true; } });
}

const ROLE_TABS = [['', 'All'], ['customer', 'Customers'], ['agent', 'Agents'], ['vendor', 'Vendors'], ['carrier', 'Carriers']];
const roleBadges = (p) => [p.is_customer && 'Customer', p.is_agent && 'Agent', p.is_vendor && 'Vendor', p.is_carrier && 'Carrier'].filter(Boolean).map((r) => badge(r, 'info')).join(' ');

export async function list(root, _p, query) {
  const f = { role: query.role || '', q: '', active: '', balances: can('soa', 'read') ? '1' : '' };
  const canW = can('parties', 'write');
  root.innerHTML = `${pageHead('Customers & parties', 'Customers, agents, vendors and carriers in one master list', canW ? '<button class="btn primary" data-act="new">+ New party</button>' : '')}
    <div class="tabs">${ROLE_TABS.map(([v, l]) => `<a data-role="${v}" class="${f.role === v ? 'on' : ''}">${l}</a>`).join('')}</div>
    <div class="toolbar"><input type="text" class="search" placeholder="Search name, code, country, contact…" data-f="q"><label class="muted small"><input type="checkbox" data-f="active"> Active only</label></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  async function load() {
    const rows = await api('GET', '/parties' + qs({ ...f, active: f.active ? '1' : '' }));
    out.innerHTML = tbl({ rows, click: true, empty: 'No parties found.', rowAttr: (r) => `data-go="#/parties/${r.id}"`, cols: [
      { label: 'Code', render: (r) => `<span class="mono">${esc(r.code)}</span>` }, { label: 'Name', render: (r) => `<b>${esc(r.name)}</b>${r.active ? '' : ' ' + badge('Inactive', 'bad')}` },
      { label: 'Role', render: roleBadges }, { label: 'Country', render: (r) => esc([r.city, r.country].filter(Boolean).join(', ')) },
      { label: 'Contact', render: (r) => `${esc(r.contact_person || '')}<div class="muted small">${esc(r.email || '')}</div>` },
      { label: 'Credit', render: (r) => `${r.credit_days} days${r.credit_limit ? `<div class="muted small">limit ${money(r.credit_limit)}</div>` : ''}` },
      ...(f.balances ? [{ label: 'Balance', num: true, render: (r) => balancesHtml(r.balances) }] : [])] });
  }
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.value; reload(); } });
  on(root, 'click', '[data-role]', (_e, el) => { f.role = el.dataset.role; root.querySelectorAll('[data-role]').forEach((a) => a.classList.toggle('on', a === el)); load(); });
  on(root, 'click', '[data-act=new]', async () => { const r = await openPartyForm(null, f.role ? { ['is_' + f.role]: 1 } : {}); if (r) { toast('Party created', 'ok'); load(); } });
  await load();
}

export async function detail(root, { id }) {
  const p = await api('GET', `/parties/${id}`);
  const canW = can('parties', 'write');
  const docs = can('finance', 'read') ? await api('GET', `/documents?party_id=${id}`) : [];
  const ships = await api('GET', `/shipments?limit=15&${p.is_agent ? 'agent_id' : 'customer_id'}=${id}`);
  root.innerHTML = `${pageHead(`${esc(p.name)} ${p.active ? '' : badge('Inactive', 'bad')}`, `<span class="mono">${esc(p.code)}</span> &middot; ${roleBadges(p)}`,
    `${canW ? '<button class="btn" data-act="edit">Edit</button>' : ''}${can('soa', 'read') ? `<a class="btn" href="#/soa?party_id=${p.id}">Statement of account</a>` : ''}${p.is_agent && can('agreements', 'read') ? `<a class="btn" href="#/agents/${p.id}">Agent page</a>` : ''}`, '<a href="#/parties">Parties</a> /')}
    <div class="split"><div>
      <div class="card"><div class="card-h"><h2>Recent shipments</h2></div>${tbl({ rows: ships, click: true, empty: 'No shipments yet.', compact: true, rowAttr: (s) => `data-go="#/shipments/${s.id}"`, cols: [
        { label: 'Booking', render: (s) => `<b>${esc(s.booking_no)}</b><div class="muted small">${esc(s.hbl_no || '')}</div>` }, { label: 'Route', render: (s) => `${esc(s.pol_name || '?')} &rarr; ${esc(s.pod_name || '?')}` }, { label: 'ETD', render: (s) => date(s.etd) }, { label: 'Status', render: (s) => shipBadge(s.status) }] })}</div>
      ${can('finance', 'read') ? `<div class="card"><div class="card-h"><h2>Documents</h2></div>${tbl({ rows: docs.slice(0, 15), click: true, empty: 'No invoices or bills yet.', compact: true, rowAttr: (d) => `data-go="#/documents/${d.id}"`, cols: [
        { label: 'Document', render: (d) => `<b>${esc(d.doc_no || 'Draft')}</b><div class="muted small">${esc(docType(d.doc_type))}</div>` }, { label: 'Date', render: (d) => date(d.doc_date) },
        { label: 'Total', num: true, render: (d) => `${money(d.total)} ${esc(d.currency)}` }, { label: 'Outstanding', num: true, render: (d) => d.outstanding != null ? money(d.outstanding) : '' }, { label: 'Status', render: (d) => docBadge(d.status) }] })}</div>` : ''}
    </div><div>
      ${p.balances ? `<div class="card"><div class="card-h"><h2>Balance</h2></div><div class="card-b">${balancesHtml(p.balances)}<div class="muted small" style="margin-top:6px">Positive = they owe us; negative = we owe them</div></div></div>` : ''}
      <div class="card"><div class="card-h"><h2>Details</h2></div><div class="card-b">${kv([['Address', esc([p.address, p.city, p.country].filter(Boolean).join(', '))], ['Contact', esc(p.contact_person)], ['Email', p.email ? `<a href="mailto:${esc(p.email)}">${esc(p.email)}</a>` : ''], ['Phone', esc(p.phone)],
        ['Tax no.', esc(p.tax_no)], ['Credit', `${p.credit_days} days${p.credit_limit ? ', limit ' + money(p.credit_limit) + ' ' + esc(p.currency) : ''}`], ['Currency', esc(p.currency)],
        p.is_agent ? ['Agent type', esc(p.agent_type)] : null, p.is_agent ? ['Territory', esc(p.agent_territory)] : null, p.is_agent ? ['Agent since', date(p.agent_since)] : null, ['Notes', esc(p.notes)]])}</div></div></div></div>`;
  on(root, 'click', '[data-act=edit]', async () => { const r = await openPartyForm(p); if (r) { toast('Saved', 'ok'); go(`#/parties/${id}`); } });
}
