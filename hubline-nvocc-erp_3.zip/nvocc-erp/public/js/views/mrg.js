// MRG: month-wise freight rate, slot cost and margin - with one-click month set-up (copy last month, fill from tariffs) and Excel import.
import { api, state, esc, $, on, qs, tbl, pageHead, money, num, int, badge, formModal, confirmBox, toast, opts, can, todayStr, download } from '../core.js';
import { icon } from '../icons.js';
import { importWizard, tilesFor } from '../importui.js';
import { shareBtn, wireShare } from '../share.js';

const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const monthLabel = (m) => `${MON[Number(m.slice(5)) - 1]} ${m.slice(0, 4)}`;
const shift = (m, n) => { const d = new Date(m + '-01T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + n); return d.toISOString().slice(0, 7); };
const marginCls = (v) => (v < 0 ? 'neg' : v > 0 ? 'pos' : '');
const METRICS = [['margin', 'Margin per box'], ['freight', 'Freight rate'], ['slot', 'Slot cost'], ['boxes', 'Boxes shipped']];

export function loadRates() {
  return importWizard({
    title: 'Load freight rates & slot costs', base: '/mrg', noun: 'rates',
    intro: 'One row per month, lane and container type: the freight rate you charge and the slot cost you pay the shipping line. Margin is calculated for you. Loading a month again updates its rates.',
    pasteHint: 'Copy your rate sheet from Excel and paste it here. Needed: Month, Type, Freight rate and Slot cost (POL, POD, Carrier, Currency and committed slots are read if present).',
    cols: [
      { label: 'Month', render: (r) => (r.month ? monthLabel(r.month) : '') }, { label: 'Lane', render: (r) => `${esc(r.pol_name || 'any')} &rarr; ${esc(r.pod_name || 'any')}<div class="muted small">${esc(r.carrier_name || '')}</div>` },
      { label: 'Type', key: 'type_code' }, { label: 'Freight', num: true, render: (r) => (r.freight_rate != null ? `${money(r.freight_rate)} <span class="muted small">${esc(r.currency || '')}</span>` : '') },
      { label: 'Slot cost', num: true, render: (r) => (r.slot_cost != null ? money(r.slot_cost) : '') }, { label: 'Margin', num: true, render: (r) => (r.margin != null ? `<b class="${marginCls(r.margin)}">${money(r.margin)}</b>` : '') },
    ],
    tiles: tilesFor([['create', 'New rates', 'ok'], ['update', 'Changed rates', 'warn'], ['nochange', 'Unchanged', ''], ['error', 'Errors', 'bad']]),
    saveLabel: (s) => `Save ${int(s.ready)} rate${s.ready === 1 ? '' : 's'}`,
    doneHtml: (r) => `<h2>Rates saved</h2><p class="muted">${r.created} new &middot; ${r.updated} updated</p>`, nextLinks: [['MRG', '#/mrg']],
  });
}

export async function page(root, _p, query) {
  const canW = can('mrg', 'write');
  const base = state.lk.settings.base_currency;
  let year = query.year || (query.month || todayStr()).slice(0, 4);
  let month = query.month || todayStr().slice(0, 7);
  let view = query.view === 'year' ? 'year' : 'month';
  let metric = 'margin';
  let sum = [];

  root.innerHTML = `${pageHead('MRG - freight, slot cost & margin', 'Month-wise selling rate, what the shipping line charges you for the slot, and what you keep on every box',
    `${canW ? `<button class="btn primary" data-act="load">${icon('upload', 16)} Load from Excel</button><button class="btn" data-act="add">${icon('plus', 16)} Add rate</button>` : ''}${shareBtn()}`)}
    <div class="mrg-top"><div class="yr"><button class="iconbtn" data-yr="-1" aria-label="Previous year">&lsaquo;</button><b data-year></b><button class="iconbtn" data-yr="1" aria-label="Next year">&rsaquo;</button></div>
      <div class="months" data-months></div>
      <div class="seg"><button data-view="month">Month</button><button data-view="year">Whole year</button></div></div>
    <div data-body></div>`;
  const body = $('[data-body]', root);

  function paintMonths() {
    $('[data-year]', root).textContent = year;
    const by = Object.fromEntries(sum.map((m) => [m.month, m]));
    $('[data-months]', root).innerHTML = MON.map((n, i) => {
      const m = `${year}-${String(i + 1).padStart(2, '0')}`, x = by[m];
      return `<button class="mchip ${view === 'month' && m === month ? 'on' : ''} ${x ? 'has' : ''}" data-month="${m}"><b>${n}</b><span>${x ? `${money(x.avg_margin)}` : '-'}</span></button>`;
    }).join('');
    for (const b of $('.seg', root).children) b.classList.toggle('on', b.dataset.view === view);
  }
  const loadSummary = async () => { sum = (await api('GET', `/mrg/summary?year=${year}`)).months; paintMonths(); };

  async function paintMonth() {
    const rows = await api('GET', `/mrg?month=${month}`);
    const sm = sum.find((x) => x.month === month);
    if (!rows.length) {
      const prev = shift(month, -1);
      body.innerHTML = `<div class="card"><div class="empty" style="padding:44px 16px"><div style="font-size:16px;color:var(--ink);font-weight:600;margin-bottom:6px">No rates for ${monthLabel(month)} yet</div>
        <div style="margin-bottom:16px">Set the month up in one click - you can adjust any rate afterwards.</div>
        ${canW ? `<div class="pill-row" style="justify-content:center"><button class="btn primary" data-act="roll">${icon('refresh', 16)} Copy from another month</button><button class="btn" data-act="tariffs">${icon('tag', 16)} Fill from the tariff book</button>
          <button class="btn" data-act="load">${icon('upload', 16)} Load from Excel</button><button class="btn" data-act="add">${icon('plus', 16)} Add a rate</button></div>` : 'Ask sales to enter this month\'s rates.'}</div></div>`;
      return;
    }
    const totBoxes = rows.reduce((a, r) => a + r.actual_boxes, 0);
    body.innerHTML = `<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:14px">
      ${[['Lanes', rows.length, ''], [`Avg freight (${base})`, money(sm ? sm.avg_freight : 0), ''], [`Avg slot cost (${base})`, money(sm ? sm.avg_slot : 0), ''], [`Avg margin / box (${base})`, money(sm ? sm.avg_margin : 0), marginCls(sm ? sm.avg_margin : 0)],
        ['Boxes shipped', int(totBoxes), ''], [`Margin earned (${base})`, money(sm ? sm.margin_total : 0), marginCls(sm ? sm.margin_total : 0)]].map(([k, v, c]) => `<div class="card stat"><div class="k">${k}</div><div class="v ${c}" style="font-size:22px">${v}</div></div>`).join('')}</div>
      <div class="card"><div class="card-h"><h2>${monthLabel(month)}</h2>${canW ? `<button class="btn sm" data-act="roll">${icon('refresh', 14)} Copy from another month</button><button class="btn sm" data-act="tariffs">${icon('tag', 14)} Fill from tariff book</button>` : ''}</div>
        ${tbl({ rows, cols: [
          { label: 'Lane', render: (r) => `<b>${esc(r.pol_name || 'Any port')} &rarr; ${esc(r.pod_name || 'Any port')}</b><div class="muted small">${esc(r.carrier_name || 'Any carrier')}</div>` }, { label: 'Type', render: (r) => `<b>${esc(r.type_code)}</b>` },
          { label: 'Freight rate', num: true, render: (r) => `${money(r.freight_rate)} <span class="muted small">${esc(r.currency)}</span>` }, { label: 'Slot cost', num: true, render: (r) => money(r.slot_cost) },
          { label: 'Margin / box', num: true, render: (r) => `<b class="${marginCls(r.margin)}">${money(r.margin)}</b><div class="small muted">${r.margin_pct != null ? r.margin_pct + '%' : ''}</div>` },
          { label: 'Committed slots', render: (r) => (r.committed_slots ? `<div class="small">${r.actual_boxes} of ${r.committed_slots}</div><div class="meter ${r.committed_used_pct < 60 ? 'low' : ''}"><i style="width:${Math.min(100, r.committed_used_pct)}%"></i></div>` : '<span class="muted small">-</span>') },
          { label: 'Shipped', num: true, render: (r) => (r.actual_boxes ? `${r.actual_boxes} <span class="muted small">boxes</span><div class="small ${marginCls(r.actual_margin)}">${money(r.actual_margin)} ${esc(r.currency)}</div>` : '<span class="muted">-</span>') },
          ...(canW ? [{ label: '', render: (r) => `<button class="btn sm ghost" data-edit="${r.id}">${icon('edit', 14)}</button><button class="btn sm ghost" data-del="${r.id}" title="Delete">&#10005;</button>` }] : [])] })}</div>`;
    body.__rows = rows;
  }

  async function paintYear() {
    const { rows } = await api('GET', `/mrg/matrix${qs({ year, metric })}`);
    const cell = (v) => (v == null ? '<td class="num muted">·</td>' : `<td class="num ${metric === 'margin' ? marginCls(v) : ''}">${metric === 'boxes' ? int(v) : money(v)}</td>`);
    body.innerHTML = `<div class="toolbar"><label class="muted small">Show <select data-metric>${METRICS.map(([k, l]) => `<option value="${k}" ${k === metric ? 'selected' : ''}>${l}</option>`).join('')}</select></label><span class="grow"></span><span class="muted small">Amounts in each lane's own currency</span></div>
      <div class="card">${rows.length ? `<div class="tbl-wrap"><table class="t compact"><thead><tr><th>Lane</th><th>Type</th>${MON.map((m) => `<th class="num">${m}</th>`).join('')}</tr></thead><tbody>
        ${rows.map((r) => `<tr><td><b>${esc(r.pol_name || 'Any')} &rarr; ${esc(r.pod_name || 'Any')}</b><div class="muted small">${esc(r.carrier_name || '')} ${esc(r.currency)}</div></td><td>${esc(r.type_code)}</td>${r.months.map(cell).join('')}</tr>`).join('')}</tbody></table></div>`
        : `<div class="empty">No rates in ${year} yet.</div>`}</div>
      ${sum.length ? `<div class="card"><div class="card-h"><h2>Month totals (${esc(base)})</h2></div>${tbl({ rows: sum, compact: true, cols: [{ label: 'Month', render: (m) => monthLabel(m.month) }, { label: 'Lanes', num: true, key: 'lanes' }, { label: 'Avg freight', num: true, render: (m) => money(m.avg_freight) },
        { label: 'Avg slot cost', num: true, render: (m) => money(m.avg_slot) }, { label: 'Avg margin / box', num: true, render: (m) => `<b class="${marginCls(m.avg_margin)}">${money(m.avg_margin)}</b>` }, { label: 'Boxes shipped', num: true, render: (m) => int(m.boxes) }, { label: 'Margin earned', num: true, render: (m) => `<b class="${marginCls(m.margin_total)}">${money(m.margin_total)}</b>` }] })}</div>` : ''}`;
  }
  const paint = async () => { try { await loadSummary(); if (view === 'year') await paintYear(); else await paintMonth(); } catch (e) { body.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; } };

  const fields = () => [
    { name: 'month', label: 'Month', type: 'select', noEmpty: true, options: () => MON.map((n, i) => [`${year}-${String(i + 1).padStart(2, '0')}`, `${n} ${year}`]), span: 1 },
    { name: 'carrier_id', label: 'Carrier / slot provider', type: 'combo', options: () => opts.parties('carrier'), span: 3 },
    { name: 'pol_id', label: 'Port of loading', type: 'combo', options: opts.ports, span: 2 }, { name: 'pod_id', label: 'Port of discharge', type: 'combo', options: opts.ports, span: 2 },
    { name: 'container_type_id', label: 'Container type', type: 'select', options: opts.types, noEmpty: true, required: true, span: 2 }, { name: 'currency', label: 'Currency', type: 'select', options: opts.currencies, noEmpty: true, span: 1 },
    { name: 'committed_slots', label: 'Committed slots', type: 'number', min: 0, span: 1, hint: 'optional' },
    { name: 'freight_rate', label: 'Freight rate (what you charge)', type: 'number', min: 0, step: 'any', required: true, span: 2 }, { name: 'slot_cost', label: 'Slot cost (what the line charges you)', type: 'number', min: 0, step: 'any', required: true, span: 2 },
    { name: 'remarks', label: 'Remarks', span: 4 }];
  root.addEventListener('click', (e) => {
    const y = e.target.closest('[data-yr]'); if (y) { year = String(Number(year) + Number(y.dataset.yr)); if (view === 'month') month = `${year}-${month.slice(5)}`; paint(); return; }
    const m = e.target.closest('[data-month]'); if (m) { month = m.dataset.month; view = 'month'; paint(); return; }
    const v = e.target.closest('[data-view]'); if (v) { view = v.dataset.view; paint(); }
  });
  root.addEventListener('change', (e) => { if (e.target.matches('[data-metric]')) { metric = e.target.value; paintYear(); } });
  on(root, 'click', '[data-act=load]', async () => { const r = await loadRates(); if (r) paint(); });
  on(root, 'click', '[data-act=add]', async () => {
    const r = await formModal({ title: 'Add freight rate & slot cost', size: 'wide', fields: fields(), values: { month, currency: 'USD', container_type_id: (state.lk.container_types.find((t) => t.code === '20GP') || {}).id }, onSubmit: (v) => api('POST', '/mrg', v) });
    if (r) { toast('Rate added', 'ok'); paint(); }
  });
  on(root, 'click', '[data-edit]', async (_e, el) => {
    const row = body.__rows.find((x) => String(x.id) === el.dataset.edit);
    const r = await formModal({ title: `Edit rate - ${row.pol_name || 'any'} to ${row.pod_name || 'any'} ${row.type_code}`, size: 'wide', fields: fields(), values: row, onSubmit: (v) => api('PUT', `/mrg/${row.id}`, v) });
    if (r) { toast('Saved', 'ok'); paint(); }
  });
  on(root, 'click', '[data-del]', async (_e, el) => { if (await confirmBox('Delete this rate?', { danger: true, ok: 'Delete' })) { try { await api('DELETE', `/mrg/${el.dataset.del}`); paint(); } catch (e) { toast(e.message, 'bad'); } } });
  on(root, 'click', '[data-act=roll]', async () => {
    const withData = sum.filter((x) => x.month !== month).map((x) => x.month);
    const from = withData.filter((m) => m < month).pop() || withData[0] || shift(month, -1);
    const r = await formModal({ title: `Set up ${monthLabel(month)} from another month`, size: 'narrow',
      intro: '<p class="muted" style="margin-top:0">Copies every lane and rate. Optionally change all freight rates and slot costs by a percentage. Rates that already exist in the month are never overwritten.</p>', fields: [
        { name: 'from', label: 'Copy from', type: 'select', noEmpty: true, options: () => [...new Set([...withData, from])].sort().map((m) => [m, monthLabel(m)]), span: 4 },
        { name: 'freight_pct', label: 'Freight change %', type: 'number', step: 'any', span: 2, hint: 'e.g. 5 or -3' }, { name: 'slot_pct', label: 'Slot cost change %', type: 'number', step: 'any', span: 2 }],
      values: { from, freight_pct: 0, slot_pct: 0 }, submitLabel: 'Copy rates', onSubmit: (v) => api('POST', '/mrg/roll-forward', { ...v, to: month }) });
    if (r) { toast(`${r.created} rate${r.created === 1 ? '' : 's'} copied${r.skipped ? `, ${r.skipped} already existed` : ''}`, 'ok'); paint(); }
  });
  on(root, 'click', '[data-act=tariffs]', async (_e, el) => {
    el.disabled = true;
    try { const r = await api('POST', '/mrg/from-tariffs', { month }); toast(`${r.created} lane${r.created === 1 ? '' : 's'} filled from the tariff book${r.missing_slot_cost ? ` - ${r.missing_slot_cost} still need a slot cost` : ''}`, r.missing_slot_cost ? '' : 'ok'); paint(); }
    catch (e) { toast(e.message, 'bad'); el.disabled = false; }
  });
  wireShare(root, () => ({ kind: 'mrg', params: view === 'month' ? { month } : { year }, title: 'Share MRG', what: view === 'month' ? `the ${monthLabel(month)} freight, slot cost and margin` : `the ${year} freight, slot cost and margin`, defaultSubject: `Freight & slot cost - ${view === 'month' ? monthLabel(month) : year}` }));
  await paint();
}
