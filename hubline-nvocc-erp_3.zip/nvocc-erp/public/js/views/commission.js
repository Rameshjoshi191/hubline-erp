import { api, state, esc, $, on, qs, tbl, pageHead, money, num, date, stmtBadge, formModal, confirmBox, toast, opts, can, kv, link, go, download } from '../core.js';
import { openStatementForm } from './agents.js';

export async function list(root, _p, query) {
  const canW = can('commission', 'write');
  const f = { status: query.status || '', agent_id: '' };
  root.innerHTML = `${pageHead('Agency commission', 'Commission statements calculated from each agent\'s agreement rules', canW ? '<button class="btn primary" data-act="new">+ New statement</button>' : '')}
    <div class="toolbar"><select data-f="agent_id"><option value="">All agents</option>${opts.parties('agent').map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="status"><option value="">All statuses</option>${['DRAFT', 'POSTED', 'CANCELLED'].map((s) => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${s[0] + s.slice(1).toLowerCase()}</option>`).join('')}</select></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/commissions' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'No commission statements yet.', rowAttr: (r) => `data-go="#/commissions/${r.id}"`, cols: [
      { label: 'Statement', render: (r) => `<b>${esc(r.stmt_no)}</b><div class="muted small">${esc(r.agreement_no || '')}</div>` }, { label: 'Agent', render: (r) => esc(r.agent_name) },
      { label: 'Period', render: (r) => `${date(r.period_from)} &ndash; ${date(r.period_to)}` }, { label: 'Shipments', num: true, key: 'line_count' },
      { label: 'Commission', num: true, render: (r) => `<b>${money(r.total)}</b> ${esc(r.currency)}` },
      { label: 'Paid?', render: (r) => r.status !== 'POSTED' ? '' : r.outstanding != null && Math.abs(r.outstanding) < 0.005 ? '<span class="badge ok">Paid</span>' : `<span class="badge warn">${money(r.outstanding)} due</span>` },
      { label: 'Status', render: (r) => stmtBadge(r.status) }] });
  };
  root.addEventListener('change', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; load(); } });
  on(root, 'click', '[data-act=new]', async () => {
    const agent = await formModal({ title: 'New commission statement', size: 'narrow', submitLabel: 'Next', fields: [{ name: 'agent_id', label: 'Agent', type: 'combo', options: () => opts.parties('agent'), required: true, span: 4 }],
      onSubmit: async (v) => { const ag = (await api('GET', `/agreements?agent_id=${v.agent_id}`)).filter((a) => a.effective_status === 'ACTIVE'); if (!ag.length) throw new Error('This agent has no active agency agreement. Activate one first.'); return { id: Number(v.agent_id), agreements: ag }; } });
    if (!agent) return;
    const r = await openStatementForm(agent.id, agent.agreements);
    if (r) go(`#/commissions/${r.id}`);
  });
  await load();
}

export async function detail(root, { id }) {
  const s = await api('GET', `/commissions/${id}`);
  const canW = can('commission', 'write');
  const draft = s.status === 'DRAFT';
  const acts = [];
  if (canW && draft) acts.push('<button class="btn primary" data-act="post">Approve &amp; post to agent ledger</button>', '<button class="btn danger" data-act="del">Delete draft</button>');
  if (canW && s.status === 'POSTED') acts.push('<button class="btn danger" data-act="cancel">Cancel statement</button>');
  acts.push(`<a class="btn" href="#/print/commission/${s.id}">Print</a>`, '<button class="btn" data-act="xlsx">Export Excel</button>');
  const warned = s.lines.filter((l) => l.note && draft);
  root.innerHTML = `${pageHead(`${esc(s.stmt_no)} ${stmtBadge(s.status)}`, `${link('#/agents/' + s.agent_id, s.agent_name)} &middot; ${esc(s.agreement_no || '')} &middot; sailings ${date(s.period_from)} &ndash; ${date(s.period_to)}`, acts.join(''), '<a href="#/commissions">Commission</a> /')}
    ${draft ? '<div class="alert info">This is a draft. Review each line - you can adjust an amount (with a note) or remove a shipment - then post it. Posting credits the agent\'s account so it appears on their statement of account.</div>' : ''}
    ${warned.length ? `<div class="alert warn"><b>${warned.length} line(s) need a look:</b> ${warned.map((l) => esc((l.hbl_no || l.booking_no) + ' - ' + l.note)).join('; ')}</div>` : ''}
    ${s.document ? `<div class="alert ${Math.abs(s.document.outstanding) < 0.005 ? 'ok' : ''}">Posted as ${link('#/documents/' + s.document.id, s.document.doc_no)} &middot; ${Math.abs(s.document.outstanding) < 0.005 ? 'fully paid' : `${money(s.document.outstanding)} ${esc(s.currency)} still to pay, due ${date(s.document.due_date)}`}</div>` : ''}
    <div class="card">${tbl({ rows: s.lines, empty: 'No lines.', cols: [
      { label: 'ETD', render: (l) => date(l.etd) }, { label: 'Shipment', render: (l) => `${link('#/shipments/' + l.shipment_id, l.hbl_no || l.booking_no)}<div class="muted small">${esc(l.pol_name || '?')} &rarr; ${esc(l.pod_name || '?')} &middot; ${esc(l.cargo_type)}</div>` },
      { label: 'Rule', render: (l) => `${esc(l.rule_name || '')}<div class="muted small">${esc(state.lk.commission_basis[l.basis] || l.basis || '')}</div>` },
      { label: 'Basis', num: true, render: (l) => l.base_qty != null ? num(l.base_qty) + (l.basis === 'PER_TEU' ? ' TEU' : l.basis === 'PER_CBM' ? ' CBM' : l.basis === 'PER_CONTAINER' ? ' cont.' : '') : l.base_amount != null ? money(l.base_amount) + ` <span class="muted small">${esc(state.lk.settings.base_currency)}</span>` : '' },
      { label: 'Rate', num: true, render: (l) => l.rate != null ? num(l.rate) + (l.basis && l.basis.startsWith('PERCENT') ? '%' : '') : '' },
      { label: 'Commission', num: true, render: (l) => `<b>${money(l.commission_amount)}</b>` }, { label: 'Note', render: (l) => `<span class="small ${l.note && draft ? 'neg' : 'muted'}">${esc(l.note || '')}</span>` },
      ...(canW && draft ? [{ label: '', render: (l) => `<button class="btn sm ghost" data-adj="${l.id}">Adjust</button><button class="btn sm ghost" data-rm="${l.id}" title="Remove from statement">&#10005;</button>` }] : [])],
      foot: `<tr><td colspan="${canW && draft ? 5 : 5}">Total commission (${esc(s.currency)})</td><td class="num">${money(s.total)}</td><td colspan="${canW && draft ? 2 : 1}"></td></tr>` })}</div>`;
  const refresh = () => go(`#/commissions/${id}`);
  const guard = async (fn, msg, back) => { try { await fn(); if (msg) toast(msg, 'ok'); back ? go(back) : refresh(); } catch (e) { toast(e.message, 'bad'); } };
  on(root, 'click', '[data-act=post]', async () => { if (await confirmBox(`Post ${s.stmt_no} for ${money(s.total)} ${s.currency}? It will be credited to ${s.agent_name}'s account.`, { ok: 'Post statement' })) guard(() => api('POST', `/commissions/${id}/post`), 'Statement posted'); });
  on(root, 'click', '[data-act=del]', async () => { if (await confirmBox('Delete this draft statement? The shipments become available again.', { danger: true, ok: 'Delete' })) guard(() => api('DELETE', `/commissions/${id}`), 'Draft deleted', '#/commissions'); });
  on(root, 'click', '[data-act=cancel]', async () => { if (await confirmBox('Cancel this posted statement? The agent credit is reversed and the shipments become available again. This only works if nothing has been paid against it.', { danger: true, ok: 'Cancel statement' })) guard(() => api('POST', `/commissions/${id}/cancel`), 'Statement cancelled'); });
  on(root, 'click', '[data-act=xlsx]', () => download(`/commissions/${id}/export`));
  on(root, 'click', '[data-adj]', async (_e, el) => {
    const l = s.lines.find((x) => String(x.id) === el.dataset.adj);
    const r = await formModal({ title: `Adjust commission - ${l.hbl_no || l.booking_no}`, size: 'narrow', submitLabel: 'Save', intro: `<p class="muted">Calculated ${money(l.commission_amount)} ${esc(s.currency)}. Give a reason for any manual change.</p>`,
      fields: [{ name: 'commission_amount', label: `Commission (${s.currency})`, type: 'number', required: true, min: 0, span: 4 }, { name: 'note', label: 'Reason / note', span: 4 }], values: { commission_amount: l.commission_amount, note: '' }, onSubmit: (v) => api('PUT', `/commissions/${id}/lines/${l.id}`, v) });
    if (r) refresh();
  });
  on(root, 'click', '[data-rm]', async (_e, el) => { if (await confirmBox('Remove this shipment from the statement? It can be picked up on a later statement.', { ok: 'Remove' })) guard(() => api('DELETE', `/commissions/${id}/lines/${el.dataset.rm}`)); });
}
