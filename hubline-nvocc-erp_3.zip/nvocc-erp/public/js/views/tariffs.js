import { api, state, esc, $, on, qs, tbl, pageHead, money, date, badge, formModal, confirmBox, toast, opts, can, go, debounce } from '../core.js';

const UNITS = [['PER_CONTAINER', 'Per container'], ['PER_TEU', 'Per TEU'], ['PER_CBM', 'Per CBM'], ['PER_TON', 'Per ton'], ['PER_BL', 'Per BL'], ['LUMPSUM', 'Lump sum']];
const unitLabel = Object.fromEntries(UNITS);
const fields = () => [
  { name: 'rate_type', label: 'Rate type', type: 'select', noEmpty: true, options: [['SELL', 'Sell - we charge'], ['BUY', 'Buy - we pay']], span: 1 },
  { name: 'party_id', label: 'Specific customer / agent / carrier', type: 'combo', options: () => opts.parties(), span: 3, hint: 'blank = general tariff' },
  { name: 'pol_id', label: 'Port of loading', type: 'combo', options: opts.ports, span: 2, hint: 'blank = any' }, { name: 'pod_id', label: 'Port of discharge', type: 'combo', options: opts.ports, span: 2, hint: 'blank = any' },
  { name: 'cargo_type', label: 'Cargo', type: 'select', noEmpty: true, options: [['FCL', 'FCL'], ['LCL', 'LCL'], ['ANY', 'Any']] }, { name: 'container_type_id', label: 'Container type', type: 'select', options: opts.types, empty: 'Any', span: 1 },
  { name: 'charge_code_id', label: 'Charge', type: 'select', noEmpty: true, required: true, options: opts.charges, span: 2 },
  { name: 'rate', label: 'Rate', type: 'number', required: true, min: 0 }, { name: 'currency', label: 'Currency', type: 'select', noEmpty: true, options: opts.currencies }, { name: 'unit', label: 'Unit', type: 'select', noEmpty: true, options: UNITS },
  { name: 'valid_from', label: 'Valid from', type: 'date' }, { name: 'valid_to', label: 'Valid to', type: 'date' }, { name: 'active', label: 'Active', type: 'checkbox' },
  { name: 'remarks', label: 'Remarks', span: 4 },
];

export async function list(root) {
  const canW = can('tariffs', 'write');
  const f = { rate_type: 'SELL', q: '', current: '1' };
  root.innerHTML = `${pageHead('Rates / tariffs', 'Sell rates for customers and agents, buy rates from carriers and vendors', canW ? '<button class="btn primary" data-act="new">+ New rate</button>' : '')}
    <div class="tabs"><a data-rt="SELL" class="on">Sell rates</a><a data-rt="BUY">Buy rates</a></div>
    <div class="toolbar"><input type="text" class="search" placeholder="Search port, charge, customer…" data-f="q"><label class="muted small"><input type="checkbox" data-f="current" checked> Currently valid only</label></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/tariffs' + qs({ ...f, active: '1' }));
    out.innerHTML = tbl({ rows, empty: 'No rates found.', cols: [
      { label: 'Lane', render: (r) => `${esc(r.pol_name || 'Any')} &rarr; ${esc(r.pod_name || 'Any')}` }, { label: 'Cargo', render: (r) => badge(r.cargo_type) + (r.container_type_code ? ' ' + badge(r.container_type_code, 'info') : '') },
      { label: 'Charge', render: (r) => `<b>${esc(r.charge_code)}</b><div class="muted small">${esc(r.charge_name)}</div>` }, { label: 'Applies to', render: (r) => esc(r.party_name || 'General') },
      { label: 'Rate', num: true, render: (r) => `<b>${money(r.rate)}</b> ${esc(r.currency)}<div class="muted small">${esc(unitLabel[r.unit] || r.unit)}</div>` },
      { label: 'Valid', render: (r) => r.valid_from || r.valid_to ? `<span class="small">${date(r.valid_from) || '…'} &ndash; ${date(r.valid_to) || '…'}</span>` : '<span class="muted small">always</span>' },
      ...(canW ? [{ label: '', render: (r) => `<button class="btn sm ghost" data-edit="${r.id}">Edit</button><button class="btn sm ghost" data-del="${r.id}" title="Delete">&#10005;</button>` }] : [])] });
    out._rows = rows;
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.type === 'checkbox' ? (e.target.checked ? '1' : '') : e.target.value; reload(); } });
  on(root, 'click', '[data-rt]', (_e, el) => { f.rate_type = el.dataset.rt; root.querySelectorAll('[data-rt]').forEach((a) => a.classList.toggle('on', a === el)); load(); });
  on(root, 'click', '[data-act=new]', async () => { const r = await formModal({ title: 'New rate', size: 'wide', fields: fields(), values: { rate_type: f.rate_type, cargo_type: 'FCL', currency: 'USD', unit: 'PER_CONTAINER', active: 1 }, onSubmit: (v) => api('POST', '/tariffs', v) }); if (r) { toast('Rate added', 'ok'); load(); } });
  on(root, 'click', '[data-edit]', async (_e, el) => { const t = out._rows.find((x) => String(x.id) === el.dataset.edit); const r = await formModal({ title: 'Edit rate', size: 'wide', fields: fields(), values: t, onSubmit: (v) => api('PUT', `/tariffs/${t.id}`, v) }); if (r) { toast('Saved', 'ok'); load(); } });
  on(root, 'click', '[data-del]', async (_e, el) => { if (await confirmBox('Delete this rate?', { danger: true, ok: 'Delete' })) { try { await api('DELETE', `/tariffs/${el.dataset.del}`); load(); } catch (e) { toast(e.message, 'bad'); } } });
  await load();
}
