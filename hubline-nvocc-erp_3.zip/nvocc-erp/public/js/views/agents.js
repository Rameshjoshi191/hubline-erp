import { api, state, esc, $, $$, on, qs, tbl, pageHead, money, num, date, badge, shipBadge, agrBadge, stmtBadge, formModal, openModal, confirmBox, toast, opts, can, kv, link, go, debounce, balancesHtml, signed, docType } from '../core.js';
import { openPartyForm } from './parties.js';

// ------------------------------------------------------------------ agents list
export async function list(root) {
  const canW = can('parties', 'write');
  root.innerHTML = `${pageHead('Agents', 'Overseas agents, their agreements and running balances', canW ? '<button class="btn primary" data-act="new">+ New agent</button>' : '')}
    <div class="toolbar"><input type="text" class="search" placeholder="Search agent name, code, country…" data-f="q"></div><div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async (q = '') => {
    const rows = await api('GET', '/agents' + qs({ q }));
    out.innerHTML = tbl({ rows, click: true, empty: 'No agents yet. Create one to start an agency agreement.', rowAttr: (r) => `data-go="#/agents/${r.id}"`, cols: [
      { label: 'Agent', render: (r) => `<b>${esc(r.name)}</b>${r.active ? '' : ' ' + badge('Inactive', 'bad')}<div class="muted small mono">${esc(r.code)}</div>` },
      { label: 'Country', render: (r) => esc([r.city, r.country].filter(Boolean).join(', ')) }, { label: 'Type', render: (r) => esc(r.agent_type || '') }, { label: 'Territory', render: (r) => esc(r.agent_territory || '') },
      { label: 'Agreement', render: (r) => r.active_agreement ? `<span class="mono">${esc(r.active_agreement)}</span><div class="muted small">to ${date(r.agreement_end) || 'open-ended'}</div>` : badge('No active agreement', 'warn') },
      { label: 'Shipments', num: true, key: 'shipment_count' }, { label: 'Balance', num: true, render: (r) => balancesHtml(r.balances) }] });
  };
  root.addEventListener('input', debounce((e) => { if (e.target.dataset.f) load(e.target.value).catch((x) => toast(x.message, 'bad')); }));
  on(root, 'click', '[data-act=new]', async () => { const r = await openPartyForm(null, { is_agent: 1, agent_type: 'BOTH' }); if (r) { toast('Agent created', 'ok'); go(`#/agents/${r.id}`); } });
  await load();
}

// ------------------------------------------------------------------ agent page
export async function detail(root, { id }) {
  const [p, agreements, stmts, ships] = await Promise.all([api('GET', `/parties/${id}`), api('GET', `/agreements?agent_id=${id}`),
    can('commission', 'read') ? api('GET', `/commissions?agent_id=${id}`) : [], api('GET', `/shipments?agent_id=${id}&limit=12`)]);
  const canW = can('agreements', 'write'), canC = can('commission', 'write');
  const open = can('finance', 'read') ? await api('GET', `/parties/${id}/open-items`) : [];
  root.innerHTML = `${pageHead(`${esc(p.name)} ${p.active ? '' : badge('Inactive', 'bad')}`, `Agent <span class="mono">${esc(p.code)}</span> &middot; ${esc([p.city, p.country].filter(Boolean).join(', '))}`,
    `${can('parties', 'write') ? '<button class="btn" data-act="edit">Edit profile</button>' : ''}${canW ? '<button class="btn primary" data-act="agr">+ New agreement</button>' : ''}${can('soa', 'read') ? `<a class="btn" href="#/soa?party_id=${id}">Statement of account</a>` : ''}`, '<a href="#/agents">Agents</a> /')}
    <div class="split"><div>
      <div class="card"><div class="card-h"><h2>Agency agreements</h2></div>${tbl({ rows: agreements, click: true, empty: 'No agreements yet.', rowAttr: (a) => `data-go="#/agreements/${a.id}"`, cols: [
        { label: 'Agreement', render: (a) => `<b>${esc(a.agreement_no)}</b><div class="muted small">${esc(a.title || '')}</div>` }, { label: 'Period', render: (a) => `${date(a.start_date)} &ndash; ${a.end_date ? date(a.end_date) : 'open'}` },
        { label: 'Rules', num: true, key: 'rule_count' }, { label: 'Status', render: (a) => agrBadge(a.effective_status) }] })}</div>
      ${can('commission', 'read') ? `<div class="card"><div class="card-h"><h2>Commission statements</h2>${canC && agreements.some((a) => a.effective_status === 'ACTIVE') ? '<button class="btn sm primary" data-act="stmt">+ New statement</button>' : ''}</div>${tbl({ rows: stmts, click: true, empty: 'No commission statements yet.', rowAttr: (s) => `data-go="#/commissions/${s.id}"`, cols: [
        { label: 'Statement', render: (s) => `<b>${esc(s.stmt_no)}</b>` }, { label: 'Period', render: (s) => `${date(s.period_from)} &ndash; ${date(s.period_to)}` }, { label: 'Total', num: true, render: (s) => `${money(s.total)} ${esc(s.currency)}` }, { label: 'Status', render: (s) => stmtBadge(s.status) }] })}</div>` : ''}
      <div class="card"><div class="card-h"><h2>Shipments nominated</h2><a class="btn sm" href="#/shipments?agent_id=${id}">All</a></div>${tbl({ rows: ships, click: true, compact: true, empty: 'No shipments yet.', rowAttr: (s) => `data-go="#/shipments/${s.id}"`, cols: [
        { label: 'Booking', render: (s) => `<b>${esc(s.booking_no)}</b>` }, { label: 'Route', render: (s) => `${esc(s.pol_name || '?')} &rarr; ${esc(s.pod_name || '?')}` }, { label: 'ETD', render: (s) => date(s.etd) }, { label: 'Cargo', key: 'cargo_type' }, { label: 'Status', render: (s) => shipBadge(s.status) }] })}</div>
    </div><div>
      ${p.balances ? `<div class="card"><div class="card-h"><h2>Balance with agent</h2></div><div class="card-b">${balancesHtml(p.balances)}<div class="muted small" style="margin-top:6px">Positive = agent owes us; negative = we owe the agent</div></div></div>` : ''}
      <div class="card"><div class="card-h"><h2>Profile</h2></div><div class="card-b">${kv([['Agent type', esc(p.agent_type)], ['Network', esc(p.agent_network)], ['Territory', esc(p.agent_territory)], ['Agent since', date(p.agent_since)], ['Contact', esc(p.contact_person)],
        ['Email', p.email ? `<a href="mailto:${esc(p.email)}">${esc(p.email)}</a>` : ''], ['Phone', esc(p.phone)], ['Address', esc([p.address, p.city, p.country].filter(Boolean).join(', '))], ['Credit', `${p.credit_days} days${p.credit_limit ? ', limit ' + money(p.credit_limit) : ''}`]])}</div></div>
      ${open.length ? `<div class="card"><div class="card-h"><h2>Open items</h2></div>${tbl({ rows: open, compact: true, cols: [{ label: 'Ref', render: (o) => `${o.kind === 'DOC' ? link('#/documents/' + o.id, o.ref) : esc(o.ref)}<div class="muted small">${esc(o.type)}</div>` }, { label: 'Amount', num: true, render: (o) => `${signed(o.signed)} <span class="muted small">${esc(o.currency)}</span>` }] })}</div>` : ''}
    </div></div>`;
  on(root, 'click', '[data-act=edit]', async () => { const r = await openPartyForm(p); if (r) { toast('Saved', 'ok'); go(`#/agents/${id}`); } });
  on(root, 'click', '[data-act=agr]', async () => { const r = await openAgreementForm(null, { agent_id: Number(id) }); if (r) { toast(`${r.agreement_no} created`, 'ok'); go(`#/agreements/${r.id}`); } });
  on(root, 'click', '[data-act=stmt]', async () => { const r = await openStatementForm(Number(id), agreements.filter((a) => a.effective_status === 'ACTIVE')); if (r) { go(`#/commissions/${r.id}`); } });
}

export async function openStatementForm(agentId, agreements) {
  const t = new Date(); const first = new Date(Date.UTC(t.getFullYear(), t.getMonth() - 1, 1)).toISOString().slice(0, 10); const last = new Date(Date.UTC(t.getFullYear(), t.getMonth(), 0)).toISOString().slice(0, 10);
  return formModal({ title: 'New commission statement', size: '', submitLabel: 'Calculate & create draft',
    intro: '<p class="muted">Every sailed shipment nominated by this agent in the period that is not already on a statement is calculated using the agreement\'s commission rules.</p>',
    fields: [{ name: 'agreement_id', label: 'Agreement', type: 'select', options: agreements.map((a) => [a.id, `${a.agreement_no} (${a.currency})`]), noEmpty: true, span: 4 },
      { name: 'from', label: 'Sailings from', type: 'date', span: 2, required: true }, { name: 'to', label: 'to', type: 'date', span: 2, required: true }],
    values: { agreement_id: agreements[0] && agreements[0].id, from: first, to: last },
    onSubmit: async (v) => { const r = await api('POST', '/commissions', { agent_id: agentId, ...v }); if (r.skipped && r.skipped.length) toast(`${r.skipped.length} shipment(s) were skipped - open the statement to see why.`, ''); return r; } });
}

// ------------------------------------------------------------------ agreements
const agreementFields = (lockAgent) => [
  { section: 'Agreement' },
  { name: 'agent_id', label: 'Agent', type: 'combo', options: () => opts.parties('agent'), required: true, span: 2, disabled: lockAgent }, { name: 'title', label: 'Title', span: 2 },
  { name: 'status', label: 'Status', type: 'select', noEmpty: true, options: [['DRAFT', 'Draft'], ['ACTIVE', 'Active'], ['TERMINATED', 'Terminated']] },
  { name: 'signed_date', label: 'Signed on', type: 'date' }, { name: 'start_date', label: 'Effective from', type: 'date' }, { name: 'end_date', label: 'Expires on', type: 'date', hint: 'blank = open-ended' },
  { name: 'auto_renew', label: 'Renews automatically', type: 'checkbox' }, { name: 'notice_days', label: 'Notice period (days)', type: 'number', min: 0 },
  { name: 'territory', label: 'Territory', span: 2 }, { name: 'exclusivity', label: 'Exclusivity', placeholder: 'Non-exclusive / Exclusive / Sole agent' },
  { section: 'Commercial terms' },
  { name: 'payment_terms_days', label: 'Payment terms (days)', type: 'number', min: 0 }, { name: 'credit_limit', label: 'Credit limit', type: 'number', min: 0 },
  { name: 'currency', label: 'Currency', type: 'select', options: opts.currencies, noEmpty: true }, { name: 'governing_law', label: 'Governing law', span: 1 },
  { name: 'commission_summary', label: 'Commission - plain-language summary', type: 'textarea', rows: 2, span: 4, hint: 'printed on the agreement; the calculation uses the rules you add below' },
  { name: 'notes', label: 'Internal notes', type: 'textarea', rows: 2, span: 4 },
];
export async function openAgreementForm(a, defaults = {}) {
  const values = a || { status: 'DRAFT', notice_days: 60, payment_terms_days: 30, currency: 'USD', credit_limit: 0, auto_renew: 0, ...defaults };
  return formModal({ title: a ? `Edit ${a.agreement_no}` : 'New agency agreement', size: 'wide', fields: agreementFields(!!a), values, submitLabel: a ? 'Save' : 'Create',
    onSubmit: (v) => { if (a) delete v.agent_id; return a ? api('PUT', `/agreements/${a.id}`, v) : api('POST', '/agreements', v); } });
}

export async function agreements(root, _p, query) {
  const f = { status: query.status || '', q: '' };
  root.innerHTML = `${pageHead('Agency agreements', 'Terms, validity and commission rules for every agent', can('agreements', 'write') ? '<button class="btn primary" data-act="new">+ New agreement</button>' : '')}
    <div class="toolbar"><input type="text" class="search" placeholder="Search agreement no., agent, title…" data-f="q"><select data-f="status"><option value="">All statuses</option>${['DRAFT', 'ACTIVE', 'EXPIRED', 'TERMINATED'].map((s) => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${s[0] + s.slice(1).toLowerCase()}</option>`).join('')}</select></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/agreements' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'No agreements found.', rowAttr: (a) => `data-go="#/agreements/${a.id}"`, cols: [
      { label: 'Agreement', render: (a) => `<b>${esc(a.agreement_no)}</b><div class="muted small">${esc(a.title || '')}</div>` }, { label: 'Agent', render: (a) => esc(a.agent_name) },
      { label: 'Period', render: (a) => `${date(a.start_date)} &ndash; ${a.end_date ? date(a.end_date) : 'open'}` },
      { label: 'Expiry', render: (a) => a.days_left == null ? '' : a.effective_status === 'ACTIVE' ? `<span class="${a.days_left <= 60 ? 'neg' : ''}">${a.days_left} days</span>` : '' },
      { label: 'Territory', render: (a) => esc(a.territory || '') }, { label: 'Rules', num: true, key: 'rule_count' }, { label: 'Status', render: (a) => agrBadge(a.effective_status) }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  on(root, 'click', '[data-act=new]', async () => { const r = await openAgreementForm(null); if (r) { toast(`${r.agreement_no} created`, 'ok'); go(`#/agreements/${r.id}`); } });
  await load();
}

const ruleFields = () => [
  { name: 'name', label: 'Rule name', required: true, span: 2, placeholder: 'e.g. FCL - USD 15 per TEU' },
  { name: 'basis', label: 'Calculated as', type: 'select', noEmpty: true, required: true, options: () => Object.entries(state.lk.commission_basis), span: 2 },
  { name: 'rate', label: 'Rate', type: 'number', required: true, min: 0, hint: 'amount, or % for the % bases' }, { name: 'currency', label: 'Currency', type: 'select', options: opts.currencies, noEmpty: true, hint: 'amount currency' },
  { name: 'min_amount', label: 'Minimum per shipment', type: 'number', min: 0 }, { name: 'max_amount', label: 'Maximum per shipment', type: 'number', min: 0 },
  { section: 'Applies to (leave blank for everything)' },
  { name: 'cargo_type', label: 'Cargo', type: 'select', noEmpty: true, options: [['ANY', 'FCL & LCL'], ['FCL', 'FCL only'], ['LCL', 'LCL only']] },
  { name: 'pol_id', label: 'Port of loading', type: 'combo', options: opts.ports, span: 1 }, { name: 'pod_id', label: 'Port of discharge', type: 'combo', options: opts.ports, span: 1 },
  { name: 'active', label: 'Active', type: 'checkbox' }, { name: 'valid_from', label: 'Sailing from', type: 'date' }, { name: 'valid_to', label: 'Sailing to', type: 'date' },
];
const rateText = (r) => (r.basis.startsWith('PERCENT') ? `${num(r.rate)}%` : `${money(r.rate)} ${esc(r.currency)}`);

export async function agreement(root, { id }) {
  const a = await api('GET', `/agreements/${id}`);
  const canW = can('agreements', 'write');
  const acts = [];
  if (canW) {
    if (a.status === 'DRAFT') acts.push('<button class="btn primary" data-st="ACTIVE">Activate</button>');
    if (a.status === 'ACTIVE') acts.push('<button class="btn danger" data-st="TERMINATED">Terminate</button>');
    acts.push('<button class="btn" data-act="edit">Edit terms</button>', '<button class="btn" data-act="renew">Renew</button>');
    if (a.status === 'DRAFT') acts.push('<button class="btn danger" data-act="del">Delete</button>');
  }
  acts.push(`<a class="btn" href="#/print/agreement/${a.id}">Print agreement</a>`);
  const daysLeft = a.end_date ? Math.round((new Date(a.end_date) - new Date(new Date().toISOString().slice(0, 10))) / 86400000) : null;
  root.innerHTML = `${pageHead(`${esc(a.agreement_no)} ${agrBadge(a.effective_status)}`, `${esc(a.title || 'Agency agreement')} &middot; ${link('#/agents/' + a.agent_id, a.agent_name)}`, acts.join(''), '<a href="#/agreements">Agreements</a> /')}
    ${a.effective_status === 'EXPIRED' ? '<div class="alert bad">This agreement has expired. New commission statements cannot be raised for sailings after the end date. Renew it to continue.</div>' : ''}
    ${a.effective_status === 'ACTIVE' && daysLeft != null && daysLeft <= 60 ? `<div class="alert warn">Expires in ${daysLeft} day(s) on ${date(a.end_date)}${a.auto_renew ? ' (set to renew automatically - confirm in writing)' : ''}.</div>` : ''}
    <div class="grid g2"><div class="card"><div class="card-h"><h2>Key terms</h2></div><div class="card-b">${kv([['Agent', link('#/agents/' + a.agent_id, a.agent_name)], ['Period', `${date(a.start_date) || '?'} &ndash; ${a.end_date ? date(a.end_date) : 'open-ended'}`], ['Signed', date(a.signed_date)],
      ['Auto-renew', a.auto_renew ? 'Yes' : 'No'], ['Notice', `${a.notice_days} days`], ['Territory', esc(a.territory)], ['Exclusivity', esc(a.exclusivity)]])}</div></div>
      <div class="card"><div class="card-h"><h2>Financial terms</h2></div><div class="card-b">${kv([['Payment terms', `${a.payment_terms_days} days`], ['Credit limit', a.credit_limit ? `${money(a.credit_limit)} ${esc(a.currency)}` : 'None'], ['Currency', esc(a.currency)], ['Governing law', esc(a.governing_law)], ['Commission', esc(a.commission_summary)], ['Notes', esc(a.notes)]])}</div></div></div>
    <div class="card"><div class="card-h"><h2>Commission rules</h2>${canW ? '<button class="btn sm primary" data-act="rule">+ Add rule</button>' : ''}</div>
      <div class="card-b muted small" style="border-bottom:1px solid var(--line)">For each sailed shipment the most specific active rule wins (route beats cargo type beats "everything"). These rules drive the commission statements.</div>
      ${tbl({ rows: a.rules, empty: 'No commission rules yet - add at least one so statements can be calculated.', cols: [
        { label: 'Rule', render: (r) => `<b>${esc(r.name)}</b>${r.active ? '' : ' ' + badge('Inactive', 'bad')}` }, { label: 'Basis', render: (r) => esc(state.lk.commission_basis[r.basis] || r.basis) }, { label: 'Rate', num: true, render: rateText },
        { label: 'Applies to', render: (r) => `<span class="small">${esc([r.cargo_type === 'ANY' ? 'FCL & LCL' : r.cargo_type, r.pol_name && 'from ' + r.pol_name, r.pod_name && 'to ' + r.pod_name].filter(Boolean).join(', '))}</span>` },
        { label: 'Min / max', num: true, render: (r) => [r.min_amount != null ? money(r.min_amount) : '', r.max_amount != null ? money(r.max_amount) : ''].filter(Boolean).join(' / ') || '' },
        ...(canW ? [{ label: '', render: (r) => `<button class="btn sm ghost" data-editrule="${r.id}">Edit</button><button class="btn sm ghost" data-delrule="${r.id}" title="Delete">&#10005;</button>` }] : [])] })}</div>
    <div class="card"><div class="card-h"><h2>Terms &amp; clauses</h2>${canW ? `<button class="btn sm" data-act="clauses">Edit clauses</button>${a.clauses.length ? '' : '<button class="btn sm primary" data-act="std">Insert standard clauses</button>'}` : ''}</div>
      <div class="card-b">${a.clauses.length ? a.clauses.map((c, i) => `<div style="margin-bottom:14px"><b>${i + 1}. ${esc(c.title)}</b><div style="white-space:pre-line;margin-top:2px">${esc(c.body)}</div></div>`).join('') : '<div class="muted">No clauses recorded yet. Insert the standard set as a starting point and edit it with your legal adviser.</div>'}</div></div>
    ${a.statements.length ? `<div class="card"><div class="card-h"><h2>Commission statements under this agreement</h2></div>${tbl({ rows: a.statements, click: true, rowAttr: (s) => `data-go="#/commissions/${s.id}"`, cols: [{ label: 'Statement', key: 'stmt_no' }, { label: 'Period', render: (s) => `${date(s.period_from)} &ndash; ${date(s.period_to)}` }, { label: 'Total', num: true, render: (s) => `${money(s.total)} ${esc(s.currency)}` }, { label: 'Status', render: (s) => stmtBadge(s.status) }] })}</div>` : ''}`;

  const refresh = () => go(`#/agreements/${id}`);
  const guard = async (fn, msg) => { try { await fn(); if (msg) toast(msg, 'ok'); refresh(); } catch (e) { toast(e.message, 'bad'); } };
  on(root, 'click', '[data-st]', async (_e, el) => {
    const st = el.dataset.st;
    if (!(await confirmBox(st === 'ACTIVE' ? 'Activate this agreement? Commission can then be calculated under it.' : 'Terminate this agreement? Commission is only payable on shipments sailed before termination.', { danger: st === 'TERMINATED', ok: st === 'ACTIVE' ? 'Activate' : 'Terminate' }))) return;
    guard(() => api('PUT', `/agreements/${id}`, { status: st }), st === 'ACTIVE' ? 'Agreement activated' : 'Agreement terminated');
  });
  on(root, 'click', '[data-act=edit]', async () => { const r = await openAgreementForm(a); if (r) { toast('Saved', 'ok'); refresh(); } });
  on(root, 'click', '[data-act=del]', async () => { if (await confirmBox('Delete this draft agreement?', { danger: true, ok: 'Delete' })) { try { await api('DELETE', `/agreements/${id}`); go('#/agreements'); } catch (e) { toast(e.message, 'bad'); } } });
  on(root, 'click', '[data-act=renew]', async () => {
    const r = await formModal({ title: 'Renew agreement', size: 'narrow', submitLabel: 'Create renewal draft', intro: '<p class="muted">Creates a new draft starting the day after this one ends, with the same terms, clauses and commission rules.</p>', fields: [{ name: 'years', label: 'Renew for (years)', type: 'number', min: 1, max: 10 }], values: { years: 1 }, onSubmit: (v) => api('POST', `/agreements/${id}/renew`, v) });
    if (r) { toast(`${r.agreement_no} created`, 'ok'); go(`#/agreements/${r.id}`); }
  });
  on(root, 'click', '[data-act=rule]', async () => { const r = await formModal({ title: 'Add commission rule', size: 'wide', fields: ruleFields(), values: { basis: 'PER_TEU', cargo_type: 'ANY', currency: a.currency, active: 1 }, onSubmit: (v) => api('POST', `/agreements/${id}/rules`, v) }); if (r) { toast('Rule added', 'ok'); refresh(); } });
  on(root, 'click', '[data-editrule]', async (_e, el) => { const rule = a.rules.find((x) => String(x.id) === el.dataset.editrule); const r = await formModal({ title: 'Edit commission rule', size: 'wide', fields: ruleFields(), values: rule, onSubmit: (v) => api('PUT', `/commission-rules/${rule.id}`, v) }); if (r) { toast('Saved', 'ok'); refresh(); } });
  on(root, 'click', '[data-delrule]', async (_e, el) => { if (await confirmBox('Delete this commission rule? Statements already created keep their calculated amounts.', { danger: true, ok: 'Delete rule' })) guard(() => api('DELETE', `/commission-rules/${el.dataset.delrule}`), 'Rule deleted'); });
  on(root, 'click', '[data-act=std]', () => guard(() => api('POST', `/agreements/${id}/standard-clauses`, {}), 'Standard clauses inserted - please review them'));
  on(root, 'click', '[data-act=clauses]', () => editClauses(a, refresh));
}

function editClauses(a, done) {
  const row = (c = { title: '', body: '' }) => `<div class="card" data-row style="padding:12px;margin-bottom:10px"><label class="f"><span>Clause title</span><input type="text" name="title" value="${esc(c.title)}"></label>
    <label class="f" style="margin-top:8px"><span>Text</span><textarea name="body" rows="4">${esc(c.body)}</textarea></label>
    <div style="margin-top:8px;display:flex;gap:6px"><button type="button" class="btn sm" data-up>&uarr; Up</button><button type="button" class="btn sm" data-down>&darr; Down</button><button type="button" class="btn sm danger" data-rm>Remove</button></div></div>`;
  const h = openModal({ title: `Clauses - ${a.agreement_no}`, size: 'wide', body: `<div class="alert bad hidden" data-err></div><div data-rows>${a.clauses.map(row).join('')}</div><button type="button" class="btn" data-add>+ Add clause</button>`,
    footer: '<button class="btn" data-close>Cancel</button><button class="btn primary" data-save>Save clauses</button>' });
  const box = h.$('[data-rows]');
  h.$('[data-add]').addEventListener('click', () => { box.insertAdjacentHTML('beforeend', row()); box.lastElementChild.querySelector('input').focus(); });
  h.el.addEventListener('click', (e) => {
    const r = e.target.closest('[data-row]'); if (!r) return;
    if (e.target.closest('[data-rm]')) r.remove();
    if (e.target.closest('[data-up]') && r.previousElementSibling) box.insertBefore(r, r.previousElementSibling);
    if (e.target.closest('[data-down]') && r.nextElementSibling) box.insertBefore(r.nextElementSibling, r);
  });
  h.$('[data-save]').addEventListener('click', async () => {
    const clauses = $$('[data-row]', h.el).map((r) => ({ title: r.querySelector('[name=title]').value, body: r.querySelector('[name=body]').value }));
    try { await api('PUT', `/agreements/${a.id}/clauses`, { clauses }); h.close(true); toast('Clauses saved', 'ok'); done(); }
    catch (e) { const er = h.$('[data-err]'); er.textContent = e.message; er.classList.remove('hidden'); }
  });
}
