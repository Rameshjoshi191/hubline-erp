// Vessel schedules: load from Excel or straight from a shipping line's web link, keep them fresh automatically, and see what a date change does to your bookings.
import { api, state, esc, $, on, qs, tbl, pageHead, date, badge, formModal, confirmBox, toast, opts, can, link, go, int, debounce, dt, todayStr, addDaysStr } from '../core.js';
import { icon } from '../icons.js';
import { importWizard, tilesFor } from '../importui.js';
import { shareBtn, wireShare } from '../share.js';

const FIELD = { etd: 'ETD', eta: 'ETA', cutoff_date: 'Cut-off' };
const SRC = { MANUAL: ['Typed in', ''], IMPORT: ['Excel', 'info'], LINK: ['Web link', 'ok'] };
const carrierOpts = () => opts.parties('carrier');

// ---------------------------------------------------------------- the wizard (Excel / CSV / paste + web link)
function linkTab(pane, ctx, sources) {
  const carrierSel = `<select data-carrier><option value="">- carrier is in the file / not needed -</option>${carrierOpts().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>`;
  pane.innerHTML = `<p style="margin-top:0">Paste the link to the shipping line's schedule. It can be a link to an <b>Excel / CSV file</b> or to a <b>web page that shows the schedule as a table</b>.</p>
    <div class="form-grid" style="grid-template-columns:1fr">
      <label class="f"><span>Web link</span><input type="text" data-url placeholder="https://www.example-line.com/schedules/latest.xlsx"></label>
      <label class="f"><span>Shipping line <em class="hint">(if the schedule does not list it)</em></span>${carrierSel}</label>
      <label class="chk" style="padding-top:0"><input type="checkbox" data-save> <span>Remember this link - refresh it with one click, or automatically every day</span></label>
      <label class="f hidden" data-namewrap><span>Name for this link</span><input type="text" data-name placeholder="e.g. MSC Gulf - India schedule"></label></div>
    <div class="pill-row" style="margin-top:12px"><button class="btn primary" data-read>${icon('link', 16)} Read the schedule</button></div>
    <div data-cands></div>
    ${sources.length ? `<div class="wiz-opt" style="margin-top:16px"><div class="wiz-opt-h">Your saved links</div>${sources.map((s) => `<div class="src-row"><div class="grow"><b>${esc(s.name)}</b><div class="muted small">${esc(s.url)}</div></div><button class="btn sm" data-usesrc="${s.id}">Read now</button></div>`).join('')}</div>` : ''}
    <div class="alert info" style="margin-top:14px">${icon('info', 15)} Some carrier sites draw their schedule with JavaScript and cannot be read from a link. If that happens we will tell you - look for a <b>Download (Excel / CSV)</b> button on their site and paste that link instead, or upload the downloaded file.</div>`;
  const q = (s) => pane.querySelector(s);
  q('[data-save]').addEventListener('change', (e) => q('[data-namewrap]').classList.toggle('hidden', !e.target.checked));
  const fetchUrl = async (url, extra = {}) => {
    const btn = q('[data-read]'); btn.disabled = true; q('[data-cands]').innerHTML = '';
    try {
      let source_id = extra.source_id || null;
      if (!source_id && q('[data-save]').checked) {
        const name = q('[data-name]').value.trim() || url.replace(/^https?:\/\//, '').slice(0, 40);
        source_id = (await api('POST', '/schedules/sources', { name, url, carrier_id: q('[data-carrier]').value || null, auto_refresh: 1 })).id;
        toast('Link saved - it will refresh automatically every day', 'ok');
      }
      const r = await api('POST', '/schedules/import/fetch', { url, carrier_id: extra.carrier_id || q('[data-carrier]').value || '', source_id });
      if (r.candidates) {
        q('[data-cands]').innerHTML = `<div class="alert warn" style="margin-top:12px"><b>This page links to several files.</b> Choose the one you want:</div>${r.candidates.map((u) => `<div class="src-row"><div class="grow small">${esc(u)}</div><button class="btn sm" data-cand="${esc(u)}">Use this file</button></div>`).join('')}`;
      } else ctx.start(r);
    } catch (e) { q('[data-cands]').innerHTML = `<div class="alert bad" style="margin-top:12px">${esc(e.message)}</div>`; }
    finally { btn.disabled = false; }
  };
  q('[data-read]').addEventListener('click', () => { const u = q('[data-url]').value.trim(); if (!u) return toast('Paste the link first.', 'bad'); fetchUrl(u); });
  q('[data-url]').addEventListener('keydown', (e) => { if (e.key === 'Enter') q('[data-read]').click(); });
  pane.addEventListener('click', (e) => {
    const c = e.target.closest('[data-cand]'); if (c) fetchUrl(c.dataset.cand);
    const s = e.target.closest('[data-usesrc]'); if (s) { const src = sources.find((x) => String(x.id) === s.dataset.usesrc); fetchUrl(src.url, { source_id: src.id, carrier_id: src.carrier_id || '' }); }
  });
}

export async function loadSchedule() {
  let sources = [];
  try { sources = await api('GET', '/schedules/sources'); } catch { /* not allowed to see them */ }
  return importWizard({
    title: 'Load vessel schedule', base: '/schedules', noun: 'sailings',
    intro: 'Bring in a shipping line\'s sailing schedule. Loading the same schedule again later only updates what changed - and shows you which bookings are affected.',
    pasteHint: 'Copy the schedule table in Excel (or from the carrier\'s web page) and paste it here. Vessel and ETD are needed; POL, POD, voyage, cut-off and ETA are read if present.',
    options: [{ name: 'carrier_id', label: 'Shipping line when the schedule does not list one', type: 'select', options: carrierOpts, span: 4 }], optionsTitle: 'If the file does not say which shipping line',
    extraTabs: [{ id: 'link', label: 'From a web link', mount: (pane, ctx) => linkTab(pane, ctx, sources) }],
    cols: [
      { label: 'Vessel / voyage', render: (r) => `<b>${esc(r.vessel)}</b><div class="muted small">${esc(r.voyage || '')}</div>` },
      { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}<div class="muted small">${esc(r.carrier_name || '')}</div>` },
      { label: 'Cut-off', render: (r) => date(r.cutoff_date) }, { label: 'ETD', render: (r) => date(r.etd) }, { label: 'ETA', render: (r) => date(r.eta) },
    ],
    tiles: tilesFor([['create', 'New sailings', 'ok'], ['update', 'Changed dates', 'warn'], ['nochange', 'Unchanged', ''], ['error', 'Errors', 'bad']]),
    saveLabel: (s) => `Save ${int(s.ready)} sailing${s.ready === 1 ? '' : 's'}`,
    doneHtml: (r) => `<h2>Schedule loaded</h2><p class="muted">${r.created} new &middot; ${r.updated} changed${r.applied && (r.applied.consols || r.applied.shipments) ? ` &middot; dates updated on ${r.applied.shipments} booking(s) and ${r.applied.consols} master BL(s) automatically` : ''}</p>
      ${r.changes && !(r.applied && (r.applied.consols || r.applied.shipments)) ? '<div class="alert info">If any of your bookings or master BLs sail on a vessel whose dates changed, you will see it under <b>Date changes</b> - one click updates them.</div>' : ''}`,
    nextLinks: [['Vessel schedules', '#/schedules']],
  });
}

// ---------------------------------------------------------------- the page
export async function list(root, _p, query) {
  const canW = can('schedules', 'write');
  const f = { q: '', carrier_id: '', pol_id: '', pod_id: '', from: '', to: '', upcoming: '1' };
  let rows = [];
  root.innerHTML = `${pageHead('Vessel schedules', 'Sailings you can book on. Load them from Excel or a shipping line\'s website - dates stay up to date by themselves.',
    `${canW ? `<button class="btn primary" data-act="load">${icon('upload', 16)} Load schedule</button><button class="btn" data-act="add">${icon('plus', 16)} Add sailing</button>` : ''}${shareBtn()}`)}
    <div data-changes></div>
    <div class="toolbar no-print"><input type="text" class="search" placeholder="Search vessel, voyage, port, carrier…" data-f="q">
      <select data-f="carrier_id"><option value="">All carriers</option>${carrierOpts().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="pol_id"><option value="">Any loading port</option>${opts.ports().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="pod_id"><option value="">Any discharge port</option>${opts.ports().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <label class="muted small">From <input type="date" data-f="from"></label><label class="muted small">to <input type="date" data-f="to"></label>
      <label class="chip on"><input type="checkbox" data-f="upcoming" checked hidden> Upcoming only</label></div>
    <div class="card" data-out></div>
    ${canW ? '<div data-sources></div>' : ''}`;
  const out = $('[data-out]', root);

  async function paintChanges() {
    if (state.me.is_agent) return;
    const el = $('[data-changes]', root);
    const ch = await api('GET', '/schedules/changes');
    if (!ch.length) { el.innerHTML = ''; return; }
    el.innerHTML = `<div class="card chg"><div class="card-h"><h2>${icon('bell', 16)} Date changes that affect your bookings <span class="badge warn">${ch.length}</span></h2></div>${ch.map((c) => `<div class="chg-row"><div class="grow">
        <b>${esc(c.vessel)} ${esc(c.voyage || '')}</b> <span class="muted small">${esc(c.pol_name || '?')} &rarr; ${esc(c.pod_name || '?')}</span>
        <div>${c.changes.map((x) => `<span class="chgpill">${FIELD[x.field] || x.field}: <s>${x.from ? date(x.from) : '-'}</s> &rarr; <b>${date(x.to)}</b></span>`).join('')}</div>
        <div class="small muted">Affects ${c.shipments.length ? c.shipments.map((s) => link('#/shipments/' + s.id, s.booking_no)).join(', ') : ''}${c.shipments.length && c.consols.length ? ' and ' : ''}${c.consols.map((k) => link('#/consols/' + k.id, k.consol_no)).join(', ')}</div></div>
        ${canW ? `<button class="btn sm primary" data-apply="${c.schedule_id}">Update ${c.shipments.length + c.consols.length} booking${c.shipments.length + c.consols.length === 1 ? '' : 's'}</button><button class="btn sm ghost" data-dismiss="${c.schedule_id}">Ignore</button>` : ''}</div>`).join('')}</div>`;
  }
  async function load() {
    rows = await api('GET', '/schedules' + qs(f));
    out.innerHTML = tbl({ rows, empty: 'No sailings yet. Use “Load schedule” to bring in a schedule from Excel or a website link.', cols: [
      { label: 'Vessel / voyage', render: (r) => `<b>${esc(r.vessel)}</b><div class="muted small">${esc(r.voyage || '')}${r.service ? ' &middot; ' + esc(r.service) : ''}</div>` },
      { label: 'Carrier', render: (r) => esc(r.carrier_name || '') }, { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` },
      { label: 'Cut-off', cls: 'nowrap', render: (r) => date(r.cutoff_date) }, { label: 'ETD', cls: 'nowrap', render: (r) => `<b>${date(r.etd)}</b>` }, { label: 'ETA', cls: 'nowrap', render: (r) => date(r.eta) },
      { label: 'Transit', num: true, render: (r) => (r.transit_days ? r.transit_days + ' d' : '') }, { label: 'Source', render: (r) => badge(...(SRC[r.source] || [r.source, ''])) },
      ...(canW ? [{ label: '', cls: 'nowrap', render: (r) => `<button class="btn sm ghost" data-edit="${r.id}">${icon('edit', 14)}</button><button class="btn sm ghost" data-del="${r.id}" title="Delete">&#10005;</button>` }] : [])] });
    if (rows.length >= 1000) out.insertAdjacentHTML('beforeend', '<div class="muted small" style="padding:8px 12px">Showing the first 1,000 sailings - narrow the filters to see more.</div>');
  }
  async function paintSources() {
    if (!canW) return;
    const list = await api('GET', '/schedules/sources');
    $('[data-sources]', root).innerHTML = `<div class="card"><div class="card-h"><h2>${icon('link', 16)} Saved web links</h2><button class="btn sm" data-act="addsrc">${icon('plus', 14)} Add link</button></div>
      ${list.length ? tbl({ rows: list, compact: true, cols: [
        { label: 'Link', render: (s) => `<b>${esc(s.name)}</b><div class="muted small">${esc(s.url)}</div>` }, { label: 'Carrier', render: (s) => esc(s.carrier_name || '') },
        { label: 'Last refresh', render: (s) => (s.last_run ? `${dt(s.last_run)}<div class="small ${/^FAILED/.test(s.last_status || '') ? 'neg' : 'muted'}">${esc(s.last_status || '')}</div>` : '<span class="muted">never</span>') },
        { label: 'Daily refresh', render: (s) => `<label class="switch"><input type="checkbox" data-auto="${s.id}" ${s.auto_refresh ? 'checked' : ''}><span></span></label>` },
        { label: '', cls: 'nowrap', render: (s) => `<button class="btn sm" data-refresh="${s.id}">${icon('refresh', 14)} Refresh now</button><button class="btn sm ghost" data-delsrc="${s.id}" title="Remove">&#10005;</button>` }] })
        : '<div class="empty">No saved links yet. Add the link to a carrier\'s schedule and it will be refreshed automatically every day.</div>'}</div>`;
    root.__sources = list;
  }
  const refreshAll = () => Promise.all([load(), paintChanges(), paintSources()]).catch((e) => toast(e.message, 'bad'));

  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')), 250);
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (!k) return; f[k] = e.target.type === 'checkbox' ? (e.target.checked ? '1' : '0') : e.target.value; if (e.target.type === 'checkbox') e.target.closest('.chip').classList.toggle('on', e.target.checked); reload(); });
  wireShare(root, () => ({ kind: 'schedules', params: { ...f }, title: 'Share vessel schedule', what: 'the vessel schedule', defaultSubject: 'Vessel schedule - HUB LINE SHIPPING' }));

  const fields = () => [
    { name: 'vessel', label: 'Vessel', required: true, span: 2 }, { name: 'voyage', label: 'Voyage', span: 1 }, { name: 'service', label: 'Service / loop', span: 1 },
    { name: 'carrier_id', label: 'Carrier', type: 'combo', options: carrierOpts, span: 2 }, { name: 'pol_id', label: 'Port of loading', type: 'combo', options: opts.ports, span: 1 }, { name: 'pod_id', label: 'Port of discharge', type: 'combo', options: opts.ports, span: 1 },
    { name: 'cutoff_date', label: 'Cut-off', type: 'date' }, { name: 'etd', label: 'ETD', type: 'date' }, { name: 'eta', label: 'ETA', type: 'date' }, { name: 'transit_days', label: 'Transit days', type: 'number', min: 0 },
    { name: 'remarks', label: 'Remarks', span: 4 }];
  on(root, 'click', '[data-act=load]', async () => { const r = await loadSchedule(); if (r) refreshAll(); });
  on(root, 'click', '[data-act=add]', async () => { const r = await formModal({ title: 'Add sailing', fields: fields(), onSubmit: (v) => api('POST', '/schedules', v) }); if (r) { toast('Sailing added', 'ok'); refreshAll(); } });
  on(root, 'click', '[data-edit]', async (_e, el) => {
    const row = rows.find((x) => String(x.id) === el.dataset.edit);
    const r = await formModal({ title: `Edit ${row.vessel} ${row.voyage || ''}`, fields: fields(), values: row, onSubmit: (v) => api('PUT', `/schedules/${row.id}`, v) });
    if (r) { toast('Saved', 'ok'); refreshAll(); }
  });
  on(root, 'click', '[data-del]', async (_e, el) => { if (await confirmBox('Delete this sailing from the schedule? Bookings are not changed.', { danger: true, ok: 'Delete' })) { try { await api('DELETE', `/schedules/${el.dataset.del}`); refreshAll(); } catch (e) { toast(e.message, 'bad'); } } });
  on(root, 'click', '[data-apply]', async (_e, el) => {
    el.disabled = true;
    try { const r = await api('POST', `/schedules/${el.dataset.apply}/apply`, {}); toast(`Updated ${r.shipments} booking(s) and ${r.consols} master BL(s)`, 'ok'); refreshAll(); } catch (e) { toast(e.message, 'bad'); el.disabled = false; }
  });
  on(root, 'click', '[data-dismiss]', async (_e, el) => { try { await api('POST', `/schedules/${el.dataset.dismiss}/dismiss`, {}); paintChanges(); } catch (e) { toast(e.message, 'bad'); } });
  on(root, 'click', '[data-act=addsrc]', async () => {
    const r = await formModal({ title: 'Save a web link', intro: '<p class="muted" style="margin-top:0">Paste the link to a schedule file or page. It is read again every day and only real changes are saved.</p>', fields: [
      { name: 'name', label: 'Name', required: true, span: 4, placeholder: 'e.g. MSC Gulf - India schedule' }, { name: 'url', label: 'Web link', required: true, span: 4, placeholder: 'https://…' },
      { name: 'carrier_id', label: 'Shipping line', type: 'combo', options: carrierOpts, span: 3 }, { name: 'auto_refresh', label: 'Refresh daily', type: 'checkbox', span: 1 }], values: { auto_refresh: 1 }, onSubmit: (v) => api('POST', '/schedules/sources', v) });
    if (r) { toast('Link saved', 'ok'); paintSources(); }
  });
  on(root, 'click', '[data-refresh]', async (_e, el) => {
    el.disabled = true;
    try { const r = await api('POST', `/schedules/sources/${el.dataset.refresh}/refresh`, {}); toast(`Refreshed: ${r.created} new, ${r.updated} changed`, 'ok'); refreshAll(); } catch (e) { toast(e.message, 'bad'); paintSources(); }
  });
  on(root, 'click', '[data-delsrc]', async (_e, el) => { if (await confirmBox('Remove this saved link? Sailings already loaded are kept.', { danger: true, ok: 'Remove' })) { await api('DELETE', `/schedules/sources/${el.dataset.delsrc}`); paintSources(); } });
  root.addEventListener('change', async (e) => {
    if (!e.target.matches('[data-auto]')) return;
    try { await api('PUT', `/schedules/sources/${e.target.dataset.auto}`, { auto_refresh: e.target.checked ? 1 : 0 }); toast(e.target.checked ? 'Daily refresh on' : 'Daily refresh off', 'ok'); } catch (x) { toast(x.message, 'bad'); }
  });
  await refreshAll();
  if (query.changes) { const c = $('.chg', root); if (c) c.scrollIntoView({ block: 'center' }); }
}
