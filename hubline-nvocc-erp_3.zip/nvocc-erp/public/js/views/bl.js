// Bills of lading tab: see every BL, open it, edit it (within your rights), download it as PDF / Excel, share it. Agents work here on their own shipments.
import { api, state, esc, $, $$, on, qs, tbl, pageHead, date, badge, shipBadge, formModal, openModal, confirmBox, toast, opts, can, kv, link, go, num, int, dt, debounce, download } from '../core.js';
import { icon } from '../icons.js';
import { shareBtn, wireShare, shareModal } from '../share.js';
import { shipmentFields } from './shipments.js';
import { loadSchedules, scheduleField, bindSchedulePicker } from '../sched-pick.js';

const isAgent = () => !!(state.me && state.me.is_agent);
const STATUSES = ['BOOKED', 'CONFIRMED', 'SAILED', 'ARRIVED', 'DELIVERED', 'CLOSED', 'CANCELLED'];
const AGENT_NEW = ['cargo_type', 'pol_id', 'pod_id', 'vessel', 'voyage', 'etd', 'eta', 'freight_terms', 'incoterm', 'shipper_text', 'consignee_text', 'notify_text', 'place_of_receipt', 'place_of_delivery',
  'commodity', 'marks', 'packages', 'package_type', 'gross_weight', 'cbm'];

// keep only the wanted fields (and only the section headings that still have something under them)
function pick(all, names) {
  const out = []; let pending = null;
  for (const f of all) {
    if (f.section) { pending = f; continue; }
    if (!names.includes(f.name)) continue;
    if (pending) { out.push(pending); pending = null; }
    out.push(f);
  }
  return out;
}
const AGENT_LABELS = { shipper_text: { label: 'Shipper - name & address', required: true, hint: '' }, consignee_text: { label: 'Consignee - name & address', required: true, hint: '' }, notify_text: { label: 'Notify party - name & address', hint: '' } };
const agentLabels = (f) => (AGENT_LABELS[f.name] ? { ...f, ...AGENT_LABELS[f.name] } : f);
const short = (s, n = 34) => { s = String(s || ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const reviewBadge = (r) => (r.needs_review ? badge('Agent edited', 'warn') : '');

// ---------------------------------------------------------------- list
export async function list(root, _p, query) {
  const agent = isAgent(), canW = can('bl', 'write');
  const f = { q: query.q || '', status: query.status || '', agent_id: query.agent_id || '', from: '', to: '', review: query.review || '', incomplete: query.incomplete || '', open: query.open || '' };
  const sel = new Set();
  let rows = [];
  root.innerHTML = `${pageHead('Bills of lading', agent ? 'Your bookings and bills of lading - view, complete the details, download' : 'Every bill of lading in one place - view, edit, download and share',
    `${agent && canW ? `<button class="btn primary" data-act="new">${icon('plus', 16)} New booking request</button>` : ''}<button class="btn" data-act="pdfsel" disabled>${icon('download', 16)} PDF of selected</button>${shareBtn('Share list')}`)}
    <div data-alerts></div>
    <div class="toolbar no-print"><input type="text" class="search" placeholder="Search BL, booking, shipper, consignee, container, vessel…" data-f="q" value="${esc(f.q)}">
      <select data-f="status"><option value="">All statuses</option>${STATUSES.map((s) => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${s[0] + s.slice(1).toLowerCase()}</option>`).join('')}</select>
      ${agent ? '' : `<select data-f="agent_id"><option value="">All agents</option>${opts.parties('agent').map(([v, l]) => `<option value="${v}" ${String(v) === String(f.agent_id) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`}
      <label class="muted small">Sailing from <input type="date" data-f="from"></label><label class="muted small">to <input type="date" data-f="to"></label>
      <span class="chips">${agent ? '' : `<label class="chip ${f.review ? 'on' : ''}"><input type="checkbox" data-f="review" ${f.review ? 'checked' : ''} hidden> Agent-edited</label>`}
        <label class="chip ${f.incomplete ? 'on' : ''}"><input type="checkbox" data-f="incomplete" ${f.incomplete ? 'checked' : ''} hidden> Details missing</label>
        <label class="chip ${f.open ? 'on' : ''}"><input type="checkbox" data-f="open" ${f.open ? 'checked' : ''} hidden> Open only</label></span></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root), pdfBtn = $('[data-act=pdfsel]', root);
  const sync = () => { pdfBtn.disabled = !sel.size; pdfBtn.lastChild.textContent = sel.size ? ` PDF of ${sel.size} selected` : ' PDF of selected'; };
  async function load() {
    rows = await api('GET', '/bls' + qs(f));
    sel.clear(); sync();
    const rv = rows.filter((r) => r.needs_review).length;
    $('[data-alerts]', root).innerHTML = !agent && rv && !f.review ? `<div class="alert warn">${icon('bell', 15)} <b>${rv}</b> bill${rv === 1 ? '' : 's'} of lading changed by an agent since you last looked. <a href="#/bls?review=1">Review them</a></div>` : '';
    out.innerHTML = tbl({ rows, click: true, empty: 'No bills of lading match these filters.', rowAttr: (r) => `data-go="#/bls/${r.id}"`, cols: [
      { label: '', render: (r) => `<input type="checkbox" data-sel="${r.id}" aria-label="Select">` },
      { label: 'B/L / booking', render: (r) => `<b>${esc(r.hbl_no || r.booking_no)}</b><div class="muted small">${r.hbl_no ? esc(r.booking_no) : 'HBL not issued'}${r.mbl_no ? ' &middot; MBL ' + esc(r.mbl_no) : ''}</div>` },
      { label: 'Shipper / consignee', render: (r) => `${esc(short(r.shipper) || '-')}<div class="muted small">&rarr; ${esc(short(r.consignee) || '-')}</div>` },
      { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` },
      { label: 'Vessel / ETD', render: (r) => `${esc([r.vessel, r.voyage].filter(Boolean).join(' / ') || '-')}<div class="muted small">${date(r.etd)}</div>` },
      { label: 'Cargo', render: (r) => `${esc(short(r.commodity, 26))}<div class="muted small">${r.container_count ? `${r.container_count} container${r.container_count === 1 ? '' : 's'}` : r.cargo_type}${r.gross_weight ? ' &middot; ' + int(r.gross_weight) + ' kg' : ''}</div>` },
      ...(agent ? [] : [{ label: 'Agent', render: (r) => esc(r.agent_name || '') }]),
      { label: 'Status', render: (r) => `${shipBadge(r.status)} ${reviewBadge(r)}` }] });
    if (rows.length >= 500) out.insertAdjacentHTML('beforeend', '<div class="muted small" style="padding:8px 12px">Showing the latest 500 - narrow the filters to see more.</div>');
  }
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')), 250);
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (!k) return; f[k] = e.target.type === 'checkbox' ? (e.target.checked ? '1' : '') : e.target.value; if (e.target.type === 'checkbox') e.target.closest('.chip').classList.toggle('on', e.target.checked); reload(); });
  on(root, 'change', '[data-sel]', (_e, el) => { const id = Number(el.dataset.sel); el.checked ? sel.add(id) : sel.delete(id); sync(); });
  on(root, 'click', '[data-act=pdfsel]', () => download(`/bls/pdf?ids=${[...sel].join(',')}`));
  on(root, 'click', '[data-act=new]', () => newRequest());
  wireShare(root, () => ({ kind: 'bls', params: { ...f }, title: 'Share bills of lading', what: 'this list of bills of lading' }));
  await load();
}

// ---------------------------------------------------------------- an agent's new booking request
async function newRequest() {
  const rows = await loadSchedules();
  const fields = [scheduleField(rows), ...pick(shipmentFields(), AGENT_NEW).map(agentLabels)];
  const r = await formModal({ title: 'New booking request', size: 'wide', fields, values: { cargo_type: 'FCL', freight_terms: 'PREPAID' }, submitLabel: 'Send booking request',
    intro: '<p class="muted" style="margin-top:0">HUB LINE will confirm the booking, add the containers and issue the bill of lading. You can still complete the details afterwards.</p>',
    onMount: (h) => bindSchedulePicker(h, rows), onSubmit: (v) => { delete v._schedule; return api('POST', '/bls', v); } });
  if (r) { toast(`Booking ${r.booking_no} sent`, 'ok'); go(`#/bls/${r.id}`); }
}

// ---------------------------------------------------------------- one bill of lading
export async function detail(root, { id }) {
  const s = await api('GET', `/bls/${id}`);
  const agent = isAgent(), rights = s.rights || { edit: false };
  const box = (label, html, cls = '') => `<div class="bl-box ${cls}"><label>${esc(label)}</label><div>${html || '<span class="muted">—</span>'}</div></div>`;
  const text = (name, txt) => esc(name || txt || '').replace(/\n/g, '<br>') + (name && txt ? `<div class="muted small">${esc(txt).replace(/\n/g, '<br>')}</div>` : '');
  const party = (name, txt) => (name ? `<b>${esc(name)}</b>${txt ? '<br>' + esc(txt).replace(/\n/g, '<br>') : ''}` : esc(txt || '').replace(/\n/g, '<br>'));
  const canReview = !agent && can('bl', 'write') && s.needs_review;

  root.innerHTML = `${pageHead(`${s.hbl_no ? 'B/L ' + esc(s.hbl_no) : 'Booking ' + esc(s.booking_no)} ${shipBadge(s.status)} ${s.hbl_no ? '' : badge('BL not issued yet', 'warn')}`,
      `${esc(s.pol_name || '?')} &rarr; ${esc(s.pod_name || '?')}${s.vessel ? ' &middot; ' + esc([s.vessel, s.voyage].filter(Boolean).join(' / ')) : ''}${s.agent_name && !agent ? ' &middot; agent ' + esc(s.agent_name) : ''}`,
      `${rights.edit ? `<button class="btn primary" data-act="edit">${icon('edit', 16)} Edit details</button>` : ''}<a class="btn" href="/api/bls/pdf?ids=${s.id}">${icon('download', 16)} PDF</a>
       <a class="btn" href="/api/export/bl?format=xlsx&id=${s.id}">${icon('sheet', 16)} Excel</a>${shareBtn('Share')}`, '<a href="#/bls">Bills of lading</a> /')}
    ${canReview ? `<div class="alert warn"><div class="pill-row"><span class="grow">${icon('bell', 15)} <b>${esc(s.agent_edit_by || 'The agent')}</b> changed this bill of lading on ${dt(s.agent_edit_at)}. Check the details, then mark it as reviewed.</span><button class="btn sm" data-act="reviewed">${icon('check', 15)} Mark reviewed</button></div></div>` : ''}
    ${!rights.edit && rights.reason ? `<div class="alert info">${icon('info', 15)} ${esc(rights.reason)}</div>` : ''}
    <div class="split"><div>
      <div class="card"><div class="card-b"><div class="bl-grid">
        ${box('Shipper', party(s.shipper_name, s.shipper_text || s.shipper_address), 'wide')}${box('Consignee', party(s.consignee_name, s.consignee_text || s.consignee_address), 'wide')}
        ${box('Notify party', party(s.notify_name, s.notify_text || s.notify_address), 'wide')}
        ${box('Place of receipt', esc(s.place_of_receipt))}${box('Port of loading', esc(s.pol_name))}${box('Port of discharge', esc(s.pod_name))}${box('Place of delivery', esc(s.place_of_delivery))}
        ${box('Vessel / voyage', esc([s.vessel, s.voyage].filter(Boolean).join(' / ')))}${box('ETD', date(s.etd))}${box('ETA', date(s.eta))}${box('Freight', esc(s.freight_terms) + (s.incoterm ? ` &middot; ${esc(s.incoterm)}` : ''))}
        ${box('Marks & numbers', esc(s.marks), 'wide')}${box('Description of goods', esc(s.commodity), 'wide')}
        ${box('Packages', s.packages != null ? `${num(s.packages)} ${esc(s.package_type || '')}` : '')}${box('Gross weight', s.gross_weight != null ? num(s.gross_weight) + ' kg' : '')}${box('Volume', s.cbm != null ? num(s.cbm) + ' CBM' : '')}${box('Cargo', esc(s.cargo_type))}
      </div></div></div>
      <div class="card"><div class="card-h"><h2>Containers</h2><span class="muted small">${s.containers.length} on this bill of lading</span></div>
        ${tbl({ rows: s.containers, compact: true, empty: s.cargo_type === 'LCL' ? 'LCL cargo travels in the consolidated container - see the master BL.' : 'No containers have been allocated yet.', cols: [
          { label: 'Container', render: (c) => `<b>${link('#/track/' + c.container_id, c.container_no)}</b><div class="muted small">${esc(c.type_code)}</div>` },
          { label: 'Seal', render: (c) => esc(c.seal_no || '') }, { label: 'Packages', num: true, render: (c) => (c.packages != null ? num(c.packages) : '') },
          { label: 'Weight kg', num: true, render: (c) => (c.weight_kg != null ? num(c.weight_kg) : '') }, { label: 'CBM', num: true, render: (c) => (c.cbm != null ? num(c.cbm) : '') },
          { label: 'Status', render: (c) => `${esc(c.status_label)}<div class="muted small">${esc(c.location || '')}</div>` },
          ...(rights.edit ? [{ label: '', render: (c) => `<button class="btn sm ghost" data-edit-cont="${c.container_id}">${icon('edit', 14)}</button>` }] : [])] })}</div></div>
    <div><div class="card"><div class="card-h"><h2>Shipment</h2></div><div class="card-b">${kv([['Booking', can('shipments', 'read') && !agent ? link('#/shipments/' + s.id, s.booking_no) : esc(s.booking_no)], ['B/L number', esc(s.hbl_no)], ['Master BL', esc(s.mbl_no)], ['Consol', esc(s.consol_no)],
        agent ? null : ['Customer', esc(s.customer_name)], agent ? null : ['Agent', esc(s.agent_name)], ['Carrier', esc(s.carrier_name)], ['Status', shipBadge(s.status)]])}</div></div>
      <div class="card"><div class="card-h"><h2>Activity</h2></div><div data-history><div class="empty small">${can('audit', 'read') ? 'Loading…' : 'Activity is visible to HUB LINE management.'}</div></div></div></div></div>`;

  if (can('audit', 'read')) api('GET', `/bls/${id}/history`).then((h) => {
    const el = $('[data-history]', root); if (!el) return;
    el.innerHTML = h.length ? `<ul class="timeline">${h.map((x) => `<li><b>${esc(x.action.replace(/_/g, ' ').toLowerCase())}</b> <span class="muted small">${esc(x.username || 'system')} &middot; ${dt(x.ts)}</span></li>`).join('')}</ul>` : '<div class="empty small">No activity yet.</div>';
  }).catch(() => {});

  wireShare(root, { kind: 'bl', params: { id: s.id }, title: 'Share bill of lading', what: `bill of lading ${s.hbl_no || s.booking_no}`, defaultSubject: `Bill of lading ${s.hbl_no || s.booking_no}` });
  on(root, 'click', '[data-act=reviewed]', async () => { try { await api('POST', `/bls/${id}/review`, {}); toast('Marked as reviewed', 'ok'); go(`#/bls/${id}`); } catch (e) { toast(e.message, 'bad'); } });
  on(root, 'click', '[data-act=edit]', async () => {
    let names = rights.fields;
    let fields = pick(shipmentFields(), names);
    if (agent) fields = fields.map(agentLabels);
    const rows = agent ? [] : await loadSchedules();
    if (!agent && rows.length && names.includes('vessel')) fields = [scheduleField(rows), ...fields];
    const r = await formModal({ title: `Edit ${s.hbl_no ? 'B/L ' + s.hbl_no : 'booking ' + s.booking_no}`, size: 'wide', fields, values: s, submitLabel: 'Save changes',
      intro: agent ? '<p class="muted" style="margin-top:0">HUB LINE is notified when you save. After the vessel has sailed the bill of lading can only be amended by HUB LINE.</p>' : '',
      onMount: (h) => bindSchedulePicker(h, rows), onSubmit: (v) => { delete v._schedule; return api('PUT', `/bls/${id}`, v); } });
    if (r) { toast('Bill of lading saved', 'ok'); go(`#/bls/${id}`); }
  });
  on(root, 'click', '[data-edit-cont]', async (_e, el) => {
    const c = s.containers.find((x) => String(x.container_id) === el.dataset.editCont);
    const r = await formModal({ title: `Container ${c.container_no}`, size: 'narrow', values: c, fields: [
      { name: 'seal_no', label: 'Seal number', span: 4 }, { name: 'packages', label: 'Packages', type: 'number', min: 0, span: 2 }, { name: 'weight_kg', label: 'Weight (kg)', type: 'number', min: 0, span: 2 }, { name: 'cbm', label: 'Volume (CBM)', type: 'number', min: 0, span: 2 }],
      onSubmit: (v) => api('PUT', `/bls/${id}/containers/${c.container_id}`, v) });
    if (r) { toast('Container details saved', 'ok'); go(`#/bls/${id}`); }
  });
}
