// Printable documents: booking confirmation, house BL, invoices/notes, statement of account, agency agreement, commission statement
import { api, state, esc, qs, money, num, int, date, docType } from '../core.js';

const co = () => state.lk.settings;
const nl = (s) => esc(s).replace(/\n/g, '<br>');

function header(title, sub = '') {
  const c = co();
  return `<div class="ph"><div class="co"><img class="plogo" src="/img/logo.png" alt="" style="height:52px;width:auto;display:block;margin:0 0 6px"><b>${esc(c.company_name)}</b><div>${nl(c.company_address)}</div><div>${[c.company_phone && 'Tel ' + esc(c.company_phone), c.company_email && esc(c.company_email)].filter(Boolean).join(' &middot; ')}</div>${c.company_tax_no ? `<div>TRN: ${esc(c.company_tax_no)}</div>` : ''}</div>
    <div style="text-align:right"><h1>${esc(title)}</h1>${sub}</div></div>`;
}
function wrap(root, html, back = 'history') {
  root.innerHTML = `<div class="printbar"><button class="btn" data-back>&larr; Back</button><button class="btn primary" data-print>Print / save as PDF</button></div><div class="paper">${html}</div>`;
  root.querySelector('[data-back]').addEventListener('click', () => (history.length > 1 ? history.back() : (location.hash = '#/dashboard')));
  root.querySelector('[data-print]').addEventListener('click', () => window.print());
}
const box = (label, html, extra = '') => `<div class="box" ${extra}><label>${esc(label)}</label>${html || '&nbsp;'}</div>`;

export async function render(root, { kind, id }, query) {
  const fn = { booking, hbl, doc, soa, agreement, commission }[kind];
  if (!fn) throw new Error('Unknown document type.');
  await fn(root, id, query);
}

// ------------------------------------------------------------------ shipment documents
const party = (id, name, text, addr) => (name ? `<b>${esc(name)}</b>${addr ? '<br>' + nl(addr) : ''}` : nl(text));

async function booking(root, id) {
  const s = await api('GET', `/shipments/${id}`);
  wrap(root, `${header('BOOKING CONFIRMATION', `<div>Booking no. <b>${esc(s.booking_no)}</b></div>`)}
    <div class="cols">${box('Customer', `<b>${esc(s.customer_name || '')}</b>`)}${box('Date', date(new Date().toISOString().slice(0, 10)))}</div>
    <div class="cols" style="margin-top:10px">${box('Shipper', party(s.shipper_id, s.shipper_name, s.shipper_text, s.shipper_address))}${box('Consignee', party(s.consignee_id, s.consignee_name, s.consignee_text, s.consignee_address))}</div>
    <h2>Routing</h2><table><tr><th>Port of loading</th><th>Port of discharge</th><th>Vessel / voyage</th><th>ETD</th><th>ETA</th></tr><tr><td>${esc(s.pol_name || '')}</td><td>${esc(s.pod_name || '')}</td><td>${esc([s.vessel, s.voyage].filter(Boolean).join(' / '))}</td><td>${date(s.etd)}</td><td>${date(s.eta)}</td></tr></table>
    <h2>Cargo</h2><table><tr><th>Description</th><th>Cargo</th><th class="num">Packages</th><th class="num">Weight (kg)</th><th class="num">Volume (CBM)</th><th>Freight</th></tr><tr><td>${esc(s.commodity || '')}</td><td>${esc(s.cargo_type)}</td><td class="num">${int(s.packages)} ${esc(s.package_type || '')}</td><td class="num">${int(s.gross_weight)}</td><td class="num">${num(s.cbm)}</td><td>${esc(s.freight_terms)}</td></tr></table>
    ${s.containers.length ? `<h2>Containers</h2><table><tr><th>Container</th><th>Type</th><th>Seal</th></tr>${s.containers.map((c) => `<tr><td>${esc(c.container_no)}</td><td>${esc(c.type_code)}</td><td>${esc(c.seal_no || '')}</td></tr>`).join('')}</table>` : ''}
    <p class="fine" style="margin-top:14px">Space and equipment are subject to availability. Cargo must be delivered within the cut-off advised. This confirmation is subject to the Company's standard trading conditions.</p>
    <div class="sig"><div>For ${esc(co().company_name)}</div><div>Accepted by customer</div></div>`);
}

async function hbl(root, id) {
  const s = await api('GET', `/shipments/${id}`);
  if (!s.hbl_no) throw new Error('This shipment has no HBL yet. Confirm the booking first.');
  const totalPk = s.containers.reduce((a, c) => a + (c.packages || 0), 0);
  wrap(root, `${header('HOUSE BILL OF LADING', `<div>B/L no. <b>${esc(s.hbl_no)}</b></div><div class="fine">Booking ${esc(s.booking_no)}${s.mbl_no ? ' &middot; MBL ' + esc(s.mbl_no) : ''}</div>`)}
    <div class="cols">${box('Shipper', party(s.shipper_id, s.shipper_name, s.shipper_text, s.shipper_address), 'style="min-height:84px"')}${box('Consignee', party(s.consignee_id, s.consignee_name, s.consignee_text, s.consignee_address), 'style="min-height:84px"')}</div>
    <div class="cols" style="margin-top:10px">${box('Notify party', party(s.notify_id, s.notify_name, s.notify_text, s.notify_address))}${box('Also notify / delivery agent', s.agent_name ? `<b>${esc(s.agent_name)}</b>` : '')}</div>
    <div class="cols3" style="margin-top:10px">${box('Place of receipt', esc(s.place_of_receipt || s.pol_name))}${box('Port of loading', esc(s.pol_name))}${box('Vessel / voyage', esc([s.vessel, s.voyage].filter(Boolean).join(' / ')))}
      ${box('Port of discharge', esc(s.pod_name))}${box('Place of delivery', esc(s.place_of_delivery || s.pod_name))}${box('Freight', s.freight_terms === 'COLLECT' ? 'FREIGHT COLLECT' : 'FREIGHT PREPAID')}</div>
    <h2>Particulars furnished by the shipper</h2>
    <table><tr><th style="width:24%">Marks &amp; numbers / container &amp; seal</th><th style="width:12%" class="num">Packages</th><th>Description of goods</th><th class="num" style="width:14%">Gross weight (kg)</th><th class="num" style="width:12%">Measurement (CBM)</th></tr>
      <tr><td>${nl(s.marks || '')}${s.containers.length ? '<br><br>' + s.containers.map((c) => `${esc(c.container_no)} / ${esc(c.type_code)}${c.seal_no ? ' / SEAL ' + esc(c.seal_no) : ''}`).join('<br>') : ''}</td>
        <td class="num">${int(s.packages ?? totalPk)}<br>${esc(s.package_type || '')}</td><td>${esc(s.commodity || '')}<br><span class="fine">${esc(s.cargo_type === 'FCL' ? 'SAID TO CONTAIN - SHIPPER\'S LOAD, STOW AND COUNT' : 'LCL CARGO')}</span></td><td class="num">${int(s.gross_weight)}</td><td class="num">${num(s.cbm)}</td></tr></table>
    <div class="cols" style="margin-top:10px">${box('Date and place of issue', [date(new Date().toISOString().slice(0, 10)), esc((co().company_address || '').split('\n').pop() || '')].filter(Boolean).join(', '))}${box('Number of original B/Ls', 'THREE (3)')}</div>
    <p class="fine" style="margin-top:10px">${nl(co().hbl_terms)}</p>
    <div class="sig"><div>Signed for the Carrier as agent: ${esc(co().company_name)}</div><div>Date</div></div>
    <p class="fine">Template for review: check wording and layout against your registered bill of lading form before issuing to customers.</p>`);
}

// ------------------------------------------------------------------ invoices / notes
async function doc(root, id) {
  const d = await api('GET', `/documents/${id}`);
  const c = co();
  const base = c.base_currency;
  const title = { INV: c.company_tax_no ? 'TAX INVOICE' : 'INVOICE', DN: 'DEBIT NOTE', CN: 'CREDIT NOTE', BILL: 'VENDOR BILL (INTERNAL COPY)', COMM: 'COMMISSION PAYABLE (INTERNAL COPY)' }[d.doc_type];
  const stamp = d.status === 'DRAFT' ? '<span class="stamp">DRAFT</span>' : d.status === 'CANCELLED' ? '<span class="stamp">CANCELLED</span>' : '';
  const external = ['INV', 'DN', 'CN'].includes(d.doc_type);
  wrap(root, `${header(title, `<div>No. <b>${esc(d.doc_no || 'DRAFT')}</b></div><div>Date: ${date(d.doc_date)}</div>${d.due_date && external ? `<div>Due: ${date(d.due_date)}</div>` : ''}${stamp ? `<div style="margin-top:6px">${stamp}</div>` : ''}`)}
    <div class="cols">${box(d.doc_type === 'BILL' || d.doc_type === 'COMM' ? 'From' : 'Bill to', `<b>${esc(d.party_name)}</b><br>${nl([d.party_address, d.party_city, d.party_country].filter(Boolean).join('\n'))}${d.party_tax_no ? `<br>TRN: ${esc(d.party_tax_no)}` : ''}`)}
      ${box('Shipment', d.shipment_id ? `Booking ${esc(d.booking_no)}<br>HBL ${esc(d.hbl_no || '-')}<br>${esc(d.pol_name || '')} &rarr; ${esc(d.pod_name || '')}<br>${esc([d.vessel, d.voyage].filter(Boolean).join(' / '))}${d.etd ? ' &middot; ETD ' + date(d.etd) : ''}` : esc(d.narration || ''))}</div>
    ${d.party_ref ? `<p style="margin:8px 0 0">Reference: <b>${esc(d.party_ref)}</b></p>` : ''}
    <h2>Details</h2><table><tr><th>Description</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount (${esc(d.currency)})</th><th class="num">VAT %</th><th class="num">VAT</th></tr>
      ${d.lines.map((l) => `<tr><td>${esc(l.description)}</td><td class="num">${num(l.qty)}</td><td class="num">${money(l.rate)}</td><td class="num">${money(l.amount)}</td><td class="num">${num(l.vat_rate)}</td><td class="num">${money(l.vat_amount)}</td></tr>`).join('')}</table>
    <table class="totals"><tr><td>Subtotal</td><td class="num">${money(d.subtotal)}</td></tr><tr><td>VAT</td><td class="num">${money(d.vat_amount)}</td></tr><tr class="grand"><td>Total ${esc(d.currency)}</td><td class="num">${money(d.total)}</td></tr>
      ${d.currency !== base && d.vat_amount > 0 ? `<tr><td class="fine">VAT in ${esc(base)} (rate ${num(d.fx_rate)})</td><td class="num fine">${money(d.vat_amount * d.fx_rate)}</td></tr>` : ''}</table>
    ${d.narration && d.shipment_id ? `<p>${esc(d.narration)}</p>` : ''}
    ${external && d.doc_type !== 'CN' && c.company_bank ? `<h2>Bank details</h2><p style="white-space:pre-line">${esc(c.company_bank)}</p>` : ''}
    ${external && c.invoice_footer ? `<p class="fine" style="margin-top:14px">${nl(c.invoice_footer)}</p>` : ''}`);
}

// ------------------------------------------------------------------ statement of account
async function soa(root, partyId, query) {
  const r = await api('GET', '/soa' + qs({ party_id: partyId, from: query.from, to: query.to, mode: query.mode, currency: query.currency }));
  const c = co();
  const open = r.mode === 'open';
  wrap(root, `${header('STATEMENT OF ACCOUNT', `<div>${open ? 'Open items as at' : 'Period'} <b>${open ? date(r.to) : `${date(r.from)} &ndash; ${date(r.to)}`}</b></div>`)}
    <div class="cols">${box('Account', `<b>${esc(r.party.name)}</b> (${esc(r.party.code)})<br>${nl([r.party.address, r.party.city, r.party.country].filter(Boolean).join('\n'))}${r.party.tax_no ? `<br>TRN: ${esc(r.party.tax_no)}` : ''}`)}${box('Credit terms', `${r.party.credit_days} days${r.party.credit_limit ? `<br>Credit limit ${money(r.party.credit_limit)} ${esc(r.party.currency)}` : ''}<br>Statement date ${date(new Date().toISOString().slice(0, 10))}`)}</div>
    ${r.currencies.length ? r.currencies.map((cu) => `<h2>${esc(cu.currency)}${open ? '' : ` &mdash; opening balance ${money(cu.opening)}`}</h2>
      <table><tr><th>Date</th><th>Document</th><th>Shipment</th><th>Description</th><th>Due</th><th class="num">Debit</th><th class="num">Credit</th><th class="num">Balance</th></tr>
        ${cu.rows.map((x) => `<tr><td>${date(x.date)}</td><td>${esc(x.ref)}<div class="fine">${esc(x.type)}</div></td><td>${esc(x.shipment || '')}</td><td>${esc(x.description || '')}</td><td>${date(x.due_date)}</td><td class="num">${x.debit ? money(x.debit) : ''}</td><td class="num">${x.credit ? money(x.credit) : ''}</td><td class="num">${money(x.balance)}</td></tr>`).join('') || '<tr><td colspan="8">No transactions</td></tr>'}
        <tr><td colspan="5"><b>Totals / closing balance ${esc(cu.currency)}</b></td><td class="num"><b>${money(cu.total_debit)}</b></td><td class="num"><b>${money(cu.total_credit)}</b></td><td class="num"><b>${money(cu.closing)}</b></td></tr></table>
      <table style="margin-top:8px"><tr><th class="num">Not due</th><th class="num">1-30</th><th class="num">31-60</th><th class="num">61-90</th><th class="num">90+</th><th class="num">Unapplied</th><th class="num">Net due</th></tr><tr>${['not_due', 'd1_30', 'd31_60', 'd61_90', 'd90_plus', 'unapplied', 'total'].map((k) => `<td class="num">${money(cu.ageing[k])}</td>`).join('')}</tr></table>`).join('') : '<p>No transactions or balance for this party in the period.</p>'}
    <p class="fine" style="margin-top:14px">Positive balances are due to ${esc(c.company_name)}; balances in brackets or negative are due from us. Please report any differences within 14 days; otherwise this statement is deemed correct.</p>
    ${c.company_bank ? `<h2>Bank details</h2><p style="white-space:pre-line">${esc(c.company_bank)}</p>` : ''}`);
}

// ------------------------------------------------------------------ agency agreement
async function agreement(root, id) {
  const a = await api('GET', `/agreements/${id}`);
  const c = co();
  wrap(root, `${header('AGENCY AGREEMENT', `<div>No. <b>${esc(a.agreement_no)}</b></div>${a.status === 'DRAFT' ? '<div style="margin-top:6px"><span class="stamp">DRAFT</span></div>' : ''}`)}
    <p>This Agreement is made between <b>${esc(c.company_name)}</b> ("the Company")${c.company_address ? `, ${esc(c.company_address.replace(/\n/g, ', '))}` : ''}, and <b>${esc(a.agent_name)}</b> ("the Agent"), ${esc([a.agent_address, a.agent_country].filter(Boolean).join(', '))}.</p>
    <h2>Key terms</h2><table><tr><th style="width:28%">Effective date</th><td>${date(a.start_date)}</td><th style="width:22%">Expiry</th><td>${a.end_date ? date(a.end_date) : 'Open-ended'}${a.auto_renew ? ' (auto-renewing)' : ''}</td></tr>
      <tr><th>Territory</th><td>${esc(a.territory || '')}</td><th>Exclusivity</th><td>${esc(a.exclusivity || '')}</td></tr>
      <tr><th>Payment terms</th><td>${a.payment_terms_days} days</td><th>Credit limit</th><td>${a.credit_limit ? money(a.credit_limit) + ' ' + esc(a.currency) : 'None'}</td></tr>
      <tr><th>Notice period</th><td>${a.notice_days} days</td><th>Governing law</th><td>${esc(a.governing_law || '')}</td></tr></table>
    ${a.commission_summary ? `<h2>Commission</h2><p>${nl(a.commission_summary)}</p>` : ''}
    ${a.rules.length ? `<table><tr><th>Commission schedule</th><th>Basis</th><th class="num">Rate</th><th>Applies to</th></tr>${a.rules.filter((r) => r.active).map((r) => `<tr><td>${esc(r.name)}</td><td>${esc(state.lk.commission_basis[r.basis] || r.basis)}</td><td class="num">${r.basis.startsWith('PERCENT') ? num(r.rate) + '%' : money(r.rate) + ' ' + esc(r.currency)}</td><td>${esc([r.cargo_type === 'ANY' ? 'FCL & LCL' : r.cargo_type, r.pol_name && 'from ' + r.pol_name, r.pod_name && 'to ' + r.pod_name].filter(Boolean).join(', '))}</td></tr>`).join('')}</table>` : ''}
    <h2>Terms and conditions</h2>${a.clauses.map((cl, i) => `<div class="clause"><b>${i + 1}. ${esc(cl.title)}</b>${nl(cl.body)}</div>`).join('') || '<p class="fine">No clauses recorded.</p>'}
    <div class="sig"><div>For ${esc(c.company_name)}<br><br>Name / title / date</div><div>For ${esc(a.agent_name)}<br><br>Name / title / date</div></div>`);
}

// ------------------------------------------------------------------ commission statement
async function commission(root, id) {
  const s = await api('GET', `/commissions/${id}`);
  wrap(root, `${header('AGENCY COMMISSION STATEMENT', `<div>No. <b>${esc(s.stmt_no)}</b></div>${s.status !== 'POSTED' ? `<div style="margin-top:6px"><span class="stamp">${esc(s.status)}</span></div>` : ''}`)}
    <div class="cols">${box('Agent', `<b>${esc(s.agent_name)}</b> (${esc(s.agent_code)})<br>${nl([s.agent_address, s.agent_country].filter(Boolean).join('\n'))}`)}${box('Statement', `Agreement ${esc(s.agreement_no || '-')}<br>Sailings ${date(s.period_from)} &ndash; ${date(s.period_to)}<br>Currency ${esc(s.currency)}`)}</div>
    <h2>Shipments</h2><table><tr><th>ETD</th><th>HBL / booking</th><th>Route</th><th>Rule</th><th class="num">Basis</th><th class="num">Commission (${esc(s.currency)})</th></tr>
      ${s.lines.map((l) => `<tr><td>${date(l.etd)}</td><td>${esc(l.hbl_no || l.booking_no)}</td><td>${esc(l.pol_name || '')} &rarr; ${esc(l.pod_name || '')} (${esc(l.cargo_type)})</td><td>${esc(l.rule_name || '')}${l.note ? `<div class="fine">${esc(l.note)}</div>` : ''}</td>
        <td class="num">${l.base_qty != null ? num(l.base_qty) : l.base_amount != null ? money(l.base_amount) : ''}</td><td class="num">${money(l.commission_amount)}</td></tr>`).join('')}
      <tr><td colspan="5"><b>Total commission</b></td><td class="num"><b>${money(s.total)}</b></td></tr></table>
    ${s.document ? `<p>Posted to your account as ${esc(s.document.doc_no)}, payable by ${date(s.document.due_date)}.</p>` : ''}
    <p class="fine">Commission is calculated under the agency agreement. Amounts due to or from the agent are shown on the statement of account.</p>`);
}
