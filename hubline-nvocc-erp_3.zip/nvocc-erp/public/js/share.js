// "Share" for every list and report: download Excel or PDF, send by e-mail straight from the ERP, or hand the file to WhatsApp / Mail / Drive on a phone.
import { esc, api, qs, openModal, on, toast, download, state } from './core.js';
import { icon } from './icons.js';

const MIME = { xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', pdf: 'application/pdf' };
let emailReady = null;
async function emailOn() { if (emailReady === null) { try { emailReady = !!(await api('GET', '/share/status')).email; } catch { emailReady = false; } } return emailReady; }
export const resetShareStatus = () => { emailReady = null; };

export const shareBtn = (label = 'Share / download', cls = '') => `<button class="btn ${cls}" data-act="share">${icon('share', 16)} ${esc(label)}</button>`;

// kind = a key of the server's export list (inventory, containers, bls, schedules, mrg ...), params = the filters currently on screen
export async function shareModal({ kind, params = {}, title = 'Share', what = 'this report', pdf = true, defaultSubject = '' }) {
  const mailOk = await emailOn();
  const canNative = typeof navigator !== 'undefined' && !!navigator.canShare && !!window.File;
  const h = openModal({ title, size: 'narrow', body: `
    <p class="muted" style="margin-top:0">Send ${esc(what)} exactly as you see it now.</p>
    <div class="share-grid">
      <button class="share-opt" data-dl="xlsx">${icon('sheet', 26)}<b>Excel</b><span>Download .xlsx</span></button>
      ${pdf ? `<button class="share-opt" data-dl="pdf">${icon('report', 26)}<b>PDF</b><span>Download .pdf</span></button>` : ''}
      ${canNative ? `<button class="share-opt" data-native>${icon('share', 26)}<b>Share…</b><span>WhatsApp, Mail, Drive</span></button>` : ''}
    </div>
    <div class="share-mail">
      <div class="wiz-opt-h">${icon('mail', 15)} Send by e-mail</div>
      ${mailOk ? `<div class="form-grid" style="grid-template-columns:1fr">
          <label class="f"><span>To <em class="hint">(separate several addresses with commas)</em></span><input type="text" data-to placeholder="name@company.com"></label>
          <label class="f"><span>Subject</span><input type="text" data-subject value="${esc(defaultSubject)}" placeholder="Leave empty for an automatic subject"></label>
          <label class="f"><span>Message <em class="hint">(optional)</em></span><textarea data-msg rows="2"></textarea></label>
          <label class="f"><span>Attach</span><select data-fmt><option value="xlsx">Excel</option>${pdf ? '<option value="pdf">PDF</option><option value="both">Excel and PDF</option>' : ''}</select></label></div>
        <div class="alert bad hidden" data-err></div>
        <button class="btn primary" data-send style="margin-top:10px">${icon('mail', 16)} Send e-mail</button>`
        : `<div class="alert info" style="margin:0">E-mail sending is not set up yet. ${state.me && state.me.role === 'admin' ? 'Fill in the mail server under <a href="#/setup/company" data-close>Setup &rarr; Company &amp; settings</a>.' : 'Ask your administrator to fill in the e-mail settings under Setup.'}</div>`}
    </div>` });
  const url = (fmt) => `/export/${kind}${qs({ ...params, format: fmt })}`;
  on(h.el, 'click', '[data-dl]', (_e, el) => { download(url(el.dataset.dl)); toast('Download started', 'ok'); });
  on(h.el, 'click', '[data-native]', async () => {
    try {
      const fmt = pdf ? 'pdf' : 'xlsx';
      const res = await fetch('/api' + url(fmt), { headers: { 'X-Requested-With': 'hubline-erp' } });
      if (!res.ok) throw new Error('Could not prepare the file.');
      const name = ((res.headers.get('content-disposition') || '').match(/filename="?([^";]+)/) || [])[1] || `report.${fmt}`;
      const file = new File([await res.blob()], name, { type: MIME[fmt] });
      if (!navigator.canShare({ files: [file] })) throw new Error('This device cannot share files from the browser - use the download buttons.');
      await navigator.share({ files: [file], title: name });
    } catch (e) { if (e.name !== 'AbortError') toast(e.message, 'bad'); }
  });
  on(h.el, 'click', '[data-send]', async (_e, btn) => {
    const err = h.$('[data-err]'); err.classList.add('hidden');
    btn.disabled = true;
    try {
      const r = await api('POST', `/export/${kind}/email`, { params, format: h.$('[data-fmt]').value, to: h.$('[data-to]').value, subject: h.$('[data-subject]').value, message: h.$('[data-msg]').value });
      toast(`E-mail sent to ${r.sent_to} recipient${r.sent_to === 1 ? '' : 's'}`, 'ok'); h.close(true);
    } catch (e) { err.textContent = e.message; err.classList.remove('hidden'); btn.disabled = false; }
  });
  return h.done;
}

// wires every [data-act=share] button inside `root`; getParams() is read at click time so the current filters are used
export function wireShare(root, cfg) {
  on(root, 'click', '[data-act=share]', () => shareModal(typeof cfg === 'function' ? cfg() : cfg));
}
