// "Fill from the vessel schedule": pick a sailing and vessel, voyage, ports and dates are filled in for you.
import { api, opts } from './core.js';

export const loadSchedules = async () => { try { return await api('GET', '/schedules/upcoming'); } catch { return []; } };
const label = (s) => `${s.vessel}${s.voyage ? ' ' + s.voyage : ''} - ${s.pol_name || '?'} > ${s.pod_name || '?'} - ETD ${s.etd || s.eta || '?'}`;
export const scheduleField = (rows) => ({ name: '_schedule', label: 'Fill from the vessel schedule', hint: 'optional - fills vessel, voyage, ports and dates', type: 'select', span: 4, empty: rows.length ? 'Choose a sailing…' : 'No upcoming sailings are loaded yet',
  options: () => rows.map((s) => [s.id, label(s)]) });

export function bindSchedulePicker(h, rows) {
  const sel = h.$('[name=_schedule]'); if (!sel) return;
  sel.addEventListener('change', () => {
    const s = rows.find((r) => String(r.id) === sel.value); if (!s) return;
    const set = (name, v) => { const el = h.$(`[name=${name}]`); if (el && v) el.value = v; };
    const combo = (name, list, id) => { const el = h.$(`[name=${name}]`); if (!el || !id) return; const m = list.find(([v]) => String(v) === String(id)); if (m) el.value = m[1]; };
    set('vessel', s.vessel); set('voyage', s.voyage); set('etd', s.etd); set('eta', s.eta); set('cutoff_date', s.cutoff_date);
    combo('pol_id', opts.ports(), s.pol_id); combo('pod_id', opts.ports(), s.pod_id); combo('carrier_id', opts.parties('carrier'), s.carrier_id);
  });
}
