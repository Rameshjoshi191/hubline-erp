// One step-by-step import wizard for every "load it from Excel" job (container inventory, vessel schedules, MRG rates).
// Step 1 choose the file (or paste, or a web link) -> Step 2 check what will happen (nothing is saved yet) -> Step 3 done.
import { esc, api, upload, tbl, badge, openModal, on, toast, fieldHtml, readForm, download, int } from './core.js';
import { icon } from './icons.js';

const ACTION = { CREATE: ['New', 'ok'], MOVE: ['Move', 'info'], LOCATION: ['New location', 'info'], UPDATE: ['Changed', 'warn'], NOCHANGE: ['No change', ''], ERROR: ['Error', 'bad'] };
const FILE_OK = /\.(xlsx|csv|tsv|txt)$/i;

/*
  cfg = {
    title, base ('/inventory'), noun ('containers'), templateName,
    cols: [{ label, render(row) }]           what to show for each row
    tiles(summary) -> [[label, value, tone]]  the four numbers on top
    options: [form fields]                    optional settings that change the result (re-checked live)
    optionsTitle, intro (html shown on step 1), pasteHint,
    extraTabs: [{ id, label, mount(el, ctx) }] ctx = { start(response) }  e.g. "From a web link"
    saveLabel(summary) -> text, doneHtml(result, summary) -> html, nextLinks: [[label, href]]
  }
  Resolves with the commit result when something was saved, otherwise null.
*/
export function importWizard(cfg) {
  const st = { step: 1, tab: 'file', resp: null, mapping: {}, options: cfg.defaults || {}, filter: 'all', busy: false, result: null, extra: {} };
  const h = openModal({ title: cfg.title, size: 'wide', body: '<div data-wiz></div>' });
  const wiz = h.$('[data-wiz]');

  const steps = (n) => `<div class="steps">${['Choose file', 'Check', 'Done'].map((t, i) => `<span class="${i + 1 < n ? 'done' : i + 1 === n ? 'now' : ''}">${i + 1}. ${t}</span>`).join('')}</div>`;
  const bar = (left, right) => `<div class="wiz-bar"><div>${left}</div><div class="pill-row">${right}</div></div>`;

  // ------------------------------------------------------------ step 1
  function paintStep1() {
    const tabs = [{ id: 'file', label: 'Excel / CSV file' }, ...(cfg.extraTabs || [])];
    wiz.innerHTML = `${steps(1)}${cfg.intro ? `<p class="muted" style="margin-top:0">${cfg.intro}</p>` : ''}
      ${tabs.length > 1 ? `<div class="tabs">${tabs.map((t) => `<a data-tab="${t.id}" class="${t.id === st.tab ? 'on' : ''}">${esc(t.label)}</a>`).join('')}</div>` : ''}
      <div data-pane></div>`;
    const pane = h.$('[data-pane]');
    if (st.tab === 'file') {
      pane.innerHTML = `<label class="dropzone" data-drop tabindex="0"><input type="file" accept=".xlsx,.csv,.tsv,.txt" hidden data-file>
          <span class="dz-ic">${icon('upload', 30)}</span><b>Drop your Excel or CSV file here</b><span class="muted">or click to choose it from your computer</span></label>
        <div class="wiz-or"><span>or paste rows copied from Excel</span></div>
        <textarea data-paste rows="4" placeholder="${esc(cfg.pasteHint || 'Copy the rows in Excel and paste them here. The first line can be the column headings - if there are none, we work out the columns from the data.')}"></textarea>
        <div class="toolbar" style="margin:10px 0 0"><button class="btn" data-paste-go>${icon('check', 16)} Check pasted rows</button><span class="grow"></span>
          ${cfg.template === false ? '' : `<a class="btn ghost" href="/api${cfg.base}/template" data-template>${icon('download', 16)} Download the Excel template</a>`}</div>`;
    } else {
      const tab = (cfg.extraTabs || []).find((t) => t.id === st.tab);
      tab.mount(pane, { start: (resp) => { accept(resp); }, wizard: h });
    }
  }
  on(wiz, 'click', '[data-tab]', (_e, el) => { st.tab = el.dataset.tab; paintStep1(); });
  on(wiz, 'change', '[data-file]', (_e, el) => { if (el.files[0]) pickFile(el.files[0]); });
  on(wiz, 'click', '[data-paste-go]', async () => {
    const text = h.$('[data-paste]').value;
    if (!text.trim()) return toast('Paste some rows first.', 'bad');
    await run(() => upload(`${cfg.base}/import/parse`, text, 'pasted rows'));
  });
  wiz.addEventListener('dragover', (e) => { if (e.target.closest('[data-drop]')) { e.preventDefault(); e.target.closest('[data-drop]').classList.add('over'); } });
  wiz.addEventListener('dragleave', (e) => { const d = e.target.closest('[data-drop]'); if (d) d.classList.remove('over'); });
  wiz.addEventListener('drop', (e) => { const d = e.target.closest('[data-drop]'); if (!d) return; e.preventDefault(); d.classList.remove('over'); if (e.dataTransfer.files[0]) pickFile(e.dataTransfer.files[0]); });
  wiz.addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[data-drop]')) { e.preventDefault(); e.target.querySelector('input').click(); } });

  async function pickFile(file) {
    if (!FILE_OK.test(file.name)) return toast('Please choose an Excel (.xlsx) or CSV file. Old .xls files: open them in Excel and use Save As .xlsx.', 'bad');
    if (file.size > 8 * 1024 * 1024) return toast('That file is larger than 8 MB. Split it into smaller files.', 'bad');
    await run(() => upload(`${cfg.base}/import/parse`, file, file.name));
  }
  async function run(fn) {
    if (st.busy) return; st.busy = true; wiz.classList.add('busy');
    try { accept(await fn()); } catch (e) { toast(e.message, 'bad'); } finally { st.busy = false; wiz.classList.remove('busy'); }
  }
  function accept(resp) {
    st.resp = resp; st.mapping = { ...resp.mapping }; st.options = { ...st.options, ...(resp.plan.options || {}) }; st.filter = resp.plan.summary && resp.plan.summary.error && !resp.plan.summary.ready ? 'error' : 'all';
    st.step = 2; paint();
  }

  // ------------------------------------------------------------ step 2
  const fieldSelect = (f, headers) => `<label class="f"><span>${esc(f.label)}${f.required ? ' <b class="req">*</b>' : ''}</span><select data-map="${f.key}"><option value="">- not in the file -</option>${headers.map((hd, i) => `<option value="${i}" ${String(st.mapping[f.key]) === String(i) ? 'selected' : ''}>${esc(hd || 'Column ' + (i + 1))}</option>`).join('')}</select></label>`;
  function paintStep2() {
    const r = st.resp, p = r.plan, sm = p.summary || {};
    const missing = (r.fields || []).filter((f) => f.required && !(f.key in st.mapping));
    const tiles = p.problem ? [] : cfg.tiles(sm);
    const rows = (p.rows || []).filter((x) => st.filter === 'all' || (st.filter === 'save' && x.action !== 'ERROR' && x.action !== 'NOCHANGE') || (st.filter === 'error' && x.action === 'ERROR') || (st.filter === 'warn' && x.level === 'warn'));
    const cnt = { all: (p.rows || []).length, save: sm.ready || 0, error: sm.error || 0, warn: sm.warn || 0 };
    wiz.innerHTML = `${steps(2)}
      <div class="wiz-file">${icon('sheet', 18)} <b>${esc(r.filename || 'Pasted rows')}</b> <span class="muted">&middot; ${int(r.totalRows)} row${r.totalRows === 1 ? '' : 's'} read${r.hasHeader ? '' : ' (no heading line - columns guessed from the data)'}</span></div>
      ${p.problem ? `<div class="alert bad">${esc(p.problem)}</div>` : ''}
      ${tiles.length ? `<div class="wiz-tiles">${tiles.map(([k, v, tone]) => `<div class="wt ${tone || ''}"><b>${int(v)}</b><span>${esc(k)}</span></div>`).join('')}</div>` : ''}
      ${cfg.options && cfg.options.length ? `<div class="wiz-opt"><div class="wiz-opt-h">${esc(cfg.optionsTitle || 'Options')}</div><div class="form-grid" data-opts>${cfg.options.map((f) => fieldHtml(f, st.options[f.name], 'wo')).join('')}</div></div>` : ''}
      <details class="wiz-map" ${p.problem || missing.length ? 'open' : ''}><summary>${icon('wand', 15)} Columns we found in your file ${missing.length ? '<span class="badge bad">check needed</span>' : '<span class="badge ok">understood automatically</span>'}</summary>
        <div class="form-grid" data-mapgrid>${(r.fields || []).map((f) => fieldSelect(f, r.headers)).join('')}</div>
        ${r.sample && r.sample.length ? `<div class="muted small" style="margin-top:10px">First rows of your file:</div>${tbl({ compact: true, rows: r.sample, cols: r.headers.map((hd, i) => ({ label: hd || `Column ${i + 1}`, render: (row) => esc(row[i]) })) })}` : ''}</details>
      ${!p.problem ? `<div class="wiz-filters">${[['all', 'All rows'], ['save', 'Will be saved'], ['error', 'Errors'], ['warn', 'Warnings']].map(([k, l]) => `<button class="chip ${st.filter === k ? 'on' : ''}" data-filter="${k}" ${k !== 'all' && !cnt[k] ? 'disabled' : ''}>${l} <b>${cnt[k]}</b></button>`).join('')}</div>
        ${tbl({ compact: true, rows, empty: 'No rows in this view.', cols: [{ label: 'Row', render: (x) => `<span class="muted small">${x.line}</span>` }, ...cfg.cols,
          { label: 'What will happen', render: (x) => `${badge(...(ACTION[x.action] || [x.action, '']))}${(x.messages || []).concat(x.notes || []).length ? `<div class="small ${x.level === 'error' ? 'neg' : 'muted'}">${(x.messages || []).concat(x.notes || []).map(esc).join('<br>')}</div>` : ''}` }] })}
        ${p.truncated ? '<div class="muted small" style="margin-top:8px">Only the first 1,500 rows are shown here; all rows are processed when you save.</div>' : ''}` : ''}
      ${bar(`<button class="btn" data-back>&larr; Choose another file</button>`, `<button class="btn primary" data-save ${sm.ready ? '' : 'disabled'}>${icon('check', 16)} ${esc(sm.ready ? cfg.saveLabel(sm) : 'Nothing to save')}</button>`)}`;
  }
  const preview = () => run(() => api('POST', `${cfg.base}/import/preview`, { token: st.resp.token, mapping: st.mapping, options: st.options }));
  on(wiz, 'change', '[data-map]', (_e, el) => { st.mapping[el.dataset.map] = el.value === '' ? '' : Number(el.value); preview(); });
  wiz.addEventListener('change', (e) => {
    if (!e.target.closest('[data-opts]')) return;
    try { st.options = { ...st.options, ...readForm(h.$('[data-opts]'), cfg.options) }; } catch (x) { return toast(x.message, 'bad'); }
    preview();
  });
  on(wiz, 'click', '[data-filter]', (_e, el) => { st.filter = el.dataset.filter; paint(); });
  on(wiz, 'click', '[data-back]', () => { st.step = 1; st.resp = null; paint(); });
  on(wiz, 'click', '[data-save]', async (_e, btn) => {
    btn.disabled = true;
    try {
      const out = await api('POST', `${cfg.base}/import/commit`, { token: st.resp.token, mapping: st.mapping, options: st.options });
      st.result = out; st.step = 3; paint();
    } catch (e) { toast(e.message, 'bad'); btn.disabled = false; }
  });

  // ------------------------------------------------------------ step 3
  function paintStep3() {
    wiz.innerHTML = `${steps(3)}<div class="wiz-done"><div class="big-ok">${icon('check', 34)}</div>${cfg.doneHtml(st.result.result, st.result.summary)}</div>
      ${bar(`<button class="btn" data-again>Load another file</button>`, `${(cfg.nextLinks || []).map(([l, href]) => `<a class="btn" href="${href}" data-closewiz>${esc(l)}</a>`).join('')}<button class="btn primary" data-finish>Finish</button>`)}`;
  }
  on(wiz, 'click', '[data-again]', () => { st.step = 1; st.resp = null; st.result = null; paint(); });
  on(wiz, 'click', '[data-finish]', () => h.close(st.result));
  on(wiz, 'click', '[data-closewiz]', () => h.close(st.result));

  function paint() { if (st.step === 1) paintStep1(); else if (st.step === 2) paintStep2(); else paintStep3(); h.dialog.scrollIntoView({ block: 'start' }); }
  paint();
  return h.done.then((v) => v || st.result || null);   // closing with Esc or the cross after saving still counts as done, so the page behind refreshes
}

// shared summary tiles
export const tilesFor = (labels) => (s) => labels.map(([key, label, tone]) => [label, s[key] || 0, tone]);
