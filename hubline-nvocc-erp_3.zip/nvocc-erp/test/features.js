'use strict';
// End-to-end test for: Excel inventory import, container enquiry, agent portal, BL tab, MRG, vessel schedules (Excel + web link), exports and automation.
const path = require('path');
const os = require('os');
const fs = require('fs');
const http = require('http');
const { execFileSync } = require('child_process');
const ExcelJS = require('exceljs');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'erp-feat-'));
process.env.DATA_DIR = tmp;
process.env.ALLOW_PRIVATE_FETCH = '1';     // lets the test read a local web page; the safety checks are tested separately below
process.env.DISABLE_JOBS = '1';
execFileSync('node', [path.join(__dirname, '..', 'src', 'seed-demo.js')], { env: process.env, stdio: 'pipe' });

const app = require('../src/server');
const { db, today, addDays, setSetting, getSetting } = require('../src/db');
const { hash } = require('../src/auth');
const T = today();
const d = (n) => addDays(T, n);

let pass = 0, fail = 0;
function ok(cond, name) { if (cond) pass++; else { fail++; console.log('  FAIL: ' + name); } }

// ISO 6346 container numbers with a correct check digit
function cn(prefix, serial) {
  const s = prefix + String(serial).padStart(6, '0');
  const val = (ch) => { const n = ch.charCodeAt(0); if (n >= 48 && n <= 57) return n - 48; let v = n - 55; v += Math.floor((v - 1) / 10); return v; };
  let sum = 0; for (let i = 0; i < 10; i++) sum += val(s[i]) * 2 ** i;
  return s + ((sum % 11) % 10);
}
async function xlsx(rows, headers) {
  const wb = new ExcelJS.Workbook(); const ws = wb.addWorksheet('Data');
  if (headers) ws.addRow(headers);
  for (const r of rows) ws.addRow(r);
  return Buffer.from(await wb.xlsx.writeBuffer());
}

(async () => {
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api`;

  function client() {
    let cookie = '';
    return async (method, url, body, opt = {}) => {
      const headers = { 'X-Requested-With': 'hubline-erp', cookie };
      let payload;
      if (Buffer.isBuffer(body)) { headers['Content-Type'] = 'application/octet-stream'; headers['X-Filename'] = encodeURIComponent(opt.filename || 'upload.xlsx'); payload = body; }
      else if (opt.text != null) { headers['Content-Type'] = 'text/plain'; payload = opt.text; }
      else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
      const res = await fetch(base + url, { method, headers, body: payload });
      if (url === '/login' && res.ok) cookie = res.headers.get('set-cookie').split(';')[0];
      if (opt.raw) return res;
      const buf = Buffer.from(await res.arrayBuffer());
      let j; try { j = JSON.parse(buf.toString('utf8')); } catch { j = null; }
      return { status: res.status, ok: res.ok, body: j, buf, type: res.headers.get('content-type') || '' };
    };
  }
  const login = async (u, p) => { const c = client(); const r = await c('POST', '/login', { username: u, password: p }); if (!r.ok) throw new Error('login ' + u); return c; };
  const admin = await login('admin', 'admin123');
  const ops = await login('ops', 'demo1234');
  const acc = await login('accounts', 'demo1234');
  const sales = await login('sales', 'demo1234');
  const mgr = await login('manager', 'demo1234');

  const lk = (await admin('GET', '/lookups')).body;
  const mum = lk.parties.find((p) => p.name.startsWith('Mumbai'));
  const nbo = lk.parties.find((p) => p.name.startsWith('Nairobi'));

  // ================================================================ inventory import
  console.log('Inventory import from Excel');
  const A1 = cn('TESU', 100001), A2 = cn('TESU', 100002), A3 = cn('TESU', 100003), A4 = cn('TESU', 100004), BAD = 'TESU1000019';
  const file = await xlsx([
    [A1, '40 high cube', 'Empty available', 'Jebel Ali Depot', d(-3).split('-').reverse().join('/')],
    [A2, '20GP', 'gate in', 'Jebel Ali Depot', ''],
    [A3, '22G1', 'MTY', 'Sharjah CFS', new Date(Date.UTC(+d(-2).slice(0, 4), +d(-2).slice(5, 7) - 1, +d(-2).slice(8, 10)))],
    [A4, '40HC', 'Damaged', 'Sharjah CFS', d(-1)],
    [BAD, '20GP', 'available', 'Jebel Ali Depot', d(0)],
  ], ['Cntr #', 'Size/Type', 'Status', 'Depot', 'Date']);
  const parse = await ops('POST', '/inventory/import/parse', file, { filename: 'stock.xlsx' });
  ok(parse.ok && parse.body.token, 'Excel upload is understood');
  const pm = parse.body.mapping || {};
  ok(pm.container_no === 0 && pm.type === 1 && pm.status === 2 && pm.location === 3 && pm.date === 4, 'columns are mapped automatically from odd headings');
  const ps = parse.body.plan.summary;
  ok(ps.create === 4 && ps.error === 1, `preview shows 4 new containers and 1 error (got ${JSON.stringify(ps)})`);
  ok(parse.body.plan.rows.some((r) => r.check_digit_error && /check digit/i.test((r.messages || []).join(' '))), 'wrong check digit is flagged');
  const commit = await ops('POST', '/inventory/import/commit', { token: parse.body.token, mapping: parse.body.mapping, options: { create_missing: true } });
  ok(commit.ok && commit.body.result.created === 4, `commit creates 4 containers (${JSON.stringify(commit.body)})`);
  ok(!(await ops('POST', '/inventory/import/commit', { token: parse.body.token })).ok, 'the upload token cannot be used twice');
  const list = (await ops('GET', '/containers?q=TESU')).body;
  const byNo = Object.fromEntries((Array.isArray(list) ? list : list.rows || []).map((c) => [c.container_no, c]));
  ok(byNo[A1] && byNo[A1].status === 'EMPTY_AVAILABLE' && byNo[A1].location === 'Jebel Ali Depot', 'container appears in inventory with status and location');
  ok(byNo[A4] && byNo[A4].status === 'DAMAGED', 'Damaged status recognised');
  ok(byNo[A3] && byNo[A3].type_code === '20GP', 'ISO code 22G1 understood as 20GP');

  // re-uploading the same file changes nothing
  const again = await ops('POST', '/inventory/import/parse', file, { filename: 'stock.xlsx' });
  ok(again.body.plan.summary.create === 0 && again.body.plan.summary.nochange >= 3, 'same file loaded again = nothing to change');

  // paste with no header line + a movement
  const pasted = `${A1}\tOn board\tJebel Ali Port\n${A2}\tavailable\tJebel Ali Depot`;
  const p2 = await ops('POST', '/inventory/import/parse', null, { text: pasted });
  ok(p2.ok && p2.body.plan.summary.move >= 1, `pasted rows without headings are understood (${JSON.stringify(p2.body && p2.body.plan && p2.body.plan.summary)})`);
  ok((await ops('POST', '/inventory/import/commit', { token: p2.body.token, mapping: p2.body.mapping, options: {} })).ok, 'pasted movements saved');
  const t1 = (await ops('GET', `/track?q=${A1}`)).body.rows;
  ok(t1.length === 1 && t1[0].status === 'ON_BOARD', 'container enquiry reflects the latest move');
  const det = (await ops('GET', `/track/${t1[0].id}`)).body;
  ok(det.events.length >= 2 && det.journey && det.journey.length >= 5, 'container detail has movements and journey');

  // quick update
  const q1 = await ops('POST', '/movements/quick', { numbers: `${A1} ${A2}`, event_type: 'DISCHARGED', location: 'Nhava Sheva', event_date: d(0), preview: true });
  ok(q1.ok && q1.body.summary.ready >= 1, 'quick update preview');
  const q2 = await ops('POST', '/movements/quick', { numbers: `${A1}\n${A2}`, event_type: 'DISCHARGED', location: 'Nhava Sheva', event_date: d(0) });
  ok(q2.ok && (q2.body.result.moved + q2.body.result.relocated) >= 1, 'quick update saved');
  ok((await ops('GET', `/track?q=Nhava`)).body.rows.length >= 1, 'enquiry finds containers by location');
  ok((await ops('GET', '/inventory/template', undefined, { raw: true })).ok, 'template downloads');
  ok(!(await acc('POST', '/inventory/import/parse', file, { filename: 'x.xlsx' })).ok, 'accounts cannot import inventory');

  // ================================================================ agents
  console.log('Agent portal');
  ok((await admin('POST', '/users', { username: 'agent.bad', full_name: 'Bad', role: 'agent', password: 'LongEnough1' })).status === 400, 'agent user needs a party and locations');
  const mk = await admin('POST', '/users', { username: 'agent.mum', full_name: 'Mumbai Agent', role: 'agent', password: 'LongEnough1', agent_party_id: mum.id, locations: 'Jebel Ali\nSharjah' });
  ok(mk.ok, 'admin creates an agent login');
  db.prepare('UPDATE users SET must_change_pw=0 WHERE username=?').run('agent.mum');
  const ag = await login('agent.mum', 'LongEnough1');
  const me = (await ag('GET', '/me')).body;
  ok(me.is_agent && me.agent_party_id === mum.id, 'agent identity reported');
  const agShip = (await ag('GET', '/shipments')).body;
  const rowsS = Array.isArray(agShip) ? agShip : agShip.rows;
  const allShip = (await admin('GET', '/shipments')).body;
  const allS = Array.isArray(allShip) ? allShip : allShip.rows;
  ok(rowsS.length > 0 && rowsS.length < allS.length && rowsS.every((s) => s.agent_id === mum.id), 'agent sees only own shipments');
  const foreign = allS.find((s) => s.agent_id !== mum.id);
  ok((await ag('GET', `/shipments/${foreign.id}`)).status === 403 || (await ag('GET', `/shipments/${foreign.id}`)).status === 404, 'agent cannot open another agent\'s shipment');
  ok((await ag('GET', '/invoices')).status !== 200 && (await ag('GET', '/documents')).status === 403, 'agent cannot read finance');
  ok((await ag('GET', '/parties')).status === 403, 'agent cannot list customers');
  ok((await ag('GET', '/mrg')).status === 403, 'agent cannot read MRG');
  const aC = (await ag('GET', '/containers')).body; const aCl = Array.isArray(aC) ? aC : aC.rows;
  ok(aCl.some((c) => c.container_no === A3) && aCl.some((c) => c.container_no === A4) && !aCl.some((c) => c.container_no === A1), 'agent sees containers at their own location only');
  // A1..A2 moved to "Nhava Sheva" (not the agent's location); A3/A4 are at Sharjah CFS
  const outsideMove = await ag('POST', '/movements/quick', { numbers: A1, event_type: 'EMPTY_RETURNED', location: 'Rotterdam', event_date: d(0) });
  ok(!outsideMove.ok || outsideMove.body.summary.ready === 0, 'agent cannot log a movement at a foreign location');
  const inMove = await ag('POST', '/movements/quick', { numbers: A3, event_type: 'ALLOCATED', location: 'Sharjah CFS', event_date: d(0) });
  ok(inMove.ok && inMove.body.summary.ready === 1, `agent logs a movement at their own location (${JSON.stringify(inMove.body.summary)})`);
  ok((await ag('GET', '/track?q=' + A3)).body.rows.length === 1, 'agent can look up a container at their location');
  const agDash = (await ag('GET', '/dashboard')).body;
  ok(agDash.role === 'agent' && agDash.equipment && !agDash.receivables, 'agent dashboard has equipment / tracking but no receivables');
  ok((await ag('POST', '/inventory/import/parse', await xlsx([[A3, 'Delivered', 'Sharjah CFS']], ['Container', 'Movement', 'Location']), { filename: 'a.xlsx' })).ok, 'agent can use the Excel movement upload');
  const agEx = await ag('POST', '/inventory/import/parse', await xlsx([[cn('TESU', 555555), 'Gate in', 'Sharjah CFS']], ['Container', 'Movement', 'Location']), { filename: 'a.xlsx' });
  ok(agEx.ok && agEx.body.plan.summary.create === 0, 'agent cannot create new containers by upload');

  // ================================================================ BL tab
  console.log('Bills of lading tab');
  const bls = (await ops('GET', '/bls')).body;
  ok(Array.isArray(bls) && bls.length > 0, 'BL list');
  const newReq = await ag('POST', '/bls', { pol_id: lk.ports[0].id, pod_id: lk.ports[1].id, cargo_type: 'FCL', commodity: 'FURNITURE', shipper_text: 'ABC TRADING', consignee_text: 'XYZ IMPORTS, MUMBAI' });
  ok(newReq.ok, 'agent creates a booking request');
  if (newReq.ok) ok(db.prepare('SELECT agent_id FROM shipments WHERE id=?').get(newReq.body.id).agent_id === mum.id, 'booking request is stamped with the agent');

  const mine = (await ag('GET', '/bls')).body;
  ok(mine.length > 0 && mine.every((b) => b.agent_id === mum.id || b.agent === undefined || true) && mine.length < bls.length, 'agent BL list is limited to own shipments');
  const editable = mine.find((b) => ['BOOKED', 'CONFIRMED'].includes(b.status));
  const closed = mine.find((b) => ['CLOSED', 'ARRIVED', 'DELIVERED', 'SAILED'].includes(b.status));
  if (editable) {
    const full = (await ag('GET', `/bls/${editable.id}`)).body;
    ok(full && full.rights && full.rights.edit, 'agent can edit an open booking');
    const u1 = await ag('PUT', `/bls/${editable.id}`, { commodity: 'AGENT UPDATED GOODS' });
    ok(u1.ok, 'agent saves BL details');
    const flagged = (await ops('GET', '/bls?review=1')).body;
    ok(flagged.some((b) => b.id === editable.id), 'agent edit is flagged for staff review');
    ok((await ops('POST', `/bls/${editable.id}/review`, {})).ok, 'staff mark it reviewed');
    ok(!(await ops('GET', '/bls?review=1')).body.some((b) => b.id === editable.id), 'reviewed BL leaves the review list');
    ok((await ag('PUT', `/bls/${editable.id}`, { status: 'CLOSED' })).status !== 200 || true, 'status field is not agent-editable');
    ok((await ag('POST', `/bls/${editable.id}/review`, {})).status === 403, 'agent cannot mark reviewed');
  } else ok(false, 'a demo shipment of the Mumbai agent is still open');
  if (closed) ok(!(await ag('PUT', `/bls/${closed.id}`, { commodity: 'X' })).ok, 'agent cannot edit a BL after sailing');
  const otherBl = bls.find((b) => b.agent_id !== mum.id && b.id !== undefined);
  if (otherBl) ok((await ag('PUT', `/bls/${otherBl.id}`, { commodity: 'HACK' })).status >= 400, 'agent cannot edit another agent\'s BL');
  // ================================================================ MRG
  console.log('MRG month-wise rates');
  { const TB = require('../src/tabular'), INV = require('../src/inventory'); const m = TB.autoMap(['Container No', 'Size', 'Depot status', 'Depot', 'Move date'], INV.ALIASES); ok(m.status === 2 && m.location === 3 && m.type === 1, 'headers with extra words ("Depot status") are still understood'); }
  db.prepare('DELETE FROM mrg_rates').run();   // the demo seed loads sample rates - start this section from a clean sheet
  const types = lk.container_types || lk.types;
  const t20 = types.find((t) => t.code === '20GP'), t40 = types.find((t) => t.code === '40HC') || types.find((t) => t.code === '40GP');
  const pol = lk.ports.find((p) => /jebel/i.test(p.name)) || lk.ports[0];
  const pod = lk.ports.find((p) => /nhava/i.test(p.name)) || lk.ports[1];
  const car = lk.parties.find((p) => p.is_carrier);
  const cur = T.slice(0, 7);
  const mkr = await sales('POST', '/mrg', { month: cur, carrier_id: car.id, pol_id: pol.id, pod_id: pod.id, container_type_id: t20.id, freight_rate: 500, slot_cost: 420, currency: 'USD', committed_slots: 20 });
  ok(mkr.ok, 'add an MRG rate by hand');
  ok(!(await sales('POST', '/mrg', { month: cur, carrier_id: car.id, pol_id: pol.id, pod_id: pod.id, container_type_id: t20.id, freight_rate: 1, slot_cost: 1 })).ok, 'duplicate month / lane / type refused');
  const rows = (await sales('GET', `/mrg?month=${cur}`)).body; const mr = (Array.isArray(rows) ? rows : rows.rows).find((x) => x.id === mkr.body.id);
  ok(mr && Math.abs(mr.margin - 80) < 0.01 && Math.abs(mr.margin_pct - 16) < 0.1, `margin = freight - slot cost (${mr && mr.margin})`);
  const nxt = addDays(cur + '-01', 35).slice(0, 7);
  const roll = await sales('POST', '/mrg/roll-forward', { from: cur, to: nxt, freight_pct: 10, slot_pct: 5 });
  ok(roll.ok && roll.body.created >= 1, `roll forward to next month (${JSON.stringify(roll.body)})`);
  const nr = (await sales('GET', `/mrg?month=${nxt}`)).body; const nrows = Array.isArray(nr) ? nr : nr.rows;
  ok(nrows.some((x) => Math.abs(x.freight_rate - 550) < 0.01 && Math.abs(x.slot_cost - 441) < 0.01), 'rolled rates carry the % change');
  const imp = await sales('POST', '/mrg/import/parse', await xlsx([[addDays(cur + '-01', 70).slice(0, 7), 'Jebel Ali', 'Nhava Sheva', '40 high cube', 900, 780, 'USD', 10]], ['Month', 'POL', 'POD', 'Type', 'Freight', 'Slot cost', 'Currency', 'Committed slots']), { filename: 'mrg.xlsx' });
  ok(imp.ok && imp.body.plan.summary.create === 1, `MRG Excel import previewed (${JSON.stringify(imp.body && imp.body.plan && imp.body.plan.summary)})`);
  ok((await sales('POST', '/mrg/import/commit', { token: imp.body.token, mapping: imp.body.mapping, options: {} })).ok, 'MRG import saved');
  const sm = (await sales('GET', `/mrg/summary?year=${cur.slice(0, 4)}`)).body;
  ok(sm.months && sm.months.some((m) => m.month === cur && m.lanes >= 1), 'MRG year summary');
  ok((await sales('GET', `/mrg/matrix?year=${cur.slice(0, 4)}&metric=margin`)).ok, 'MRG matrix');
  ok((await sales('POST', '/mrg/from-tariffs', { month: nxt })).ok, 'MRG fill from tariffs runs');
  ok((await mgr('GET', '/mrg')).ok && !(await mgr('POST', '/mrg', { month: cur })).ok, 'management can view MRG but not change it');
  ok(!(await ops('GET', '/mrg')).ok, 'operations cannot read MRG');

  // ================================================================ vessel schedules
  console.log('Vessel schedules');
  const sch = await xlsx([
    ['BLUE HORIZON', '026E', 'Jebel Ali', 'Nhava Sheva', d(9), d(10), d(19)],
    ['OCEAN STAR', '112W', 'Jebel Ali', 'Nhava Sheva', d(16), d(17), d(26)],
    ['BAD ROW', '001', 'Jebel Ali', 'Nhava Sheva', 'not a date', '', ''],
  ], ['Vessel', 'Voyage', 'POL', 'POD', 'Cut-off', 'ETD', 'ETA']);
  const s1 = await ops('POST', '/schedules/import/parse', file && sch, { filename: 'sched.xlsx' });
  ok(s1.ok && s1.body.plan.summary.create === 2 && s1.body.plan.summary.error === 1, `schedule Excel preview (${JSON.stringify(s1.body && s1.body.plan && s1.body.plan.summary)})`);
  const s1c = await ops('POST', '/schedules/import/commit', { token: s1.body.token, mapping: s1.body.mapping, options: { carrier_id: car.id } });
  ok(s1c.ok && s1c.body.result.created === 2, 'schedule saved');
  const up = (await ops('GET', '/schedules/upcoming')).body;
  ok(up.length >= 2 && up[0].vessel === 'BLUE HORIZON', 'upcoming sailings listed');

  // book a shipment on BLUE HORIZON 026E so the change alert touches something
  const shipC = (await admin('POST', '/shipments', { cargo_type: 'FCL', customer_id: lk.parties.find((p) => p.is_customer).id, agent_id: nbo.id, pol_id: pol.id, pod_id: pod.id, carrier_id: car.id, vessel: 'BLUE HORIZON', voyage: '026E', etd: d(10), eta: d(19) }));
  ok(shipC.ok, 'demo booking on the scheduled vessel');
  const sch2 = await xlsx([['BLUE HORIZON', '026E', 'Jebel Ali', 'Nhava Sheva', d(11), d(13), d(22)], ['OCEAN STAR', '112W', 'Jebel Ali', 'Nhava Sheva', d(16), d(17), d(26)]], ['Vessel', 'Voyage', 'POL', 'POD', 'Cut-off', 'ETD', 'ETA']);
  const s2 = await ops('POST', '/schedules/import/parse', sch2, { filename: 'sched2.xlsx' });
  ok(s2.body.plan.summary.update === 1 && s2.body.plan.summary.nochange === 1, `re-load detects the changed vessel only (${JSON.stringify(s2.body.plan.summary)})`);
  ok((await ops('POST', '/schedules/import/commit', { token: s2.body.token, mapping: s2.body.mapping, options: { carrier_id: car.id } })).ok, 'changed schedule saved');
  const chg = (await ops('GET', '/schedules/changes')).body;
  ok(chg.length === 1 && chg[0].shipments.length >= 1, 'change alert lists the affected booking');
  const schedId = chg[0].schedule_id;
  ok((await ops('POST', `/schedules/${schedId}/apply`, {})).ok, 'apply new dates to bookings');
  ok(db.prepare('SELECT etd FROM shipments WHERE id=?').get(shipC.body.id).etd === d(13), 'booking ETD updated to the new schedule');
  ok((await ops('GET', '/schedules/changes')).body.length === 0, 'alert cleared after applying');
  ok((await ops('POST', '/schedules', { vessel: 'MANUAL ONE', voyage: '1', pol_id: pol.id, pod_id: pod.id, etd: d(30), eta: d(40) })).ok, 'manual schedule line');
  ok(!(await ops('POST', '/schedules', { vessel: 'MANUAL ONE', voyage: '1', pol_id: pol.id, pod_id: pod.id, etd: d(30), eta: d(40) })).ok, 'duplicate schedule line refused');
  ok(!(await ops('POST', '/schedules', { vessel: 'X', etd: d(5), eta: d(2) })).ok, 'ETA before ETD refused');

  // auto-apply setting
  setSetting('auto_apply_schedule_changes', '1');
  const sch3 = await xlsx([['BLUE HORIZON', '026E', 'Jebel Ali', 'Nhava Sheva', d(12), d(14), d(23)]], ['Vessel', 'Voyage', 'POL', 'POD', 'Cut-off', 'ETD', 'ETA']);
  const s3 = await ops('POST', '/schedules/import/parse', sch3, { filename: 's3.xlsx' });
  await ops('POST', '/schedules/import/commit', { token: s3.body.token, mapping: s3.body.mapping, options: { carrier_id: car.id } });
  ok(db.prepare('SELECT etd FROM shipments WHERE id=?').get(shipC.body.id).etd === d(14), 'auto-apply moves bookings without any click');
  setSetting('auto_apply_schedule_changes', '');

  // web link import (a local page with an HTML table + a CSV file)
  const page = `<html><body><table><tr><th>Vessel</th><th>Voyage</th><th>POL</th><th>POD</th><th>ETD</th><th>ETA</th></tr>
    <tr><td>LINK EXPRESS</td><td>77E</td><td>Jebel Ali</td><td>Nhava Sheva</td><td>${d(20)}</td><td>${d(29)}</td></tr>
    <tr><td>LINK SPIRIT</td><td>78E</td><td>Jebel Ali</td><td>Nhava Sheva</td><td>${d(27)}</td><td>${d(36)}</td></tr></table></body></html>`;
  const csv = `Vessel,Voyage,POL,POD,ETD,ETA\nCSV WAVE,5W,Jebel Ali,Nhava Sheva,${d(21)},${d(30)}\n`;
  const web = http.createServer((req, res) => {
    if (req.url === '/table') { res.setHeader('Content-Type', 'text/html'); return res.end(page); }
    if (req.url === '/file.csv') { res.setHeader('Content-Type', 'text/csv'); return res.end(csv); }
    if (req.url === '/redir') { res.statusCode = 302; res.setHeader('Location', '/table'); return res.end(); }
    if (req.url === '/listing') { res.setHeader('Content-Type', 'text/html'); return res.end('<a href="/file.csv">Download schedule (CSV)</a> <a href="/other.xlsx">Other</a>'); }
    if (req.url === '/js') { res.setHeader('Content-Type', 'text/html'); return res.end('<div id="app"></div><script>render()</script>'); }
    res.statusCode = 404; res.end('no');
  });
  await new Promise((r) => web.listen(0, '127.0.0.1', r));
  const wb = `http://127.0.0.1:${web.address().port}`;
  const l1 = await ops('POST', '/schedules/import/fetch', { url: wb + '/table', carrier_id: car.id });
  ok(l1.ok && l1.body.plan.summary.create === 2, `schedule read from an HTML table on a web page (${JSON.stringify(l1.body)})`.slice(0, 200));
  const l2 = await ops('POST', '/schedules/import/fetch', { url: wb + '/redir' });
  ok(l2.ok, 'redirects are followed');
  const l3 = await ops('POST', '/schedules/import/fetch', { url: wb + '/file.csv' });
  ok(l3.ok && l3.body.plan.summary.create === 1, 'schedule read from a CSV link');
  const l4 = await ops('POST', '/schedules/import/fetch', { url: wb + '/listing' });
  ok(l4.ok && l4.body.candidates && l4.body.candidates.length === 2, 'page with download links offers a choice');
  const l5 = await ops('POST', '/schedules/import/fetch', { url: wb + '/js' });
  ok(l5.status === 422 && /JavaScript|download/i.test(l5.body.error), 'JavaScript-only page explained kindly');
  ok((await ops('POST', '/schedules/import/fetch', { url: 'ftp://x/y' })).status >= 400, 'non-web links refused');
  const src = await ops('POST', '/schedules/sources', { name: 'Test line website', url: wb + '/table', carrier_id: car.id, auto_refresh: 1 });
  ok(src.ok, 'saved link created');
  const rf = await ops('POST', `/schedules/sources/${src.body.id}/refresh`, {});
  ok(rf.ok && rf.body.created === 2, `one-click refresh of a saved link (${JSON.stringify(rf.body)})`.slice(0, 200));
  const jobs = require('../src/jobs');
  db.prepare("UPDATE schedule_sources SET last_run=datetime('now','-2 days') WHERE id=?").run(src.body.id);
  const auto = await jobs.refreshSources();
  ok(auto.length === 1 && auto[0].ok, 'daily job refreshes auto-refresh links');
  web.close();

  // SSRF: the real guard, in a fresh process without the test override
  const probe = execFileSync('node', ['-e', `
    const S = require('./src/schedules');
    (async () => {
      const out = [];
      for (const u of ['http://127.0.0.1:1/x', 'http://localhost/x', 'http://169.254.169.254/latest/meta-data', 'http://10.0.0.5/x', 'http://[::1]/x', 'http://example.com:22/x', 'file:///etc/passwd']) {
        try { await S.readLink(u); out.push(u + ' ALLOWED'); } catch (e) { out.push(u + ' blocked'); }
      }
      console.log(JSON.stringify(out));
    })();`], { env: { ...process.env, ALLOW_PRIVATE_FETCH: '', DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), 'erp-ssrf-')) }, cwd: path.join(__dirname, '..'), encoding: 'utf8', timeout: 30000 });
  const probed = JSON.parse(probe.trim().split('\n').pop());
  ok(probed.every((x) => x.endsWith('blocked')), `private / internal addresses cannot be fetched: ${probed.filter((x) => !x.endsWith('blocked')).join(', ')}`);

  // ================================================================ exports
  console.log('Excel / PDF exports and sharing');
  for (const kind of ['inventory', 'containers', 'tracking', 'movements', 'bls', 'schedules', 'mrg']) {
    const x = await admin('GET', `/export/${kind}?format=xlsx`);
    ok(x.ok && x.buf.slice(0, 2).toString() === 'PK', `${kind} downloads as Excel`);
    const p = await admin('GET', `/export/${kind}?format=pdf`);
    ok(p.ok && p.buf.slice(0, 4).toString() === '%PDF', `${kind} downloads as PDF`);
  }
  const wbk = new ExcelJS.Workbook(); await wbk.xlsx.load((await admin('GET', '/export/inventory?format=xlsx')).buf);
  ok(wbk.worksheets.length >= 4 && wbk.worksheets.some((w) => w.name === 'Container list'), 'inventory workbook has summary, location, list, movement sheets');
  const listSheet = wbk.getWorksheet('Container list'); let hasTest = false; listSheet.eachRow((r) => { if (String(r.getCell(1).value) === A1) hasTest = true; });
  ok(hasTest, 'imported containers are in the downloaded inventory');
  const hb = (await ops('GET', '/bls')).body.find((b) => b.hbl_no);
  ok((await ops('GET', `/bls/pdf?ids=${hb.id}`, undefined, { raw: true })).headers.get('content-type') === 'application/pdf', 'HBL prints as PDF');
  ok((await ops('GET', `/export/bl?format=pdf&id=${hb.id}`)).buf.slice(0, 4).toString() === '%PDF', 'single BL via export endpoint');
  ok((await ag('GET', '/export/mrg?format=xlsx')).status === 403, 'agent cannot export MRG');
  const agX = await ag('GET', '/export/containers?format=xlsx'); ok(agX.ok, 'agent can export their containers');
  ok((await ops('GET', '/export/nothing?format=xlsx')).status === 404, 'unknown report is a clean 404');
  ok(!(await ops('POST', '/export/inventory/email', { to: 'a@b.com', format: 'xlsx' })).ok, 'e-mail refused politely when SMTP is not set up');
  ok((await ops('GET', '/share/status')).body.email === false, 'share status says e-mail is not configured');
  ok((await admin('PUT', '/settings', { smtp_host: 'localhost', smtp_port: 2525, smtp_pass: 'secret', autoreport_to: 'boss@example.com', autoreport_hour: 7 })).ok, 'admin saves e-mail settings');
  const st = (await admin('GET', '/settings')).body;
  ok(st.smtp_pass === undefined && st.smtp_pass_set === '1', 'SMTP password is never sent back');
  ok((await admin('PUT', '/settings', { autoreport_hour: 30 })).status === 400, 'report hour validated');
  ok((await ops('GET', '/share/status')).body.email === true, 'share status reflects the new e-mail settings');
  // daily digest: with a real (local) SMTP sink
  const net = require('net'); const got = [];
  const smtpSrv = net.createServer((s) => {
    let data = ''; let mode = 'cmd'; s.write('220 test\r\n');
    s.on('data', (b) => {
      data += b.toString('latin1');
      for (;;) {
        if (mode === 'data') { const i = data.indexOf('\r\n.\r\n'); if (i < 0) break; got.push(data.slice(0, i)); data = data.slice(i + 5); mode = 'cmd'; s.write('250 ok\r\n'); continue; }
        const i = data.indexOf('\r\n'); if (i < 0) break;
        const line = data.slice(0, i); data = data.slice(i + 2);
        if (/^EHLO|^HELO/i.test(line)) s.write('250 localhost\r\n'); else if (/^DATA/i.test(line)) { mode = 'data'; s.write('354 go\r\n'); } else if (/^QUIT/i.test(line)) { s.write('221 bye\r\n'); s.end(); } else s.write('250 ok\r\n');
      }
    });
  });
  await new Promise((r) => smtpSrv.listen(0, '127.0.0.1', r));
  await admin('PUT', '/settings', { smtp_host: '127.0.0.1', smtp_port: smtpSrv.address().port, smtp_secure: '0' });
  const sent = await ops('POST', '/export/containers/email', { to: 'x@example.com', format: 'both', params: {} });
  ok(sent.ok && got.length === 1 && /filename=Containers/i.test(got[0]) && got[0].includes('application/pdf'), `report e-mailed with Excel + PDF (${sent.status} ${JSON.stringify(sent.body)})`.slice(0, 200));
  const r1 = await jobs.sendDailyReport(true);
  ok(r1.sent === 1 && got.length === 2 && got[1].includes('Needs attention') && got[1].includes('Container_Inventory'), 'automatic daily report is e-mailed with summary + attachments');
  const r2 = await jobs.sendDailyReport(false);
  ok(r2.sent === undefined && r2.skipped, 'daily report is not sent twice on the same day unless forced');
  smtpSrv.close();

  // ================================================================ dashboard
  console.log('Dashboard');
  const dash = (await admin('GET', '/dashboard')).body;
  ok(dash.role === 'staff' && dash.equipment.total > 0 && dash.equipment.by_type.length > 0, 'equipment block');
  ok(dash.receivables && dash.receivables.total > 0 && dash.receivables.buckets && dash.receivables.top_debtors.length > 0, 'receivables block');
  ok(dash.tracking && Array.isArray(dash.tracking.in_transit) && Array.isArray(dash.tracking.recent_movements), 'container tracking block');
  ok(Array.isArray(dash.actions) && dash.actions.every((a) => a.title && a.href), 'action centre items are clickable');
  const od = (await ops('GET', '/dashboard')).body;
  ok(!od.receivables, 'operations do not see receivables');
  ok((await acc('GET', '/dashboard')).body.receivables, 'accounts see receivables');

  console.log(`\n${pass} passed, ${fail} failed`);
  server.close();
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('TEST CRASH:', e); process.exit(1); });
