'use strict';
// Container inventory import (Excel / CSV / paste), quick movement updates, container enquiry (tracking) and known locations.
const express = require('express');
const { db, audit, today } = require('../db');
const A = require('../auth');
const { bad } = require('../util');
const L = require('../logic');
const S = require('../scope');
const INV = require('../inventory');
const TR = require('../track');
const kit = require('../importkit');
const ops = require('./ops');

const r = express.Router();
const helpers = { addEvent: ops.addEvent, createContainer: ops.createContainer };

// ---------------------------------------------------------------- import wizard (staff: create + move; agents: move at their own locations)
kit.mount(r, {
  path: 'inventory', module: 'movements', entity: 'container', aliases: INV.ALIASES, templateName: 'Container_inventory_template.xlsx',
  fields: Object.entries(INV.FIELD_LABELS).map(([key, label]) => ({ key, label, required: key === 'container_no' })),
  template: (user) => {
    const agent = S.isAgent(user);
    const statuses = Object.entries(L.CONTAINER_STATUS).map(([k, v]) => ({ a: v.label, b: k }));
    const types = db.prepare('SELECT code, description FROM container_types WHERE active=1 ORDER BY size_ft, code').all().map((t) => ({ a: t.code, b: t.description }));
    const cols = agent
      ? [['Container No', 'container_no', 18], ['Movement', 'status', 26], ['Location', 'location', 24], ['Date', 'date', 14], ['Remarks', 'remarks', 30]]
      : [['Container No', 'container_no', 18], ['Type', 'type', 10], ['Movement', 'status', 26], ['Location', 'location', 24], ['Date', 'date', 14], ['Ownership', 'ownership', 12], ['Owner', 'owner', 22], ['Booking No', 'booking', 18], ['Free days', 'free_days', 10], ['Remarks', 'remarks', 30]];
    return [
      { name: 'Containers', columns: cols.map(([header, key, width]) => ({ header, key, width })), rows: [] },
      { name: 'How to fill', title: ['How to fill the Containers sheet', 'One row per container. Only the Container No is compulsory. Delete nothing in the header row.'], columns: [{ header: 'Column', key: 'a', width: 26 }, { header: 'What to type', key: 'b', width: 80 }],
        rows: [{ a: 'Container No', b: '4 letters + 7 digits, e.g. MSKU1234565 (spaces and dashes are ignored, the check digit is verified)' },
          { a: 'Movement', b: 'Plain words are understood: Gate in, On board, Discharged, Delivered, Empty return, Available, Damaged ... (list below)' },
          { a: 'Location', b: agent ? 'Your depot / CFS / port (must be one of your assigned locations)' : 'Depot, CFS, terminal or city' },
          { a: 'Date', b: 'Any normal date: 2026-03-14, 14/03/2026, 14-Mar-2026. Empty = today' },
          ...(agent ? [] : [{ a: 'Type', b: 'Needed only for NEW containers: 20GP, 40HC, 40 high cube, 22G1, 45G1 ...' }, { a: 'Ownership / Owner', b: 'For new containers: OWN, COC, SOC or LEASED, and the line / lessor name' }]),
          { a: 'Booking No', b: 'Optional - links the movement to a booking or HBL' }, { a: 'Free days', b: 'Only for Discharged / Delivered: days of free time from that date' }, { a: '', b: '' },
          { a: 'MOVEMENTS RECOGNISED', b: '' }, ...statuses, ...(agent ? [] : [{ a: '', b: '' }, { a: 'CONTAINER TYPES', b: '' }, ...types])] },
    ];
  },
  plan: (table, options, user) => INV.buildPlan(table, options, user),
  commit: (plan, user) => INV.commitPlan(plan, user, helpers),
});

// ---------------------------------------------------------------- quick update: paste container numbers, pick the movement once
r.post('/movements/quick', A.need('movements', 'write'), (req, res) => {
  const b = req.body || {};
  const nums = String(b.numbers || '').split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean);
  if (!nums.length) bad('Paste at least one container number.');
  if (nums.length > 500) bad('Please update at most 500 containers at a time.');
  if (!L.CONTAINER_STATUS[b.event_type]) bad('Choose the movement.');
  const table = { hasHeader: true, headers: ['Container No', 'Movement', 'Location', 'Date', 'Free days', 'Remarks', 'Booking No'], rowOffset: 1,
    dataRows: nums.map((n) => [n, b.event_type, b.location || '', b.event_date || '', b.free_days == null ? '' : String(b.free_days), b.remarks || '', b.booking || '']),
    map: { container_no: 0, status: 1, location: 2, date: 3, free_days: 4, remarks: 5, booking: 6 } };
  const plan = INV.buildPlan(table, { create_missing: false, allow_invalid: !!b.allow_invalid }, req.user);
  const rows = plan.rows.map(INV.publicRow);
  if (b.preview) return res.json({ summary: plan.summary, rows });
  const result = plan.summary.ready ? INV.commitPlan(plan, req.user, helpers) : { created: 0, moved: 0, relocated: 0, skipped: 0 };
  audit(req.user, 'BULK_MOVEMENT', 'container', null, { count: nums.length, type: b.event_type, location: b.location, saved: result.moved + result.relocated, agent: S.isAgent(req.user) });
  res.json({ result, summary: plan.summary, rows });
});

// the latest movements (agents: only what they may see)
r.get('/movements/recent', A.need('containers', 'read'), (req, res) => {
  const lim = Math.min(parseInt(req.query.limit || '60', 10) || 60, 300);
  let rows = db.prepare(`SELECT e.id, e.event_date, e.event_type, e.location, e.remarks, e.created_at, e.shipment_id, c.id AS container_id, c.container_no, t.code AS type_code, s.booking_no, s.hbl_no, u.full_name AS by_user, u.role AS by_role
    FROM container_events e JOIN containers c ON c.id=e.container_id JOIN container_types t ON t.id=c.type_id LEFT JOIN shipments s ON s.id=e.shipment_id LEFT JOIN users u ON u.id=e.user_id
    ${req.query.mine === '1' ? 'WHERE e.user_id=' + Number(req.user.id) : ''} ORDER BY e.event_date DESC, e.id DESC LIMIT ${S.isAgent(req.user) ? 600 : lim}`).all();
  if (S.isAgent(req.user)) { const mine = S.agentContainerIds(req.user); rows = S.hideForeignRefs(req.user, rows.filter((x) => mine.has(x.container_id) || S.locationAllowed(req.user, x.location))).slice(0, lim); }
  for (const x of rows) x.label = (L.CONTAINER_STATUS[x.event_type] || {}).label || x.event_type;
  res.json(rows);
});

// ---------------------------------------------------------------- container enquiry
r.get('/track', A.need('containers', 'read'), (req, res) => res.json({ rows: TR.search(req.user, req.query.q) }));
r.get('/track/:id', A.need('containers', 'read'), (req, res) => {
  const d = TR.detail(req.user, Number(req.params.id));
  if (!d) bad('Container not found', 404);
  res.json(d);
});

// places the system already knows (for drop-downs); an agent only gets their own
r.get('/locations', A.requireLogin, (req, res) => {
  if (S.isAgent(req.user)) return res.json(String(req.user.locations || '').split(/[\n,;|]+/).map((s) => s.trim()).filter(Boolean));
  const set = new Set(db.prepare("SELECT DISTINCT location FROM containers WHERE location IS NOT NULL AND location<>''").all().map((x) => x.location));
  for (const p of db.prepare('SELECT name FROM ports WHERE active=1').all()) set.add(p.name);
  res.json([...set].sort((a, b) => a.localeCompare(b)));
});

module.exports = r;
