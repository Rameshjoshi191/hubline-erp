'use strict';
const express = require('express');
const { db, audit, nextNo, today, addDays, round2, getSetting } = require('../db');
const { need } = require('../auth');
const { bad, extract, insertRow, updateRow, diff, sendXlsx, MONEY } = require('../util');
const L = require('../logic');
const S = require('../services');

const r = express.Router();

// ================================================================ parties (customers / agents / vendors / carriers)
const PARTY_FIELDS = [
  { name: 'code', type: 'upper' }, { name: 'name', required: true, label: 'Name' },
  { name: 'is_customer', type: 'bool', def: 0 }, { name: 'is_agent', type: 'bool', def: 0 },
  { name: 'is_vendor', type: 'bool', def: 0 }, { name: 'is_carrier', type: 'bool', def: 0 },
  { name: 'address' }, { name: 'city' }, { name: 'country' }, { name: 'contact_person' }, { name: 'email' }, { name: 'phone' },
  { name: 'tax_no' }, { name: 'credit_days', type: 'int', def: 30 }, { name: 'credit_limit', type: 'real', def: 0 },
  { name: 'currency', type: 'upper', def: 'USD' },
  { name: 'agent_type', type: 'upper' }, { name: 'agent_network' }, { name: 'agent_territory' }, { name: 'agent_since', type: 'date' },
  { name: 'notes' }, { name: 'active', type: 'bool', def: 1 },
];
const ROLE_COL = { customer: 'is_customer', agent: 'is_agent', vendor: 'is_vendor', carrier: 'is_carrier' };

function balancesByParty() {
  const map = {};
  for (const it of L.openItems({ to: today() })) {
    const m = map[it.party_id] = map[it.party_id] || {};
    m[it.currency] = round2((m[it.currency] || 0) + it.signed);
  }
  return map;
}

r.get('/parties', need('parties', 'read'), (req, res) => {
  const w = [], p = {};
  if (req.query.role && ROLE_COL[req.query.role]) w.push(`${ROLE_COL[req.query.role]}=1`);
  if (req.query.active === '1') w.push('active=1');
  if (req.query.q) { w.push('(name LIKE @q OR code LIKE @q OR country LIKE @q OR contact_person LIKE @q OR email LIKE @q)'); p.q = `%${req.query.q}%`; }
  const rows = db.prepare(`SELECT * FROM parties ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY name`).all(p);
  if (req.query.balances === '1' && (need && true)) {
    const canSee = ['admin', 'management', 'accounts', 'sales'].includes(req.user.role);
    if (canSee) { const bm = balancesByParty(); for (const x of rows) x.balances = bm[x.id] || {}; }
  }
  res.json(rows);
});

r.get('/parties/:id', need('parties', 'read'), (req, res) => {
  const p = db.prepare('SELECT * FROM parties WHERE id=?').get(req.params.id);
  if (!p) bad('Not found', 404);
  p.shipments_as_customer = db.prepare('SELECT COUNT(*) n FROM shipments WHERE customer_id=?').get(p.id).n;
  p.shipments_as_agent = db.prepare('SELECT COUNT(*) n FROM shipments WHERE agent_id=?').get(p.id).n;
  if (['admin', 'management', 'accounts', 'sales'].includes(req.user.role)) p.balances = balancesByParty()[p.id] || {};
  res.json(p);
});

function checkParty(v, cur) {
  const flags = ['is_customer', 'is_agent', 'is_vendor', 'is_carrier'];
  const merged = { ...(cur || {}), ...v };
  if (!flags.some((f) => merged[f])) bad('Select at least one role (customer, agent, vendor or carrier).');
  if (v.agent_type && !['ORIGIN', 'DESTINATION', 'BOTH'].includes(v.agent_type)) bad('Agent type must be ORIGIN, DESTINATION or BOTH.');
  if (v.currency && !db.prepare('SELECT 1 FROM currencies WHERE code=?').get(v.currency)) bad('Unknown currency ' + v.currency);
  if (v.credit_days != null && v.credit_days < 0) bad('Credit days cannot be negative.');
  if (cur && cur.is_agent && v.is_agent === 0) {
    if (db.prepare('SELECT 1 FROM agreements WHERE agent_id=?').get(cur.id)) bad('This agent has agency agreements, so the agent role cannot be removed.');
  }
}

r.post('/parties', need('parties', 'write'), (req, res) => {
  const v = extract(req.body, PARTY_FIELDS);
  checkParty(v, null);
  if (!v.code) {
    const key = v.is_customer ? 'P_CUSTOMER' : v.is_agent ? 'P_AGENT' : v.is_carrier ? 'P_CARRIER' : 'P_VENDOR';
    do { v.code = nextNo(key); } while (db.prepare('SELECT 1 FROM parties WHERE code=?').get(v.code));
  } else if (db.prepare('SELECT 1 FROM parties WHERE code=?').get(v.code)) bad('That code is already used.', 409);
  const id = insertRow('parties', v);
  audit(req.user, 'CREATE', 'party', id, { code: v.code, name: v.name });
  res.json({ id, code: v.code });
});
r.put('/parties/:id', need('parties', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM parties WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, PARTY_FIELDS, { partial: true });
  checkParty(v, cur);
  if (v.code && v.code !== cur.code && db.prepare('SELECT 1 FROM parties WHERE code=? AND id<>?').get(v.code, cur.id)) bad('That code is already used.', 409);
  updateRow('parties', cur.id, v);
  audit(req.user, 'UPDATE', 'party', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.delete('/parties/:id', need('parties', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM parties WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  try { db.prepare('DELETE FROM parties WHERE id=?').run(cur.id); }
  catch (e) { if (String(e.message).includes('FOREIGN KEY')) bad('This party has shipments, documents or agreements and cannot be deleted. Mark it inactive instead.', 409); throw e; }
  audit(req.user, 'DELETE', 'party', cur.id, { code: cur.code, name: cur.name });
  res.json({ ok: true });
});

// ================================================================ agents (overview)
r.get('/agents', need('agreements', 'read'), (req, res) => {
  const rows = db.prepare(`SELECT p.*,
      (SELECT COUNT(*) FROM shipments s WHERE s.agent_id=p.id AND s.status<>'CANCELLED') AS shipment_count,
      (SELECT agreement_no FROM agreements a WHERE a.agent_id=p.id AND a.status='ACTIVE' AND (a.end_date IS NULL OR a.end_date>=@t) ORDER BY a.end_date DESC LIMIT 1) AS active_agreement,
      (SELECT end_date FROM agreements a WHERE a.agent_id=p.id AND a.status='ACTIVE' AND (a.end_date IS NULL OR a.end_date>=@t) ORDER BY a.end_date DESC LIMIT 1) AS agreement_end
    FROM parties p WHERE p.is_agent=1 ${req.query.q ? 'AND (p.name LIKE @q OR p.code LIKE @q OR p.country LIKE @q)' : ''} ORDER BY p.name`)
    .all({ t: today(), q: `%${req.query.q || ''}%` });
  const bm = balancesByParty();
  for (const x of rows) x.balances = bm[x.id] || {};
  res.json(rows);
});

// ================================================================ agency agreements
const AGR_FIELDS = [
  { name: 'agent_id', type: 'int', required: true, label: 'Agent' }, { name: 'title' },
  { name: 'status', type: 'upper', def: 'DRAFT' }, { name: 'signed_date', type: 'date' },
  { name: 'start_date', type: 'date' }, { name: 'end_date', type: 'date' }, { name: 'auto_renew', type: 'bool', def: 0 },
  { name: 'notice_days', type: 'int', def: 60 }, { name: 'territory' }, { name: 'exclusivity' },
  { name: 'payment_terms_days', type: 'int', def: 30 }, { name: 'credit_limit', type: 'real', def: 0 },
  { name: 'currency', type: 'upper', def: 'USD' }, { name: 'commission_summary' }, { name: 'governing_law' }, { name: 'notes' },
];
const EFFECTIVE = `CASE WHEN a.status='ACTIVE' AND a.end_date IS NOT NULL AND a.end_date<@today THEN 'EXPIRED' ELSE a.status END`;

function checkAgreement(v, cur) {
  const m = { ...(cur || {}), ...v };
  if (v.status && !['DRAFT', 'ACTIVE', 'TERMINATED'].includes(v.status)) bad('Status must be DRAFT, ACTIVE or TERMINATED.');
  if (v.agent_id) {
    const p = db.prepare('SELECT is_agent FROM parties WHERE id=?').get(v.agent_id);
    if (!p || !p.is_agent) bad('The selected party is not marked as an agent.');
  }
  if (m.start_date && m.end_date && m.end_date < m.start_date) bad('End date is before start date.');
  if (m.status === 'ACTIVE' && !m.start_date) bad('An active agreement needs a start date.');
  if (v.currency && !db.prepare('SELECT 1 FROM currencies WHERE code=?').get(v.currency)) bad('Unknown currency ' + v.currency);
  for (const k of ['notice_days', 'payment_terms_days']) if (m[k] != null && m[k] < 0) bad('Days cannot be negative.');
}

r.get('/agreements', need('agreements', 'read'), (req, res) => {
  const w = [], p = { today: today() };
  if (req.query.agent_id) { w.push('a.agent_id=@agent'); p.agent = req.query.agent_id; }
  if (req.query.q) { w.push('(a.agreement_no LIKE @q OR p.name LIKE @q OR a.title LIKE @q)'); p.q = `%${req.query.q}%`; }
  let rows = db.prepare(`SELECT a.*, ${EFFECTIVE} AS effective_status, p.name AS agent_name, p.code AS agent_code, p.country AS agent_country,
      (SELECT COUNT(*) FROM commission_rules cr WHERE cr.agreement_id=a.id AND cr.active=1) AS rule_count,
      CASE WHEN a.end_date IS NULL THEN NULL ELSE CAST(julianday(a.end_date)-julianday(@today) AS INTEGER) END AS days_left
    FROM agreements a JOIN parties p ON p.id=a.agent_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY a.id DESC`).all(p);
  if (req.query.status) rows = rows.filter((x) => x.effective_status === req.query.status);
  res.json(rows);
});

r.get('/agreements/:id', need('agreements', 'read'), (req, res) => {
  const a = db.prepare(`SELECT a.*, ${EFFECTIVE} AS effective_status, p.name AS agent_name, p.code AS agent_code, p.address AS agent_address,
      p.country AS agent_country, p.contact_person AS agent_contact
    FROM agreements a JOIN parties p ON p.id=a.agent_id WHERE a.id=@id`).get({ id: req.params.id, today: today() });
  if (!a) bad('Not found', 404);
  a.clauses = db.prepare('SELECT * FROM agreement_clauses WHERE agreement_id=? ORDER BY seq,id').all(a.id);
  a.rules = db.prepare(`SELECT cr.*, pl.name AS pol_name, pd.name AS pod_name FROM commission_rules cr
    LEFT JOIN ports pl ON pl.id=cr.pol_id LEFT JOIN ports pd ON pd.id=cr.pod_id WHERE cr.agreement_id=? ORDER BY cr.id`).all(a.id);
  a.statements = db.prepare('SELECT id,stmt_no,period_from,period_to,currency,total,status FROM commission_statements WHERE agreement_id=? ORDER BY id DESC').all(a.id);
  res.json(a);
});

r.post('/agreements', need('agreements', 'write'), (req, res) => {
  const v = extract(req.body, AGR_FIELDS);
  checkAgreement(v, null);
  v.agreement_no = nextNo('AGREEMENT', v.start_date || today());
  v.created_by = req.user.id;
  const id = insertRow('agreements', v);
  audit(req.user, 'CREATE', 'agreement', id, { agreement_no: v.agreement_no, agent_id: v.agent_id });
  res.json({ id, agreement_no: v.agreement_no });
});
r.put('/agreements/:id', need('agreements', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM agreements WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, AGR_FIELDS, { partial: true });
  checkAgreement(v, cur);
  updateRow('agreements', cur.id, v);
  audit(req.user, 'UPDATE', 'agreement', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.delete('/agreements/:id', need('agreements', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM agreements WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (cur.status !== 'DRAFT') bad('Only draft agreements can be deleted. Mark active agreements as terminated instead.');
  if (db.prepare('SELECT 1 FROM commission_statements WHERE agreement_id=?').get(cur.id)) bad('Commission statements exist for this agreement.');
  db.prepare('DELETE FROM agreements WHERE id=?').run(cur.id);
  audit(req.user, 'DELETE', 'agreement', cur.id, { agreement_no: cur.agreement_no });
  res.json({ ok: true });
});

// Renewal: copy terms, clauses and rules into a new DRAFT starting the day after the old one ends
r.post('/agreements/:id/renew', need('agreements', 'write'), (req, res) => {
  const a = db.prepare('SELECT * FROM agreements WHERE id=?').get(req.params.id);
  if (!a) bad('Not found', 404);
  const start = a.end_date ? addDays(a.end_date, 1) : today();
  const years = Math.max(1, parseInt(req.body.years || 1, 10));
  const end = new Date(start + 'T00:00:00Z'); end.setUTCFullYear(end.getUTCFullYear() + years); end.setUTCDate(end.getUTCDate() - 1);
  const tx = db.transaction(() => {
    const no = nextNo('AGREEMENT', start);
    const id = db.prepare(`INSERT INTO agreements(agreement_no,agent_id,title,status,start_date,end_date,auto_renew,notice_days,territory,exclusivity,payment_terms_days,credit_limit,currency,commission_summary,governing_law,notes,created_by)
      VALUES(?,?,?,'DRAFT',?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(no, a.agent_id, a.title, start, end.toISOString().slice(0, 10), a.auto_renew, a.notice_days, a.territory, a.exclusivity,
      a.payment_terms_days, a.credit_limit, a.currency, a.commission_summary, a.governing_law, `Renewal of ${a.agreement_no}`, req.user.id).lastInsertRowid;
    for (const c of db.prepare('SELECT * FROM agreement_clauses WHERE agreement_id=? ORDER BY seq').all(a.id))
      db.prepare('INSERT INTO agreement_clauses(agreement_id,seq,title,body) VALUES(?,?,?,?)').run(id, c.seq, c.title, c.body);
    for (const c of db.prepare('SELECT * FROM commission_rules WHERE agreement_id=?').all(a.id))
      db.prepare(`INSERT INTO commission_rules(agreement_id,name,basis,rate,currency,cargo_type,pol_id,pod_id,min_amount,max_amount,active) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
        .run(id, c.name, c.basis, c.rate, c.currency, c.cargo_type, c.pol_id, c.pod_id, c.min_amount, c.max_amount, c.active);
    return { id, no };
  });
  const out = tx();
  audit(req.user, 'RENEW', 'agreement', a.id, { new_agreement: out.no });
  res.json({ id: out.id, agreement_no: out.no });
});

// Clauses (replace-all)
r.put('/agreements/:id/clauses', need('agreements', 'write'), (req, res) => {
  const a = db.prepare('SELECT * FROM agreements WHERE id=?').get(req.params.id);
  if (!a) bad('Not found', 404);
  const clauses = Array.isArray(req.body.clauses) ? req.body.clauses : bad('clauses must be a list');
  db.transaction(() => {
    db.prepare('DELETE FROM agreement_clauses WHERE agreement_id=?').run(a.id);
    clauses.forEach((c, i) => {
      if (!String(c.title || '').trim()) bad(`Clause ${i + 1} needs a title.`);
      db.prepare('INSERT INTO agreement_clauses(agreement_id,seq,title,body) VALUES(?,?,?,?)').run(a.id, i + 1, String(c.title).trim(), String(c.body || ''));
    });
  })();
  audit(req.user, 'UPDATE', 'agreement', a.id, { clauses: clauses.length });
  res.json({ ok: true });
});

// Starting-point clause set. NOTE: template text only; have it reviewed by your legal adviser.
r.post('/agreements/:id/standard-clauses', need('agreements', 'write'), (req, res) => {
  const a = db.prepare('SELECT a.*, p.name AS agent_name FROM agreements a JOIN parties p ON p.id=a.agent_id WHERE a.id=?').get(req.params.id);
  if (!a) bad('Not found', 404);
  const co = getSetting('company_name', 'the Company');
  const MON = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const d = (x) => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(x || ''); return m ? `${+m[3]} ${MON[+m[2] - 1]} ${m[1]}` : '[date]'; };
  const T = [
    ['Appointment and territory', `${co} ("the Company") appoints ${a.agent_name} ("the Agent") as its agent for the solicitation, booking and handling of NVOCC cargo in the territory of ${a.territory || '[territory]'}. Exclusivity: ${a.exclusivity || 'Non-exclusive'}. The Agent shall not hold itself out as having authority to bind the Company except as expressly stated in this Agreement.`],
    ['Term and renewal', `This Agreement starts on ${d(a.start_date)} and continues until ${d(a.end_date)}${a.auto_renew ? ', and renews automatically for successive periods of the same length unless either party gives written notice of non-renewal' : ''}. Either party may terminate this Agreement by giving ${a.notice_days} days' written notice to the other.`],
    ['Duties of the Agent', 'The Agent shall promote the Company\'s services, provide accurate booking instructions and cargo details, comply with applicable customs, dangerous-goods and export-control requirements, and promptly notify the Company of any claim, loss or delay affecting a shipment.'],
    ['Rates and charges', 'Freight and local charges shall be as quoted by the Company in its current tariff or in writing for the specific shipment. The Company may amend its tariff on reasonable written notice; amended rates apply to bookings made after the effective date.'],
    ['Agency commission', `${a.commission_summary || 'Commission is payable on shipments nominated by the Agent as set out in the Commission Schedule below.'} Commission is calculated per shipment in ${a.currency}, is confirmed by a commission statement, and is payable within ${a.payment_terms_days} days of the statement being approved. No commission is payable on cancelled shipments, or where freight and charges remain unpaid by the Agent's nominated party.`],
    ['Payment terms and statements of account', `Invoices and debit notes are payable within ${a.payment_terms_days} days of the invoice date${a.credit_limit ? `, subject to a credit limit of ${a.currency} ${Number(a.credit_limit).toLocaleString()}` : ''}. The Company will issue a statement of account periodically; any dispute must be notified in writing within 14 days of the statement date, after which the statement is deemed accepted. The Company may set off amounts due from the Agent against commission or other sums payable to the Agent.`],
    ['Free time, demurrage and detention', 'Free time, demurrage and detention are governed by the terms of the carrier or container owner. Where these charges arise from the acts or omissions of the Agent or its nominated consignee, they shall be for the Agent\'s account and may be recovered by debit note.'],
    ['Liability and indemnity', 'Each party shall be liable only in accordance with the applicable bill of lading terms and applicable law. The Agent shall indemnify the Company against losses arising from mis-declared cargo, dangerous goods not properly declared, or breach of this Agreement by the Agent.'],
    ['Compliance and confidentiality', 'Each party shall comply with applicable sanctions, anti-money-laundering and anti-bribery laws. Neither party shall disclose the other\'s confidential commercial information, including rates and customer details, except as required by law.'],
    ['Termination', 'Either party may terminate immediately by written notice if the other commits a material breach that is not remedied within 14 days of notice, or becomes insolvent. On termination, all amounts due between the parties become payable in accordance with the latest statement of account, and commission is payable only on shipments sailed before the termination date.'],
    ['Governing law and jurisdiction', `This Agreement is governed by the laws of ${a.governing_law || '[governing law and forum]'}.`],
  ];
  const existing = db.prepare('SELECT COUNT(*) n FROM agreement_clauses WHERE agreement_id=?').get(a.id).n;
  if (existing && !req.body.append) bad('This agreement already has clauses. Clear them first, or choose to append.');
  db.transaction(() => {
    T.forEach(([title, body], i) => db.prepare('INSERT INTO agreement_clauses(agreement_id,seq,title,body) VALUES(?,?,?,?)').run(a.id, existing + i + 1, title, body));
  })();
  audit(req.user, 'UPDATE', 'agreement', a.id, { standard_clauses: T.length });
  res.json({ ok: true, added: T.length });
});

// ---------------------------------------------------------------- commission rules
const RULE_FIELDS = [
  { name: 'name', required: true, label: 'Rule name' }, { name: 'basis', type: 'upper', required: true, label: 'Basis' },
  { name: 'rate', type: 'real', required: true, label: 'Rate' }, { name: 'currency', type: 'upper', required: true, label: 'Currency' },
  { name: 'cargo_type', type: 'upper', def: 'ANY' }, { name: 'pol_id', type: 'int' }, { name: 'pod_id', type: 'int' },
  { name: 'min_amount', type: 'real' }, { name: 'max_amount', type: 'real' },
  { name: 'valid_from', type: 'date' }, { name: 'valid_to', type: 'date' }, { name: 'active', type: 'bool', def: 1 },
];
function checkRule(v) {
  if (v.basis && !L.COMM_BASIS[v.basis]) bad('Unknown commission basis.');
  if (v.cargo_type && !['ANY', 'FCL', 'LCL'].includes(v.cargo_type)) bad('Cargo type must be ANY, FCL or LCL.');
  if (v.rate != null && v.rate < 0) bad('Rate cannot be negative.');
  if (v.basis && v.basis.startsWith('PERCENT') && v.rate > 100) bad('A percentage rate cannot exceed 100.');
  if (v.min_amount != null && v.max_amount != null && v.max_amount < v.min_amount) bad('Maximum is below minimum.');
  if (v.currency && !db.prepare('SELECT 1 FROM currencies WHERE code=?').get(v.currency)) bad('Unknown currency ' + v.currency);
}
r.post('/agreements/:id/rules', need('agreements', 'write'), (req, res) => {
  if (!db.prepare('SELECT 1 FROM agreements WHERE id=?').get(req.params.id)) bad('Agreement not found', 404);
  const v = extract(req.body, RULE_FIELDS); checkRule(v);
  v.agreement_id = Number(req.params.id);
  const id = insertRow('commission_rules', v);
  audit(req.user, 'CREATE', 'commission_rule', id, v);
  res.json({ id });
});
r.put('/commission-rules/:id', need('agreements', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM commission_rules WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, RULE_FIELDS, { partial: true }); checkRule(v);
  updateRow('commission_rules', cur.id, v);
  audit(req.user, 'UPDATE', 'commission_rule', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.delete('/commission-rules/:id', need('agreements', 'write'), (req, res) => {
  db.prepare('DELETE FROM commission_rules WHERE id=?').run(req.params.id);
  audit(req.user, 'DELETE', 'commission_rule', req.params.id);
  res.json({ ok: true });
});

// ================================================================ commission statements
r.get('/commissions', need('commission', 'read'), (req, res) => {
  const w = [], p = {};
  if (req.query.agent_id) { w.push('cs.agent_id=@agent'); p.agent = req.query.agent_id; }
  if (req.query.status) { w.push('cs.status=@st'); p.st = req.query.status; }
  res.json(db.prepare(`SELECT cs.*, p.name AS agent_name, a.agreement_no,
      (SELECT COUNT(*) FROM commission_lines l WHERE l.statement_id=cs.id) AS line_count,
      CASE WHEN cs.document_id IS NULL THEN NULL ELSE (SELECT ${L.outstandingSql()} FROM documents d WHERE d.id=cs.document_id) END AS outstanding
    FROM commission_statements cs JOIN parties p ON p.id=cs.agent_id LEFT JOIN agreements a ON a.id=cs.agreement_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY cs.id DESC`).all(p));
});

function commissionInput(b) {
  const agent_id = Number(b.agent_id), agreement_id = Number(b.agreement_id);
  if (!agent_id || !agreement_id) bad('Choose an agent and an agreement.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.from || '') || !/^\d{4}-\d{2}-\d{2}$/.test(b.to || '')) bad('Choose the period (from and to dates).');
  if (b.to < b.from) bad('The period end is before its start.');
  return { agent_id, agreement_id, from: b.from, to: b.to, currency: b.currency ? String(b.currency).toUpperCase() : undefined };
}

r.post('/commissions/preview', need('commission', 'read'), (req, res) => {
  res.json(L.buildCommission(commissionInput(req.body)));
});

r.post('/commissions', need('commission', 'write'), (req, res) => {
  const inp = commissionInput(req.body);
  const calc = L.buildCommission(inp);
  if (!calc.lines.length) bad('No eligible shipments for that agent and period, so there is nothing to put on a statement.');
  const tx = db.transaction(() => {
    const no = nextNo('COMM', inp.to);
    const id = db.prepare(`INSERT INTO commission_statements(stmt_no,agent_id,agreement_id,period_from,period_to,currency,total,status,notes,created_by)
      VALUES(?,?,?,?,?,?,?,'DRAFT',?,?)`).run(no, inp.agent_id, inp.agreement_id, inp.from, inp.to, calc.currency, calc.total, req.body.notes || null, req.user.id).lastInsertRowid;
    const ins = db.prepare(`INSERT INTO commission_lines(statement_id,shipment_id,rule_id,rule_name,basis,base_qty,base_amount,rate,commission_amount,note) VALUES(?,?,?,?,?,?,?,?,?,?)`);
    for (const l of calc.lines) ins.run(id, l.shipment_id, l.rule_id, l.rule_name, l.basis, l.base_qty, l.base_amount, l.rate, l.commission_amount, l.warning || null);
    return { id, no };
  });
  const out = tx();
  audit(req.user, 'CREATE', 'commission', out.id, { stmt_no: out.no, total: calc.total, lines: calc.lines.length });
  res.json({ id: out.id, stmt_no: out.no, skipped: calc.skipped });
});

function loadStatement(id) {
  const cs = db.prepare(`SELECT cs.*, p.name AS agent_name, p.code AS agent_code, p.address AS agent_address, p.country AS agent_country, a.agreement_no
    FROM commission_statements cs JOIN parties p ON p.id=cs.agent_id LEFT JOIN agreements a ON a.id=cs.agreement_id WHERE cs.id=?`).get(id);
  if (!cs) bad('Not found', 404);
  cs.lines = db.prepare(`SELECT l.*, s.booking_no, s.hbl_no, s.etd, s.cargo_type, pl.name AS pol_name, pd.name AS pod_name
    FROM commission_lines l JOIN shipments s ON s.id=l.shipment_id LEFT JOIN ports pl ON pl.id=s.pol_id LEFT JOIN ports pd ON pd.id=s.pod_id
    WHERE l.statement_id=? ORDER BY s.etd, l.id`).all(id);
  if (cs.document_id) {
    cs.document = db.prepare(`SELECT d.id, d.doc_no, d.status, d.total, d.due_date, ${L.outstandingSql()} AS outstanding FROM documents d WHERE d.id=?`).get(cs.document_id);
  }
  return cs;
}
r.get('/commissions/:id', need('commission', 'read'), (req, res) => res.json(loadStatement(req.params.id)));

function draftOnly(id) {
  const cs = db.prepare('SELECT * FROM commission_statements WHERE id=?').get(id);
  if (!cs) bad('Not found', 404);
  if (cs.status !== 'DRAFT') bad('Only draft statements can be changed.');
  return cs;
}
function retotal(id) {
  const t = db.prepare('SELECT COALESCE(SUM(commission_amount),0) s FROM commission_lines WHERE statement_id=?').get(id).s;
  db.prepare('UPDATE commission_statements SET total=? WHERE id=?').run(round2(t), id);
}
r.put('/commissions/:id/lines/:lid', need('commission', 'write'), (req, res) => {
  draftOnly(req.params.id);
  const amt = Number(req.body.commission_amount);
  if (Number.isNaN(amt) || amt < 0) bad('Enter a valid commission amount.');
  db.prepare('UPDATE commission_lines SET commission_amount=?, note=? WHERE id=? AND statement_id=?').run(round2(amt), req.body.note || null, req.params.lid, req.params.id);
  retotal(req.params.id);
  audit(req.user, 'ADJUST', 'commission', req.params.id, { line: req.params.lid, amount: amt, note: req.body.note });
  res.json({ ok: true });
});
r.delete('/commissions/:id/lines/:lid', need('commission', 'write'), (req, res) => {
  draftOnly(req.params.id);
  db.prepare('DELETE FROM commission_lines WHERE id=? AND statement_id=?').run(req.params.lid, req.params.id);
  retotal(req.params.id);
  audit(req.user, 'REMOVE_LINE', 'commission', req.params.id, { line: req.params.lid });
  res.json({ ok: true });
});
r.delete('/commissions/:id', need('commission', 'write'), (req, res) => {
  draftOnly(req.params.id);
  db.prepare('DELETE FROM commission_statements WHERE id=?').run(req.params.id);
  audit(req.user, 'DELETE', 'commission', req.params.id);
  res.json({ ok: true });
});

// Post = approve and create a posted COMM document that credits the agent's ledger
r.post('/commissions/:id/post', need('commission', 'write'), (req, res) => {
  const cs = draftOnly(req.params.id);
  const st = loadStatement(cs.id);
  if (!st.lines.length || !(st.total > 0)) bad('The statement has no commission to post.');
  const ag = cs.agreement_id ? db.prepare('SELECT payment_terms_days FROM agreements WHERE id=?').get(cs.agreement_id) : null;
  const docId = S.createDocument({
    doc_type: 'COMM', party_id: cs.agent_id, currency: cs.currency, doc_date: today(),
    due_date: addDays(today(), ag ? ag.payment_terms_days : 30), party_ref: cs.stmt_no,
    narration: `Agency commission ${cs.stmt_no} for ${cs.period_from} to ${cs.period_to}`,
    lines: st.lines.map((l) => ({
      description: `HBL ${l.hbl_no || l.booking_no} (${l.pol_name || '?'} - ${l.pod_name || '?'}, ETD ${l.etd}) - ${l.rule_name || ''}${l.note ? ' - ' + l.note : ''}`,
      qty: 1, rate: l.commission_amount, vat_rate: 0,
    })).filter((l) => l.rate > 0),
    post: true,
  }, req.user);
  db.prepare("UPDATE commission_statements SET status='POSTED', document_id=? WHERE id=?").run(docId, cs.id);
  audit(req.user, 'POST', 'commission', cs.id, { document_id: docId });
  res.json({ ok: true, document_id: docId });
});

r.post('/commissions/:id/cancel', need('commission', 'write'), (req, res) => {
  const cs = db.prepare('SELECT * FROM commission_statements WHERE id=?').get(req.params.id);
  if (!cs) bad('Not found', 404);
  if (cs.status === 'CANCELLED') bad('Already cancelled.');
  db.transaction(() => {
    if (cs.document_id) {
      db.prepare('UPDATE commission_statements SET document_id=NULL WHERE id=?').run(cs.id); // detach so the doc guard passes
      try { S.cancelDocument(cs.document_id, req.user, `Statement ${cs.stmt_no} cancelled`); }
      catch (e) { db.prepare('UPDATE commission_statements SET document_id=? WHERE id=?').run(cs.document_id, cs.id); throw e; }
    }
    db.prepare("UPDATE commission_statements SET status='CANCELLED' WHERE id=?").run(cs.id);
  })();
  audit(req.user, 'CANCEL', 'commission', cs.id);
  res.json({ ok: true });
});

r.get('/commissions/:id/export', need('commission', 'read'), async (req, res) => {
  const st = loadStatement(req.params.id);
  const co = getSetting('company_name', '');
  await sendXlsx(res, `${st.stmt_no}.xlsx`, [{
    name: 'Commission statement',
    title: [`${co} - Agency commission statement ${st.stmt_no}`, `Agent: ${st.agent_name} (${st.agent_code})`, `Agreement: ${st.agreement_no || '-'}   Period: ${st.period_from} to ${st.period_to}   Currency: ${st.currency}   Status: ${st.status}`],
    columns: [
      { header: 'ETD', key: 'etd', width: 12 }, { header: 'Booking', key: 'booking_no', width: 18 }, { header: 'HBL', key: 'hbl_no', width: 18 },
      { header: 'POL', key: 'pol_name', width: 16 }, { header: 'POD', key: 'pod_name', width: 16 }, { header: 'Cargo', key: 'cargo_type', width: 8 },
      { header: 'Rule', key: 'rule_name', width: 28 }, { header: 'Basis', key: 'basis_label', width: 22 },
      { header: 'Qty', key: 'base_qty', width: 10, fmt: '#,##0.00' }, { header: 'Base amount (base ccy)', key: 'base_amount', width: 16, fmt: MONEY },
      { header: 'Rate', key: 'rate', width: 10, fmt: '#,##0.00' }, { header: 'Commission', key: 'commission_amount', width: 14, fmt: MONEY },
      { header: 'Note', key: 'note', width: 30 },
    ],
    rows: st.lines.map((l) => ({ ...l, basis_label: L.COMM_BASIS[l.basis] || l.basis })),
    totals: { commission_amount: st.total },
  }], { company: co });
});

module.exports = r;
