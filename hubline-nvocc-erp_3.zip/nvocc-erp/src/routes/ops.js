'use strict';
const express = require('express');
const { db, audit, nextNo, today, round2, getSetting } = require('../db');
const A = require('../auth');
const { need } = A;
const { bad, extract, insertRow, updateRow, diff } = require('../util');
const L = require('../logic');
const S = require('../scope');

const r = express.Router();
const stripForAgent = (s) => { delete s.customer_id; delete s.customer_name; delete s.customer_credit_days; delete s.remarks; return s; };

// ================================================================ container events (shared helpers)
function addEvent(e, user) {
  const st = L.CONTAINER_STATUS[e.event_type];
  if (!st) bad('Unknown container status: ' + e.event_type);
  const date = e.event_date || today();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) bad('Invalid event date.');
  let free = e.free_days === '' || e.free_days == null ? null : parseInt(e.free_days, 10);
  if (free != null && (Number.isNaN(free) || free < 0)) bad('Free days must be zero or more.');
  if (!st.clock) free = null;
  const id = db.prepare(`INSERT INTO container_events(container_id,event_date,event_type,location,shipment_id,consol_id,free_days,remarks,user_id)
    VALUES(?,?,?,?,?,?,?,?,?)`).run(e.container_id, date, e.event_type, e.location || null, e.shipment_id || null, e.consol_id || null, free, e.remarks || null, user ? user.id : null).lastInsertRowid;
  L.refreshContainer(e.container_id);
  return id;
}
// skip if the container's latest event is identical (avoids duplicates in consol cascades)
// Used by system cascades (sailing, arrival ...). Never dates an event before the container's latest movement,
// so a back-dated sailing cannot end up "older" than the allocation it follows.
function addEventOnce(e, user) {
  const last = db.prepare('SELECT * FROM container_events WHERE container_id=? ORDER BY event_date DESC, id DESC LIMIT 1').get(e.container_id);
  const date = e.event_date || today();
  const eff = last && last.event_date > date ? last.event_date : date;
  if (last && last.event_type === e.event_type && last.event_date === eff) return null;
  return addEvent({ ...e, event_date: eff }, user);
}
const portName = (id) => (id ? (db.prepare('SELECT name FROM ports WHERE id=?').get(id) || {}).name : null);

// ================================================================ shipments / bookings / HBL
const SHIP_FIELDS = [
  { name: 'cargo_type', type: 'upper', def: 'FCL' }, { name: 'customer_id', type: 'int' }, { name: 'shipper_id', type: 'int' },
  { name: 'consignee_id', type: 'int' }, { name: 'notify_id', type: 'int' },
  { name: 'shipper_text' }, { name: 'consignee_text' }, { name: 'notify_text' },
  { name: 'agent_id', type: 'int' }, { name: 'carrier_id', type: 'int' }, { name: 'consol_id', type: 'int' },
  { name: 'pol_id', type: 'int' }, { name: 'pod_id', type: 'int' }, { name: 'place_of_receipt' }, { name: 'place_of_delivery' },
  { name: 'vessel' }, { name: 'voyage' }, { name: 'etd', type: 'date' }, { name: 'eta', type: 'date' },
  { name: 'freight_terms', type: 'upper', def: 'PREPAID' }, { name: 'incoterm', type: 'upper' },
  { name: 'commodity' }, { name: 'marks' }, { name: 'packages', type: 'int' }, { name: 'package_type' },
  { name: 'gross_weight', type: 'real' }, { name: 'cbm', type: 'real' }, { name: 'remarks' },
];
const SHIP_FROM = `FROM shipments s
  LEFT JOIN parties cu ON cu.id=s.customer_id LEFT JOIN parties sh ON sh.id=s.shipper_id LEFT JOIN parties co ON co.id=s.consignee_id
  LEFT JOIN parties nt ON nt.id=s.notify_id LEFT JOIN parties ag ON ag.id=s.agent_id LEFT JOIN parties ca ON ca.id=s.carrier_id
  LEFT JOIN ports pl ON pl.id=s.pol_id LEFT JOIN ports pd ON pd.id=s.pod_id LEFT JOIN consols k ON k.id=s.consol_id`;
const SHIP_COLS = `s.*, cu.name AS customer_name, sh.name AS shipper_name, co.name AS consignee_name, nt.name AS notify_name,
  ag.name AS agent_name, ca.name AS carrier_name, pl.name AS pol_name, pd.name AS pod_name, k.consol_no, k.mbl_no`;

function checkShipment(v, cur) {
  const m = { ...(cur || {}), ...v };
  if (v.cargo_type && !['FCL', 'LCL'].includes(v.cargo_type)) bad('Cargo type must be FCL or LCL.');
  if (v.freight_terms && !['PREPAID', 'COLLECT'].includes(v.freight_terms)) bad('Freight terms must be PREPAID or COLLECT.');
  if (m.etd && m.eta && m.eta < m.etd) bad('ETA is before ETD.');
  if (m.pol_id && m.pod_id && m.pol_id === m.pod_id) bad('Port of loading and discharge cannot be the same.');
  if (v.agent_id) { const p = db.prepare('SELECT is_agent FROM parties WHERE id=?').get(v.agent_id); if (!p || !p.is_agent) bad('The selected party is not an agent.'); }
  for (const k of ['packages', 'gross_weight', 'cbm']) if (m[k] != null && m[k] < 0) bad('Packages, weight and CBM cannot be negative.');
}

r.get('/shipments', need('shipments', 'read'), (req, res) => {
  const w = [], p = {};
  const q = req.query;
  const scope = S.shipmentSql(req.user); if (scope) w.push(scope);       // external agents: only their own shipments
  if (q.q) { w.push('(s.booking_no LIKE @q OR s.hbl_no LIKE @q OR cu.name LIKE @q OR sh.name LIKE @q OR co.name LIKE @q OR ag.name LIKE @q OR s.commodity LIKE @q OR k.mbl_no LIKE @q OR EXISTS(SELECT 1 FROM shipment_containers sc JOIN containers c ON c.id=sc.container_id WHERE sc.shipment_id=s.id AND c.container_no LIKE @q))'); p.q = `%${q.q}%`; }
  if (q.status) { w.push('s.status=@st'); p.st = q.status; }
  if (q.open === '1') w.push("s.status NOT IN ('CLOSED','CANCELLED')");
  if (q.cargo_type) { w.push('s.cargo_type=@ct'); p.ct = q.cargo_type; }
  if (q.agent_id) { w.push('s.agent_id=@ag'); p.ag = q.agent_id; }
  if (q.customer_id) { w.push('s.customer_id=@cu'); p.cu = q.customer_id; }
  if (q.consol_id) { w.push('s.consol_id=@ko'); p.ko = q.consol_id; }
  if (q.from) { w.push('COALESCE(s.etd, substr(s.created_at,1,10))>=@from'); p.from = q.from; }
  if (q.to) { w.push('COALESCE(s.etd, substr(s.created_at,1,10))<=@to'); p.to = q.to; }
  const rows = db.prepare(`SELECT ${SHIP_COLS},
      (SELECT COUNT(*) FROM shipment_containers sc WHERE sc.shipment_id=s.id) AS container_count,
      (SELECT COALESCE(SUM(t.teu),0) FROM shipment_containers sc JOIN containers c ON c.id=sc.container_id JOIN container_types t ON t.id=c.type_id WHERE sc.shipment_id=s.id) AS teu
    ${SHIP_FROM} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY s.id DESC LIMIT ${Math.min(parseInt(q.limit || '500', 10) || 500, 5000)}`).all(p);
  if (A.can(req.user.role, 'finance', 'read')) {
    const pr = L.shipmentProfit(rows.map((x) => x.id));
    for (const x of rows) x.profit = pr[x.id] ? pr[x.id].profit : 0;
  }
  if (S.isAgent(req.user)) rows.forEach(stripForAgent);
  res.json(rows);
});

r.get('/shipments/:id', need('shipments', 'read'), (req, res) => {
  const s = db.prepare(`SELECT ${SHIP_COLS}, sh.address AS shipper_address, co.address AS consignee_address, nt.address AS notify_address, cu.credit_days AS customer_credit_days ${SHIP_FROM} WHERE s.id=?`).get(req.params.id);
  if (!s) bad('Shipment not found', 404);
  S.assertShipment(req.user, s);
  s.containers = db.prepare(`SELECT sc.*, c.container_no, c.status, c.location, t.code AS type_code, t.teu FROM shipment_containers sc
    JOIN containers c ON c.id=sc.container_id JOIN container_types t ON t.id=c.type_id WHERE sc.shipment_id=? ORDER BY c.container_no`).all(s.id);
  for (const c of s.containers) c.status_label = (L.CONTAINER_STATUS[c.status] || {}).label || c.status;
  if (A.can(req.user.role, 'finance', 'read')) {
    s.documents = db.prepare(`SELECT d.id, d.doc_no, d.doc_type, d.status, d.doc_date, d.currency, d.total, d.subtotal, d.fx_rate, p.name AS party_name,
        CASE WHEN d.status='POSTED' THEN ${L.outstandingSql()} ELSE NULL END AS outstanding
      FROM documents d JOIN parties p ON p.id=d.party_id WHERE d.shipment_id=? ORDER BY d.id`).all(s.id);
    s.profit = L.shipmentProfit([s.id])[s.id] || { income: 0, expense: 0, profit: 0 };
    s.base_currency = L.baseCurrency();
  }
  s.commission = S.isAgent(req.user) ? null : db.prepare(`SELECT cs.stmt_no, cs.status, l.commission_amount, cs.currency FROM commission_lines l JOIN commission_statements cs ON cs.id=l.statement_id
    WHERE l.shipment_id=? AND cs.status<>'CANCELLED'`).get(s.id) || null;
  if (S.isAgent(req.user)) stripForAgent(s);
  res.json(s);
});

r.post('/shipments', need('shipments', 'write'), (req, res) => {
  const v = extract(req.body, SHIP_FIELDS);
  checkShipment(v, null);
  if (v.consol_id && !db.prepare('SELECT 1 FROM consols WHERE id=?').get(v.consol_id)) bad('Consol not found.');
  v.booking_no = nextNo('BOOKING');
  v.created_by = req.user.id;
  const id = insertRow('shipments', v);
  audit(req.user, 'CREATE', 'shipment', id, { booking_no: v.booking_no });
  res.json({ id, booking_no: v.booking_no });
});

r.put('/shipments/:id', need('shipments', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (['CLOSED', 'CANCELLED'].includes(cur.status)) bad(`A ${cur.status.toLowerCase()} shipment cannot be edited.`);
  const v = extract(req.body, SHIP_FIELDS, { partial: true });
  checkShipment(v, cur);
  if ('cargo_type' in v && v.cargo_type !== cur.cargo_type && db.prepare('SELECT 1 FROM shipment_containers WHERE shipment_id=?').get(cur.id)) bad('Remove the containers before changing between FCL and LCL.');
  if ('agent_id' in v && v.agent_id !== cur.agent_id && db.prepare("SELECT 1 FROM commission_lines l JOIN commission_statements cs ON cs.id=l.statement_id WHERE l.shipment_id=? AND cs.status<>'CANCELLED'").get(cur.id))
    bad('This shipment is already on a commission statement, so the agent cannot be changed.');
  if ('consol_id' in v && v.consol_id !== cur.consol_id) bad('Use the consolidation screen to attach or detach a shipment from a master BL.');
  updateRow('shipments', cur.id, v);
  audit(req.user, 'UPDATE', 'shipment', cur.id, diff(cur, v));
  res.json({ ok: true });
});

r.delete('/shipments/:id', need('shipments', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (cur.status !== 'BOOKED' || cur.hbl_no) bad('Only unconfirmed bookings can be deleted. Cancel the shipment instead.');
  if (db.prepare('SELECT 1 FROM documents WHERE shipment_id=?').get(cur.id)) bad('Documents are linked to this booking. Cancel the booking instead.');
  db.transaction(() => {
    for (const sc of db.prepare('SELECT container_id FROM shipment_containers WHERE shipment_id=?').all(cur.id)) detachContainer(cur, sc.container_id, req.user);
    db.prepare('DELETE FROM shipments WHERE id=?').run(cur.id);
  })();
  audit(req.user, 'DELETE', 'shipment', cur.id, { booking_no: cur.booking_no });
  res.json({ ok: true });
});

const NEXT = {
  BOOKED: ['CONFIRMED', 'CANCELLED'], CONFIRMED: ['SAILED', 'CANCELLED'], SAILED: ['ARRIVED'], ARRIVED: ['DELIVERED'],
  DELIVERED: ['CLOSED'], CLOSED: [], CANCELLED: ['BOOKED'],
};

function setShipmentStatus(s, status, user, opts = {}) {
  if (!(NEXT[s.status] || []).includes(status)) bad(`A shipment that is ${s.status.toLowerCase()} cannot move to ${status.toLowerCase()}.`);
  const containers = db.prepare('SELECT container_id FROM shipment_containers WHERE shipment_id=?').all(s.id).map((x) => x.container_id);
  const pol = portName(s.pol_id), pod = portName(s.pod_id);
  if (status === 'CONFIRMED') {
    if (!(s.shipper_id || s.shipper_text)) bad('Add the shipper before confirming.');
    if (!(s.consignee_id || s.consignee_text)) bad('Add the consignee before confirming.');
    if (!s.pol_id || !s.pod_id) bad('Select the port of loading and discharge before confirming.');
    if (!s.customer_id) bad('Select the billing customer before confirming.');
    if (!s.hbl_no) db.prepare('UPDATE shipments SET hbl_no=? WHERE id=?').run(nextNo('HBL'), s.id);
  }
  if (status === 'SAILED') {
    if (!s.hbl_no) bad('Confirm the booking and issue the HBL before sailing.');
    if (!s.etd) bad('Enter the ETD (sailing date) first.');
    for (const cid of containers) addEventOnce({ container_id: cid, event_type: 'ON_BOARD', event_date: opts.date || s.etd, location: pol, shipment_id: s.id, consol_id: s.consol_id, remarks: 'Vessel sailed' }, user);
  }
  if (status === 'ARRIVED') {
    for (const cid of containers) addEventOnce({ container_id: cid, event_type: 'DISCHARGED', event_date: opts.date || s.eta || today(), location: pod, shipment_id: s.id, consol_id: s.consol_id,
      free_days: opts.free_days != null ? opts.free_days : (getSetting('default_free_days', '') || null), remarks: 'Vessel arrived' }, user);
  }
  if (status === 'DELIVERED') {
    for (const cid of containers) {
      const c = db.prepare('SELECT status FROM containers WHERE id=?').get(cid);
      if (c.status === 'DISCHARGED') addEventOnce({ container_id: cid, event_type: 'DELIVERED_FULL', event_date: opts.date || today(), location: s.place_of_delivery || pod, shipment_id: s.id, consol_id: s.consol_id, remarks: 'Cargo delivered' }, user);
    }
  }
  if (status === 'CANCELLED') {
    if (db.prepare("SELECT 1 FROM documents WHERE shipment_id=? AND status='POSTED'").get(s.id)) bad('Posted invoices/bills exist for this shipment. Cancel or credit them first.');
    if (db.prepare("SELECT 1 FROM commission_lines l JOIN commission_statements cs ON cs.id=l.statement_id WHERE l.shipment_id=? AND cs.status<>'CANCELLED'").get(s.id)) bad('This shipment is on a commission statement. Cancel the statement first.');
    for (const cid of containers) detachContainer(s, cid, user);
    if (s.consol_id) db.prepare('UPDATE shipments SET consol_id=NULL WHERE id=?').run(s.id);
  }
  db.prepare('UPDATE shipments SET status=? WHERE id=?').run(status, s.id);
  audit(user, 'STATUS', 'shipment', s.id, { from: s.status, to: status });
}

r.post('/shipments/:id/status', need('shipments', 'write'), (req, res) => {
  const s = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.params.id);
  if (!s) bad('Not found', 404);
  const status = String(req.body.status || '').toUpperCase();
  if (s.consol_id && ['SAILED', 'ARRIVED'].includes(status)) bad('This shipment is on a master BL. Sail or arrive the whole consolidation from the Consol screen.');
  db.transaction(() => setShipmentStatus(s, status, req.user, { date: req.body.date, free_days: req.body.free_days }))();
  res.json({ ok: true });
});

// ---- containers on a shipment
function attachContainer(s, container, body, user) {
  if (['CLOSED', 'CANCELLED', 'DELIVERED'].includes(s.status)) bad(`Containers cannot be added to a ${s.status.toLowerCase()} shipment.`);
  if (['SAILED', 'ARRIVED'].includes(s.status)) bad('The shipment has already sailed. Edit container movements from the container screen instead.');
  if (db.prepare('SELECT 1 FROM shipment_containers WHERE shipment_id=? AND container_id=?').get(s.id, container.id)) bad('That container is already on this shipment.');
  const st = L.CONTAINER_STATUS[container.status] || { group: 'EMPTY' };
  const lclShared = s.cargo_type === 'LCL' && s.consol_id && container.consol_id === s.consol_id;
  if (st.group === 'CLOSED') bad('That container has been off-hired and is not in inventory.');
  if (st.group === 'OUT_OF_SERVICE') bad('That container is damaged / out of service.');
  if (st.group !== 'EMPTY' && !lclShared) bad(`Container ${container.container_no} is not empty (${(L.CONTAINER_STATUS[container.status] || {}).label}). Only empty containers can be allocated.`);
  if (s.cargo_type === 'FCL') {
    const other = db.prepare(`SELECT s2.booking_no FROM shipment_containers sc JOIN shipments s2 ON s2.id=sc.shipment_id
      WHERE sc.container_id=? AND s2.id<>? AND s2.status NOT IN ('CLOSED','CANCELLED','DELIVERED')`).get(container.id, s.id);
    if (other) bad(`Container ${container.container_no} is already allocated to ${other.booking_no}.`);
  }
  const num = (v) => (v === '' || v == null ? null : Number(v));
  db.prepare('INSERT INTO shipment_containers(shipment_id,container_id,seal_no,packages,weight_kg,cbm) VALUES(?,?,?,?,?,?)')
    .run(s.id, container.id, body.seal_no || null, num(body.packages), num(body.weight_kg), num(body.cbm));
  if (st.group === 'EMPTY') addEvent({ container_id: container.id, event_type: 'ALLOCATED', event_date: body.date || today(), location: container.location, shipment_id: s.id, consol_id: s.consol_id, remarks: `Allocated to ${s.booking_no}` }, user);
}
function detachContainer(s, containerId, user) {
  db.prepare('DELETE FROM shipment_containers WHERE shipment_id=? AND container_id=?').run(s.id, containerId);
  const c = db.prepare('SELECT * FROM containers WHERE id=?').get(containerId);
  const stillUsed = db.prepare(`SELECT 1 FROM shipment_containers sc JOIN shipments s2 ON s2.id=sc.shipment_id WHERE sc.container_id=? AND s2.status NOT IN ('CLOSED','CANCELLED','DELIVERED')`).get(containerId);
  if (c && c.status === 'ALLOCATED' && !stillUsed) addEvent({ container_id: containerId, event_type: 'EMPTY_AVAILABLE', event_date: today(), location: c.location, remarks: `Released from ${s.booking_no}` }, user);
}
r.post('/shipments/:id/containers', need('shipments', 'write'), need('containers', 'read'), (req, res) => {
  const s = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.params.id);
  if (!s) bad('Not found', 404);
  const c = db.prepare('SELECT * FROM containers WHERE id=?').get(req.body.container_id);
  if (!c) bad('Choose a container.');
  db.transaction(() => attachContainer(s, c, req.body, req.user))();
  audit(req.user, 'ADD_CONTAINER', 'shipment', s.id, { container: c.container_no });
  res.json({ ok: true });
});
r.put('/shipments/:id/containers/:cid', need('shipments', 'write'), (req, res) => {
  const num = (v) => (v === '' || v == null ? null : Number(v));
  db.prepare('UPDATE shipment_containers SET seal_no=?, packages=?, weight_kg=?, cbm=? WHERE shipment_id=? AND container_id=?')
    .run(req.body.seal_no || null, num(req.body.packages), num(req.body.weight_kg), num(req.body.cbm), req.params.id, req.params.cid);
  res.json({ ok: true });
});
r.delete('/shipments/:id/containers/:cid', need('shipments', 'write'), (req, res) => {
  const s = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.params.id);
  if (!s) bad('Not found', 404);
  if (!['BOOKED', 'CONFIRMED'].includes(s.status)) bad('Containers can only be removed before the shipment sails.');
  db.transaction(() => detachContainer(s, Number(req.params.cid), req.user))();
  audit(req.user, 'REMOVE_CONTAINER', 'shipment', s.id, { container_id: req.params.cid });
  res.json({ ok: true });
});

// ================================================================ consolidations / master BL
const CONSOL_FIELDS = [
  { name: 'mbl_no' }, { name: 'carrier_id', type: 'int' }, { name: 'vessel' }, { name: 'voyage' },
  { name: 'pol_id', type: 'int' }, { name: 'pod_id', type: 'int' }, { name: 'etd', type: 'date' }, { name: 'eta', type: 'date' },
  { name: 'cutoff_date', type: 'date' }, { name: 'remarks' },
];
const CONSOL_STATUS_NEXT = { PLANNED: ['CLOSED', 'SAILED', 'CANCELLED'], CLOSED: ['SAILED', 'PLANNED', 'CANCELLED'], SAILED: ['ARRIVED'], ARRIVED: ['COMPLETED'], COMPLETED: [], CANCELLED: ['PLANNED'] };

r.get('/consols', need('shipments', 'read'), A.staffOnly, (req, res) => {
  const w = [], p = {};
  if (req.query.q) { w.push('(k.consol_no LIKE @q OR k.mbl_no LIKE @q OR k.vessel LIKE @q OR ca.name LIKE @q)'); p.q = `%${req.query.q}%`; }
  if (req.query.status) { w.push('k.status=@st'); p.st = req.query.status; }
  if (req.query.open === '1') w.push("k.status IN ('PLANNED','CLOSED')");
  res.json(db.prepare(`SELECT k.*, ca.name AS carrier_name, pl.name AS pol_name, pd.name AS pod_name,
      (SELECT COUNT(*) FROM shipments s WHERE s.consol_id=k.id) AS shipment_count,
      (SELECT COALESCE(SUM(s.cbm),0) FROM shipments s WHERE s.consol_id=k.id) AS total_cbm
    FROM consols k LEFT JOIN parties ca ON ca.id=k.carrier_id LEFT JOIN ports pl ON pl.id=k.pol_id LEFT JOIN ports pd ON pd.id=k.pod_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY k.id DESC LIMIT 500`).all(p));
});
r.get('/consols/:id', need('shipments', 'read'), A.staffOnly, (req, res) => {
  const k = db.prepare(`SELECT k.*, ca.name AS carrier_name, pl.name AS pol_name, pd.name AS pod_name FROM consols k
    LEFT JOIN parties ca ON ca.id=k.carrier_id LEFT JOIN ports pl ON pl.id=k.pol_id LEFT JOIN ports pd ON pd.id=k.pod_id WHERE k.id=?`).get(req.params.id);
  if (!k) bad('Not found', 404);
  k.shipments = db.prepare(`SELECT s.id,s.booking_no,s.hbl_no,s.status,s.cargo_type,s.packages,s.gross_weight,s.cbm,s.commodity,
      cu.name AS customer_name, co.name AS consignee_name, ag.name AS agent_name
    FROM shipments s LEFT JOIN parties cu ON cu.id=s.customer_id LEFT JOIN parties co ON co.id=s.consignee_id LEFT JOIN parties ag ON ag.id=s.agent_id
    WHERE s.consol_id=? ORDER BY s.id`).all(k.id);
  k.containers = db.prepare(`SELECT DISTINCT c.id, c.container_no, c.status, c.location, t.code AS type_code, t.teu FROM shipment_containers sc
    JOIN shipments s ON s.id=sc.shipment_id JOIN containers c ON c.id=sc.container_id JOIN container_types t ON t.id=c.type_id WHERE s.consol_id=? ORDER BY c.container_no`).all(k.id);
  for (const c of k.containers) c.status_label = (L.CONTAINER_STATUS[c.status] || {}).label || c.status;
  k.totals = { packages: 0, weight: 0, cbm: 0, teu: 0 };
  for (const s of k.shipments) { k.totals.packages += s.packages || 0; k.totals.weight += s.gross_weight || 0; k.totals.cbm += s.cbm || 0; }
  for (const c of k.containers) k.totals.teu += c.teu;
  res.json(k);
});
r.post('/consols', need('shipments', 'write'), (req, res) => {
  const v = extract(req.body, CONSOL_FIELDS);
  if (v.etd && v.eta && v.eta < v.etd) bad('ETA is before ETD.');
  v.consol_no = nextNo('CONSOL');
  const id = insertRow('consols', v);
  audit(req.user, 'CREATE', 'consol', id, { consol_no: v.consol_no });
  res.json({ id, consol_no: v.consol_no });
});
r.put('/consols/:id', need('shipments', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM consols WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (['COMPLETED', 'CANCELLED'].includes(cur.status)) bad('This consolidation is closed for editing.');
  const v = extract(req.body, CONSOL_FIELDS, { partial: true });
  const m = { ...cur, ...v };
  if (m.etd && m.eta && m.eta < m.etd) bad('ETA is before ETD.');
  db.transaction(() => {
    updateRow('consols', cur.id, v);
    // keep child shipments in step with vessel / voyage / dates while not yet sailed
    if (['PLANNED', 'CLOSED'].includes(cur.status)) {
      db.prepare('UPDATE shipments SET vessel=?, voyage=?, etd=?, eta=?, carrier_id=COALESCE(?,carrier_id) WHERE consol_id=? AND status IN (\'BOOKED\',\'CONFIRMED\')')
        .run(m.vessel, m.voyage, m.etd, m.eta, m.carrier_id, cur.id);
    }
  })();
  audit(req.user, 'UPDATE', 'consol', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.delete('/consols/:id', need('shipments', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM consols WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (db.prepare('SELECT 1 FROM shipments WHERE consol_id=?').get(cur.id)) bad('Detach the shipments first.');
  if (cur.status !== 'PLANNED' && cur.status !== 'CANCELLED') bad('Only planned or cancelled consolidations can be deleted.');
  db.prepare('DELETE FROM consols WHERE id=?').run(cur.id);
  audit(req.user, 'DELETE', 'consol', cur.id);
  res.json({ ok: true });
});
r.post('/consols/:id/shipments', need('shipments', 'write'), (req, res) => {
  const k = db.prepare('SELECT * FROM consols WHERE id=?').get(req.params.id);
  const s = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.body.shipment_id);
  if (!k || !s) bad('Consolidation or shipment not found.', 404);
  if (!['PLANNED', 'CLOSED'].includes(k.status)) bad('Shipments can only be added before the vessel sails.');
  if (!['BOOKED', 'CONFIRMED'].includes(s.status)) bad('Only booked or confirmed shipments can be added.');
  if (s.consol_id && s.consol_id !== k.id) bad('This shipment is already on another master BL.');
  if (k.pol_id && s.pol_id && k.pol_id !== s.pol_id) bad('The shipment\'s port of loading differs from the consolidation\'s.');
  if (k.pod_id && s.pod_id && k.pod_id !== s.pod_id) bad('The shipment\'s port of discharge differs from the consolidation\'s.');
  db.transaction(() => {
    db.prepare(`UPDATE shipments SET consol_id=?, vessel=COALESCE(?,vessel), voyage=COALESCE(?,voyage), etd=COALESCE(?,etd), eta=COALESCE(?,eta),
      carrier_id=COALESCE(?,carrier_id), pol_id=COALESCE(pol_id,?), pod_id=COALESCE(pod_id,?) WHERE id=?`)
      .run(k.id, k.vessel, k.voyage, k.etd, k.eta, k.carrier_id, k.pol_id, k.pod_id, s.id);
    for (const sc of db.prepare('SELECT container_id FROM shipment_containers WHERE shipment_id=?').all(s.id)) {
      const c = db.prepare('SELECT * FROM containers WHERE id=?').get(sc.container_id);
      if (c && (L.CONTAINER_STATUS[c.status] || {}).group === 'EMPTY') addEvent({ container_id: c.id, event_type: 'ALLOCATED', event_date: req.body.date || today(), location: c.location, shipment_id: s.id, consol_id: k.id, remarks: `On ${k.consol_no}` }, req.user);
    }
  })();
  audit(req.user, 'ADD_SHIPMENT', 'consol', k.id, { booking_no: s.booking_no });
  res.json({ ok: true });
});
r.delete('/consols/:id/shipments/:sid', need('shipments', 'write'), (req, res) => {
  const k = db.prepare('SELECT * FROM consols WHERE id=?').get(req.params.id);
  if (!k) bad('Not found', 404);
  if (!['PLANNED', 'CLOSED'].includes(k.status)) bad('Shipments cannot be removed after the vessel has sailed.');
  db.prepare('UPDATE shipments SET consol_id=NULL WHERE id=? AND consol_id=?').run(req.params.sid, k.id);
  audit(req.user, 'REMOVE_SHIPMENT', 'consol', k.id, { shipment_id: req.params.sid });
  res.json({ ok: true });
});
r.post('/consols/:id/status', need('shipments', 'write'), (req, res) => {
  const k = db.prepare('SELECT * FROM consols WHERE id=?').get(req.params.id);
  if (!k) bad('Not found', 404);
  const status = String(req.body.status || '').toUpperCase();
  if (!(CONSOL_STATUS_NEXT[k.status] || []).includes(status)) bad(`A ${k.status.toLowerCase()} consolidation cannot move to ${status.toLowerCase()}.`);
  db.transaction(() => {
    const ships = db.prepare('SELECT * FROM shipments WHERE consol_id=? AND status<>\'CANCELLED\'').all(k.id);
    if (status === 'SAILED') {
      if (!k.mbl_no) bad('Enter the master BL number before sailing.');
      if (!k.etd) bad('Enter the ETD before sailing.');
      if (!ships.length) bad('There are no shipments on this consolidation.');
      const unconf = ships.filter((s) => s.status === 'BOOKED');
      if (unconf.length) bad(`Confirm these bookings (issue the HBL) or remove them first: ${unconf.map((s) => s.booking_no).join(', ')}`);
      for (const s of ships) if (s.status === 'CONFIRMED') setShipmentStatus(s, 'SAILED', req.user, { date: req.body.date || k.etd });
    }
    if (status === 'ARRIVED') {
      for (const s of ships) if (s.status === 'SAILED') setShipmentStatus(s, 'ARRIVED', req.user, { date: req.body.date || k.eta, free_days: req.body.free_days });
    }
    if (status === 'CANCELLED' && ships.length) bad('Remove the shipments first.');
    db.prepare('UPDATE consols SET status=? WHERE id=?').run(status, k.id);
  })();
  audit(req.user, 'STATUS', 'consol', k.id, { from: k.status, to: status });
  res.json({ ok: true });
});

// ================================================================ containers
r.get('/containers', need('containers', 'read'), (req, res) => {
  const asOf = req.query.as_of || today();
  let rows = S.hideForeignRefs(req.user, S.filterContainers(req.user, L.containerSnapshot(asOf, { inventoryOnly: req.query.include_closed !== '1' })));   // agents: their locations / shipments only
  const q = req.query;
  if (q.q) { const s = q.q.toUpperCase(); rows = rows.filter((x) => x.container_no.includes(s) || (x.location || '').toUpperCase().includes(s) || (x.booking_no || '').toUpperCase().includes(s) || (x.hbl_no || '').toUpperCase().includes(s)); }
  if (q.status) rows = rows.filter((x) => x.status === q.status);
  if (q.group) rows = rows.filter((x) => x.group === q.group);
  if (q.type_id) rows = rows.filter((x) => String(x.type_id) === String(q.type_id));
  if (q.ownership) rows = rows.filter((x) => x.ownership === q.ownership);
  if (q.location) rows = rows.filter((x) => (x.location || '') === q.location);
  if (q.overdue === '1') rows = rows.filter((x) => x.overdue);
  res.json({ as_of: asOf, rows });
});

const CONT_FIELDS = [
  { name: 'type_id', type: 'int', required: true, label: 'Container type' }, { name: 'ownership', type: 'upper', def: 'COC' },
  { name: 'owner_id', type: 'int' }, { name: 'condition', type: 'upper', def: 'SOUND' }, { name: 'remarks' },
];
function validateContainerNo(raw, allowInvalid) {
  const no = L.normContainerNo(raw);
  if (!/^[A-Z]{4}\d{7}$/.test(no)) bad(`"${raw}" is not a valid container number (expected 4 letters + 7 digits, e.g. MSKU1234565).`);
  if (!allowInvalid && !L.iso6346Valid(no)) bad(`${no} fails the ISO 6346 check-digit test. Check for a typo, or tick "accept invalid check digit".`);
  return no;
}
function checkContainerFields(v) {
  if (v.ownership && !['COC', 'SOC', 'LEASED', 'OWN'].includes(v.ownership)) bad('Ownership must be COC, SOC, LEASED or OWN.');
  if (v.condition && !['SOUND', 'DAMAGED', 'UNDER_REPAIR'].includes(v.condition)) bad('Unknown condition.');
  if (v.type_id && !db.prepare('SELECT 1 FROM container_types WHERE id=?').get(v.type_id)) bad('Unknown container type.');
}
function createContainer(no, v, initial, user) {
  const id = insertRow('containers', { container_no: no, ...v, status: initial.event_type, location: initial.location || null });
  addEvent({ container_id: id, ...initial, remarks: initial.remarks || 'Added to inventory' }, user);
  return id;
}

r.post('/containers', need('containers', 'write'), (req, res) => {
  const b = req.body;
  const no = validateContainerNo(b.container_no, !!b.allow_invalid);
  if (db.prepare('SELECT 1 FROM containers WHERE container_no=?').get(no)) bad(`Container ${no} already exists.`, 409);
  const v = extract(b, CONT_FIELDS); checkContainerFields(v);
  const id = db.transaction(() => createContainer(no, v, { event_type: b.status || 'EMPTY_AVAILABLE', event_date: b.date || today(), location: b.location }, req.user))();
  audit(req.user, 'CREATE', 'container', id, { container_no: no });
  res.json({ id, container_no: no });
});

r.post('/containers/bulk', need('containers', 'write'), (req, res) => {
  const b = req.body;
  const nums = String(b.numbers || '').split(/[\s,;]+/).filter(Boolean);
  if (!nums.length) bad('Paste at least one container number.');
  if (nums.length > 500) bad('Please add at most 500 containers at a time.');
  const v = extract(b, CONT_FIELDS); checkContainerFields(v);
  const created = [], skipped = [], invalid = [];
  db.transaction(() => {
    for (const raw of nums) {
      let no;
      try { no = validateContainerNo(raw, !!b.allow_invalid); } catch (e) { invalid.push({ number: raw, reason: e.message }); continue; }
      if (db.prepare('SELECT 1 FROM containers WHERE container_no=?').get(no) || created.includes(no)) { skipped.push({ number: no, reason: 'Already in the system' }); continue; }
      createContainer(no, v, { event_type: b.status || 'EMPTY_AVAILABLE', event_date: b.date || today(), location: b.location }, req.user);
      created.push(no);
    }
  })();
  audit(req.user, 'BULK_CREATE', 'container', null, { created: created.length, skipped: skipped.length, invalid: invalid.length });
  res.json({ created, skipped, invalid });
});

r.get('/containers/:id', need('containers', 'read'), (req, res) => {
  const c = db.prepare(`SELECT c.*, t.code AS type_code, t.teu, o.name AS owner_name FROM containers c JOIN container_types t ON t.id=c.type_id LEFT JOIN parties o ON o.id=c.owner_id WHERE c.id=?`).get(req.params.id);
  if (!c || !S.canSeeContainer(req.user, c.id, c.location)) bad('Not found', 404);
  const snap = L.containerSnapshot(today()).find((x) => x.id === c.id);
  Object.assign(c, snap ? { status_label: snap.status_label, group: snap.group, days_in_status: snap.days_in_status, free_until: snap.free_until, free_days_left: snap.free_days_left, overdue: snap.overdue, free_days: snap.free_days, clock_from: snap.clock_from } : {});
  c.events = db.prepare(`SELECT e.*, s.booking_no, s.hbl_no, k.consol_no, u.username FROM container_events e LEFT JOIN shipments s ON s.id=e.shipment_id
    LEFT JOIN consols k ON k.id=e.consol_id LEFT JOIN users u ON u.id=e.user_id WHERE e.container_id=? ORDER BY e.event_date DESC, e.id DESC`).all(c.id);
  for (const e of c.events) e.label = (L.CONTAINER_STATUS[e.event_type] || {}).label || e.event_type;
  c.shipments = db.prepare(`SELECT s.id, s.booking_no, s.hbl_no, s.status, s.cargo_type, s.agent_id FROM shipment_containers sc JOIN shipments s ON s.id=sc.shipment_id WHERE sc.container_id=? ORDER BY s.id DESC`).all(c.id).filter((s) => S.ownsShipment(req.user, s));
  if (S.isAgent(req.user)) for (const e of c.events) { if (e.shipment_id && !c.shipments.some((s) => s.id === e.shipment_id)) { e.shipment_id = null; e.booking_no = null; e.hbl_no = null; e.consol_no = null; } }
  res.json(c);
});
r.put('/containers/:id', need('containers', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM containers WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, [...CONT_FIELDS, { name: 'active', type: 'bool' }], { partial: true }); checkContainerFields(v);
  updateRow('containers', cur.id, v);
  audit(req.user, 'UPDATE', 'container', cur.id, diff(cur, v));
  res.json({ ok: true });
});

r.post('/containers/:id/events', need('containers', 'write'), (req, res) => {
  const c = db.prepare('SELECT * FROM containers WHERE id=?').get(req.params.id);
  if (!c) bad('Not found', 404);
  const id = db.transaction(() => addEvent({ ...req.body, container_id: c.id }, req.user))();
  audit(req.user, 'MOVEMENT', 'container', c.id, { type: req.body.event_type, date: req.body.event_date, location: req.body.location });
  res.json({ id });
});
r.post('/container-events/bulk', need('containers', 'write'), (req, res) => {
  const ids = Array.isArray(req.body.container_ids) ? req.body.container_ids : bad('Select at least one container.');
  if (!ids.length) bad('Select at least one container.');
  db.transaction(() => { for (const cid of ids) { if (!db.prepare('SELECT 1 FROM containers WHERE id=?').get(cid)) bad('Container not found: ' + cid); addEvent({ ...req.body, container_id: cid }, req.user); } })();
  audit(req.user, 'BULK_MOVEMENT', 'container', null, { count: ids.length, type: req.body.event_type, date: req.body.event_date, location: req.body.location });
  res.json({ ok: true, count: ids.length });
});
r.delete('/container-events/:id', need('containers', 'write'), (req, res) => {
  const e = db.prepare('SELECT * FROM container_events WHERE id=?').get(req.params.id);
  if (!e) bad('Not found', 404);
  if (db.prepare('SELECT COUNT(*) n FROM container_events WHERE container_id=?').get(e.container_id).n <= 1) bad('A container needs at least one movement record.');
  db.transaction(() => { db.prepare('DELETE FROM container_events WHERE id=?').run(e.id); L.refreshContainer(e.container_id); })();
  audit(req.user, 'DELETE_MOVEMENT', 'container', e.container_id, e);
  res.json({ ok: true });
});

module.exports = r;
module.exports.setShipmentStatus = setShipmentStatus;
Object.assign(module.exports, { addEvent, createContainer, validateContainerNo, SHIP_FIELDS, checkShipment });
