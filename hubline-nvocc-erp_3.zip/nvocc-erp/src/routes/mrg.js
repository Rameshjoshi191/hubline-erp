'use strict';
// MRG: month-wise freight rate, slot cost and margin.
const express = require('express');
const { db, audit, today } = require('../db');
const A = require('../auth');
const { need } = A;
const { bad, extract, insertRow, diff } = require('../util');
const kit = require('../importkit');
const MRG = require('../mrg');

const r = express.Router();

kit.mount(r, {
  path: 'mrg', module: 'mrg', entity: 'mrg', aliases: MRG.ALIASES, fields: MRG.FIELDS, templateName: 'MRG_rates_template.xlsx',
  template: () => [
    { name: 'Rates', columns: [['Month', 12], ['Carrier', 22], ['POL', 22], ['POD', 22], ['Type', 10], ['Freight rate', 13], ['Slot cost', 13], ['Currency', 10], ['Committed slots', 15], ['Remarks', 26]].map(([header, width]) => ({ header, key: header, width })), rows: [] },
    { name: 'How to fill', title: ['How to fill the Rates sheet', 'One row per month, lane and container type. Loading the same month again updates the rates.'], columns: [{ header: 'Column', key: 'a', width: 22 }, { header: 'What to type', key: 'b', width: 90 }], rows: [
      { a: 'Month', b: 'Mar 2026, 2026-03 or 03/2026' }, { a: 'POL / POD', b: 'Port name or UN/LOCODE (Jebel Ali or AEJEA)' }, { a: 'Type', b: '20GP, 40HC, 40 high cube, 22G1 ...' },
      { a: 'Freight rate', b: 'What you charge / sell per container' }, { a: 'Slot cost', b: 'What the shipping line charges you per container slot' }, { a: 'Margin', b: 'Calculated for you: freight rate minus slot cost' },
      { a: 'Committed slots', b: 'Optional: the minimum quantity you committed to for that month' }] },
  ],
  plan: (table) => MRG.buildPlan(table),
  commit: (plan, user) => MRG.commitPlan(plan, user),
});

r.get('/mrg', need('mrg', 'read'), (req, res) => res.json(MRG.rows(req.query)));
r.get('/mrg/summary', need('mrg', 'read'), (req, res) => res.json({ year: req.query.year || today().slice(0, 4), months: MRG.summary(req.query.year || today().slice(0, 4)) }));
r.get('/mrg/matrix', need('mrg', 'read'), (req, res) => {
  const metric = ['freight', 'slot', 'margin', 'boxes'].includes(req.query.metric) ? req.query.metric : 'margin';
  res.json({ year: req.query.year || today().slice(0, 4), metric, rows: MRG.matrix(req.query.year || today().slice(0, 4), metric) });
});

const FIELDS = [
  { name: 'month', required: true, label: 'Month' }, { name: 'carrier_id', type: 'int' }, { name: 'pol_id', type: 'int' }, { name: 'pod_id', type: 'int' },
  { name: 'container_type_id', type: 'int', required: true, label: 'Container type' }, { name: 'freight_rate', type: 'real', required: true, label: 'Freight rate' },
  { name: 'slot_cost', type: 'real', required: true, label: 'Slot cost' }, { name: 'currency', type: 'upper', def: 'USD' }, { name: 'committed_slots', type: 'int' }, { name: 'remarks' },
];
function check(v) {
  if (v.month && !/^\d{4}-(0[1-9]|1[0-2])$/.test(v.month)) bad('Month must look like 2026-03.');
  if (v.freight_rate != null && v.freight_rate < 0) bad('Freight rate cannot be negative.');
  if (v.slot_cost != null && v.slot_cost < 0) bad('Slot cost cannot be negative.');
  if (v.committed_slots != null && v.committed_slots < 0) bad('Committed slots cannot be negative.');
  if (v.pol_id && v.pod_id && v.pol_id === v.pod_id) bad('Port of loading and discharge cannot be the same.');
  if (v.currency && !db.prepare('SELECT 1 FROM currencies WHERE code=?').get(v.currency)) bad('Unknown currency - add it under Currencies & rates first.');
}
r.post('/mrg', need('mrg', 'write'), (req, res) => {
  const v = extract(req.body, FIELDS); check(v); v.created_by = req.user.id;
  let id;
  try { id = insertRow('mrg_rates', v); } catch (e) { if (String(e.message).includes('UNIQUE')) bad('There is already a rate for this month, lane and container type - edit it instead.', 409); throw e; }
  audit(req.user, 'CREATE', 'mrg', id, v);
  res.json({ id });
});
r.put('/mrg/:id', need('mrg', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM mrg_rates WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, FIELDS, { partial: true }); check({ ...cur, ...v });
  const cols = Object.keys(v);
  try { if (cols.length) db.prepare(`UPDATE mrg_rates SET ${cols.map((c) => `${c}=@${c}`).join(',')}, updated_at=datetime('now') WHERE id=@__id`).run({ ...v, __id: cur.id }); }
  catch (e) { if (String(e.message).includes('UNIQUE')) bad('There is already a rate for this month, lane and container type.', 409); throw e; }
  audit(req.user, 'UPDATE', 'mrg', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.delete('/mrg/:id', need('mrg', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM mrg_rates WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  db.prepare('DELETE FROM mrg_rates WHERE id=?').run(cur.id);
  audit(req.user, 'DELETE', 'mrg', cur.id, cur);
  res.json({ ok: true });
});

// automation: copy a month forward (with an optional % change) / build the month from the tariff book
r.post('/mrg/roll-forward', need('mrg', 'write'), (req, res) => {
  const b = req.body || {};
  res.json(MRG.rollForward(String(b.from || ''), String(b.to || ''), { freight_pct: Number(b.freight_pct) || 0, slot_pct: Number(b.slot_pct) || 0 }, req.user));
});
r.post('/mrg/from-tariffs', need('mrg', 'write'), (req, res) => res.json(MRG.fromTariffs(String((req.body || {}).month || ''), req.user)));

module.exports = r;
