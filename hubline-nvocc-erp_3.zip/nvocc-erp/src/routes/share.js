'use strict';
// Download or e-mail any list / report as Excel or PDF - one endpoint for every screen's "Share" button.
const express = require('express');
const { audit, allSettings } = require('../db');
const A = require('../auth');
const { bad, xlsxBuffer, XLSX_MIME } = require('../util');
const X = require('../exporters');
const SH = require('../share');

const r = express.Router();

const safeName = (s) => String(s).replace(/[^\w.\-]+/g, '_');
async function render(kind, params, format, user) {
  if (!X.EXPORTS[kind]) bad('Unknown report.', 404);
  if (!X.allowed(kind, user)) bad('Your role cannot use this report.', 403);
  const def = await X.EXPORTS[kind].build(params || {}, user);
  const co = allSettings();
  if (format === 'pdf') {
    const buf = def.hbl ? await SH.hblPdf(def.hbl, co) : await SH.pdfFromSheets({ title: def.title, subtitle: def.subtitle, sheets: def.sheets, landscape: def.landscape !== false });
    return { buf, name: safeName(def.filename) + '.pdf', mime: 'application/pdf', def };
  }
  if (format !== 'xlsx') bad('Format must be xlsx or pdf.');
  return { buf: await xlsxBuffer(def.sheets, { company: co.company_name }), name: safeName(def.filename) + '.xlsx', mime: XLSX_MIME, def };
}

r.get('/share/status', A.requireLogin, (req, res) => res.json({ email: SH.mailConfigured() }));

r.get('/export/:kind', A.requireLogin, async (req, res) => {
  const { format = 'xlsx', ...params } = req.query;
  const out = await render(req.params.kind, params, String(format).toLowerCase(), req.user);
  audit(req.user, 'EXPORT', req.params.kind, null, { format, ...params });
  res.setHeader('Content-Type', out.mime);
  res.setHeader('Content-Disposition', `attachment; filename="${out.name}"`);
  res.setHeader('Content-Length', out.buf.length);
  res.end(out.buf);
});

r.post('/export/:kind/email', A.requireLogin, async (req, res) => {
  const b = req.body || {};
  const formats = b.format === 'both' ? ['xlsx', 'pdf'] : [b.format === 'pdf' ? 'pdf' : 'xlsx'];
  if (!SH.mailConfigured()) bad('E-mail is not set up yet. Ask your administrator to fill in the e-mail settings under Setup > Company & settings.');
  const files = [];
  let def;
  for (const f of formats) { const o = await render(req.params.kind, b.params || {}, f, req.user); files.push({ filename: o.name, content: o.buf, contentType: o.mime }); def = o.def; }
  const subject = String(b.subject || '').trim() || `${def.title}${def.subtitle ? ' - ' + def.subtitle : ''}`;
  const text = `${String(b.message || '').trim() ? String(b.message).trim() + '\n\n' : ''}${def.title}${def.subtitle ? ' (' + def.subtitle + ')' : ''} is attached.\n\nSent from the ${allSettings().company_name || 'HUB LINE'} ERP by ${req.user.full_name}.`;
  const n = await SH.sendMail({ to: b.to, subject, text, attachments: files });
  audit(req.user, 'EMAIL', req.params.kind, null, { to: b.to, formats });
  res.json({ ok: true, sent_to: n });
});

module.exports = r;
