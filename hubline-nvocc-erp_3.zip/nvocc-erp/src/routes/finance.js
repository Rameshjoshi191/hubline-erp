'use strict';
const express = require('express');
const { db, audit, nextNo, today, round2, getSetting } = require('../db');
const { need } = require('../auth');
const { bad, sendXlsx, MONEY } = require('../util');
const L = require('../logic');
const S = require('../services');

const r = express.Router();

// ================================================================ documents
r.get('/documents', need('finance', 'read'), (req, res) => {
  const w = [], p = {};
  const q = req.query;
  if (q.type) { w.push('d.doc_type=@type'); p.type = q.type; }
  if (q.side === 'receivable') w.push("d.doc_type IN ('INV','DN')");
  if (q.side === 'payable') w.push("d.doc_type IN ('BILL','COMM')");
  if (q.party_id) { w.push('d.party_id=@party'); p.party = q.party_id; }
  if (q.shipment_id) { w.push('d.shipment_id=@ship'); p.ship = q.shipment_id; }
  if (q.status) { w.push('d.status=@st'); p.st = q.status; }
  if (q.from) { w.push('d.doc_date>=@from'); p.from = q.from; }
  if (q.to) { w.push('d.doc_date<=@to'); p.to = q.to; }
  if (q.q) { w.push('(d.doc_no LIKE @q OR pt.name LIKE @q OR d.party_ref LIKE @q OR s.booking_no LIKE @q OR s.hbl_no LIKE @q OR d.narration LIKE @q)'); p.q = `%${q.q}%`; }
  let rows = db.prepare(`SELECT d.*, pt.name AS party_name, pt.code AS party_code, s.booking_no, s.hbl_no,
      CASE WHEN d.status='POSTED' THEN ${L.outstandingSql()} ELSE NULL END AS outstanding
    FROM documents d JOIN parties pt ON pt.id=d.party_id LEFT JOIN shipments s ON s.id=d.shipment_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY d.doc_date DESC, d.id DESC LIMIT 1000`).all(p);
  if (q.open === '1') rows = rows.filter((x) => x.status === 'POSTED' && Math.abs(x.outstanding) > 0.004);
  const today_ = today();
  for (const x of rows) {
    if (x.outstanding != null) x.outstanding = round2(x.outstanding);
    x.overdue = x.status === 'POSTED' && x.outstanding > 0.004 && x.due_date && x.due_date < today_;
    x.sign = L.DOC_SIGN[x.doc_type];
  }
  res.json(rows);
});

// Suggest invoice/bill lines from the tariff for a shipment
r.get('/documents/suggest', need('finance', 'write'), (req, res) => {
  const s = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.query.shipment_id);
  if (!s) bad('Choose a shipment first.');
  const rateType = req.query.rate_type === 'BUY' ? 'BUY' : 'SELL';
  const currency = String(req.query.currency || 'USD').toUpperCase();
  const date = today();
  const conts = db.prepare(`SELECT c.type_id, t.code, t.teu, COUNT(*) n FROM shipment_containers sc JOIN containers c ON c.id=sc.container_id
    JOIN container_types t ON t.id=c.type_id WHERE sc.shipment_id=? GROUP BY c.type_id`).all(s.id);
  const lookup = db.prepare(`SELECT t.*, cc.code AS charge_code, cc.name AS charge_name, cc.vat_rate AS charge_vat FROM tariffs t JOIN charge_codes cc ON cc.id=t.charge_code_id
    WHERE t.active=1 AND t.rate_type=@rt AND (t.valid_from IS NULL OR t.valid_from<=@d) AND (t.valid_to IS NULL OR t.valid_to>=@d)
      AND (t.pol_id IS NULL OR t.pol_id=@pol) AND (t.pod_id IS NULL OR t.pod_id=@pod) AND (t.cargo_type='ANY' OR t.cargo_type=@ct)
      AND (t.container_type_id IS NULL OR t.container_type_id=@ctype) AND (t.party_id IS NULL OR t.party_id IN (@p1,@p2))`);
  const score = (t) => (t.party_id ? 4 : 0) + (t.pol_id ? 1 : 0) + (t.pod_id ? 1 : 0) + (t.container_type_id ? 1 : 0) + (t.cargo_type !== 'ANY' ? 1 : 0);
  const out = [];
  const pickBest = (rows) => { const best = {}; for (const t of rows) { const k = t.charge_code_id; if (!best[k] || score(t) > score(best[k]) || (score(t) === score(best[k]) && t.id > best[k].id)) best[k] = t; } return Object.values(best); };
  const totalTeu = conts.reduce((a, c) => a + c.teu * c.n, 0), totalN = conts.reduce((a, c) => a + c.n, 0);
  const common = { rt: rateType, d: date, pol: s.pol_id || 0, pod: s.pod_id || 0, ct: s.cargo_type, p1: s.customer_id || 0, p2: s.agent_id || 0 };
  const qtyFor = (unit, c) => {
    switch (unit) {
      case 'PER_CONTAINER': return c ? c.n : totalN;
      case 'PER_TEU': return c ? c.teu * c.n : totalTeu;
      case 'PER_CBM': return Number(s.cbm) || 0;
      case 'PER_TON': return round2((Number(s.gross_weight) || 0) / 1000);
      default: return 1;
    }
  };
  const push = (t, qty, note) => {
    if (!(qty > 0)) return;
    let rate = t.rate;
    try { rate = round2(L.convert(t.rate, t.currency, currency, date)); } catch (e) { bad(e.message); }
    out.push({ charge_code_id: t.charge_code_id, description: t.charge_name + (note ? ` (${note})` : ''), qty, unit: t.unit, rate, vat_rate: t.charge_vat || 0, tariff_id: t.id });
  };
  if (s.cargo_type === 'FCL' && conts.length) {
    const seen = new Set();
    for (const c of conts) {
      for (const t of pickBest(lookup.all({ ...common, ctype: c.type_id }))) {
        if (t.container_type_id) push(t, qtyFor(t.unit, c), c.code);
        else if (!seen.has(t.charge_code_id)) { seen.add(t.charge_code_id); push(t, qtyFor(t.unit, null)); }
      }
    }
  } else {
    for (const t of pickBest(lookup.all({ ...common, ctype: 0 }))) push(t, qtyFor(t.unit, null));
  }
  res.json(out);
});

r.get('/documents/:id', need('finance', 'read'), (req, res) => {
  const d = db.prepare(`SELECT d.*, pt.name AS party_name, pt.code AS party_code, pt.address AS party_address, pt.city AS party_city, pt.country AS party_country,
      pt.tax_no AS party_tax_no, pt.credit_days AS party_credit_days, s.booking_no, s.hbl_no, s.vessel, s.voyage, s.etd, pl.name AS pol_name, pd.name AS pod_name,
      s.commodity AS shipment_commodity,
      CASE WHEN d.status='POSTED' THEN ${L.outstandingSql()} ELSE NULL END AS outstanding
    FROM documents d JOIN parties pt ON pt.id=d.party_id LEFT JOIN shipments s ON s.id=d.shipment_id
    LEFT JOIN ports pl ON pl.id=s.pol_id LEFT JOIN ports pd ON pd.id=s.pod_id WHERE d.id=?`).get(req.params.id);
  if (!d) bad('Document not found', 404);
  d.lines = db.prepare(`SELECT l.*, c.code AS charge_code FROM document_lines l LEFT JOIN charge_codes c ON c.id=l.charge_code_id WHERE l.document_id=? ORDER BY l.id`).all(d.id);
  d.allocations = db.prepare(`SELECT a.*, CASE a.from_type WHEN 'PAYMENT' THEN (SELECT pay_no FROM payments WHERE id=a.from_id) ELSE (SELECT doc_no FROM documents WHERE id=a.from_id) END AS from_ref
    FROM allocations a WHERE a.to_doc_id=? ORDER BY a.id`).all(d.id)
    .concat(db.prepare(`SELECT a.*, (SELECT doc_no FROM documents WHERE id=a.to_doc_id) AS to_ref FROM allocations a WHERE a.from_type='DOC' AND a.from_id=? ORDER BY a.id`).all(d.id));
  d.sign = L.DOC_SIGN[d.doc_type];
  d.label = L.DOC_LABEL[d.doc_type];
  if (d.outstanding != null) d.outstanding = round2(d.outstanding);
  res.json(d);
});

r.post('/documents', need('finance', 'write'), (req, res) => {
  const id = S.createDocument({ ...req.body, doc_type: String(req.body.doc_type || '').toUpperCase() }, req.user);
  res.json({ id, doc_no: db.prepare('SELECT doc_no FROM documents WHERE id=?').get(id).doc_no });
});
r.put('/documents/:id', need('finance', 'write'), (req, res) => {
  S.updateDraftDocument(Number(req.params.id), req.body, req.user);
  res.json({ ok: true });
});
r.post('/documents/:id/post', need('finance', 'write'), (req, res) => {
  const doc_no = S.postDocument(Number(req.params.id), req.user);
  res.json({ ok: true, doc_no });
});
r.post('/documents/:id/cancel', need('finance', 'write'), (req, res) => {
  S.cancelDocument(Number(req.params.id), req.user, req.body.reason);
  res.json({ ok: true });
});
r.delete('/documents/:id', need('finance', 'write'), (req, res) => {
  const d = db.prepare('SELECT * FROM documents WHERE id=?').get(req.params.id);
  if (!d) bad('Not found', 404);
  if (d.status !== 'DRAFT') bad('Only drafts can be deleted. Cancel posted documents instead.');
  db.prepare('DELETE FROM documents WHERE id=?').run(d.id);
  audit(req.user, 'DELETE', 'document', d.id);
  res.json({ ok: true });
});

// ================================================================ payments / receipts
r.get('/payments', need('finance', 'read'), (req, res) => {
  const w = [], p = {};
  const q = req.query;
  if (q.direction) { w.push('p.direction=@dir'); p.dir = q.direction; }
  if (q.party_id) { w.push('p.party_id=@party'); p.party = q.party_id; }
  if (q.from) { w.push('p.pay_date>=@from'); p.from = q.from; }
  if (q.to) { w.push('p.pay_date<=@to'); p.to = q.to; }
  if (q.q) { w.push('(p.pay_no LIKE @q OR pt.name LIKE @q OR p.reference LIKE @q)'); p.q = `%${q.q}%`; }
  const rows = db.prepare(`SELECT p.*, pt.name AS party_name,
      p.amount - COALESCE((SELECT SUM(a.amount) FROM allocations a WHERE a.from_type='PAYMENT' AND a.from_id=p.id),0) AS unallocated
    FROM payments p JOIN parties pt ON pt.id=p.party_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY p.pay_date DESC, p.id DESC LIMIT 1000`).all(p);
  for (const x of rows) x.unallocated = x.status === 'CANCELLED' ? 0 : round2(x.unallocated);
  res.json(rows);
});
r.get('/payments/:id', need('finance', 'read'), (req, res) => {
  const p = db.prepare('SELECT p.*, pt.name AS party_name FROM payments p JOIN parties pt ON pt.id=p.party_id WHERE p.id=?').get(req.params.id);
  if (!p) bad('Not found', 404);
  p.allocations = db.prepare(`SELECT a.*, d.doc_no, d.doc_type FROM allocations a JOIN documents d ON d.id=a.to_doc_id WHERE a.from_type='PAYMENT' AND a.from_id=? ORDER BY a.id`).all(p.id);
  p.unallocated = L.paymentUnallocated(p.id);
  res.json(p);
});

const compatible = (direction, docType) => (direction === 'RECEIPT' ? L.DOC_SIGN[docType] > 0 : L.DOC_SIGN[docType] < 0);

function applyAllocations({ fromType, fromId, party_id, currency, direction, docType, date, allocations, available }, user) {
  let total = 0;
  for (const a of allocations || []) {
    const amt = round2(a.amount);
    if (!(amt > 0)) continue;
    const doc = db.prepare('SELECT * FROM documents WHERE id=?').get(a.doc_id);
    if (!doc || doc.status !== 'POSTED') bad('Choose a posted document to settle.');
    if (doc.party_id !== party_id) bad(`${doc.doc_no} belongs to a different party.`);
    if (doc.currency !== currency) bad(`${doc.doc_no} is in ${doc.currency} but this settlement is in ${currency}. Settle each currency separately.`);
    if (fromType === 'PAYMENT' && !compatible(direction, doc.doc_type)) bad(`A ${direction === 'RECEIPT' ? 'receipt' : 'payment'} cannot settle ${L.DOC_LABEL[doc.doc_type].toLowerCase()} ${doc.doc_no}.`);
    const out = L.docOutstanding(doc.id);
    if (amt > out + 0.005) bad(`${doc.doc_no}: amount ${amt.toFixed(2)} is more than the outstanding ${out.toFixed(2)}.`);
    db.prepare('INSERT INTO allocations(alloc_date,currency,amount,from_type,from_id,to_doc_id,created_by) VALUES(?,?,?,?,?,?,?)')
      .run(date, currency, amt, fromType, fromId, doc.id, user.id);
    total = round2(total + amt);
  }
  if (total > available + 0.005) bad(`You allocated ${total.toFixed(2)} but only ${available.toFixed(2)} is available.`);
  return total;
}

r.post('/payments', need('finance', 'write'), (req, res) => {
  const b = req.body;
  const direction = String(b.direction || '').toUpperCase();
  if (!['RECEIPT', 'PAYMENT'].includes(direction)) bad('Choose receipt or payment.');
  const party = db.prepare('SELECT * FROM parties WHERE id=?').get(b.party_id);
  if (!party) bad('Choose the customer / agent / vendor.');
  const amount = round2(b.amount);
  if (!(amount > 0)) bad('Enter an amount greater than zero.');
  const currency = String(b.currency || '').toUpperCase();
  if (!db.prepare('SELECT 1 FROM currencies WHERE code=?').get(currency)) bad('Choose a currency.');
  const date = b.pay_date || today();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) bad('Invalid date.');
  const fx = L.fxRate(currency, date);
  if (!fx) bad(`No exchange rate for ${currency}. Add it under Setup > Exchange rates.`);
  const id = db.transaction(() => {
    const pid = db.prepare(`INSERT INTO payments(pay_no,direction,party_id,pay_date,method,currency,amount,fx_rate,reference,bank,narration,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(nextNo(direction, date), direction, party.id, date, b.method || null, currency, amount, fx, b.reference || null, b.bank || null, b.narration || null, req.user.id).lastInsertRowid;
    applyAllocations({ fromType: 'PAYMENT', fromId: pid, party_id: party.id, currency, direction, date, allocations: b.allocations, available: amount }, req.user);
    return pid;
  })();
  const p = db.prepare('SELECT pay_no FROM payments WHERE id=?').get(id);
  audit(req.user, 'CREATE', 'payment', id, { pay_no: p.pay_no, direction, amount, currency, party_id: party.id });
  res.json({ id, pay_no: p.pay_no });
});
r.post('/payments/:id/allocate', need('finance', 'write'), (req, res) => {
  const p = db.prepare('SELECT * FROM payments WHERE id=?').get(req.params.id);
  if (!p || p.status !== 'POSTED') bad('Payment not found or cancelled.');
  db.transaction(() => applyAllocations({ fromType: 'PAYMENT', fromId: p.id, party_id: p.party_id, currency: p.currency, direction: p.direction, date: req.body.date || today(), allocations: req.body.allocations, available: L.paymentUnallocated(p.id) }, req.user))();
  audit(req.user, 'ALLOCATE', 'payment', p.id, req.body.allocations);
  res.json({ ok: true });
});
r.post('/payments/:id/cancel', need('finance', 'write'), (req, res) => {
  const p = db.prepare('SELECT * FROM payments WHERE id=?').get(req.params.id);
  if (!p) bad('Not found', 404);
  if (p.status === 'CANCELLED') bad('Already cancelled.');
  db.transaction(() => {
    db.prepare("DELETE FROM allocations WHERE from_type='PAYMENT' AND from_id=?").run(p.id);
    db.prepare("UPDATE payments SET status='CANCELLED' WHERE id=?").run(p.id);
  })();
  audit(req.user, 'CANCEL', 'payment', p.id, req.body.reason || null);
  res.json({ ok: true });
});

// Net a credit note / bill against an invoice / debit note of the same party and currency
r.post('/allocations/net', need('finance', 'write'), (req, res) => {
  const from = db.prepare('SELECT * FROM documents WHERE id=?').get(req.body.from_doc_id);
  const to = db.prepare('SELECT * FROM documents WHERE id=?').get(req.body.to_doc_id);
  if (!from || !to) bad('Choose both documents.');
  if (from.status !== 'POSTED' || to.status !== 'POSTED') bad('Both documents must be posted.');
  if (from.party_id !== to.party_id) bad('Both documents must belong to the same party.');
  if (from.currency !== to.currency) bad('Both documents must be in the same currency.');
  if (L.DOC_SIGN[from.doc_type] === L.DOC_SIGN[to.doc_type]) bad('Choose one debit-side document (invoice / debit note) and one credit-side document (credit note / bill / commission).');
  const amt = round2(req.body.amount);
  if (!(amt > 0)) bad('Enter an amount.');
  const max = Math.min(L.docOutstanding(from.id), L.docOutstanding(to.id));
  if (amt > max + 0.005) bad(`The most you can net is ${max.toFixed(2)}.`);
  const id = db.prepare("INSERT INTO allocations(alloc_date,currency,amount,from_type,from_id,to_doc_id,created_by) VALUES(?,?,?,'DOC',?,?,?)")
    .run(req.body.date || today(), from.currency, amt, from.id, to.id, req.user.id).lastInsertRowid;
  audit(req.user, 'NET', 'allocation', id, { from: from.doc_no, to: to.doc_no, amount: amt });
  res.json({ ok: true, id });
});
r.delete('/allocations/:id', need('finance', 'write'), (req, res) => {
  const a = db.prepare('SELECT * FROM allocations WHERE id=?').get(req.params.id);
  if (!a) bad('Not found', 404);
  db.prepare('DELETE FROM allocations WHERE id=?').run(a.id);
  audit(req.user, 'UNALLOCATE', 'allocation', a.id, a);
  res.json({ ok: true });
});

r.get('/parties/:id/open-items', need('finance', 'read'), (req, res) => {
  res.json(L.openItems({ to: today(), party_id: Number(req.params.id), currency: req.query.currency }));
});

// ================================================================ statement of account
r.get('/soa', need('soa', 'read'), async (req, res) => {
  if (!req.query.party_id) bad('Choose a party.');
  const mode = req.query.mode === 'open' ? 'open' : 'ledger';
  const soa = L.buildSoa({ party_id: Number(req.query.party_id), from: req.query.from, to: req.query.to, mode, currency: req.query.currency || undefined });
  if (req.query.format !== 'xlsx') return res.json(soa);
  const co = getSetting('company_name', '');
  const sheets = soa.currencies.map((c) => ({
    name: `SOA ${c.currency}`,
    title: [`${co} - Statement of account`, `${soa.party.name} (${soa.party.code})`, `${mode === 'open' ? 'Open items' : 'Ledger'} ${mode === 'ledger' ? soa.from + ' to ' : 'as at '}${soa.to}   Currency: ${c.currency}`,
      mode === 'ledger' ? `Opening balance: ${c.opening.toFixed(2)}` : ''],
    columns: [
      { header: 'Date', key: 'date', width: 12 }, { header: 'Document', key: 'ref', width: 20 }, { header: 'Type', key: 'type', width: 10 },
      { header: 'Shipment / HBL', key: 'shipment', width: 20 }, { header: 'Description', key: 'description', width: 36 }, { header: 'Due date', key: 'due_date', width: 12 },
      { header: 'Debit', key: 'debit', width: 14, fmt: MONEY }, { header: 'Credit', key: 'credit', width: 14, fmt: MONEY }, { header: 'Balance', key: 'balance', width: 14, fmt: MONEY },
    ],
    rows: c.rows, totals: { debit: c.total_debit, credit: c.total_credit, balance: c.closing },
  }));
  if (!sheets.length) sheets.push({ name: 'SOA', title: [`${co} - Statement of account`, soa.party.name, 'No transactions'], columns: [{ header: 'Date', key: 'date' }], rows: [] });
  await sendXlsx(res, `SOA_${soa.party.code}_${soa.to}.xlsx`, sheets, { company: co });
});

module.exports = r;
