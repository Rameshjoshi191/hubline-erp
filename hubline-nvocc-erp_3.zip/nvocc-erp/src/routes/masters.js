'use strict';
const express = require('express');
const { db, audit, today } = require('../db');
const { need } = require('../auth');
const { bad, crud, extract, insertRow, updateRow, diff } = require('../util');

const r = express.Router();

crud(r, {
  path: 'ports', table: 'ports', module: 'masters', search: ['code', 'name', 'country'], order: 'name', entity: 'port',
  fields: [
    { name: 'code', type: 'upper', required: true, label: 'Port code' }, { name: 'name', required: true, label: 'Port name' },
    { name: 'country' }, { name: 'active', type: 'bool', def: 1 },
  ],
});

crud(r, {
  path: 'container-types', table: 'container_types', module: 'masters', search: ['code', 'description'], order: 'size_ft, code', entity: 'container_type',
  fields: [
    { name: 'code', type: 'upper', required: true, label: 'Type code' }, { name: 'description' },
    { name: 'size_ft', type: 'int', required: true, label: 'Size (ft)' }, { name: 'teu', type: 'real', required: true, label: 'TEU' },
    { name: 'is_reefer', type: 'bool', def: 0 }, { name: 'active', type: 'bool', def: 1 },
  ],
});

crud(r, {
  path: 'charge-codes', table: 'charge_codes', module: 'masters', search: ['code', 'name'], order: 'code', entity: 'charge_code',
  fields: [
    { name: 'code', type: 'upper', required: true, label: 'Charge code' }, { name: 'name', required: true, label: 'Charge name' },
    { name: 'category', type: 'upper', def: 'OTHER' }, { name: 'side', type: 'upper', def: 'BOTH' },
    { name: 'vat_rate', type: 'real', def: 0 }, { name: 'active', type: 'bool', def: 1 },
  ],
  before(v) {
    if (v.category && !['FREIGHT', 'ORIGIN', 'DESTINATION', 'DOC', 'OTHER'].includes(v.category)) bad('Category must be FREIGHT, ORIGIN, DESTINATION, DOC or OTHER.');
    if (v.side && !['INCOME', 'EXPENSE', 'BOTH'].includes(v.side)) bad('Side must be INCOME, EXPENSE or BOTH.');
    if (v.vat_rate != null && (v.vat_rate < 0 || v.vat_rate > 100)) bad('VAT rate must be between 0 and 100.');
  },
});

// ---------------------------------------------------------------- currencies & exchange rates
r.get('/currencies', need('masters', 'read'), (req, res) => {
  res.json(db.prepare(`SELECT c.code, c.name, c.active,
      (SELECT rate FROM exchange_rates e WHERE e.currency=c.code ORDER BY effective_date DESC LIMIT 1) AS rate,
      (SELECT effective_date FROM exchange_rates e WHERE e.currency=c.code ORDER BY effective_date DESC LIMIT 1) AS rate_date
    FROM currencies c ORDER BY c.code`).all());
});
r.post('/currencies', need('masters', 'write'), (req, res) => {
  const code = String(req.body.code || '').trim().toUpperCase();
  if (!/^[A-Z]{3}$/.test(code)) bad('Currency code must be 3 letters (e.g. USD).');
  if (db.prepare('SELECT 1 FROM currencies WHERE code=?').get(code)) bad('Currency already exists.', 409);
  db.prepare('INSERT INTO currencies(code,name) VALUES(?,?)').run(code, String(req.body.name || '').trim());
  audit(req.user, 'CREATE', 'currency', code);
  res.json({ ok: true });
});
r.get('/exchange-rates', need('masters', 'read'), (req, res) => {
  res.json(db.prepare(`SELECT * FROM exchange_rates ${req.query.currency ? 'WHERE currency=?' : ''} ORDER BY effective_date DESC, currency LIMIT 200`)
    .all(...(req.query.currency ? [req.query.currency] : [])));
});
r.post('/exchange-rates', need('masters', 'write'), (req, res) => {
  const v = extract(req.body, [
    { name: 'currency', type: 'upper', required: true, label: 'Currency' }, { name: 'rate', type: 'real', required: true, label: 'Rate' },
    { name: 'effective_date', type: 'date', def: today() },
  ]);
  if (!(v.rate > 0)) bad('Rate must be greater than zero.');
  if (!db.prepare('SELECT 1 FROM currencies WHERE code=?').get(v.currency)) bad('Unknown currency.');
  db.prepare(`INSERT INTO exchange_rates(currency,rate,effective_date) VALUES(?,?,?)
    ON CONFLICT(currency,effective_date) DO UPDATE SET rate=excluded.rate`).run(v.currency, v.rate, v.effective_date);
  audit(req.user, 'RATE', 'exchange_rate', v.currency, v);
  res.json({ ok: true });
});
r.delete('/exchange-rates/:id', need('masters', 'write'), (req, res) => {
  db.prepare('DELETE FROM exchange_rates WHERE id=?').run(req.params.id);
  audit(req.user, 'DELETE', 'exchange_rate', req.params.id);
  res.json({ ok: true });
});

// ---------------------------------------------------------------- tariffs / rate sheets
const TARIFF_FIELDS = [
  { name: 'rate_type', type: 'upper', def: 'SELL' }, { name: 'party_id', type: 'int' },
  { name: 'pol_id', type: 'int' }, { name: 'pod_id', type: 'int' }, { name: 'cargo_type', type: 'upper', def: 'FCL' },
  { name: 'container_type_id', type: 'int' }, { name: 'charge_code_id', type: 'int', required: true, label: 'Charge' },
  { name: 'currency', type: 'upper', required: true, label: 'Currency' }, { name: 'rate', type: 'real', required: true, label: 'Rate' },
  { name: 'unit', type: 'upper', def: 'PER_CONTAINER' }, { name: 'valid_from', type: 'date' }, { name: 'valid_to', type: 'date' },
  { name: 'remarks' }, { name: 'active', type: 'bool', def: 1 },
];
const TARIFF_SELECT = `SELECT t.*, p.name AS party_name, pl.name AS pol_name, pd.name AS pod_name, ct.code AS container_type_code,
    cc.code AS charge_code, cc.name AS charge_name, cc.category AS charge_category, cc.vat_rate AS charge_vat
  FROM tariffs t LEFT JOIN parties p ON p.id=t.party_id LEFT JOIN ports pl ON pl.id=t.pol_id LEFT JOIN ports pd ON pd.id=t.pod_id
  LEFT JOIN container_types ct ON ct.id=t.container_type_id JOIN charge_codes cc ON cc.id=t.charge_code_id`;
function checkTariff(v) {
  if (v.rate_type && !['SELL', 'BUY'].includes(v.rate_type)) bad('Rate type must be SELL or BUY.');
  if (v.cargo_type && !['FCL', 'LCL', 'ANY'].includes(v.cargo_type)) bad('Cargo type must be FCL, LCL or ANY.');
  if (v.unit && !['PER_CONTAINER', 'PER_TEU', 'PER_CBM', 'PER_TON', 'PER_BL', 'LUMPSUM'].includes(v.unit)) bad('Unknown unit.');
  if (v.rate != null && v.rate < 0) bad('Rate cannot be negative.');
  if (v.valid_from && v.valid_to && v.valid_to < v.valid_from) bad('"Valid to" is before "valid from".');
}
r.get('/tariffs', need('tariffs', 'read'), (req, res) => {
  const w = [], p = {};
  if (req.query.rate_type) { w.push('t.rate_type=@rt'); p.rt = req.query.rate_type; }
  if (req.query.party_id) { w.push('t.party_id=@party'); p.party = req.query.party_id; }
  if (req.query.pol_id) { w.push('t.pol_id=@pol'); p.pol = req.query.pol_id; }
  if (req.query.pod_id) { w.push('t.pod_id=@pod'); p.pod = req.query.pod_id; }
  if (req.query.active === '1') w.push('t.active=1');
  if (req.query.current === '1') { w.push('(t.valid_from IS NULL OR t.valid_from<=@d) AND (t.valid_to IS NULL OR t.valid_to>=@d)'); p.d = today(); }
  if (req.query.q) { w.push('(cc.name LIKE @q OR cc.code LIKE @q OR p.name LIKE @q OR pl.name LIKE @q OR pd.name LIKE @q)'); p.q = `%${req.query.q}%`; }
  res.json(db.prepare(`${TARIFF_SELECT} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY pl.name, pd.name, cc.code, t.id DESC LIMIT 1000`).all(p));
});

// Find applicable sell/buy rates for a lane. Most specific rows first.
r.get('/tariffs/lookup', need('tariffs', 'read'), (req, res) => {
  const q = req.query, d = q.date || today();
  const rows = db.prepare(`${TARIFF_SELECT} WHERE t.active=1 AND t.rate_type=@rt
      AND (t.valid_from IS NULL OR t.valid_from<=@d) AND (t.valid_to IS NULL OR t.valid_to>=@d)
      AND (t.pol_id IS NULL OR t.pol_id=@pol) AND (t.pod_id IS NULL OR t.pod_id=@pod)
      AND (t.cargo_type='ANY' OR t.cargo_type=@ct)
      AND (t.container_type_id IS NULL OR t.container_type_id=@ctype)
      AND (t.party_id IS NULL OR t.party_id IN (@p1,@p2))`)
    .all({ rt: q.rate_type || 'SELL', d, pol: q.pol_id || 0, pod: q.pod_id || 0, ct: q.cargo_type || 'FCL', ctype: q.container_type_id || 0, p1: q.customer_id || 0, p2: q.agent_id || 0 });
  // keep the most specific tariff per charge code
  const score = (t) => (t.party_id ? 4 : 0) + (t.pol_id ? 1 : 0) + (t.pod_id ? 1 : 0) + (t.container_type_id ? 1 : 0) + (t.cargo_type !== 'ANY' ? 1 : 0);
  const best = {};
  for (const t of rows) { const k = t.charge_code_id; if (!best[k] || score(t) > score(best[k]) || (score(t) === score(best[k]) && t.id > best[k].id)) best[k] = t; }
  res.json(Object.values(best).sort((a, b) => a.charge_code.localeCompare(b.charge_code)));
});

r.post('/tariffs', need('tariffs', 'write'), (req, res) => {
  const v = extract(req.body, TARIFF_FIELDS); checkTariff(v);
  const id = insertRow('tariffs', v);
  audit(req.user, 'CREATE', 'tariff', id, v);
  res.json({ id });
});
r.put('/tariffs/:id', need('tariffs', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM tariffs WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, TARIFF_FIELDS, { partial: true }); checkTariff({ ...cur, ...v });
  updateRow('tariffs', cur.id, v);
  audit(req.user, 'UPDATE', 'tariff', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.delete('/tariffs/:id', need('tariffs', 'write'), (req, res) => {
  db.prepare('DELETE FROM tariffs WHERE id=?').run(req.params.id);
  audit(req.user, 'DELETE', 'tariff', req.params.id);
  res.json({ ok: true });
});

module.exports = r;
