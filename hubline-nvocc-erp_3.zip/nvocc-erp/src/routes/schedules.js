'use strict';
// Vessel schedules: list, add by hand, Excel/CSV/paste wizard, web-link import (with saved sources), change alerts.
const express = require('express');
const { db, audit, today, getSetting } = require('../db');
const A = require('../auth');
const { need } = A;
const { bad, extract, insertRow } = require('../util');
const T = require('../tabular');
const kit = require('../importkit');
const SCH = require('../schedules');

const r = express.Router();

const wizard = kit.mount(r, {
  path: 'schedules', module: 'schedules', entity: 'schedule', aliases: SCH.ALIASES, fields: SCH.FIELDS, templateName: 'Vessel_schedule_template.xlsx',
  template: () => [
    { name: 'Schedule', columns: [['Carrier', 20], ['Service', 14], ['Vessel', 22], ['Voyage', 10], ['POL', 22], ['POD', 22], ['Cut-off', 14], ['ETD', 14], ['ETA', 14], ['Remarks', 26]].map(([header, width]) => ({ header, key: header, width })), rows: [] },
    { name: 'How to fill', title: ['How to fill the Schedule sheet', 'One row per vessel call on a lane. Vessel and ETD are compulsory.'], columns: [{ header: 'Column', key: 'a', width: 20 }, { header: 'What to type', key: 'b', width: 90 }], rows: [
      { a: 'Vessel', b: 'Vessel name, e.g. BLUE HORIZON' }, { a: 'Voyage', b: 'Voyage number, e.g. 026E. Used to keep your bookings and master BLs in step when the carrier changes the dates.' },
      { a: 'POL / POD', b: 'Port name or UN/LOCODE (Jebel Ali or AEJEA). Ports that are not in your list are kept as text.' },
      { a: 'ETD / ETA / Cut-off', b: 'Any normal date: 2026-03-14, 14/03/2026, 14-Mar-2026. Load the same file again next week - changed dates are detected automatically.' },
      { a: 'Carrier', b: 'Shipping line name (matched to your carriers)' }] },
  ],
  plan: (table, options) => SCH.buildPlan(table, options),
  commit: (plan, user) => SCH.commitPlan(plan, user, { source: plan.opt.source, source_id: plan.opt.source_id }),
});

// ---------------------------------------------------------------- listing
r.get('/schedules', need('schedules', 'read'), (req, res) => res.json(SCH.list(req.query)));
r.get('/schedules/upcoming', need('schedules', 'read'), (req, res) => res.json(SCH.list({ ...req.query, upcoming: '1', limit: '80' })));

// ---------------------------------------------------------------- manual add / edit
const FIELDS = [
  { name: 'carrier_id', type: 'int' }, { name: 'service' }, { name: 'vessel', type: 'upper', required: true, label: 'Vessel' }, { name: 'voyage', type: 'upper' },
  { name: 'pol_id', type: 'int' }, { name: 'pod_id', type: 'int' }, { name: 'cutoff_date', type: 'date' }, { name: 'etd', type: 'date' }, { name: 'eta', type: 'date' },
  { name: 'transit_days', type: 'int' }, { name: 'remarks' }, { name: 'active', type: 'bool', def: 1 },
];
const sigFor = (v) => SCH.sigOf(v, { id: v.pol_id }, { id: v.pod_id });
function check(v) {
  if (!v.etd && !v.eta) bad('Enter the ETD or the ETA.');
  if (v.etd && v.eta && v.eta < v.etd) bad('ETA is before ETD.');
  if (v.pol_id && v.pod_id && v.pol_id === v.pod_id) bad('Port of loading and discharge cannot be the same.');
}
r.post('/schedules', need('schedules', 'write'), (req, res) => {
  const v = extract(req.body, FIELDS); check(v);
  v.sig = sigFor(v); v.source = 'MANUAL';
  if (v.etd && v.eta && !v.transit_days) v.transit_days = Math.round((new Date(v.eta) - new Date(v.etd)) / 86400000);
  if (db.prepare('SELECT 1 FROM vessel_schedules WHERE sig=?').get(v.sig)) bad('This vessel / voyage / route is already in the schedule - edit it instead.', 409);
  const id = insertRow('vessel_schedules', v);
  audit(req.user, 'CREATE', 'schedule', id, { vessel: v.vessel, voyage: v.voyage });
  res.json({ id });
});
r.put('/schedules/:id', need('schedules', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM vessel_schedules WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, FIELDS, { partial: true });
  const m = { ...cur, ...v }; check(m);
  const sig = sigFor(m);
  if (sig !== cur.sig && db.prepare('SELECT 1 FROM vessel_schedules WHERE sig=? AND id<>?').get(sig, cur.id)) bad('Another schedule line already has this vessel / voyage / route.', 409);
  db.transaction(() => {
    for (const k of ['etd', 'eta', 'cutoff_date']) if (k in v && (v[k] || null) !== (cur[k] || null) && v[k]) db.prepare('INSERT INTO schedule_changes(schedule_id,field,old_value,new_value) VALUES(?,?,?,?)').run(cur.id, k, cur[k], v[k]);
    const cols = Object.keys(v).concat('sig');
    db.prepare(`UPDATE vessel_schedules SET ${cols.map((c) => `${c}=@${c}`).join(',')}, updated_at=datetime('now') WHERE id=@__id`).run({ ...v, sig, __id: cur.id });
  })();
  if (getSetting('auto_apply_schedule_changes', '') === '1' && ['etd', 'eta', 'cutoff_date'].some((k) => k in v && v[k] !== cur[k])) SCH.applyToOperations(cur.id, req.user);
  audit(req.user, 'UPDATE', 'schedule', cur.id, v);
  res.json({ ok: true });
});
r.delete('/schedules/:id', need('schedules', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM vessel_schedules WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  db.prepare('DELETE FROM vessel_schedules WHERE id=?').run(cur.id);
  audit(req.user, 'DELETE', 'schedule', cur.id, { vessel: cur.vessel, voyage: cur.voyage });
  res.json({ ok: true });
});

// ---------------------------------------------------------------- web link -> the same wizard
r.post('/schedules/import/fetch', need('schedules', 'write'), async (req, res) => {
  const url = String(req.body.url || '').trim();
  if (!url) bad('Paste the link to the schedule page or file.');
  let out;
  try { out = await SCH.readLink(url); } catch (e) { bad(e.status === 422 ? e.message : `Could not read that link: ${e.message}`, 422); }
  if (out.candidates) return res.json({ candidates: out.candidates });
  wizard.start(req, res, out.rows, out.filename, { carrier_id: req.body.carrier_id || '', source_id: req.body.source_id || null });
});

// ---------------------------------------------------------------- saved links (refresh by hand or automatically every day)
r.get('/schedules/sources', need('schedules', 'read'), A.staffOnly, (req, res) => {
  res.json(db.prepare('SELECT s.*, p.name AS carrier_name FROM schedule_sources s LEFT JOIN parties p ON p.id=s.carrier_id ORDER BY s.name').all());
});
const SRC_FIELDS = [{ name: 'name', required: true, label: 'Name' }, { name: 'url', required: true, label: 'Link' }, { name: 'carrier_id', type: 'int' }, { name: 'auto_refresh', type: 'bool', def: 0 }, { name: 'active', type: 'bool', def: 1 }];
const checkUrl = (u) => { try { const x = new URL(u); if (!['http:', 'https:'].includes(x.protocol)) throw new Error(); } catch { bad('The link must start with http:// or https://'); } };
r.post('/schedules/sources', need('schedules', 'write'), (req, res) => {
  const v = extract(req.body, SRC_FIELDS); checkUrl(v.url);
  const id = insertRow('schedule_sources', v);
  audit(req.user, 'CREATE', 'schedule_source', id, { name: v.name, url: v.url });
  res.json({ id });
});
r.put('/schedules/sources/:id', need('schedules', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM schedule_sources WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, SRC_FIELDS, { partial: true }); if (v.url) checkUrl(v.url);
  const cols = Object.keys(v); if (cols.length) db.prepare(`UPDATE schedule_sources SET ${cols.map((c) => `${c}=@${c}`).join(',')} WHERE id=@__id`).run({ ...v, __id: cur.id });
  res.json({ ok: true });
});
r.delete('/schedules/sources/:id', need('schedules', 'write'), (req, res) => {
  db.prepare('DELETE FROM schedule_sources WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});
r.post('/schedules/sources/:id/refresh', need('schedules', 'write'), async (req, res) => {
  const src = db.prepare('SELECT * FROM schedule_sources WHERE id=?').get(req.params.id);
  if (!src) bad('Not found', 404);
  const out = await SCH.refreshSource(src, req.user);
  audit(req.user, 'REFRESH', 'schedule_source', src.id, out.ok ? { created: out.created, updated: out.updated } : { error: out.error });
  if (!out.ok) bad(out.error, 422);
  res.json(out);
});

// ---------------------------------------------------------------- changed dates that touch your bookings / master BLs
r.get('/schedules/changes', need('schedules', 'read'), A.staffOnly, (req, res) => {
  const list = db.prepare(`SELECT c.schedule_id, v.vessel, v.voyage, v.etd, v.eta, v.cutoff_date, COALESCE(pl.name, v.pol_text) AS pol_name, COALESCE(pd.name, v.pod_text) AS pod_name, v.pol_id,
      group_concat(c.field || '|' || COALESCE(c.old_value,'') || '|' || c.new_value, ';') AS ch, MAX(c.ts) AS ts
    FROM schedule_changes c JOIN vessel_schedules v ON v.id=c.schedule_id LEFT JOIN ports pl ON pl.id=v.pol_id LEFT JOIN ports pd ON pd.id=v.pod_id
    WHERE c.applied=0 AND c.dismissed=0 GROUP BY c.schedule_id ORDER BY ts DESC LIMIT 50`).all();
  const out = [];
  for (const x of list) {
    const aff = SCH.affected({ vessel: x.vessel, voyage: x.voyage, pol_id: x.pol_id });
    if (!aff.consols.length && !aff.shipments.length) continue;
    out.push({ schedule_id: x.schedule_id, vessel: x.vessel, voyage: x.voyage, pol_name: x.pol_name, pod_name: x.pod_name, ts: x.ts,
      changes: x.ch.split(';').map((s) => { const [field, from, to] = s.split('|'); return { field, from, to }; }), consols: aff.consols, shipments: aff.shipments });
  }
  res.json(out);
});
r.post('/schedules/:id/apply', need('schedules', 'write'), need('shipments', 'write'), (req, res) => {
  if (!db.prepare('SELECT 1 FROM vessel_schedules WHERE id=?').get(req.params.id)) bad('Not found', 404);
  res.json({ ok: true, ...SCH.applyToOperations(Number(req.params.id), req.user) });
});
r.post('/schedules/:id/dismiss', need('schedules', 'write'), (req, res) => {
  db.prepare('UPDATE schedule_changes SET dismissed=1 WHERE schedule_id=?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = r;
