'use strict';
const express = require('express');
const { db, today, addDays, round2, getSetting } = require('../db');
const A = require('../auth');
const { need } = A;
const { bad, sendXlsx, MONEY } = require('../util');
const L = require('../logic');
const S = require('../scope');
const D = require('../dashboard');

const r = express.Router();

// ================================================================ dashboard
r.get('/dashboard', need('dashboard', 'read'), (req, res) => {
  res.json(S.isAgent(req.user) ? D.agentDashboard(req.user) : D.staffDashboard(req.user));
});

// ================================================================ daily container inventory
function inventoryReport(date) {
  const prev = addDays(date, -1);
  const closing = L.containerSnapshot(date, { inventoryOnly: true });
  const opening = L.containerSnapshot(prev, { inventoryOnly: true });
  const openIds = new Set(opening.map((x) => x.id)), closeIds = new Set(closing.map((x) => x.id));
  const ins = closing.filter((x) => !openIds.has(x.id)), outs = opening.filter((x) => !closeIds.has(x.id));
  const statuses = Object.keys(L.CONTAINER_STATUS).filter((s) => L.CONTAINER_STATUS[s].group !== 'CLOSED');

  const typeMap = {};
  const T = (code, teu) => (typeMap[code] = typeMap[code] || { type_code: code, teu, opening: 0, in: 0, out: 0, closing: 0, empty: 0, laden: 0, out_of_service: 0, ...Object.fromEntries(statuses.map((s) => [s, 0])) });
  for (const c of opening) T(c.type_code, c.teu).opening++;
  for (const c of ins) T(c.type_code, c.teu).in++;
  for (const c of outs) T(c.type_code, c.teu).out++;
  for (const c of closing) {
    const t = T(c.type_code, c.teu);
    t.closing++; t[c.status]++;
    if (c.group === 'EMPTY') t.empty++; else if (c.group === 'LADEN') t.laden++; else t.out_of_service++;
  }
  const types = Object.values(typeMap).sort((a, b) => a.type_code.localeCompare(b.type_code));
  const totals = { type_code: 'TOTAL', teu: null, opening: 0, in: 0, out: 0, closing: 0, empty: 0, laden: 0, out_of_service: 0, ...Object.fromEntries(statuses.map((s) => [s, 0])) };
  for (const t of types) for (const k of Object.keys(totals)) if (typeof totals[k] === 'number' && k !== 'teu') totals[k] += t[k];
  totals.teu_closing = round2(closing.reduce((a, c) => a + c.teu, 0));

  const locMap = {};
  for (const c of closing) {
    const key = c.location || '(no location)';
    const l = locMap[key] = locMap[key] || { location: key, total: 0, empty: 0, laden: 0, out_of_service: 0, by_type: {} };
    l.total++; l.by_type[c.type_code] = (l.by_type[c.type_code] || 0) + 1;
    if (c.group === 'EMPTY') l.empty++; else if (c.group === 'LADEN') l.laden++; else l.out_of_service++;
  }
  const locations = Object.values(locMap).sort((a, b) => b.total - a.total);

  const movements = db.prepare(`SELECT e.id, e.event_date, e.event_type, e.location, e.remarks, c.container_no, t.code AS type_code, s.booking_no, s.hbl_no, k.consol_no
    FROM container_events e JOIN containers c ON c.id=e.container_id JOIN container_types t ON t.id=c.type_id
    LEFT JOIN shipments s ON s.id=e.shipment_id LEFT JOIN consols k ON k.id=e.consol_id WHERE e.event_date=? ORDER BY e.id`).all(date);
  for (const m of movements) m.label = (L.CONTAINER_STATUS[m.event_type] || {}).label || m.event_type;

  const idle = { d0_7: 0, d8_14: 0, d15_30: 0, d31_60: 0, d60_plus: 0 };
  for (const c of closing) if (c.group === 'EMPTY') {
    const d = c.days_in_status;
    idle[d <= 7 ? 'd0_7' : d <= 14 ? 'd8_14' : d <= 30 ? 'd15_30' : d <= 60 ? 'd31_60' : 'd60_plus']++;
  }
  const detention = closing.filter((c) => c.free_days_left != null && c.free_days_left <= 3).sort((a, b) => a.free_days_left - b.free_days_left);
  return { date, prev_date: prev, statuses, status_labels: Object.fromEntries(statuses.map((s) => [s, L.CONTAINER_STATUS[s].label])),
    types, totals, locations, movements, idle, detention, rows: closing, in_rows: ins, out_rows: outs };
}

r.get('/reports/container-inventory', need('reports', 'read'), async (req, res) => {
  const date = req.query.date || today();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) bad('Invalid date.');
  const rep = inventoryReport(date);
  if (req.query.format !== 'xlsx') return res.json(rep);
  const co = getSetting('company_name', '');
  await sendXlsx(res, `Container_Inventory_${date}.xlsx`, require('../exporters').inventorySheets(rep), { company: co });
});

// ================================================================ ageing
r.get('/reports/ageing', need('finance', 'read'), async (req, res) => {
  const rep = L.ageingReport({ to: req.query.to || today(), currency: req.query.currency || undefined, role: req.query.role || undefined });
  if (req.query.format !== 'xlsx') return res.json(rep);
  const co = getSetting('company_name', '');
  await sendXlsx(res, `Ageing_${rep.to}.xlsx`, [{
    name: 'Ageing', title: [`${co} - Ageing of open balances`, `As at ${rep.to}`, 'Positive = they owe us; negative = we owe them'],
    columns: [{ header: 'Code', key: 'party_code', width: 12 }, { header: 'Party', key: 'party_name', width: 36 }, { header: 'Ccy', key: 'currency', width: 6 },
      { header: 'Not due', key: 'not_due', width: 14, fmt: MONEY }, { header: '1-30', key: 'd1_30', width: 14, fmt: MONEY }, { header: '31-60', key: 'd31_60', width: 14, fmt: MONEY },
      { header: '61-90', key: 'd61_90', width: 14, fmt: MONEY }, { header: '90+', key: 'd90_plus', width: 14, fmt: MONEY }, { header: 'Unapplied', key: 'unapplied', width: 14, fmt: MONEY }, { header: 'Net balance', key: 'total', width: 16, fmt: MONEY }],
    rows: rep.rows }], { company: co });
});

// ================================================================ shipment register & profitability
function shipmentRows(q, role) {
  const w = [], p = {};
  if (q.from) { w.push('COALESCE(s.etd, substr(s.created_at,1,10))>=@from'); p.from = q.from; }
  if (q.to) { w.push('COALESCE(s.etd, substr(s.created_at,1,10))<=@to'); p.to = q.to; }
  if (q.agent_id) { w.push('s.agent_id=@ag'); p.ag = q.agent_id; }
  if (q.customer_id) { w.push('s.customer_id=@cu'); p.cu = q.customer_id; }
  if (q.status) { w.push('s.status=@st'); p.st = q.status; }
  const rows = db.prepare(`SELECT s.id, s.booking_no, s.hbl_no, s.status, s.cargo_type, s.etd, s.eta, s.vessel, s.voyage, s.commodity, s.packages, s.gross_weight, s.cbm, s.freight_terms,
      cu.name AS customer_name, sh.name AS shipper_name, co.name AS consignee_name, ag.name AS agent_name, ca.name AS carrier_name, pl.name AS pol_name, pd.name AS pod_name, k.mbl_no,
      (SELECT COUNT(*) FROM shipment_containers sc WHERE sc.shipment_id=s.id) AS containers,
      (SELECT COALESCE(SUM(t.teu),0) FROM shipment_containers sc JOIN containers c ON c.id=sc.container_id JOIN container_types t ON t.id=c.type_id WHERE sc.shipment_id=s.id) AS teu,
      (SELECT group_concat(c.container_no, ', ') FROM shipment_containers sc JOIN containers c ON c.id=sc.container_id WHERE sc.shipment_id=s.id) AS container_nos
    FROM shipments s LEFT JOIN parties cu ON cu.id=s.customer_id LEFT JOIN parties sh ON sh.id=s.shipper_id LEFT JOIN parties co ON co.id=s.consignee_id
    LEFT JOIN parties ag ON ag.id=s.agent_id LEFT JOIN parties ca ON ca.id=s.carrier_id LEFT JOIN ports pl ON pl.id=s.pol_id LEFT JOIN ports pd ON pd.id=s.pod_id LEFT JOIN consols k ON k.id=s.consol_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY s.etd, s.id`).all(p);
  if (A.can(role, 'finance', 'read')) {
    const pr = L.shipmentProfit(rows.map((x) => x.id));
    for (const x of rows) { const o = pr[x.id] || { income: 0, expense: 0, profit: 0 }; x.income = o.income; x.expense = o.expense; x.profit = o.profit; }
  }
  return rows;
}

r.get('/reports/shipments', need('reports', 'read'), async (req, res) => {
  const rows = shipmentRows(req.query, req.user.role);
  if (req.query.format !== 'xlsx') return res.json(rows);
  const co = getSetting('company_name', '');
  const fin = A.can(req.user.role, 'finance', 'read');
  const cols = [
    { header: 'Booking', key: 'booking_no', width: 18 }, { header: 'HBL', key: 'hbl_no', width: 18 }, { header: 'MBL', key: 'mbl_no', width: 16 }, { header: 'Status', key: 'status', width: 11 },
    { header: 'Cargo', key: 'cargo_type', width: 7 }, { header: 'ETD', key: 'etd', width: 12 }, { header: 'ETA', key: 'eta', width: 12 }, { header: 'POL', key: 'pol_name', width: 16 }, { header: 'POD', key: 'pod_name', width: 16 },
    { header: 'Customer', key: 'customer_name', width: 26 }, { header: 'Shipper', key: 'shipper_name', width: 24 }, { header: 'Consignee', key: 'consignee_name', width: 24 }, { header: 'Agent', key: 'agent_name', width: 24 },
    { header: 'Carrier', key: 'carrier_name', width: 20 }, { header: 'Vessel / voyage', key: 'vv', width: 22 }, { header: 'Commodity', key: 'commodity', width: 24 },
    { header: 'Containers', key: 'container_nos', width: 30 }, { header: 'TEU', key: 'teu', width: 7 }, { header: 'CBM', key: 'cbm', width: 8 }, { header: 'Weight kg', key: 'gross_weight', width: 10 },
    ...(fin ? [{ header: `Income (${L.baseCurrency()})`, key: 'income', width: 14, fmt: MONEY }, { header: `Expense (${L.baseCurrency()})`, key: 'expense', width: 14, fmt: MONEY }, { header: `Profit (${L.baseCurrency()})`, key: 'profit', width: 14, fmt: MONEY }] : []),
  ];
  const totals = { teu: round2(rows.reduce((a, x) => a + x.teu, 0)) };
  if (fin) for (const k of ['income', 'expense', 'profit']) totals[k] = round2(rows.reduce((a, x) => a + (x[k] || 0), 0));
  await sendXlsx(res, `Shipment_register_${today()}.xlsx`, [{ name: 'Shipments', title: [`${co} - Shipment register`, `${req.query.from || 'start'} to ${req.query.to || 'today'}`],
    columns: cols, rows: rows.map((x) => ({ ...x, vv: [x.vessel, x.voyage].filter(Boolean).join(' / ') })), totals }], { company: co });
});

r.get('/reports/profit', need('finance', 'read'), (req, res) => {
  const rows = shipmentRows(req.query, req.user.role).filter((x) => x.status !== 'CANCELLED');
  const group = req.query.group || 'agent';
  const key = { agent: (x) => x.agent_name || '(no agent)', customer: (x) => x.customer_name || '(none)', month: (x) => (x.etd || '').slice(0, 7) || '(no ETD)',
    lane: (x) => `${x.pol_name || '?'} > ${x.pod_name || '?'}`, shipment: (x) => x.hbl_no || x.booking_no }[group] || ((x) => x.agent_name);
  const map = {};
  for (const x of rows) {
    const k = key(x);
    const g = map[k] = map[k] || { name: k, shipments: 0, teu: 0, cbm: 0, income: 0, expense: 0, profit: 0 };
    g.shipments++; g.teu += x.teu; g.cbm += x.cbm || 0; g.income += x.income; g.expense += x.expense; g.profit += x.profit;
  }
  const out = Object.values(map).map((g) => ({ ...g, teu: round2(g.teu), cbm: round2(g.cbm), income: round2(g.income), expense: round2(g.expense), profit: round2(g.profit),
    margin: g.income ? round2(g.profit / g.income * 100) : null })).sort((a, b) => b.profit - a.profit);
  res.json({ group, base_currency: L.baseCurrency(), rows: out });
});

module.exports = r;
module.exports.inventoryReport = inventoryReport;
module.exports.shipmentRows = shipmentRows;
