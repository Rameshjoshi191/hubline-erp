'use strict';
// Bills of lading tab: register, view, edit, download. Agents work here on their own shipments only.
const express = require('express');
const { db, audit, nextNo, allSettings } = require('../db');
const A = require('../auth');
const { need } = A;
const { bad, extract, insertRow, updateRow, diff } = require('../util');
const S = require('../scope');
const BL = require('../bl');
const SH = require('../share');
const ops = require('./ops');

const r = express.Router();
const nowStamp = () => new Date().toISOString().slice(0, 19).replace('T', ' ');

r.get('/bls', need('bl', 'read'), (req, res) => res.json(BL.blRows(req.user, req.query)));

// one PDF with several bills of lading, one per page: /bls/pdf?ids=1,2,3
r.get('/bls/pdf', need('bl', 'read'), async (req, res) => {
  const ids = String(req.query.ids || '').split(',').map((x) => parseInt(x, 10)).filter(Number.isInteger).slice(0, 100);
  if (!ids.length) bad('Select at least one bill of lading.');
  const list = ids.map((id) => BL.blFull(req.user, id)).filter(Boolean);
  if (!list.length) bad('Bill of lading not found', 404);
  const buf = await SH.hblPdf(list, allSettings());
  audit(req.user, 'EXPORT', 'bl', null, { pdf: list.length });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${list.length === 1 ? 'BL_' + (list[0].hbl_no || list[0].booking_no) : 'Bills_of_lading'}.pdf"`);
  res.end(buf);
});

r.get('/bls/:id', need('bl', 'read'), (req, res) => {
  const s = BL.blFull(req.user, Number(req.params.id));
  if (!s) bad('Bill of lading not found', 404);
  res.json(s);
});

r.get('/bls/:id/history', need('audit', 'read'), (req, res) => {
  res.json(db.prepare("SELECT ts, username, action, detail FROM audit_log WHERE entity='shipment' AND entity_id=? ORDER BY id DESC LIMIT 60").all(String(req.params.id)));
});

// an agent sends in a new booking request (staff then confirm it, add the billing customer and issue the HBL)
r.post('/bls', need('bl', 'write'), (req, res) => {
  if (!S.isAgent(req.user)) bad('HUB LINE staff create bookings under Shipments / bookings.', 403);
  if (!req.user.agent_party_id) bad('Your login is not linked to an agent company yet. Ask HUB LINE to finish setting up your account.', 403);
  const fields = require('./ops').SHIP_FIELDS.filter((f) => BL.AGENT_NEW_FIELDS.includes(f.name));
  const v = extract(req.body, fields);
  ops.checkShipment(v, null);
  if (!v.shipper_text) bad('Enter the shipper name and address.');
  if (!v.consignee_text) bad('Enter the consignee name and address.');
  if (!v.pol_id || !v.pod_id) bad('Choose the port of loading and the port of discharge.');
  v.agent_id = Number(req.user.agent_party_id);
  v.booking_no = nextNo('BOOKING'); v.created_by = req.user.id; v.remarks = `Booking request from agent ${req.user.full_name}`;
  v.agent_edit_at = nowStamp(); v.agent_edit_by = req.user.username;
  const id = insertRow('shipments', v);
  audit(req.user, 'CREATE', 'shipment', id, { booking_no: v.booking_no, by_agent: true });
  res.json({ id, booking_no: v.booking_no });
});

r.put('/bls/:id', need('bl', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.params.id);
  if (!cur || !S.ownsShipment(req.user, cur)) bad('Bill of lading not found', 404);
  const rights = BL.editRights(req.user, cur);
  if (!rights.edit) bad(rights.reason, 403);
  const fields = ops.SHIP_FIELDS.filter((f) => rights.fields.includes(f.name));
  const v = extract(req.body, fields, { partial: true });
  ops.checkShipment(v, cur);
  if ('cargo_type' in v && v.cargo_type !== cur.cargo_type && db.prepare('SELECT 1 FROM shipment_containers WHERE shipment_id=?').get(cur.id)) bad('Remove the containers before changing between FCL and LCL.');
  if (cur.consol_id) { for (const k of ['vessel', 'voyage', 'etd', 'eta', 'carrier_id']) delete v[k]; }   // vessel details of a consolidated BL come from the master BL
  const changes = diff(cur, v);
  if (!Object.keys(changes).length) return res.json({ ok: true, changed: false });
  if (S.isAgent(req.user)) { v.agent_edit_at = nowStamp(); v.agent_edit_by = req.user.username; }
  updateRow('shipments', cur.id, v);
  audit(req.user, 'BL_EDIT', 'shipment', cur.id, { ...changes, by_agent: S.isAgent(req.user) || undefined });
  res.json({ ok: true, changed: true });
});

r.put('/bls/:id/containers/:cid', need('bl', 'write'), (req, res) => {
  const s = db.prepare('SELECT * FROM shipments WHERE id=?').get(req.params.id);
  if (!s || !S.ownsShipment(req.user, s)) bad('Bill of lading not found', 404);
  const rights = BL.editRights(req.user, s);
  if (!rights.edit) bad(rights.reason, 403);
  const row = db.prepare('SELECT * FROM shipment_containers WHERE shipment_id=? AND container_id=?').get(s.id, req.params.cid);
  if (!row) bad('That container is not on this bill of lading.', 404);
  const num = (x) => (x === '' || x == null ? null : Number(x));
  for (const k of ['packages', 'weight_kg', 'cbm']) { const n = num(req.body[k]); if (n != null && (Number.isNaN(n) || n < 0)) bad('Packages, weight and CBM must be zero or more.'); }
  const v = { seal_no: String(req.body.seal_no || '').trim() || null, packages: num(req.body.packages), weight_kg: num(req.body.weight_kg), cbm: num(req.body.cbm) };
  db.prepare('UPDATE shipment_containers SET seal_no=?, packages=?, weight_kg=?, cbm=? WHERE shipment_id=? AND container_id=?').run(v.seal_no, v.packages, v.weight_kg, v.cbm, s.id, row.container_id);
  if (S.isAgent(req.user)) db.prepare('UPDATE shipments SET agent_edit_at=?, agent_edit_by=? WHERE id=?').run(nowStamp(), req.user.username, s.id);
  audit(req.user, 'BL_EDIT', 'shipment', s.id, { container_id: row.container_id, ...diff(row, v), by_agent: S.isAgent(req.user) || undefined });
  res.json({ ok: true });
});

// staff confirm they have looked at what an agent changed
r.post('/bls/:id/review', need('bl', 'write'), A.staffOnly, (req, res) => {
  const s = db.prepare('SELECT id FROM shipments WHERE id=?').get(req.params.id);
  if (!s) bad('Bill of lading not found', 404);
  db.prepare('UPDATE shipments SET reviewed_at=? WHERE id=?').run(nowStamp(), s.id);
  audit(req.user, 'BL_REVIEWED', 'shipment', s.id);
  res.json({ ok: true });
});

module.exports = r;
