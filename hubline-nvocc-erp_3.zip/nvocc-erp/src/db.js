'use strict';
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = process.env.DB_FILE || path.join(DATA_DIR, 'nvocc.db');

const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT,
  role TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  must_change_pw INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS sequences(
  name TEXT NOT NULL, year TEXT NOT NULL DEFAULT '', prefix TEXT NOT NULL,
  next_no INTEGER NOT NULL DEFAULT 1, pad INTEGER NOT NULL DEFAULT 5,
  PRIMARY KEY(name, year)
);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY,
  ts TEXT NOT NULL DEFAULT (datetime('now')),
  user_id INTEGER, username TEXT,
  action TEXT NOT NULL, entity TEXT NOT NULL, entity_id TEXT, detail TEXT
);
CREATE INDEX IF NOT EXISTS ix_audit_entity ON audit_log(entity, entity_id);

-- ---------- masters ----------
CREATE TABLE IF NOT EXISTS ports(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, country TEXT, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS container_types(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, description TEXT, size_ft INTEGER NOT NULL DEFAULT 20,
  teu REAL NOT NULL DEFAULT 1, is_reefer INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS currencies(
  code TEXT PRIMARY KEY, name TEXT, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS exchange_rates(
  id INTEGER PRIMARY KEY, currency TEXT NOT NULL REFERENCES currencies(code),
  rate REAL NOT NULL, effective_date TEXT NOT NULL, UNIQUE(currency, effective_date)
);
CREATE TABLE IF NOT EXISTS charge_codes(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'OTHER', side TEXT NOT NULL DEFAULT 'BOTH',
  vat_rate REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS parties(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  is_customer INTEGER NOT NULL DEFAULT 0, is_agent INTEGER NOT NULL DEFAULT 0,
  is_vendor INTEGER NOT NULL DEFAULT 0, is_carrier INTEGER NOT NULL DEFAULT 0,
  address TEXT, city TEXT, country TEXT, contact_person TEXT, email TEXT, phone TEXT,
  tax_no TEXT, credit_days INTEGER NOT NULL DEFAULT 30, credit_limit REAL NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'USD',
  agent_type TEXT, agent_network TEXT, agent_territory TEXT, agent_since TEXT,
  notes TEXT, active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS tariffs(
  id INTEGER PRIMARY KEY,
  rate_type TEXT NOT NULL DEFAULT 'SELL',            -- SELL (to customer/agent) or BUY (from carrier/vendor)
  party_id INTEGER REFERENCES parties(id),           -- specific customer / agent / carrier, or NULL = general
  pol_id INTEGER REFERENCES ports(id), pod_id INTEGER REFERENCES ports(id),
  cargo_type TEXT NOT NULL DEFAULT 'FCL',
  container_type_id INTEGER REFERENCES container_types(id),
  charge_code_id INTEGER NOT NULL REFERENCES charge_codes(id),
  currency TEXT NOT NULL DEFAULT 'USD', rate REAL NOT NULL DEFAULT 0,
  unit TEXT NOT NULL DEFAULT 'PER_CONTAINER',
  valid_from TEXT, valid_to TEXT, remarks TEXT, active INTEGER NOT NULL DEFAULT 1
);

-- ---------- agency agreements & commission ----------
CREATE TABLE IF NOT EXISTS agreements(
  id INTEGER PRIMARY KEY, agreement_no TEXT UNIQUE NOT NULL,
  agent_id INTEGER NOT NULL REFERENCES parties(id),
  title TEXT, status TEXT NOT NULL DEFAULT 'DRAFT',  -- DRAFT, ACTIVE, TERMINATED (EXPIRED is derived)
  signed_date TEXT, start_date TEXT, end_date TEXT, auto_renew INTEGER NOT NULL DEFAULT 0,
  notice_days INTEGER NOT NULL DEFAULT 60, territory TEXT, exclusivity TEXT,
  payment_terms_days INTEGER NOT NULL DEFAULT 30, credit_limit REAL NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'USD',
  commission_summary TEXT, governing_law TEXT, notes TEXT,
  created_by INTEGER, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS agreement_clauses(
  id INTEGER PRIMARY KEY, agreement_id INTEGER NOT NULL REFERENCES agreements(id) ON DELETE CASCADE,
  seq INTEGER NOT NULL DEFAULT 0, title TEXT NOT NULL, body TEXT
);
CREATE TABLE IF NOT EXISTS commission_rules(
  id INTEGER PRIMARY KEY, agreement_id INTEGER NOT NULL REFERENCES agreements(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  basis TEXT NOT NULL,       -- PER_TEU, PER_CONTAINER, PER_CBM, PER_BL, PERCENT_FREIGHT, PERCENT_PROFIT
  rate REAL NOT NULL DEFAULT 0, currency TEXT NOT NULL DEFAULT 'USD',
  cargo_type TEXT NOT NULL DEFAULT 'ANY',      -- ANY, FCL, LCL
  pol_id INTEGER REFERENCES ports(id), pod_id INTEGER REFERENCES ports(id),
  min_amount REAL, max_amount REAL,
  valid_from TEXT, valid_to TEXT, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS commission_statements(
  id INTEGER PRIMARY KEY, stmt_no TEXT UNIQUE NOT NULL,
  agent_id INTEGER NOT NULL REFERENCES parties(id),
  agreement_id INTEGER REFERENCES agreements(id),
  period_from TEXT NOT NULL, period_to TEXT NOT NULL, currency TEXT NOT NULL,
  total REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'DRAFT',  -- DRAFT, POSTED, CANCELLED
  document_id INTEGER, notes TEXT, created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS commission_lines(
  id INTEGER PRIMARY KEY, statement_id INTEGER NOT NULL REFERENCES commission_statements(id) ON DELETE CASCADE,
  shipment_id INTEGER NOT NULL, rule_id INTEGER, rule_name TEXT, basis TEXT,
  base_qty REAL, base_amount REAL, rate REAL, commission_amount REAL NOT NULL DEFAULT 0, note TEXT
);
CREATE INDEX IF NOT EXISTS ix_commline_ship ON commission_lines(shipment_id);

-- ---------- operations ----------
CREATE TABLE IF NOT EXISTS consols(
  id INTEGER PRIMARY KEY, consol_no TEXT UNIQUE NOT NULL, mbl_no TEXT,
  carrier_id INTEGER REFERENCES parties(id), vessel TEXT, voyage TEXT,
  pol_id INTEGER REFERENCES ports(id), pod_id INTEGER REFERENCES ports(id),
  etd TEXT, eta TEXT, cutoff_date TEXT,
  status TEXT NOT NULL DEFAULT 'PLANNED',   -- PLANNED, CLOSED, SAILED, ARRIVED, COMPLETED, CANCELLED
  remarks TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS shipments(
  id INTEGER PRIMARY KEY, booking_no TEXT UNIQUE NOT NULL, hbl_no TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'BOOKED',    -- BOOKED, CONFIRMED, SAILED, ARRIVED, DELIVERED, CLOSED, CANCELLED
  cargo_type TEXT NOT NULL DEFAULT 'FCL',
  customer_id INTEGER REFERENCES parties(id),  -- billing customer
  shipper_id INTEGER REFERENCES parties(id), consignee_id INTEGER REFERENCES parties(id),
  notify_id INTEGER REFERENCES parties(id),
  shipper_text TEXT, consignee_text TEXT, notify_text TEXT,
  agent_id INTEGER REFERENCES parties(id),     -- overseas / nominating agent
  carrier_id INTEGER REFERENCES parties(id),
  consol_id INTEGER REFERENCES consols(id),
  pol_id INTEGER REFERENCES ports(id), pod_id INTEGER REFERENCES ports(id),
  place_of_receipt TEXT, place_of_delivery TEXT,
  vessel TEXT, voyage TEXT, etd TEXT, eta TEXT,
  freight_terms TEXT NOT NULL DEFAULT 'PREPAID', incoterm TEXT,
  commodity TEXT, marks TEXT, packages INTEGER, package_type TEXT,
  gross_weight REAL, cbm REAL, remarks TEXT,
  created_by INTEGER, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_ship_agent ON shipments(agent_id);
CREATE INDEX IF NOT EXISTS ix_ship_consol ON shipments(consol_id);
CREATE TABLE IF NOT EXISTS containers(
  id INTEGER PRIMARY KEY, container_no TEXT UNIQUE NOT NULL,
  type_id INTEGER NOT NULL REFERENCES container_types(id),
  ownership TEXT NOT NULL DEFAULT 'COC',     -- COC carrier-owned, SOC shipper-owned, LEASED, OWN
  owner_id INTEGER REFERENCES parties(id),   -- carrier / lessor
  status TEXT NOT NULL DEFAULT 'EMPTY_AVAILABLE', location TEXT,
  free_days INTEGER, free_days_from TEXT,
  seal_no TEXT, consol_id INTEGER REFERENCES consols(id),
  condition TEXT NOT NULL DEFAULT 'SOUND', remarks TEXT,
  last_event_date TEXT, active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS container_events(
  id INTEGER PRIMARY KEY, container_id INTEGER NOT NULL REFERENCES containers(id) ON DELETE CASCADE,
  event_date TEXT NOT NULL, event_type TEXT NOT NULL, location TEXT,
  shipment_id INTEGER REFERENCES shipments(id), consol_id INTEGER REFERENCES consols(id),
  free_days INTEGER, remarks TEXT, user_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_cev ON container_events(container_id, event_date, id);
CREATE INDEX IF NOT EXISTS ix_cev_date ON container_events(event_date);
CREATE TABLE IF NOT EXISTS shipment_containers(
  id INTEGER PRIMARY KEY, shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
  container_id INTEGER NOT NULL REFERENCES containers(id),
  seal_no TEXT, packages INTEGER, weight_kg REAL, cbm REAL,
  UNIQUE(shipment_id, container_id)
);

-- ---------- finance ----------
CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY, doc_no TEXT UNIQUE, doc_type TEXT NOT NULL,  -- INV, DN, CN, BILL, COMM
  party_id INTEGER NOT NULL REFERENCES parties(id), shipment_id INTEGER REFERENCES shipments(id),
  doc_date TEXT NOT NULL, due_date TEXT, currency TEXT NOT NULL, fx_rate REAL NOT NULL DEFAULT 1,
  subtotal REAL NOT NULL DEFAULT 0, vat_amount REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'DRAFT',   -- DRAFT, POSTED, CANCELLED
  party_ref TEXT, narration TEXT, created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), posted_at TEXT
);
CREATE INDEX IF NOT EXISTS ix_doc_party ON documents(party_id, status);
CREATE INDEX IF NOT EXISTS ix_doc_ship ON documents(shipment_id);
CREATE TABLE IF NOT EXISTS document_lines(
  id INTEGER PRIMARY KEY, document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  charge_code_id INTEGER REFERENCES charge_codes(id), description TEXT NOT NULL,
  qty REAL NOT NULL DEFAULT 1, unit TEXT, rate REAL NOT NULL DEFAULT 0,
  amount REAL NOT NULL DEFAULT 0, vat_rate REAL NOT NULL DEFAULT 0, vat_amount REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY, pay_no TEXT UNIQUE NOT NULL,
  direction TEXT NOT NULL,                 -- RECEIPT (money in) or PAYMENT (money out)
  party_id INTEGER NOT NULL REFERENCES parties(id),
  pay_date TEXT NOT NULL, method TEXT, currency TEXT NOT NULL, amount REAL NOT NULL,
  fx_rate REAL NOT NULL DEFAULT 1, reference TEXT, bank TEXT, narration TEXT,
  status TEXT NOT NULL DEFAULT 'POSTED',   -- POSTED, CANCELLED
  created_by INTEGER, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS allocations(
  id INTEGER PRIMARY KEY, alloc_date TEXT NOT NULL, currency TEXT NOT NULL, amount REAL NOT NULL,
  from_type TEXT NOT NULL,                 -- PAYMENT or DOC (credit note / bill netted against an invoice)
  from_id INTEGER NOT NULL, to_doc_id INTEGER NOT NULL REFERENCES documents(id),
  created_by INTEGER, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_alloc_to ON allocations(to_doc_id);
CREATE INDEX IF NOT EXISTS ix_alloc_from ON allocations(from_type, from_id);
`);

// ---------- additive migrations (safe to run on every start) ----------
function addCol(table, col, ddl) {
  if (!db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${ddl}`);
}
// external agents sign in with a user tied to their agent party and the locations (depots / CFS / ports) they look after
addCol('users', 'agent_party_id', 'INTEGER REFERENCES parties(id)');
addCol('users', 'locations', 'TEXT');
// a BL edited by an agent waits in the staff "action centre" until somebody reviews it
addCol('shipments', 'agent_edit_at', 'TEXT');
addCol('shipments', 'agent_edit_by', 'TEXT');
addCol('shipments', 'reviewed_at', 'TEXT');

db.exec(`
CREATE TABLE IF NOT EXISTS schedule_sources(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, url TEXT NOT NULL, carrier_id INTEGER REFERENCES parties(id),
  auto_refresh INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1,
  last_run TEXT, last_status TEXT, last_count INTEGER, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS vessel_schedules(
  id INTEGER PRIMARY KEY, sig TEXT UNIQUE NOT NULL,
  carrier_id INTEGER REFERENCES parties(id), carrier_text TEXT, service TEXT,
  vessel TEXT NOT NULL, voyage TEXT,
  pol_id INTEGER REFERENCES ports(id), pol_text TEXT, pod_id INTEGER REFERENCES ports(id), pod_text TEXT,
  cutoff_date TEXT, etd TEXT, eta TEXT, transit_days INTEGER, remarks TEXT,
  source TEXT NOT NULL DEFAULT 'MANUAL', source_id INTEGER REFERENCES schedule_sources(id) ON DELETE SET NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_vs_etd ON vessel_schedules(etd);
CREATE TABLE IF NOT EXISTS schedule_changes(
  id INTEGER PRIMARY KEY, schedule_id INTEGER NOT NULL REFERENCES vessel_schedules(id) ON DELETE CASCADE,
  ts TEXT NOT NULL DEFAULT (datetime('now')), field TEXT NOT NULL, old_value TEXT, new_value TEXT,
  applied INTEGER NOT NULL DEFAULT 0, dismissed INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS mrg_rates(
  id INTEGER PRIMARY KEY, month TEXT NOT NULL,                       -- YYYY-MM
  carrier_id INTEGER REFERENCES parties(id),
  pol_id INTEGER REFERENCES ports(id), pod_id INTEGER REFERENCES ports(id),
  container_type_id INTEGER REFERENCES container_types(id),
  freight_rate REAL NOT NULL DEFAULT 0,                              -- what we charge / market freight per container
  slot_cost REAL NOT NULL DEFAULT 0,                                 -- what the carrier charges us for the slot
  currency TEXT NOT NULL DEFAULT 'USD', committed_slots INTEGER, remarks TEXT,
  created_by INTEGER, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_mrg ON mrg_rates(month, COALESCE(carrier_id,0), COALESCE(pol_id,0), COALESCE(pod_id,0), COALESCE(container_type_id,0));
`);

// ---------- helpers ----------
const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const round4 = (n) => Math.round((Number(n) + Number.EPSILON) * 10000) / 10000;

function getSetting(key, def = null) {
  const r = db.prepare('SELECT value FROM settings WHERE key=?').get(key);
  return r ? r.value : def;
}
function setSetting(key, value) {
  db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, value == null ? '' : String(value));
}
function allSettings() {
  const o = {};
  for (const r of db.prepare('SELECT key,value FROM settings').all()) o[r.key] = r.value;
  return o;
}

// Document numbering: PREFIX-YYYY-00001 (yearly reset) or PREFIX-00001 when yearly=false
const SEQ_DEFAULTS = {
  BOOKING: 'BKG', HBL: 'HBL', CONSOL: 'CNS', INV: 'INV', DN: 'DN', CN: 'CN', BILL: 'BILL',
  COMM: 'COM', RECEIPT: 'RCT', PAYMENT: 'PAY', AGREEMENT: 'AGR',
  P_CUSTOMER: 'CU', P_AGENT: 'AG', P_VENDOR: 'VN', P_CARRIER: 'CR',
};
function nextNo(name, dateStr, opts = {}) {
  const yearly = !name.startsWith('P_');
  const year = yearly ? String((dateStr || new Date().toISOString()).slice(0, 4)) : '';
  const pad = opts.pad || (yearly ? 5 : 4);
  const tx = db.transaction(() => {
    let row = db.prepare('SELECT * FROM sequences WHERE name=? AND year=?').get(name, year);
    if (!row) {
      const prefix = getSetting('prefix_' + name, SEQ_DEFAULTS[name] || name);
      db.prepare('INSERT INTO sequences(name,year,prefix,next_no,pad) VALUES(?,?,?,1,?)').run(name, year, prefix, pad);
      row = db.prepare('SELECT * FROM sequences WHERE name=? AND year=?').get(name, year);
    }
    db.prepare('UPDATE sequences SET next_no=next_no+1 WHERE name=? AND year=?').run(name, year);
    const num = String(row.next_no).padStart(row.pad, '0');
    return yearly ? `${row.prefix}-${year}-${num}` : `${row.prefix}-${num}`;
  });
  return tx();
}

function audit(user, action, entity, entityId, detail) {
  try {
    db.prepare('INSERT INTO audit_log(user_id,username,action,entity,entity_id,detail) VALUES(?,?,?,?,?,?)')
      .run(user ? user.id : null, user ? user.username : 'system', action, entity, entityId == null ? null : String(entityId),
        detail == null ? null : (typeof detail === 'string' ? detail : JSON.stringify(detail)).slice(0, 2000));
  } catch (e) { /* audit must never break a transaction */ }
}

const today = () => new Date().toISOString().slice(0, 10);
function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + Number(n));
  return d.toISOString().slice(0, 10);
}
function daysBetween(a, b) { // b - a in days
  return Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 86400000);
}

module.exports = { db, DB_FILE, round2, round4, getSetting, setSetting, allSettings, nextNo, audit, today, addDays, daysBetween };
