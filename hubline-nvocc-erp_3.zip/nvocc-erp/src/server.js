'use strict';
// Optional demo mode for free hosting: when started directly with SEED_DEMO=1 and the database has no data, load the demo data first.
if (require.main === module && process.env.SEED_DEMO === '1') require('./demo-autoseed')();
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const { db, DB_FILE } = require('./db');
const A = require('./auth');
const { HttpError } = require('./util');
const { bootstrap } = require('./bootstrap');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === '1');

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'");
  next();
});
// liveness probe for hosting platforms (no auth, no data)
app.get('/healthz', (req, res) => { db.prepare('SELECT 1').get(); res.json({ ok: true }); });
app.use(express.json({ limit: '2mb' }));
app.use(cookieParser());
app.use(A.loadUser);

// CSRF defence: state-changing API calls must carry a custom header that a cross-site form cannot send
app.use('/api', (req, res, next) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && req.get('X-Requested-With') !== 'hubline-erp') {
    return res.status(403).json({ error: 'Blocked: missing request header.' });
  }
  res.setHeader('Cache-Control', 'no-store');
  next();
});

// spreadsheet uploads (raw file bytes) and pasted rows (plain text) for the import wizards - only read for signed-in users
const rawBody = express.raw({ type: ['application/octet-stream', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'text/csv'], limit: '8mb' });
const textBody = express.text({ type: 'text/plain', limit: '2mb' });
app.use('/api', (req, res, next) => (req.user ? rawBody(req, res, (e) => (e ? next(e) : textBody(req, res, next))) : next()));

app.use('/api', require('./routes/core'));
app.use('/api', require('./routes/masters'));
app.use('/api', require('./routes/agents'));
app.use('/api', require('./routes/ops'));
app.use('/api', require('./routes/inventory'));
app.use('/api', require('./routes/bl'));
app.use('/api', require('./routes/schedules'));
app.use('/api', require('./routes/mrg'));
app.use('/api', require('./routes/finance'));
app.use('/api', require('./routes/reports'));
app.use('/api', require('./routes/share'));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

app.use(express.static(path.join(__dirname, '..', 'public'), { extensions: ['html'], maxAge: 0 }));
app.use((req, res, next) => {
  if (req.method !== 'GET') return next();
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err && Number.isInteger(err.status) && err.status >= 400 && err.status < 600 && err.expose !== false && !err.type) return res.status(err.status).json({ error: err.message });
  const msg = String(err && err.message || '');
  if (msg.includes('UNIQUE constraint failed')) {
    const col = (msg.split(':')[1] || '').trim().split('.').pop();
    return res.status(409).json({ error: `That ${col || 'value'} already exists.` });
  }
  if (msg.includes('FOREIGN KEY constraint failed')) return res.status(409).json({ error: 'This record is linked to other data and cannot be changed that way.' });
  if (msg.includes('CHECK constraint failed') || msg.includes('NOT NULL constraint failed')) return res.status(400).json({ error: 'Some required information is missing or invalid: ' + msg });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed request.' });
  if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'That upload is too large (limit 8 MB). Split it into smaller files.' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server. Please try again, and tell your administrator if it continues.' });
});

const { firstRunPassword } = bootstrap();
const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '127.0.0.1';

if (require.main === module) {
  app.listen(PORT, HOST, () => {
    console.log(`\nHUB LINE ERP running at http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
    console.log(`Database: ${DB_FILE}`);
    if (process.env.DISABLE_JOBS !== '1') require('./jobs').start();
    if (firstRunPassword) {
      console.log('\n==============================================================');
      console.log(' First run: administrator account created');
      console.log('   username: admin');
      console.log(`   password: ${firstRunPassword}   (you must change it at first sign-in)`);
      console.log('==============================================================\n');
    }
  });
}
module.exports = app;
