'use strict';
// Container inventory import engine (Excel / CSV / pasted text / quick update all share this code).
// Step 1 buildPlan(): reads every row, understands free-text statuses and container types, checks the ISO 6346 check digit,
// looks at what the system already knows about the container and decides CREATE / MOVE / LOCATION / NOCHANGE / ERROR - without saving anything.
// Step 2 commitPlan(): saves the good rows in ONE transaction (all or nothing), through the same event logic the rest of the ERP uses.
const { db, today } = require('./db');
const L = require('./logic');
const T = require('./tabular');
const S = require('./scope');

const ALIASES = {
  container_no: ['container no', 'container number', 'container', 'cntr no', 'cntr', 'cntr#', 'cont no', 'container #', 'container nr', 'box no', 'unit', 'unit no', 'equipment', 'equipment no', 'eqp no', 'container id'],
  type: ['type', 'size', 'size type', 'size/type', 'container type', 'cntr type', 'iso', 'iso code', 'iso type', 'type code', 'eq type', 'equipment type', 'sz/tp', 'sztp'],
  status: ['status', 'movement', 'move', 'moves', 'event', 'activity', 'move type', 'movement type', 'current status', 'container status', 'state', 'stage'],
  location: ['location', 'depot', 'yard', 'place', 'terminal', 'loc', 'site', 'city', 'port', 'current location', 'depot / location', 'cfs', 'warehouse'],
  date: ['date', 'event date', 'movement date', 'move date', 'status date', 'activity date', 'last move', 'last movement', 'updated', 'date of movement', 'date time', 'datetime', 'gate date'],
  ownership: ['ownership', 'own', 'coc/soc', 'coc soc', 'ownership type', 'owned by'],
  owner: ['owner', 'lessor', 'line', 'carrier', 'shipping line', 'leasing company', 'owner / lessor'],
  booking: ['booking', 'booking no', 'booking number', 'bkg', 'bkg no', 'booking ref'],
  hbl: ['hbl', 'hbl no', 'house bl', 'house bl no', 'bl', 'bl no', 'b/l', 'b/l no', 'bl number'],
  free_days: ['free days', 'free time', 'free', 'freedays', 'detention free days'],
  remarks: ['remarks', 'remark', 'notes', 'note', 'comment', 'comments'],
  condition: ['condition', 'cond'],
};
const FIELD_LABELS = { container_no: 'Container number', type: 'Container type', status: 'Movement / status', location: 'Location', date: 'Date', ownership: 'Ownership', owner: 'Owner / lessor',
  booking: 'Booking no.', hbl: 'HBL no.', free_days: 'Free days', remarks: 'Remarks', condition: 'Condition' };

// ---------------------------------------------------------------- status understanding
const SYN = {
  EMPTY_AVAILABLE: ['empty available', 'available', 'avail', 'empty', 'mty', 'in stock', 'in yard', 'empty in yard', 'ready', 'free', 'empty at depot', 'restocked'],
  ALLOCATED: ['allocated', 'allocation', 'allocate', 'reserved', 'booked', 'empty allocated'],
  RELEASED_SHIPPER: ['released to shipper', 'release to shipper', 'empty release', 'empty released', 'empty pickup', 'empty pick up', 'pickup', 'pick up', 'picked up', 'gate out empty', 'empty gate out', 'out for stuffing', 'stuffing', 'with shipper', 'at shipper', 'at factory'],
  GATED_IN_FULL: ['gate in full', 'gated in full', 'full gate in', 'laden gate in', 'gate in laden', 'received full', 'in port', 'at terminal', 'at port', 'cfs received', 'stuffed', 'laden'],
  ON_BOARD: ['on board', 'onboard', 'loaded on board', 'loaded', 'load', 'sailed', 'shipped', 'departed', 'vessel departed', 'departure', 'in transit', 'transit', 'at sea', 'shipped on board', 'sob'],
  DISCHARGED: ['discharged', 'discharge', 'unloaded', 'arrived', 'arrival', 'landed', 'vessel arrived', 'at pod', 'dischg', 'disch'],
  DELIVERED_FULL: ['delivered', 'delivery', 'full out', 'gate out full', 'gate out laden', 'out for delivery', 'delivered to consignee', 'released to consignee', 'trucked', 'deliverd'],
  EMPTY_RETURNED: ['empty returned', 'empty return', 'returned empty', 'return empty', 'returned', 'return', 'empty gate in', 'gate in empty', 'mty return', 'mty returned', 'empty in', 'destuffed', 'de stuffed', 'unstuffed', 'emptied'],
  DAMAGED: ['damaged', 'damage', 'under repair', 'repair', 'in repair', 'survey', 'dmg'],
  OFF_HIRED: ['off hired', 'off hire', 'offhire', 'offhired', 'returned to lessor', 'return to lessor', 'sold', 'scrapped', 'written off'],
};
const nrm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const AMBIGUOUS_GATE_IN = ['gate in', 'gated in', 'gatein', 'gate-in'];

// -> { status, note } or null.  `current` = the container's present status (helps read words like "gate in" / "released")
function mapStatus(text, current) {
  const t = nrm(text);
  if (!t) return null;
  for (const [k, v] of Object.entries(L.CONTAINER_STATUS)) if (t === nrm(k) || t === nrm(v.label)) return { status: k };
  for (const [k, list] of Object.entries(SYN)) if (list.some((s) => nrm(s) === t)) return contextual(k, t, current);
  if (AMBIGUOUS_GATE_IN.some((s) => nrm(s) === t)) return contextual(null, t, current);
  let best = null;
  for (const [k, list] of Object.entries(SYN)) for (const s of list) {
    const ns = nrm(s);
    if (new RegExp(`(^| )${escRe(ns)}( |$)`).test(t) && (!best || ns.length > best.len)) best = { k, len: ns.length };
  }
  if (best) return contextual(best.k, t, current);
  if (new RegExp('(^| )gate ?in( |$)').test(t)) return contextual(null, t, current);
  return null;
}
function contextual(key, t, current) {
  const c = current || '';
  if (key === null || (key === 'GATED_IN_FULL' && /^gated? ?in$/.test(t))) {           // bare "gate in": full at POL, or empty returning?
    if (['RELEASED_SHIPPER', 'ALLOCATED'].includes(c)) return { status: 'GATED_IN_FULL', note: 'read "gate in" as laden gate-in at the port' };
    if (['DISCHARGED', 'DELIVERED_FULL', 'EMPTY_RETURNED'].includes(c)) return { status: 'EMPTY_RETURNED', note: 'read "gate in" as empty returned' };
    return { status: c ? 'EMPTY_RETURNED' : 'EMPTY_AVAILABLE', note: 'read "gate in" as an empty container arriving at the depot' };
  }
  if (key === 'RELEASED_SHIPPER' && /^(released|release)$/.test(t) && c === 'DISCHARGED') return { status: 'DELIVERED_FULL', note: 'read "released" as released to the consignee' };
  return { status: key };
}

// ---------------------------------------------------------------- container type understanding
const ISO_TYPE = { '22G1': '20GP', '20G1': '20GP', '2200': '20GP', '42G1': '40GP', '40G1': '40GP', '4200': '40GP', '45G1': '40HC', '4500': '40HC', 'L5G1': '45HC', '22R1': '20RF', '25R1': '20RF',
  '42R1': '40RH', '45R1': '40RH', 'L5R1': '40RH', '22U1': '20OT', '42U1': '40OT', '22P1': '20FR', '42P1': '40FR', '22T1': '20TK', '22T5': '20TK' };
function mapType(text, types) {
  const raw = String(text || '').trim().toUpperCase();
  if (!raw) return null;
  const compact = raw.replace(/[^A-Z0-9]/g, '');
  const byCode = (c) => types.find((t) => t.code === c);
  if (byCode(compact)) return { type: byCode(compact) };
  if (ISO_TYPE[compact] && byCode(ISO_TYPE[compact])) return { type: byCode(ISO_TYPE[compact]) };
  const size = /(?:^|[^0-9])(20|40|45)(?![0-9])/.exec(raw.replace(/['"`]|FT|FEET|FOOT/g, ' ')) || /^(20|40|45)/.exec(compact);
  if (!size) return null;
  const sz = size[1];
  const has = (re) => re.test(raw.replace(/[^A-Z]/g, ' '));
  const kind = has(/\b(RF|RH|REEFER|REEF|RE)\b/) ? 'R' : has(/\b(OT|OPEN|OPENTOP)\b/) ? 'OT' : has(/\b(FR|FLAT|FLATRACK)\b/) ? 'FR' : has(/\b(TK|TANK)\b/) ? 'TK' : has(/\b(HC|HQ|HIGH|HIGHCUBE|H)\b/) || /(HC|HQ)$/.test(compact) ? 'HC' : 'GP';
  let code = null, approx = false;
  if (sz === '20') code = { R: '20RF', OT: '20OT', FR: '20FR', TK: '20TK', HC: '20GP', GP: '20GP' }[kind];
  else if (sz === '40') code = { R: byCode('40RH') ? '40RH' : '40RF', OT: '40OT', FR: '40FR', HC: '40HC', GP: '40GP', TK: '40GP' }[kind];
  else code = '45HC';
  if (/^(20|40|45)$/.test(compact)) approx = true;
  const t = code && byCode(code);
  return t ? { type: t, approx } : null;
}
function mapOwnership(text) {
  const t = String(text || '').toUpperCase();
  if (!t.trim()) return null;
  if (/^COC|CARRIER/.test(t)) return 'COC';
  if (/^SOC|SHIPPER/.test(t)) return 'SOC';
  if (/LEAS/.test(t)) return 'LEASED';
  if (/^OWN|COMPANY|HUB/.test(t)) return 'OWN';
  return null;
}

// headerless paste: work out which column is which from what the cells look like
function guessMap(dataRows) {
  const cols = Math.max(...dataRows.map((r) => r.length), 0), map = {};
  const sample = (i) => dataRows.slice(0, 20).map((r) => String(r[i] == null ? '' : r[i]).trim()).filter(Boolean);
  for (let i = 0; i < cols; i++) {
    const s = sample(i); if (!s.length) continue;
    const frac = (fn) => s.filter(fn).length / s.length;
    if (!('container_no' in map) && frac((v) => /^[A-Za-z]{4}[\s-]?\d{6}[\s-]?\d$/.test(v)) > 0.6) map.container_no = i;
    else if (!('date' in map) && frac((v) => !!T.parseDate(v)) > 0.6) map.date = i;
    else if (!('status' in map) && frac((v) => !!mapStatus(v, null)) > 0.6) map.status = i;
    else if (!('type' in map) && frac((v) => !!mapType(v, db.prepare('SELECT * FROM container_types').all())) > 0.6) map.type = i;
    else if (!('location' in map)) map.location = i;
  }
  return map;
}

// ---------------------------------------------------------------- plan
// table = T.structure(...) result; options as documented below; user = the signed-in user (agents are fenced in)
function buildPlan(table, options = {}, user = null) {
  const types = db.prepare('SELECT * FROM container_types').all();
  const agent = S.isAgent(user);
  const opt = {
    create_missing: agent ? false : options.create_missing !== false,
    default_type_id: options.default_type_id ? Number(options.default_type_id) : null,
    default_status: options.default_status || null,
    default_date: options.default_date || null,
    default_location: String(options.default_location || '').trim(),
    default_ownership: options.default_ownership || 'OWN',
    allow_invalid: !!options.allow_invalid,
  };
  if (opt.default_status && !L.CONTAINER_STATUS[opt.default_status]) opt.default_status = null;
  const defType = opt.default_type_id ? types.find((t) => t.id === opt.default_type_id) : null;
  let map = table.map;
  if (!table.hasHeader && !Object.keys(map).length) map = guessMap(table.dataRows);
  const has = (f) => f in map;
  const rows = [], virtual = new Map();
  const myLocs = agent ? S.locationTokens(user) : [];
  const parties = db.prepare('SELECT id, name FROM parties').all();
  const findParty = (nm) => { const n = nrm(nm); return n ? parties.find((p) => nrm(p.name) === n) || parties.find((p) => nrm(p.name).includes(n) && n.length > 3) : null; };
  const findShipment = (bk, hbl) => (bk || hbl) ? db.prepare('SELECT id, agent_id, booking_no FROM shipments WHERE (booking_no=? AND ?<>\'\') OR (hbl_no=? AND ?<>\'\')').get(bk, bk, hbl, hbl) : null;
  const t0 = today();

  if (!has('container_no')) return { rows: [], map, opt, summary: { total: 0 }, problem: 'No column with container numbers was found. Choose which column holds them below.' };

  table.dataRows.forEach((raw, i) => {
    const line = table.rowOffset + i;
    const g = (f) => T.pick(raw, map, f);
    const no0 = g('container_no');
    if (!no0 && raw.every((v) => !String(v).trim())) return;
    const r = { line, container_no: L.normContainerNo(no0), input: no0, action: 'ERROR', level: 'error', messages: [], notes: [] };
    const err = (m) => { r.messages.push(m); r.action = 'ERROR'; r.level = 'error'; return r; };
    const warn = (m) => { r.messages.push(m); if (r.level === 'ok') r.level = 'warn'; };
    rows.push(r);

    if (!/^[A-Z]{4}\d{7}$/.test(r.container_no)) return err(no0 ? `"${no0}" is not a container number (4 letters + 7 digits, e.g. MSKU1234565)` : 'Container number is empty');
    r.level = 'ok';
    if (!L.iso6346Valid(r.container_no)) { if (!opt.allow_invalid) { r.messages.push('Check digit is wrong - probably a typo'); r.level = 'error'; r.action = 'ERROR'; r.check_digit_error = true; return r; } warn('Check digit is wrong (accepted because you allowed it)'); }

    // the date
    const dRaw = g('date');
    let date = opt.default_date || t0;
    if (dRaw) { const p = T.parseDate(dRaw, { defaultYear: Number(t0.slice(0, 4)) }); if (!p) return err(`Date "${dRaw}" is not understood (use e.g. 2026-03-14 or 14/03/2026)`); date = p; }
    if (date > new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10)) warn('Date is in the future');
    r.date = date;

    // where is the container now (database + earlier rows of this same file)
    let cur = virtual.get(r.container_no);
    if (!cur) {
      const c = db.prepare('SELECT c.id, c.status, c.location, c.last_event_date, c.type_id, t.code AS type_code FROM containers c JOIN container_types t ON t.id=c.type_id WHERE c.container_no=?').get(r.container_no);
      cur = c ? { exists: true, id: c.id, status: c.status, location: c.location, last: c.last_event_date, type_id: c.type_id, type_code: c.type_code } : { exists: false };
    } else if (cur.fromFile) warn('This container appears more than once in the file - the rows are applied in order');
    r.exists = cur.exists;
    r.current_status = cur.status || null; r.current_location = cur.location || null;
    if (cur.exists) r.current_status_label = (L.CONTAINER_STATUS[cur.status] || {}).label || cur.status;

    if (agent) {
      if (!cur.exists) return err('Unknown container - ask HUB LINE operations to add it to the inventory first');
      if (!S.canSeeContainer(user, cur.id, cur.location)) return err('This container is not at your locations or on your shipments');
    } else if (!cur.exists && !opt.create_missing) return err('Not in the inventory (adding new containers is switched off)');

    // status
    const sTxt = g('status');
    let status = null;
    if (sTxt) {
      const m = mapStatus(sTxt, cur.status);
      if (!m) return err(`Movement "${sTxt}" is not understood. Use words like Gate in, On board, Discharged, Delivered, Empty return, Available.`);
      status = m.status; if (m.note) r.notes.push(m.note);
    } else if (!cur.exists) status = opt.default_status || 'EMPTY_AVAILABLE';
    r.status = status;

    // location (agents are fenced to their own places)
    let loc = g('location') || opt.default_location;
    if (agent) {
      if (!loc && myLocs.length === 1) loc = user.locations.split(/[\n,;|]+/).map((s) => s.trim()).filter(Boolean)[0];
      if (!loc) return err('Location is required');
      if (!S.locationAllowed(user, loc)) return err(`Location "${loc}" is outside your assigned locations (${user.locations})`);
    }
    r.location = loc || null;
    if (!status) {   // no movement given: this row can only be a change of place
      if (loc && loc !== cur.location) { status = cur.status; r.status = status; r.action = 'LOCATION'; }
      else { r.action = 'NOCHANGE'; r.level = r.level === 'warn' ? 'warn' : 'ok'; r.messages.push('Nothing to change (no movement and same location)'); return r; }
    }
    r.status_label = (L.CONTAINER_STATUS[status] || {}).label || status;

    // the container itself
    const ex = {};
    if (!cur.exists) {
      const tTxt = g('type');
      let tm = tTxt ? mapType(tTxt, types) : null;
      if (tTxt && !tm) return err(`Container type "${tTxt}" is not understood (use e.g. 20GP, 40HC, 40 high cube, 22G1, 45G1)`);
      if (tm && tm.approx) warn(`"${tTxt}" read as ${tm.type.code} - please check`);
      const ty = tm ? tm.type : defType;
      if (!ty) return err('Container type is missing - add a Type column or choose a default type');
      r.type_code = ty.code;
      const own = mapOwnership(g('ownership')) || opt.default_ownership;
      const oTxt = g('owner'); const ow = oTxt ? findParty(oTxt) : null;
      if (oTxt && !ow) warn(`Owner "${oTxt}" is not a known party - left blank`);
      ex.create = { no: r.container_no, type_id: ty.id, ownership: ['COC', 'SOC', 'LEASED', 'OWN'].includes(own) ? own : 'OWN', owner_id: ow ? ow.id : null, condition: /^dam/i.test(g('condition')) ? 'DAMAGED' : 'SOUND' };
      r.action = 'CREATE';
      r.messages.push('New container');
    } else {
      r.type_code = cur.type_code;
      const tTxt = g('type');
      if (tTxt) { const tm = mapType(tTxt, types); if (tm && tm.type.id !== cur.type_id) warn(`File says ${tm.type.code} but the system has ${cur.type_code} - type not changed`); }
      if (r.action !== 'LOCATION') {
        const sameSpot = !loc || String(loc).toLowerCase() === String(cur.location || '').toLowerCase();
        if (status === cur.status && sameSpot && (!cur.last || date >= cur.last)) { r.action = 'NOCHANGE'; r.messages.push('Already in this status and location'); return r; }
        r.action = 'MOVE';
      }
      if (cur.last && date < cur.last) warn(`Older than the latest movement (${cur.last}) - saved in the history only, current status stays`);
      if (L.CONTAINER_STATUS[cur.status] && L.CONTAINER_STATUS[cur.status].group === 'CLOSED' && status !== 'OFF_HIRED') warn('This container had been off-hired - this brings it back into the inventory');
    }

    // booking / HBL link
    const bk = g('booking').toUpperCase(), hb = g('hbl').toUpperCase();
    if (bk || hb) {
      const sh = findShipment(bk, hb);
      if (!sh) warn(`Booking / HBL "${bk || hb}" was not found - movement saved without the link`);
      else if (agent && !S.ownsShipment(user, sh)) warn('That booking is not yours - link ignored');
      else { r.shipment_id = sh.id; r.booking_no = sh.booking_no; }
    }
    const fd = g('free_days');
    let free = null;
    if (fd !== '') { free = parseInt(fd, 10); if (Number.isNaN(free) || free < 0) { warn(`Free days "${fd}" ignored`); free = null; } }
    r.free_days = (L.CONTAINER_STATUS[status] || {}).clock ? free : null;
    r.remarks = g('remarks') || null;
    ex.event = { container_id: cur.id || null, event_type: status, event_date: date, location: r.location || (cur.location || null), shipment_id: r.shipment_id || null, free_days: r.free_days, remarks: r.remarks };
    r._exec = ex;
    virtual.set(r.container_no, { exists: true, id: cur.id, status, location: r.location || cur.location, last: cur.last && cur.last > date ? cur.last : date, type_id: cur.type_id, type_code: r.type_code, fromFile: true });
  });

  const summary = { total: rows.length, create: 0, move: 0, location: 0, nochange: 0, error: 0, warn: 0 };
  for (const r of rows) {
    if (r.action === 'CREATE') summary.create++; else if (r.action === 'MOVE') summary.move++; else if (r.action === 'LOCATION') summary.location++;
    else if (r.action === 'NOCHANGE') summary.nochange++; else summary.error++;
    if (r.level === 'warn') summary.warn++;
  }
  summary.ready = summary.create + summary.move + summary.location;
  return { rows, map, opt, summary };
}

// executes a plan produced by buildPlan(); `helpers` = { addEvent, createContainer } (from routes/ops.js)
function commitPlan(plan, user, helpers) {
  const done = { created: 0, moved: 0, relocated: 0, skipped: 0 };
  db.transaction(() => {
    for (const r of plan.rows) {
      if (!r._exec) { done.skipped++; continue; }
      const { create, event } = r._exec;
      const remarks = event.remarks || (create ? 'Added by import' : 'Updated by import');
      if (create) {
        helpers.createContainer(create.no, { type_id: create.type_id, ownership: create.ownership, owner_id: create.owner_id, condition: create.condition },
          { event_type: event.event_type, event_date: event.event_date, location: event.location, shipment_id: event.shipment_id, free_days: event.free_days, remarks }, user);
        done.created++;
      } else {
        const cid = event.container_id || (db.prepare('SELECT id FROM containers WHERE container_no=?').get(r.container_no) || {}).id;
        if (!cid) { done.skipped++; continue; }
        helpers.addEvent({ ...event, container_id: cid, remarks: r.action === 'LOCATION' && !event.remarks ? 'Location update' : remarks }, user);
        if (r.action === 'LOCATION') done.relocated++; else done.moved++;
      }
    }
  })();
  return done;
}

// what the client stores and sends back (no server internals)
function publicRow(r) {
  const { _exec, ...rest } = r;
  return rest;
}

module.exports = { ALIASES, FIELD_LABELS, mapStatus, mapType, mapOwnership, guessMap, buildPlan, commitPlan, publicRow };
