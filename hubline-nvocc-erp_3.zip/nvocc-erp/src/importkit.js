'use strict';
// One step-by-step import wizard backend, reused for container inventory, vessel schedules and MRG rates:
//   GET  /<x>/template          -> Excel template with the right headings and a notes sheet
//   POST /<x>/import/parse      -> upload an .xlsx/.csv (raw body) or pasted text; returns what was understood + a dry-run preview
//   POST /<x>/import/preview    -> same, after the user corrected the column mapping / options (no re-upload)
//   POST /<x>/import/commit     -> saves everything that passed, in one transaction
const crypto = require('crypto');
const { db, audit } = require('./db');
const A = require('./auth');
const T = require('./tabular');
const { bad, xlsxBuffer, XLSX_MIME } = require('./util');

const store = new Map();          // token -> { user, kind, rows, filename, at }
const TTL = 45 * 60 * 1000;
function put(user, kind, rows, filename) {
  const now = Date.now();
  for (const [k, v] of store) if (now - v.at > TTL) store.delete(k);
  if (store.size > 300) store.delete(store.keys().next().value);
  const token = crypto.randomBytes(16).toString('hex');
  store.set(token, { user: user.id, kind, rows, filename, at: now });
  return token;
}
function get(token, user, kind) {
  const e = store.get(String(token || ''));
  if (!e || e.user !== user.id || e.kind !== kind) bad('This upload has expired. Please upload the file again.', 410);
  e.at = Date.now();
  return e;
}

function inputOf(req) {
  const b = req.body;
  if (Buffer.isBuffer(b) && b.length) return b;
  if (typeof b === 'string' && b.trim()) return b;
  return null;
}

function mount(router, cfg) {
  const base = `/${cfg.path}`;
  const guard = A.need(cfg.module, cfg.kind || 'write');

  router.get(`${base}/template`, guard, async (req, res) => {
    const buf = await xlsxBuffer(await cfg.template(req.user), { company: cfg.company });
    res.setHeader('Content-Type', XLSX_MIME);
    res.setHeader('Content-Disposition', `attachment; filename="${cfg.templateName}"`);
    res.end(buf);
  });

  const respond = (res, entry, token, mapping, options, user) => {
    const table = T.structure(entry.rows, cfg.aliases, mapping);
    const plan = cfg.plan(table, options || {}, user);
    const rows = (plan.rows || []).map((r) => { const { _exec, ...rest } = r; return rest; });
    res.json({
      token, filename: entry.filename, hasHeader: table.hasHeader, headers: table.headers,
      mapping: { ...(plan.map || table.map) }, fields: cfg.fields, sample: table.dataRows.slice(0, 4), totalRows: table.dataRows.length,
      plan: { summary: plan.summary, rows: rows.slice(0, 1500), truncated: rows.length > 1500, problem: plan.problem || null, options: plan.opt || options || {} },
    });
    return plan;
  };

  router.post(`${base}/import/parse`, guard, async (req, res) => {
    const input = inputOf(req);
    if (!input) bad('Choose an Excel or CSV file, or paste some rows.');
    let filename = '';
    try { filename = decodeURIComponent(req.get('X-Filename') || ''); } catch { filename = ''; }
    const rows = await T.readTable(input, filename);
    const token = put(req.user, cfg.path, rows, filename || 'pasted rows');
    respond(res, get(token, req.user, cfg.path), token, null, {}, req.user);
  });
  // lets a route that fetched its own rows (e.g. from a web link) join the same wizard
  const start = (req, res, rows, filename, options) => {
    const token = put(req.user, cfg.path, rows, filename);
    respond(res, get(token, req.user, cfg.path), token, null, options || {}, req.user);
  };

  router.post(`${base}/import/preview`, guard, (req, res) => {
    const e = get(req.body.token, req.user, cfg.path);
    respond(res, e, req.body.token, req.body.mapping, req.body.options, req.user);
  });

  router.post(`${base}/import/commit`, guard, (req, res) => {
    const e = get(req.body.token, req.user, cfg.path);
    const table = T.structure(e.rows, cfg.aliases, req.body.mapping);
    const plan = cfg.plan(table, req.body.options || {}, req.user);
    if (plan.problem) bad(plan.problem);
    if (!plan.summary.ready) bad('There is nothing to save - every row is either unchanged or has an error.');
    const result = cfg.commit(plan, req.user);
    audit(req.user, 'IMPORT', cfg.entity, null, { file: e.filename, ...result });
    store.delete(req.body.token);
    res.json({ ok: true, result, summary: plan.summary });
  });
  return { start };
}

module.exports = { mount };
