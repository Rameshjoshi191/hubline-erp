'use strict';
// Every list / report the user can download or share is described ONCE here as "sheets".
// The same description becomes Excel, PDF and an e-mail attachment, so a new export never needs separate code for each format.
const { db, getSetting, today, round2 } = require('./db');
const A = require('./auth');
const S = require('./scope');
const L = require('./logic');
const BL = require('./bl');
const TR = require('./track');
const SCH = require('./schedules');
const MRG = require('./mrg');
const { MONEY } = require('./util');

const co = () => getSetting('company_name', 'HUB LINE SHIPPING LLC');
const col = (header, key, width, fmt) => ({ header, key, width, ...(fmt ? { fmt } : {}) });
const monthName = (m) => new Date(m + '-01T00:00:00Z').toLocaleString('en-GB', { month: 'short', year: 'numeric', timeZone: 'UTC' });

// ---------------------------------------------------------------- inventory report (the daily report)
function inventorySheets(rep) {
  const title = [`${co()} - Daily container inventory report`, `As at ${rep.date}`];
  const stCols = rep.statuses.map((s) => col(rep.status_labels[s], s, 16));
  const locTypes = [...new Set(rep.rows.map((x) => x.type_code))].sort();
  return [
    { name: 'Summary', title, columns: [col('Type', 'type_code', 10), col('Opening', 'opening', 10), col('In', 'in', 8), col('Out', 'out', 8), col('Closing', 'closing', 10), col('Empty', 'empty', 9), col('Laden', 'laden', 9),
        col('Out of service', 'out_of_service', 12), ...stCols],
      rows: rep.types, totals: Object.fromEntries(Object.entries(rep.totals).filter(([k]) => k !== 'type_code' && k !== 'teu' && k !== 'teu_closing')),
      pdfKeys: ['type_code', 'opening', 'in', 'out', 'closing', 'empty', 'laden', 'out_of_service'] },
    { name: 'By location', title, columns: [col('Location / depot', 'location', 28), col('Total', 'total', 9), col('Empty', 'empty', 9), col('Laden', 'laden', 9), col('Out of service', 'out_of_service', 12),
        ...locTypes.map((t) => col(t, 't_' + t, 8))],
      rows: rep.locations.map((l) => ({ ...l, ...Object.fromEntries(locTypes.map((t) => [`t_${t}`, l.by_type[t] || 0])) })) },
    { name: 'Container list', title, columns: [col('Container no.', 'container_no', 16), col('Type', 'type_code', 8), col('Ownership', 'ownership', 10), col('Owner / lessor', 'owner_name', 20), col('Status', 'status_label', 32),
        col('Location', 'location', 20), col('Since', 'last_date', 12), col('Days in status', 'days_in_status', 10), col('Booking', 'booking_no', 18), col('HBL', 'hbl_no', 18), col('Consol', 'consol_no', 16),
        col('Free until', 'free_until', 12), col('Free days left', 'free_days_left', 10), col('Condition', 'condition', 10)], rows: rep.rows,
      pdfKeys: ['container_no', 'type_code', 'ownership', 'status_label', 'location', 'last_date', 'days_in_status', 'booking_no', 'free_until', 'free_days_left'] },
    { name: 'Movements', title: [...title, `Movements recorded on ${rep.date}`], columns: [col('Container no.', 'container_no', 16), col('Type', 'type_code', 8), col('Movement', 'label', 34), col('Location', 'location', 22),
        col('Booking', 'booking_no', 18), col('HBL', 'hbl_no', 18), col('Consol', 'consol_no', 16), col('Remarks', 'remarks', 30)], rows: rep.movements },
    { name: 'Detention alert', title: [...title, 'Containers past or within 3 days of the end of free time'], columns: [col('Container no.', 'container_no', 16), col('Type', 'type_code', 8), col('Status', 'status_label', 30), col('Location', 'location', 20),
        col('Free time from', 'clock_from', 12), col('Free days', 'free_days', 10), col('Free until', 'free_until', 12), col('Days left (negative = overdue)', 'free_days_left', 16), col('Booking', 'booking_no', 18)], rows: rep.detention },
  ];
}

const listCols = {
  containers: [col('Container no.', 'container_no', 16), col('Type', 'type_code', 8), col('Ownership', 'ownership', 10), col('Owner / lessor', 'owner_name', 20), col('Status', 'status_label', 32), col('Location', 'location', 22),
    col('Since', 'last_date', 12), col('Days', 'days_in_status', 7), col('Booking', 'booking_no', 18), col('HBL', 'hbl_no', 18), col('Free until', 'free_until', 12), col('Days left', 'free_days_left', 9)],
};

// ---------------------------------------------------------------- the registry
// perm: module needed to read; build(params, user) -> { filename, title, subtitle, sheets, landscape? }
const EXPORTS = {
  inventory: { perm: 'reports', async build(p) {
    const date = /^\d{4}-\d{2}-\d{2}$/.test(p.date || '') ? p.date : today();
    const rep = require('./routes/reports').inventoryReport(date);
    return { filename: `Container_Inventory_${date}`, title: 'Daily container inventory', subtitle: `As at ${date}`, sheets: inventorySheets(rep) };
  } },

  containers: { perm: 'containers', async build(p, u) {
    const asOf = /^\d{4}-\d{2}-\d{2}$/.test(p.as_of || '') ? p.as_of : today();
    let rows = S.hideForeignRefs(u, S.filterContainers(u, L.containerSnapshot(asOf, { inventoryOnly: true })));
    if (p.q) { const s = String(p.q).toUpperCase(); rows = rows.filter((x) => x.container_no.includes(s) || (x.location || '').toUpperCase().includes(s) || (x.booking_no || '').toUpperCase().includes(s) || (x.hbl_no || '').toUpperCase().includes(s)); }
    if (p.group) rows = rows.filter((x) => x.group === p.group);
    if (p.status) rows = rows.filter((x) => x.status === p.status);
    if (p.type_id) rows = rows.filter((x) => String(x.type_id) === String(p.type_id));
    if (p.ownership) rows = rows.filter((x) => x.ownership === p.ownership);
    if (p.location) rows = rows.filter((x) => (x.location || '') === p.location);
    if (p.overdue === '1') rows = rows.filter((x) => x.overdue);
    const byLoc = {};
    for (const r of rows) { const k = r.location || '(no location)'; const o = byLoc[k] = byLoc[k] || { location: k, total: 0, empty: 0, laden: 0, out_of_service: 0 }; o.total++; if (r.group === 'EMPTY') o.empty++; else if (r.group === 'LADEN') o.laden++; else o.out_of_service++; }
    const title = [`${co()} - Container inventory`, `As at ${asOf}${S.isAgent(u) ? ' - ' + (u.locations || '') : ''}`];
    return { filename: `Containers_${asOf}`, title: 'Container inventory', subtitle: `As at ${asOf}`, sheets: [
      { name: 'Container list', title, columns: listCols.containers, rows },
      { name: 'By location', title, columns: [col('Location', 'location', 30), col('Total', 'total', 9), col('Empty', 'empty', 9), col('Laden', 'laden', 9), col('Out of service', 'out_of_service', 13)], rows: Object.values(byLoc).sort((a, b) => b.total - a.total) }] };
  } },

  tracking: { perm: 'containers', async build(p, u) {
    const rows = TR.search(u, p.q);
    const title = [`${co()} - Container tracking`, `As at ${today()}`, `Search: ${p.q || ''}`];
    return { filename: `Tracking_${today()}`, title: 'Container tracking', subtitle: `As at ${today()}`, sheets: [{ name: 'Tracking', title, rows: rows.map((r) => ({ ...r, vv: [r.vessel, r.voyage].filter(Boolean).join(' / '), route: [r.pol_name, r.pod_name].filter(Boolean).join(' > ') })),
      columns: [col('Container no.', 'container_no', 16), col('Type', 'type_code', 8), col('Status', 'status_label', 32), col('Location', 'location', 22), col('Since', 'last_date', 12), col('Booking', 'booking_no', 18), col('HBL', 'hbl_no', 18),
        col('MBL', 'mbl_no', 16), col('Vessel / voyage', 'vv', 22), col('Route', 'route', 26), col('ETD', 'etd', 12), col('ETA', 'eta', 12), col('Free until', 'free_until', 12), col('Days left', 'free_days_left', 9)],
      pdfKeys: ['container_no', 'type_code', 'status_label', 'location', 'last_date', 'booking_no', 'vv', 'route', 'eta', 'free_until'] }] };
  } },

  movements: { perm: 'containers', async build(p, u) {
    const from = /^\d{4}-\d{2}-\d{2}$/.test(p.from || '') ? p.from : today(), to = /^\d{4}-\d{2}-\d{2}$/.test(p.to || '') ? p.to : from;
    let rows = db.prepare(`SELECT e.id, e.event_date, e.event_type, e.location, e.remarks, e.free_days, e.shipment_id, c.id AS cid, c.container_no, t.code AS type_code, s.booking_no, s.hbl_no, k.consol_no, us.full_name AS by_user
      FROM container_events e JOIN containers c ON c.id=e.container_id JOIN container_types t ON t.id=c.type_id LEFT JOIN shipments s ON s.id=e.shipment_id LEFT JOIN consols k ON k.id=e.consol_id LEFT JOIN users us ON us.id=e.user_id
      WHERE e.event_date>=? AND e.event_date<=? ORDER BY e.event_date, e.id`).all(from, to);
    if (S.isAgent(u)) { const mine = S.agentContainerIds(u); rows = S.hideForeignRefs(u, rows.filter((r) => mine.has(r.cid) || S.locationAllowed(u, r.location))); }
    if (p.location) rows = rows.filter((r) => String(r.location || '').toLowerCase().includes(String(p.location).toLowerCase()));
    for (const r of rows) r.label = (L.CONTAINER_STATUS[r.event_type] || {}).label || r.event_type;
    const title = [`${co()} - Container movements`, `${from} to ${to}${p.location ? ' - ' + p.location : ''}`];
    return { filename: `Movements_${from}_${to}`, title: 'Container movements', subtitle: `${from} to ${to}`, sheets: [{ name: 'Movements', title, rows,
      columns: [col('Date', 'event_date', 12), col('Container no.', 'container_no', 16), col('Type', 'type_code', 8), col('Movement', 'label', 34), col('Location', 'location', 24), col('Booking', 'booking_no', 18), col('HBL', 'hbl_no', 18),
        col('Free days', 'free_days', 9), col('Remarks', 'remarks', 30), col('Updated by', 'by_user', 20)] }] };
  } },

  bls: { perm: 'bl', async build(p, u) {
    const rows = BL.blRows(u, p);
    const staff = !S.isAgent(u);
    const title = [`${co()} - Bills of lading register`, `As at ${today()}`];
    return { filename: `BL_register_${today()}`, title: 'Bills of lading', subtitle: `As at ${today()}`, sheets: [{ name: 'Bills of lading', title, rows: rows.map((r) => ({ ...r, vv: [r.vessel, r.voyage].filter(Boolean).join(' / ') })),
      columns: [col('B/L no.', 'hbl_no', 18), col('Booking', 'booking_no', 18), col('MBL', 'mbl_no', 16), col('Status', 'status', 11), col('Shipper', 'shipper', 26), col('Consignee', 'consignee', 26), col('Notify', 'notify', 22),
        col('POL', 'pol_name', 16), col('POD', 'pod_name', 16), col('Vessel / voyage', 'vv', 22), col('ETD', 'etd', 12), col('ETA', 'eta', 12), col('Containers', 'container_nos', 30), col('Goods', 'commodity', 26),
        col('Packages', 'packages', 9), col('Weight kg', 'gross_weight', 10), col('CBM', 'cbm', 8), col('Freight', 'freight_terms', 10), ...(staff ? [col('Agent', 'agent_name', 22)] : [])],
      pdfKeys: ['hbl_no', 'booking_no', 'status', 'shipper', 'consignee', 'pol_name', 'pod_name', 'vv', 'etd', 'packages', 'gross_weight'] }] };
  } },

  bl: { perm: 'bl', async build(p, u) {
    const s = BL.blFull(u, Number(p.id));
    if (!s) { const e = new Error('Bill of lading not found'); e.status = 404; throw e; }
    const kv = (a, b) => ({ field: a, value: b == null ? '' : b });
    const party = (name, text) => name || text || '';
    const title = [`${co()} - Bill of lading`, s.hbl_no ? `B/L ${s.hbl_no}` : `Booking ${s.booking_no} (draft)`];
    return { filename: `BL_${s.hbl_no || s.booking_no}`, title: 'Bill of lading', subtitle: s.hbl_no || s.booking_no, landscape: false, hbl: s, sheets: [
      { name: 'Bill of lading', title, columns: [col('Field', 'field', 26), col('Details', 'value', 70)], rows: [
        kv('B/L number', s.hbl_no || '(not issued)'), kv('Booking', s.booking_no), kv('Master BL', s.mbl_no), kv('Status', s.status), kv('Shipper', party(s.shipper_name, s.shipper_text)), kv('Consignee', party(s.consignee_name, s.consignee_text)),
        kv('Notify party', party(s.notify_name, s.notify_text)), kv('Agent', s.agent_name), kv('Place of receipt', s.place_of_receipt), kv('Port of loading', s.pol_name), kv('Port of discharge', s.pod_name), kv('Place of delivery', s.place_of_delivery),
        kv('Vessel / voyage', [s.vessel, s.voyage].filter(Boolean).join(' / ')), kv('ETD', s.etd), kv('ETA', s.eta), kv('Freight', s.freight_terms), kv('Incoterm', s.incoterm), kv('Goods', s.commodity), kv('Marks', s.marks),
        kv('Packages', s.packages != null ? `${s.packages} ${s.package_type || ''}` : ''), kv('Gross weight (kg)', s.gross_weight), kv('Volume (CBM)', s.cbm)] },
      { name: 'Containers', title, columns: [col('Container no.', 'container_no', 18), col('Type', 'type_code', 8), col('Seal', 'seal_no', 14), col('Packages', 'packages', 10), col('Weight kg', 'weight_kg', 11), col('CBM', 'cbm', 8), col('Status', 'status_label', 32)], rows: s.containers }] };
  } },

  schedules: { perm: 'schedules', async build(p) {
    const rows = SCH.list({ ...p, upcoming: p.upcoming === '0' ? '' : (p.upcoming || '1') });
    const title = [`${co()} - Vessel schedules`, `As at ${today()}`];
    return { filename: `Vessel_schedules_${today()}`, title: 'Vessel schedules', subtitle: `As at ${today()}`, sheets: [{ name: 'Vessel schedules', title, rows,
      columns: [col('Carrier', 'carrier_name', 22), col('Service', 'service', 14), col('Vessel', 'vessel', 22), col('Voyage', 'voyage', 10), col('POL', 'pol_name', 20), col('POD', 'pod_name', 20), col('Cut-off', 'cutoff_date', 12),
        col('ETD', 'etd', 12), col('ETA', 'eta', 12), col('Transit days', 'transit_days', 9), col('Remarks', 'remarks', 26)] }] };
  } },

  mrg: { perm: 'mrg', async build(p) {
    const q = p.month ? { month: p.month } : { year: p.year || today().slice(0, 4) };
    const rows = MRG.rows(q);
    const label = p.month ? monthName(p.month) : q.year;
    const title = [`${co()} - Month-wise freight rate, slot cost and margin`, label];
    const sheets = [{ name: 'Rates & margin', title, rows: rows.map((r) => ({ ...r, monthLabel: monthName(r.month) })),
      columns: [col('Month', 'monthLabel', 11), col('Carrier', 'carrier_name', 20), col('POL', 'pol_name', 18), col('POD', 'pod_name', 18), col('Type', 'type_code', 8), col('Ccy', 'currency', 6), col('Freight rate', 'freight_rate', 12, MONEY),
        col('Slot cost', 'slot_cost', 12, MONEY), col('Margin / box', 'margin', 12, MONEY), col('Margin %', 'margin_pct', 9), col('Committed slots', 'committed_slots', 10), col('Actual boxes', 'actual_boxes', 10), col('Actual margin', 'actual_margin', 13, MONEY)],
      pdfKeys: ['monthLabel', 'carrier_name', 'pol_name', 'pod_name', 'type_code', 'currency', 'freight_rate', 'slot_cost', 'margin', 'margin_pct', 'actual_boxes', 'actual_margin'] }];
    if (!p.month) sheets.push({ name: 'Month totals', title, rows: MRG.summary(q.year).map((m) => ({ ...m, monthLabel: monthName(m.month) })),
      columns: [col('Month', 'monthLabel', 12), col('Lanes', 'lanes', 8), col(`Avg freight (${L.baseCurrency()})`, 'avg_freight', 16, MONEY), col(`Avg slot cost (${L.baseCurrency()})`, 'avg_slot', 16, MONEY),
        col(`Avg margin / box (${L.baseCurrency()})`, 'avg_margin', 16, MONEY), col('Boxes shipped', 'boxes', 12), col('TEU', 'teu', 9), col(`Margin total (${L.baseCurrency()})`, 'margin_total', 18, MONEY)] });
    return { filename: `MRG_${p.month || q.year}`, title: 'Freight, slot cost & margin', subtitle: label, sheets };
  } },

  ageing: { perm: 'finance', async build(p) {
    const rep = L.ageingReport({ to: p.to || today(), currency: p.currency || undefined, role: p.role || undefined });
    const title = [`${co()} - Ageing of open balances`, `As at ${rep.to}`, 'Positive = they owe us; negative = we owe them'];
    return { filename: `Ageing_${rep.to}`, title: 'Ageing', subtitle: `As at ${rep.to}`, sheets: [{ name: 'Ageing', title, rows: rep.rows,
      columns: [col('Code', 'party_code', 12), col('Party', 'party_name', 36), col('Ccy', 'currency', 6), col('Not due', 'not_due', 14, MONEY), col('1-30', 'd1_30', 14, MONEY), col('31-60', 'd31_60', 14, MONEY), col('61-90', 'd61_90', 14, MONEY),
        col('90+', 'd90_plus', 14, MONEY), col('Unapplied', 'unapplied', 14, MONEY), col('Net balance', 'total', 16, MONEY)] }] };
  } },
};

function allowed(kind, u) {
  const e = EXPORTS[kind];
  return !!e && A.can(u.role, e.perm, 'read');
}

module.exports = { EXPORTS, allowed, inventorySheets, monthName };
