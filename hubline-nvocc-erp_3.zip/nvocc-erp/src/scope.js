'use strict';
// Data scoping for external agents.
// An agent user sees ONLY (a) shipments nominated to their own agent party and (b) containers that are on those
// shipments or currently sit at one of the locations (depot / CFS / port) assigned to them. Everything else is hidden.
// Staff roles are never restricted.
const { db } = require('./db');
const { HttpError } = require('./util');

const isAgent = (u) => !!u && u.role === 'agent';

// "Colombo CFS; Colombo Port, Hambantota" -> ['colombo cfs', 'colombo port', 'hambantota']
function locationTokens(u) {
  return String((u && u.locations) || '').split(/[\n,;|]+/).map((s) => s.trim().toLowerCase()).filter(Boolean);
}
// a location is "in scope" when it contains one of the agent's location names ("Colombo CFS" is inside "Colombo")
function locationAllowed(u, loc) {
  if (!isAgent(u)) return true;
  const l = String(loc || '').trim().toLowerCase();
  if (!l) return false;
  return locationTokens(u).some((t) => l.includes(t));
}

// SQL fragment limiting a shipments query (alias s) to the agent's own shipments; null for staff
function shipmentSql(u, alias = 's') {
  return isAgent(u) ? `${alias}.agent_id=${Number(u.agent_party_id) || -1}` : null;
}
function ownsShipment(u, s) {
  return !isAgent(u) || (s && Number(s.agent_id) === Number(u.agent_party_id));
}
function assertShipment(u, s) {
  if (!s || !ownsShipment(u, s)) throw new HttpError(404, 'Shipment not found');
  return s;
}

// ids of containers attached to the agent's shipments
function agentContainerIds(u) {
  return new Set(db.prepare(`SELECT sc.container_id FROM shipment_containers sc JOIN shipments s ON s.id=sc.shipment_id WHERE s.agent_id=?`)
    .all(Number(u.agent_party_id) || -1).map((r) => r.container_id));
}
// filters an array of container snapshot rows ({id, location}) down to what the agent may see
function filterContainers(u, rows) {
  if (!isAgent(u)) return rows;
  const mine = agentContainerIds(u);
  return rows.filter((c) => mine.has(c.id) || locationAllowed(u, c.location));
}
// an agent sees a container's location and status, but never another agent's booking / BL numbers
function hideForeignRefs(u, rows) {
  if (!isAgent(u)) return rows;
  const mine = new Set(db.prepare('SELECT id FROM shipments WHERE agent_id=?').all(Number(u.agent_party_id) || -1).map((r) => r.id));
  return rows.map((x) => (x.shipment_id == null || mine.has(x.shipment_id) ? x : { ...x, shipment_id: null, booking_no: null, hbl_no: null, consol_id: null, consol_no: null, mbl_no: null }));
}
function canSeeContainer(u, containerId, location) {
  if (!isAgent(u)) return true;
  if (locationAllowed(u, location)) return true;
  return agentContainerIds(u).has(containerId);
}

module.exports = { isAgent, locationTokens, locationAllowed, shipmentSql, ownsShipment, assertShipment, agentContainerIds, filterContainers, hideForeignRefs, canSeeContainer };
