'use strict';
const ExcelJS = require('exceljs');
const { db, audit } = require('./db');
const { need } = require('./auth');

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (msg, status = 400) => { throw new HttpError(status, msg); };

const isBlank = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');

// Coerce a value according to a field type
function coerce(v, type) {
  if (isBlank(v)) return null;
  switch (type) {
    case 'int': { const n = parseInt(v, 10); if (Number.isNaN(n)) bad('Invalid whole number: ' + v); return n; }
    case 'real': { const n = Number(v); if (Number.isNaN(n)) bad('Invalid number: ' + v); return n; }
    case 'bool': return (v === true || v === 1 || v === '1' || v === 'true' || v === 'on') ? 1 : 0;
    case 'date': if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v))) bad('Invalid date: ' + v); return String(v);
    case 'upper': return String(v).trim().toUpperCase();
    default: return String(v).trim();
  }
}

// Build an object of column values from a request body using a field spec
// fields: [{ name, type, required, label, def }]
function extract(body, fields, { partial = false } = {}) {
  const out = {};
  for (const f of fields) {
    if (partial && !(f.name in body)) continue;
    let v = coerce(body[f.name], f.type || 'text');
    if (v === null && f.def !== undefined && !partial) v = f.def;
    if (v === null && f.required) bad(`${f.label || f.name} is required.`);
    if (v === null && f.notNull) v = f.def !== undefined ? f.def : (f.type === 'int' || f.type === 'real' || f.type === 'bool' ? 0 : '');
    out[f.name] = v;
  }
  return out;
}

function insertRow(table, values) {
  const cols = Object.keys(values);
  const r = db.prepare(`INSERT INTO ${table}(${cols.join(',')}) VALUES(${cols.map((c) => '@' + c).join(',')})`).run(values);
  return r.lastInsertRowid;
}
function updateRow(table, id, values) {
  const cols = Object.keys(values);
  if (!cols.length) return;
  db.prepare(`UPDATE ${table} SET ${cols.map((c) => `${c}=@${c}`).join(',')} WHERE id=@__id`).run({ ...values, __id: id });
}

// Generic CRUD router factory for simple master tables
function crud(router, { path, table, module, fields, search = [], order = 'id', entity, extraWhere, before }) {
  const ent = entity || table;
  router.get(`/${path}`, need(module, 'read'), (req, res) => {
    const where = [], params = {};
    if (req.query.q && search.length) { where.push('(' + search.map((s) => `${s} LIKE @q`).join(' OR ') + ')'); params.q = `%${req.query.q}%`; }
    if (req.query.active === '1') where.push('active=1');
    if (extraWhere) where.push(extraWhere);
    res.json(db.prepare(`SELECT * FROM ${table} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${order}`).all(params));
  });
  router.get(`/${path}/:id`, need(module, 'read'), (req, res) => {
    const r = db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id);
    if (!r) bad('Not found', 404);
    res.json(r);
  });
  router.post(`/${path}`, need(module, 'write'), (req, res) => {
    const v = extract(req.body, fields);
    if (before) before(v, null, req);
    const id = insertRow(table, v);
    audit(req.user, 'CREATE', ent, id, v);
    res.json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(id));
  });
  router.put(`/${path}/:id`, need(module, 'write'), (req, res) => {
    const cur = db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id);
    if (!cur) bad('Not found', 404);
    const v = extract(req.body, fields, { partial: true });
    if (before) before(v, cur, req);
    updateRow(table, cur.id, v);
    audit(req.user, 'UPDATE', ent, cur.id, diff(cur, v));
    res.json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(cur.id));
  });
  router.delete(`/${path}/:id`, need(module, 'write'), (req, res) => {
    const cur = db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id);
    if (!cur) bad('Not found', 404);
    try { db.prepare(`DELETE FROM ${table} WHERE id=?`).run(cur.id); }
    catch (e) {
      if (String(e.message).includes('FOREIGN KEY')) bad('This record is used elsewhere and cannot be deleted. Mark it inactive instead.', 409);
      throw e;
    }
    audit(req.user, 'DELETE', ent, cur.id, cur);
    res.json({ ok: true });
  });
}

function diff(before, after) {
  const d = {};
  for (const k of Object.keys(after)) if (String(before[k] ?? '') !== String(after[k] ?? '')) d[k] = { from: before[k], to: after[k] };
  return d;
}

// ---------------------------------------------------------------- Excel export
// sheet: { name, title: [strings], columns: [{header,key,width,fmt}], rows: [objects], totals: {key: value} }
async function xlsxBuffer(sheets, meta = {}) {
  const wb = new ExcelJS.Workbook();
  wb.creator = meta.company || 'NVOCC ERP';
  wb.created = new Date();
  for (const sh of sheets) {
    const ws = wb.addWorksheet(sh.name.slice(0, 31));
    let r = 1;
    (sh.title || []).forEach((t, i) => {
      ws.getCell(r, 1).value = t;
      ws.getCell(r, 1).font = { bold: true, size: i === 0 ? 14 : 11 };
      r++;
    });
    if (sh.title && sh.title.length) r++;
    const headerRow = r;
    sh.columns.forEach((c, i) => {
      const cell = ws.getCell(r, i + 1);
      cell.value = c.header;
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F3A5F' } };
      cell.alignment = { vertical: 'middle', wrapText: true };
      ws.getColumn(i + 1).width = c.width || 14;
    });
    r++;
    for (const row of sh.rows) {
      sh.columns.forEach((c, i) => {
        const cell = ws.getCell(r, i + 1);
        cell.value = row[c.key] === undefined ? null : row[c.key];
        if (c.fmt) cell.numFmt = c.fmt;
      });
      r++;
    }
    if (sh.totals) {
      sh.columns.forEach((c, i) => {
        const cell = ws.getCell(r, i + 1);
        if (i === 0 && !(c.key in sh.totals)) cell.value = 'Total';
        if (c.key in sh.totals) { cell.value = sh.totals[c.key]; if (c.fmt) cell.numFmt = c.fmt; }
        cell.font = { bold: true };
        cell.border = { top: { style: 'thin' } };
      });
    }
    ws.views = [{ state: 'frozen', ySplit: headerRow }];
    if (sh.rows.length) ws.autoFilter = { from: { row: headerRow, column: 1 }, to: { row: headerRow, column: sh.columns.length } };
  }
  return Buffer.from(await wb.xlsx.writeBuffer());
}
async function sendXlsx(res, filename, sheets, meta = {}) {
  const buf = await xlsxBuffer(sheets, meta);
  res.setHeader('Content-Type', XLSX_MIME);
  res.setHeader('Content-Disposition', `attachment; filename="${filename.replace(/[^\w.\-]+/g, '_')}"`);
  res.setHeader('Content-Length', buf.length);
  res.end(buf);
}

const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const MONEY = '#,##0.00;[Red]-#,##0.00';

module.exports = { HttpError, bad, isBlank, coerce, extract, insertRow, updateRow, crud, diff, sendXlsx, xlsxBuffer, XLSX_MIME, MONEY };
