'use strict';
// Reading spreadsheets / CSV / pasted text into a plain table, plus the "smart" helpers used by every import wizard:
// header detection, column-name matching, tolerant date parsing.
const ExcelJS = require('exceljs');
const { bad } = require('./util');

const norm = (s) => String(s == null ? '' : s).toLowerCase().replace(/[^a-z0-9]+/g, '');

// ---------------------------------------------------------------- delimited text (CSV / TSV / pasted from Excel)
function parseDelimited(text) {
  text = String(text || '').replace(/^﻿/, '');
  const firstLines = text.split(/\r?\n/).slice(0, 5).join('\n');
  const count = (ch) => (firstLines.match(new RegExp(ch === '\t' ? '\\t' : '\\' + ch, 'g')) || []).length;
  const delim = [['\t', count('\t')], [';', count(';')], [',', count(',')], ['|', count('|')]].sort((a, b) => b[1] - a[1])[0];
  const d = delim[1] ? delim[0] : ',';
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c;
    } else if (c === '"' && cur === '') q = true;
    else if (c === d) { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; rows.push(row); row = []; }
    else cur += c;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  return rows.map((r) => r.map((v) => v.trim()));
}

const cellText = (v) => {
  if (v == null) return '';
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === 'object') {
    if (v.richText) return v.richText.map((t) => t.text).join('');
    if (v.text !== undefined) return String(v.text);
    if (v.result !== undefined) return cellText(v.result);
    if (v.hyperlink) return String(v.hyperlink);
    return '';
  }
  return String(v).trim();
};

// ---------------------------------------------------------------- xlsx
async function parseXlsx(buffer) {
  const wb = new ExcelJS.Workbook();
  try { await wb.xlsx.load(buffer); } catch (e) { bad('That file could not be read as an Excel workbook (.xlsx). Save it as .xlsx or .csv and try again.'); }
  let best = null;
  for (const ws of wb.worksheets) {
    const rows = [];
    ws.eachRow({ includeEmpty: false }, (row) => {
      const vals = [];
      for (let c = 1; c <= row.cellCount; c++) vals.push(cellText(row.getCell(c).value));
      rows.push(vals);
    });
    // the first sheet that actually holds data (a header + at least one row) is the one to read; notes sheets come after it
    if (!best || (best.rows.length < 2 && rows.length > best.rows.length)) best = { name: ws.name, rows };
  }
  if (!best || !best.rows.length) bad('The workbook is empty.');
  return best;
}

// Entry point: buffer (xlsx / csv bytes) or text, plus optional filename to help tell them apart
async function readTable(input, filename = '') {
  let rows;
  if (Buffer.isBuffer(input)) {
    const isZip = input.length > 4 && input[0] === 0x50 && input[1] === 0x4b;   // "PK" - xlsx is a zip
    if (isZip || /\.xlsx$/i.test(filename)) rows = (await parseXlsx(input)).rows;
    else if (/\.xls$/i.test(filename) && !isZip) bad('Old .xls files are not supported. Open it in Excel and save as .xlsx (or .csv).');
    else rows = parseDelimited(input.toString('utf8'));
  } else rows = parseDelimited(input);
  rows = rows.filter((r) => r.some((v) => String(v).trim() !== ''));
  if (!rows.length) bad('No data found. Check that the file is not empty.');
  if (rows.length > 5001) bad('That file has more than 5,000 rows. Please split it into smaller files.');
  return rows;
}

// ---------------------------------------------------------------- header detection & column mapping
// aliases: { field: ['header', 'other header', ...] }  (compared after norm())
function detectHeader(rows, aliases) {
  const flat = {};
  for (const [f, list] of Object.entries(aliases)) for (const a of list) flat[norm(a)] = f;
  let best = { idx: -1, score: 0 };
  for (let i = 0; i < Math.min(rows.length, 15); i++) {
    const seen = new Set();
    for (const cell of rows[i]) { const f = flat[norm(cell)]; if (f) seen.add(f); }
    if (seen.size > best.score) best = { idx: i, score: seen.size };
  }
  if (best.score === 0) return null;
  return best.idx;
}
// returns { field: columnIndex } from the header row
function autoMap(headerRow, aliases) {
  const map = {};
  const flat = {};
  for (const [f, list] of Object.entries(aliases)) for (const a of list) if (!(norm(a) in flat)) flat[norm(a)] = f;
  headerRow.forEach((h, i) => { const f = flat[norm(h)]; if (f && !(f in map)) map[f] = i; });
  // second pass: headers with extra words ("Depot status", "Date of gate in") - match whole words of an alias inside the header
  const words = (s) => String(s == null ? '' : s).toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  const has = (hw, aw) => { for (let i = 0; i + aw.length <= hw.length; i++) if (aw.every((w, j) => hw[i + j] === w)) return true; return false; };
  const used = new Set(Object.values(map));
  headerRow.forEach((h, i) => {
    if (used.has(i)) return;
    const hw = words(h); if (hw.length < 2) return;
    let best = null;
    for (const [f, list] of Object.entries(aliases)) {
      if (f in map) continue;
      for (const a of list) { const aw = words(a); if (aw.join('').length >= 3 && has(hw, aw) && (!best || aw.join('').length > best.len)) best = { f, len: aw.join('').length }; }
    }
    if (best) { map[best.f] = i; used.add(i); }
  });
  return map;
}
// Builds a ready-to-use table: { headers, dataRows, map, headerIdx, hasHeader }
function structure(rows, aliases, override) {
  const hIdx = detectHeader(rows, aliases);
  const headers = hIdx == null ? rows[0].map((_, i) => `Column ${i + 1}`) : rows[hIdx];
  const dataRows = rows.slice(hIdx == null ? 0 : hIdx + 1);
  const map = hIdx == null ? {} : autoMap(headers, aliases);
  if (override) for (const [f, idx] of Object.entries(override)) { if (idx === '' || idx == null || idx === -1) delete map[f]; else map[f] = Number(idx); }
  return { headers, dataRows, map, headerIdx: hIdx, hasHeader: hIdx != null, rowOffset: hIdx == null ? 1 : hIdx + 2 };
}
const pick = (row, map, field) => (field in map ? String(row[map[field]] == null ? '' : row[map[field]]).trim() : '');

// ---------------------------------------------------------------- dates
const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12,
  january: 1, february: 2, march: 3, april: 4, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
const pad = (n) => String(n).padStart(2, '0');
function validYMD(y, m, d) {
  if (y < 1990 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) return null;
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCMonth() !== m - 1) return null;
  return `${y}-${pad(m)}-${pad(d)}`;
}
// Accepts 2026-03-14, 14/03/2026, 14-Mar-2026, 14 March 2026, Mar 14 2026, 14.03.26, Excel serial numbers (45000)
// Day-first is assumed for numeric dates (UAE / India / most of the world). Returns YYYY-MM-DD or null.
function parseDate(v, { defaultYear } = {}) {
  if (v == null) return null;
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  let s = String(v).trim();
  if (!s) return null;
  s = s.replace(/^[A-Za-z]{3,9},?\s+(?=\d)/, '');   // "Mon 14 Mar"
  s = s.replace(/\s+\d{1,2}:\d{2}(:\d{2})?(\s*[ap]m)?$/i, '').replace(/T\d{2}:\d{2}.*$/, '');
  let m;
  if ((m = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(s))) return validYMD(+m[1], +m[2], +m[3]);
  if ((m = /^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/.exec(s))) { const y = m[3].length === 2 ? 2000 + +m[3] : +m[3]; return validYMD(y, +m[2], +m[1]); }
  if ((m = /^(\d{1,2})[\s\-/.]*([A-Za-z]{3,9})[\s\-/.,]*(\d{2,4})?$/.exec(s)) && MONTHS[m[2].toLowerCase()]) {
    const y = m[3] ? (m[3].length === 2 ? 2000 + +m[3] : +m[3]) : defaultYear;
    return y ? validYMD(y, MONTHS[m[2].toLowerCase()], +m[1]) : null;
  }
  if ((m = /^([A-Za-z]{3,9})[\s\-/.]*(\d{1,2})(?:st|nd|rd|th)?[\s,\-/.]*(\d{2,4})?$/.exec(s)) && MONTHS[m[1].toLowerCase()]) {
    const y = m[3] ? (m[3].length === 2 ? 2000 + +m[3] : +m[3]) : defaultYear;
    return y ? validYMD(y, MONTHS[m[1].toLowerCase()], +m[2]) : null;
  }
  if (/^\d{5}(\.\d+)?$/.test(s)) { const n = Math.floor(Number(s)); if (n > 30000 && n < 80000) return new Date(Date.UTC(1899, 11, 30) + n * 86400000).toISOString().slice(0, 10); }
  return null;
}

module.exports = { norm, parseDelimited, readTable, detectHeader, autoMap, structure, pick, parseDate };
