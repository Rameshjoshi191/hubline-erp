'use strict';
const { db, round2, getSetting, today, addDays, daysBetween } = require('./db');

// ------------------------------------------------------------------ currency
const baseCurrency = () => getSetting('base_currency', 'AED');

// rate = units of BASE currency per 1 unit of `currency`
function fxRate(currency, date) {
  const base = baseCurrency();
  if (!currency || currency === base) return 1;
  const r = db.prepare('SELECT rate FROM exchange_rates WHERE currency=? AND effective_date<=? ORDER BY effective_date DESC LIMIT 1')
    .get(currency, date || today());
  if (r) return r.rate;
  const any = db.prepare('SELECT rate FROM exchange_rates WHERE currency=? ORDER BY effective_date ASC LIMIT 1').get(currency);
  return any ? any.rate : null;
}
function convert(amount, from, to, date) {
  if (from === to) return amount;
  const a = fxRate(from, date), b = fxRate(to, date);
  if (!a || !b) throw new Error(`No exchange rate available for ${!a ? from : to}. Add it under Setup > Exchange rates.`);
  return amount * a / b;
}

// ------------------------------------------------------------------ containers
const CONTAINER_STATUS = {
  EMPTY_AVAILABLE: { label: 'Empty - available', group: 'EMPTY' },
  ALLOCATED:       { label: 'Empty - allocated to booking', group: 'EMPTY' },
  RELEASED_SHIPPER:{ label: 'Released to shipper for stuffing', group: 'EMPTY' },
  GATED_IN_FULL:   { label: 'Laden - gated in at POL', group: 'LADEN' },
  ON_BOARD:        { label: 'Laden - on board / in transit', group: 'LADEN' },
  DISCHARGED:      { label: 'Laden - discharged at POD', group: 'LADEN', clock: true },
  DELIVERED_FULL:  { label: 'Laden - delivered to consignee', group: 'LADEN', clock: true },
  EMPTY_RETURNED:  { label: 'Empty - returned to depot/line', group: 'EMPTY' },
  DAMAGED:         { label: 'Damaged / under repair', group: 'OUT_OF_SERVICE' },
  OFF_HIRED:       { label: 'Off-hired / returned to owner', group: 'CLOSED' },
};
const CLOCK_RESET = ['EMPTY_RETURNED', 'EMPTY_AVAILABLE', 'OFF_HIRED'];

// ISO 6346 check digit: 4 letters (owner code + category) + 6 digits + 1 check digit
function iso6346CheckDigit(first10) {
  const letterVal = {};
  let v = 10;
  for (const ch of 'ABCDEFGHIJKLMNOPQRSTUVWXYZ') { if (v % 11 === 0) v++; letterVal[ch] = v++; }
  let sum = 0;
  for (let i = 0; i < 10; i++) {
    const c = first10[i];
    const val = /\d/.test(c) ? Number(c) : letterVal[c];
    sum += val * Math.pow(2, i);
  }
  const check = sum % 11;
  return check === 10 ? 0 : check;
}
function iso6346Valid(no) {
  if (!/^[A-Z]{3}[UJZ]\d{7}$/.test(no)) return false;
  return iso6346CheckDigit(no.slice(0, 10)) === Number(no[10]);
}
const normContainerNo = (s) => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

// Cache columns on containers table from the latest event
function refreshContainer(id) {
  const e = db.prepare('SELECT * FROM container_events WHERE container_id=? ORDER BY event_date DESC, id DESC LIMIT 1').get(id);
  if (!e) return;
  const st = CONTAINER_STATUS[e.event_type];
  const clock = clockFor(id, today());
  db.prepare('UPDATE containers SET status=?, location=?, last_event_date=?, consol_id=?, free_days=?, free_days_from=? WHERE id=?')
    .run(e.event_type, e.location, e.event_date, st && st.group === 'CLOSED' ? null : e.consol_id, clock ? clock.days : null, clock ? clock.from : null, id);
}

function clockFor(containerId, asOf) {
  return db.prepare(`SELECT f.event_date AS "from", f.free_days AS days FROM container_events f
    WHERE f.container_id=? AND f.event_date<=? AND f.free_days IS NOT NULL
      AND f.id > COALESCE((SELECT MAX(r.id) FROM container_events r WHERE r.container_id=f.container_id AND r.event_date<=?
                            AND r.event_type IN ('EMPTY_RETURNED','EMPTY_AVAILABLE','OFF_HIRED')),0)
    ORDER BY f.event_date DESC, f.id DESC LIMIT 1`).get(containerId, asOf, asOf);
}

// Inventory as at a date, reconstructed from movement events.
function containerSnapshot(asOf, filters = {}) {
  const rows = db.prepare(`
    SELECT c.id, c.container_no, c.type_id, t.code AS type_code, t.size_ft, t.teu, c.ownership, c.owner_id, o.name AS owner_name,
           c.condition, c.seal_no, c.remarks, c.active,
           e.event_type AS status, e.location, e.event_date AS last_date, e.shipment_id, e.consol_id,
           s.booking_no, s.hbl_no, k.consol_no, k.mbl_no
    FROM containers c
    JOIN container_types t ON t.id=c.type_id
    LEFT JOIN parties o ON o.id=c.owner_id
    JOIN container_events e ON e.id = (SELECT x.id FROM container_events x WHERE x.container_id=c.id AND x.event_date<=? ORDER BY x.event_date DESC, x.id DESC LIMIT 1)
    LEFT JOIN shipments s ON s.id=e.shipment_id
    LEFT JOIN consols k ON k.id=e.consol_id
    WHERE c.active=1
    ORDER BY c.container_no`).all(asOf);
  const out = [];
  for (const r of rows) {
    const st = CONTAINER_STATUS[r.status] || { label: r.status, group: 'EMPTY' };
    r.status_label = st.label; r.group = st.group;
    r.days_in_status = daysBetween(r.last_date, asOf);
    r.clock_from = null; r.free_days = null; r.free_days_left = null; r.free_until = null; r.overdue = false;
    if (st.clock) {
      const c = clockFor(r.id, asOf);
      if (c) {
        r.clock_from = c.from; r.free_days = c.days;
        r.free_until = addDays(c.from, c.days);
        r.free_days_left = daysBetween(asOf, r.free_until);
        r.overdue = r.free_days_left < 0;
      }
    }
    if (filters.inventoryOnly && st.group === 'CLOSED') continue;
    out.push(r);
  }
  return out;
}

// ------------------------------------------------------------------ finance
const DOC_SIGN = { INV: 1, DN: 1, CN: -1, BILL: -1, COMM: -1 }; // +1 = debit (party owes us)
const DOC_LABEL = { INV: 'Invoice', DN: 'Debit note', CN: 'Credit note', BILL: 'Vendor bill', COMM: 'Agency commission' };

function computeLines(lines) {
  let subtotal = 0, vat = 0;
  const out = lines.map((l) => {
    const qty = Number(l.qty) || 0, rate = Number(l.rate) || 0;
    const amount = round2(qty * rate);
    const vr = Number(l.vat_rate) || 0;
    const va = round2(amount * vr / 100);
    subtotal += amount; vat += va;
    return { ...l, qty, rate, amount, vat_rate: vr, vat_amount: va };
  });
  return { lines: out, subtotal: round2(subtotal), vat_amount: round2(vat), total: round2(subtotal + vat) };
}

function outstandingSql(asOfParam) {
  const cond = asOfParam ? `AND a.alloc_date<=${asOfParam}` : '';
  return `(d.total
    - COALESCE((SELECT SUM(a.amount) FROM allocations a WHERE a.to_doc_id=d.id ${cond}),0)
    - COALESCE((SELECT SUM(a.amount) FROM allocations a WHERE a.from_type='DOC' AND a.from_id=d.id ${cond}),0))`;
}

function docOutstanding(docId) {
  const r = db.prepare(`SELECT ${outstandingSql()} AS o FROM documents d WHERE d.id=?`).get(docId);
  return r ? round2(r.o) : 0;
}
function paymentUnallocated(payId) {
  const p = db.prepare('SELECT amount FROM payments WHERE id=?').get(payId);
  const a = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM allocations WHERE from_type='PAYMENT' AND from_id=?").get(payId);
  return p ? round2(p.amount - a.s) : 0;
}

// All open items (documents with balance + unallocated payments) as at `to`
function openItems({ to, party_id, currency }) {
  to = to || today();
  const items = [];
  const docs = db.prepare(`SELECT d.id, d.doc_no, d.doc_type, d.party_id, p.name AS party_name, p.code AS party_code, d.doc_date, d.due_date, d.currency,
      d.total, ${outstandingSql('@to')} AS outstanding, d.party_ref, d.narration, s.booking_no, s.hbl_no
    FROM documents d JOIN parties p ON p.id=d.party_id LEFT JOIN shipments s ON s.id=d.shipment_id
    WHERE d.status='POSTED' AND d.doc_date<=@to ${party_id ? 'AND d.party_id=@party' : ''} ${currency ? 'AND d.currency=@cur' : ''}`)
    .all({ to, party: party_id, cur: currency });
  for (const d of docs) {
    const out = round2(d.outstanding);
    if (Math.abs(out) < 0.005) continue;
    items.push({ kind: 'DOC', id: d.id, party_id: d.party_id, party_name: d.party_name, party_code: d.party_code, currency: d.currency,
      ref: d.doc_no, type: d.doc_type, date: d.doc_date, due_date: d.due_date || d.doc_date, original: d.total,
      outstanding: out, signed: out * DOC_SIGN[d.doc_type], shipment: d.hbl_no || d.booking_no || '', description: d.narration || '' });
  }
  const pays = db.prepare(`SELECT p.id, p.pay_no, p.direction, p.party_id, pt.name AS party_name, pt.code AS party_code, p.pay_date, p.currency, p.amount, p.method, p.reference,
      p.amount - COALESCE((SELECT SUM(a.amount) FROM allocations a WHERE a.from_type='PAYMENT' AND a.from_id=p.id AND a.alloc_date<=@to),0) AS unalloc
    FROM payments p JOIN parties pt ON pt.id=p.party_id
    WHERE p.status='POSTED' AND p.pay_date<=@to ${party_id ? 'AND p.party_id=@party' : ''} ${currency ? 'AND p.currency=@cur' : ''}`)
    .all({ to, party: party_id, cur: currency });
  for (const p of pays) {
    const u = round2(p.unalloc);
    if (Math.abs(u) < 0.005) continue;
    items.push({ kind: 'PAY', id: p.id, party_id: p.party_id, party_name: p.party_name, party_code: p.party_code, currency: p.currency,
      ref: p.pay_no, type: p.direction, date: p.pay_date, due_date: null, original: p.amount, outstanding: u,
      signed: p.direction === 'RECEIPT' ? -u : u, shipment: '', description: [p.method, p.reference].filter(Boolean).join(' ') + ' (unapplied)' });
  }
  return items;
}

const AGE_BUCKETS = ['not_due', 'd1_30', 'd31_60', 'd61_90', 'd90_plus', 'unapplied'];
function bucketOf(item, to) {
  if (item.kind === 'PAY') return 'unapplied';
  const late = daysBetween(item.due_date, to);
  if (late <= 0) return 'not_due';
  if (late <= 30) return 'd1_30';
  if (late <= 60) return 'd31_60';
  if (late <= 90) return 'd61_90';
  return 'd90_plus';
}
function emptyAgeing() { const o = {}; for (const b of AGE_BUCKETS) o[b] = 0; o.total = 0; return o; }

// Statement of account for one party
function buildSoa({ party_id, from, to, mode = 'ledger', currency }) {
  to = to || today();
  from = from || addDays(to, -90);
  const party = db.prepare('SELECT * FROM parties WHERE id=?').get(party_id);
  if (!party) throw new Error('Party not found');
  const byCur = {};
  const cur = (c) => (byCur[c] = byCur[c] || { currency: c, opening: 0, rows: [], total_debit: 0, total_credit: 0, closing: 0, ageing: emptyAgeing() });

  if (mode === 'ledger') {
    const entries = [];
    const docs = db.prepare(`SELECT d.*, s.booking_no, s.hbl_no FROM documents d LEFT JOIN shipments s ON s.id=d.shipment_id
      WHERE d.party_id=? AND d.status='POSTED' AND d.doc_date<=? ${currency ? 'AND d.currency=@c' : ''}`.replace('@c', '?'))
      .all(...[party_id, to].concat(currency ? [currency] : []));
    for (const d of docs) {
      const sign = DOC_SIGN[d.doc_type];
      entries.push({ date: d.doc_date, order: 1, id: d.id, kind: 'DOC', ref: d.doc_no, type: d.doc_type, currency: d.currency, due_date: d.due_date,
        shipment: d.hbl_no || d.booking_no || '', description: d.narration || d.party_ref || '',
        debit: sign > 0 ? d.total : 0, credit: sign < 0 ? d.total : 0 });
    }
    const pays = db.prepare(`SELECT * FROM payments WHERE party_id=? AND status='POSTED' AND pay_date<=? ${currency ? 'AND currency=?' : ''}`)
      .all(...[party_id, to].concat(currency ? [currency] : []));
    for (const p of pays) {
      entries.push({ date: p.pay_date, order: 2, id: p.id, kind: 'PAY', ref: p.pay_no, type: p.direction, currency: p.currency, due_date: null, shipment: '',
        description: [p.method, p.reference, p.bank].filter(Boolean).join(' / '),
        debit: p.direction === 'PAYMENT' ? p.amount : 0, credit: p.direction === 'RECEIPT' ? p.amount : 0 });
    }
    entries.sort((a, b) => a.date.localeCompare(b.date) || a.order - b.order || a.id - b.id);
    for (const e of entries) {
      const c = cur(e.currency);
      if (e.date < from) { c.opening = round2(c.opening + e.debit - e.credit); continue; }
      c.total_debit = round2(c.total_debit + e.debit);
      c.total_credit = round2(c.total_credit + e.credit);
      c.rows.push(e);
    }
    for (const c of Object.values(byCur)) {
      let bal = c.opening;
      for (const r of c.rows) { bal = round2(bal + r.debit - r.credit); r.balance = bal; }
      c.closing = bal;
    }
  }

  // open items (used for open-item statements, and ageing in both modes)
  const items = openItems({ to, party_id, currency });
  for (const it of items) {
    const c = cur(it.currency);
    const b = bucketOf(it, to);
    c.ageing[b] = round2(c.ageing[b] + it.signed);
    c.ageing.total = round2(c.ageing.total + it.signed);
    if (mode === 'open') {
      c.rows.push({ ...it, debit: it.signed > 0 ? it.signed : 0, credit: it.signed < 0 ? -it.signed : 0, bucket: b });
    }
  }
  if (mode === 'open') {
    for (const c of Object.values(byCur)) {
      c.rows.sort((a, b) => a.date.localeCompare(b.date));
      let bal = 0;
      for (const r of c.rows) { bal = round2(bal + r.debit - r.credit); r.balance = bal; c.total_debit = round2(c.total_debit + r.debit); c.total_credit = round2(c.total_credit + r.credit); }
      c.closing = bal;
    }
  }
  const currencies = Object.values(byCur).filter((c) => c.rows.length || Math.abs(c.opening) > 0.004 || Math.abs(c.closing) > 0.004)
    .sort((a, b) => a.currency.localeCompare(b.currency));
  return { party, from, to, mode, currencies, generated_at: new Date().toISOString() };
}

function ageingReport({ to, currency, role }) {
  to = to || today();
  const items = openItems({ to, currency });
  const map = {};
  for (const it of items) {
    const k = `${it.party_id}|${it.currency}`;
    if (!map[k]) map[k] = { party_id: it.party_id, party_name: it.party_name, party_code: it.party_code, currency: it.currency, ...emptyAgeing() };
    const b = bucketOf(it, to);
    map[k][b] = round2(map[k][b] + it.signed);
    map[k].total = round2(map[k].total + it.signed);
  }
  let rows = Object.values(map);
  if (role) {
    const flag = { customer: 'is_customer', agent: 'is_agent', vendor: 'is_vendor', carrier: 'is_carrier' }[role];
    if (flag) {
      const ids = new Set(db.prepare(`SELECT id FROM parties WHERE ${flag}=1`).all().map((r) => r.id));
      rows = rows.filter((r) => ids.has(r.party_id));
    }
  }
  rows.sort((a, b) => a.currency.localeCompare(b.currency) || Math.abs(b.total) - Math.abs(a.total));
  const totals = {};
  for (const r of rows) {
    const t = totals[r.currency] = totals[r.currency] || { currency: r.currency, ...emptyAgeing() };
    for (const b of AGE_BUCKETS.concat('total')) t[b] = round2(t[b] + r[b]);
  }
  return { to, rows, totals: Object.values(totals) };
}

// Income / expense per shipment in base currency, from POSTED documents
function shipmentProfit(shipmentIds) {
  const where = shipmentIds ? `AND d.shipment_id IN (${shipmentIds.map(() => '?').join(',') || 'NULL'})` : '';
  const rows = db.prepare(`SELECT d.shipment_id, d.doc_type, SUM(d.subtotal*d.fx_rate) AS amt
    FROM documents d WHERE d.status='POSTED' AND d.shipment_id IS NOT NULL ${where} GROUP BY d.shipment_id, d.doc_type`)
    .all(...(shipmentIds || []));
  const out = {};
  for (const r of rows) {
    const o = out[r.shipment_id] = out[r.shipment_id] || { income: 0, expense: 0, profit: 0 };
    if (r.doc_type === 'INV' || r.doc_type === 'DN') o.income += r.amt;
    else if (r.doc_type === 'CN') o.income -= r.amt;
    else if (r.doc_type === 'BILL') o.expense += r.amt;
  }
  for (const o of Object.values(out)) { o.income = round2(o.income); o.expense = round2(o.expense); o.profit = round2(o.income - o.expense); }
  return out;
}

function shipmentFreightIncomeBase(shipmentId) {
  const r = db.prepare(`SELECT COALESCE(SUM(CASE d.doc_type WHEN 'CN' THEN -l.amount ELSE l.amount END * d.fx_rate),0) AS amt
    FROM document_lines l JOIN documents d ON d.id=l.document_id JOIN charge_codes c ON c.id=l.charge_code_id
    WHERE d.status='POSTED' AND d.shipment_id=? AND d.doc_type IN ('INV','DN','CN') AND c.category='FREIGHT'`).get(shipmentId);
  return round2(r.amt);
}

// ------------------------------------------------------------------ agency commission engine
const COMM_BASIS = {
  PER_TEU: 'Per TEU', PER_CONTAINER: 'Per container', PER_CBM: 'Per CBM (LCL)', PER_BL: 'Flat per HBL',
  PERCENT_FREIGHT: '% of ocean freight income', PERCENT_PROFIT: '% of shipment profit (profit share)',
};
const COMMISSIONABLE_STATUS = ['SAILED', 'ARRIVED', 'DELIVERED', 'CLOSED'];

function pickRule(rules, ship) {
  const cands = rules.filter((r) => r.active
    && (!r.valid_from || !ship.etd || ship.etd >= r.valid_from)
    && (!r.valid_to || !ship.etd || ship.etd <= r.valid_to)
    && (r.cargo_type === 'ANY' || r.cargo_type === ship.cargo_type)
    && (!r.pol_id || r.pol_id === ship.pol_id)
    && (!r.pod_id || r.pod_id === ship.pod_id));
  if (!cands.length) return null;
  const score = (r) => (r.cargo_type !== 'ANY' ? 1 : 0) + (r.pol_id ? 2 : 0) + (r.pod_id ? 2 : 0);
  cands.sort((a, b) => score(b) - score(a) || b.id - a.id);
  return cands[0];
}

function buildCommission({ agent_id, agreement_id, from, to, currency }) {
  const ag = db.prepare('SELECT * FROM agreements WHERE id=? AND agent_id=?').get(agreement_id, agent_id);
  if (!ag) throw new Error('Agreement not found for this agent.');
  currency = currency || ag.currency;
  const rules = db.prepare('SELECT * FROM commission_rules WHERE agreement_id=?').all(agreement_id);
  const ships = db.prepare(`SELECT s.*, pl.name AS pol_name, pd.name AS pod_name FROM shipments s
      LEFT JOIN ports pl ON pl.id=s.pol_id LEFT JOIN ports pd ON pd.id=s.pod_id
      WHERE s.agent_id=? AND s.etd>=? AND s.etd<=? AND s.status IN (${COMMISSIONABLE_STATUS.map(() => '?').join(',')})
        AND s.id NOT IN (SELECT cl.shipment_id FROM commission_lines cl JOIN commission_statements cs ON cs.id=cl.statement_id WHERE cs.status<>'CANCELLED')
      ORDER BY s.etd, s.id`).all(agent_id, from, to, ...COMMISSIONABLE_STATUS);
  const profits = shipmentProfit(ships.map((s) => s.id));
  const lines = [], skipped = [];
  for (const s of ships) {
    if (ag.start_date && s.etd < ag.start_date || ag.end_date && s.etd > ag.end_date) {
      skipped.push({ shipment_id: s.id, booking_no: s.booking_no, hbl_no: s.hbl_no, etd: s.etd, reason: 'Sailing date is outside the agreement period' });
      continue;
    }
    const rule = pickRule(rules, s);
    if (!rule) {
      skipped.push({ shipment_id: s.id, booking_no: s.booking_no, hbl_no: s.hbl_no, etd: s.etd, reason: 'No commission rule matches this shipment' });
      continue;
    }
    const cont = db.prepare(`SELECT COUNT(*) n, COALESCE(SUM(t.teu),0) teu FROM shipment_containers sc JOIN containers c ON c.id=sc.container_id
      JOIN container_types t ON t.id=c.type_id WHERE sc.shipment_id=?`).get(s.id);
    let base_qty = null, base_amount = null, amount = 0, warning = '';
    const date = s.etd;
    switch (rule.basis) {
      case 'PER_TEU': base_qty = cont.teu; amount = base_qty * rule.rate; if (!base_qty) warning = 'No containers attached'; break;
      case 'PER_CONTAINER': base_qty = cont.n; amount = base_qty * rule.rate; if (!base_qty) warning = 'No containers attached'; break;
      case 'PER_CBM': base_qty = Number(s.cbm) || 0; amount = base_qty * rule.rate; if (!base_qty) warning = 'No CBM on shipment'; break;
      case 'PER_BL': base_qty = 1; amount = rule.rate; break;
      case 'PERCENT_FREIGHT': {
        base_amount = shipmentFreightIncomeBase(s.id);
        if (!base_amount) warning = 'No posted freight invoice for this shipment';
        amount = convert(base_amount, baseCurrency(), rule.currency, date) * rule.rate / 100; break;
      }
      case 'PERCENT_PROFIT': {
        const p = profits[s.id];
        base_amount = p ? p.profit : 0;
        if (!p) warning = 'No posted invoices/bills for this shipment';
        amount = Math.max(0, convert(base_amount, baseCurrency(), rule.currency, date)) * rule.rate / 100; break;
      }
      default: amount = 0;
    }
    if (rule.min_amount != null && amount < rule.min_amount) amount = rule.min_amount;
    if (rule.max_amount != null && amount > rule.max_amount) amount = rule.max_amount;
    const inStmtCur = round2(convert(amount, rule.currency, currency, date));
    lines.push({ shipment_id: s.id, booking_no: s.booking_no, hbl_no: s.hbl_no, etd: s.etd, cargo_type: s.cargo_type,
      pol_name: s.pol_name, pod_name: s.pod_name, rule_id: rule.id, rule_name: rule.name, basis: rule.basis,
      base_qty: base_qty == null ? null : round2(base_qty), base_amount: base_amount == null ? null : round2(base_amount),
      rate: rule.rate, rule_currency: rule.currency, commission_amount: inStmtCur, warning });
  }
  return { currency, lines, skipped, total: round2(lines.reduce((t, l) => t + l.commission_amount, 0)) };
}

module.exports = {
  baseCurrency, fxRate, convert,
  CONTAINER_STATUS, CLOCK_RESET, iso6346Valid, iso6346CheckDigit, normContainerNo, refreshContainer, containerSnapshot, clockFor,
  DOC_SIGN, DOC_LABEL, computeLines, outstandingSql, docOutstanding, paymentUnallocated, openItems, buildSoa, ageingReport, AGE_BUCKETS,
  shipmentProfit, COMM_BASIS, COMMISSIONABLE_STATUS, buildCommission,
};
