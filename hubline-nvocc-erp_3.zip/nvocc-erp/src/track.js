'use strict';
// Container enquiry / tracking: search by container, booking, HBL, MBL or vessel and show where each box is and how it got there.
const { db, today, daysBetween } = require('./db');
const L = require('./logic');
const S = require('./scope');

const JOURNEY = [
  ['RELEASED_SHIPPER', 'Empty released'], ['GATED_IN_FULL', 'Gated in (laden)'], ['ON_BOARD', 'On board / sailed'],
  ['DISCHARGED', 'Discharged'], ['DELIVERED_FULL', 'Delivered'], ['EMPTY_RETURNED', 'Empty returned'],
];

const SHIP_SQL = `SELECT s.id, s.booking_no, s.hbl_no, s.status, s.vessel, s.voyage, s.etd, s.eta, s.cargo_type, s.commodity, s.agent_id,
    pl.name AS pol_name, pd.name AS pod_name, k.mbl_no, k.consol_no, ca.name AS carrier_name, ag.name AS agent_name
  FROM shipments s LEFT JOIN ports pl ON pl.id=s.pol_id LEFT JOIN ports pd ON pd.id=s.pod_id LEFT JOIN consols k ON k.id=s.consol_id
  LEFT JOIN parties ca ON ca.id=s.carrier_id LEFT JOIN parties ag ON ag.id=s.agent_id`;

// the shipment a container is currently working for: the one on its latest movement, else its newest open shipment
function currentShipment(u, containerId, eventShipmentId) {
  let s = null;
  if (eventShipmentId) s = db.prepare(SHIP_SQL + ' WHERE s.id=?').get(eventShipmentId);
  if (!s) s = db.prepare(SHIP_SQL + ` JOIN shipment_containers sc ON sc.shipment_id=s.id WHERE sc.container_id=? ORDER BY (s.status IN ('CLOSED','CANCELLED')), s.id DESC LIMIT 1`).get(containerId);
  if (s && !S.ownsShipment(u, s)) return null;      // an agent never sees other agents' cargo details
  return s || null;
}

// tokens: container numbers (full or partial), booking / HBL / MBL / consol numbers, vessel names
function search(u, q, { limit = 300 } = {}) {
  const s0 = String(q || '').trim();
  let words;
  if (/[\n,;]/.test(s0)) words = s0.split(/[\n,;]+/).map((s) => s.trim()).filter(Boolean);
  else { const parts = s0.split(/\s+/).filter(Boolean); words = parts.length > 1 && parts.every((p) => /^[A-Za-z]{4}-?\d{3,7}$/.test(p)) ? parts : (s0 ? [s0] : []); }
  if (!words.length) return [];
  const snap = S.filterContainers(u, L.containerSnapshot(today(), { inventoryOnly: false }));
  const byId = new Map(snap.map((c) => [c.id, c]));
  const hit = new Set();
  for (const w of words) {
    const up = w.toUpperCase().replace(/[\s-]+/g, '');
    const like = `%${w}%`;
    if (/^[A-Z]{4}\d{0,7}$/.test(up) || /^[A-Z]{3,4}\d{3,}$/.test(up)) {
      for (const c of snap) if (c.container_no.includes(up)) hit.add(c.id);
    }
    // booking / HBL / MBL / consol / vessel -> the containers on those shipments
    const rows = db.prepare(`SELECT DISTINCT sc.container_id AS id FROM shipment_containers sc JOIN shipments s ON s.id=sc.shipment_id LEFT JOIN consols k ON k.id=s.consol_id
      WHERE s.booking_no LIKE ? OR s.hbl_no LIKE ? OR k.mbl_no LIKE ? OR k.consol_no LIKE ? OR s.vessel LIKE ?`).all(like, like, like, like, like);
    for (const r of rows) if (byId.has(r.id)) hit.add(r.id);
    if (!/^[A-Z]{4}\d/.test(up)) for (const c of snap) if ((c.location || '').toLowerCase().includes(w.toLowerCase())) hit.add(c.id);   // "colombo" lists everything there
  }
  const out = [];
  for (const id of hit) {
    const c = byId.get(id); if (!c) continue;
    const sh = currentShipment(u, id, c.shipment_id);
    out.push({ id: c.id, container_no: c.container_no, type_code: c.type_code, ownership: c.ownership, status: c.status, status_label: c.status_label, group: c.group,
      location: c.location, last_date: c.last_date, days_in_status: c.days_in_status, free_until: c.free_until, free_days_left: c.free_days_left, overdue: c.overdue,
      booking_no: sh && sh.booking_no, hbl_no: sh && sh.hbl_no, mbl_no: sh && sh.mbl_no, vessel: sh && sh.vessel, voyage: sh && sh.voyage,
      pol_name: sh && sh.pol_name, pod_name: sh && sh.pod_name, etd: sh && sh.etd, eta: sh && sh.eta, shipment_id: sh && sh.id, shipment_status: sh && sh.status,
      days_to_eta: sh && sh.eta && c.group === 'LADEN' && c.status === 'ON_BOARD' ? daysBetween(today(), sh.eta) : null });
    if (out.length >= limit) break;
  }
  out.sort((a, b) => a.container_no.localeCompare(b.container_no));
  return out;
}

// full story of one container
function detail(u, id) {
  const c = db.prepare(`SELECT c.*, t.code AS type_code, t.teu, t.size_ft, o.name AS owner_name FROM containers c JOIN container_types t ON t.id=c.type_id LEFT JOIN parties o ON o.id=c.owner_id WHERE c.id=?`).get(id);
  if (!c || !S.canSeeContainer(u, c.id, c.location)) return null;
  const snap = L.containerSnapshot(today()).find((x) => x.id === c.id) || {};
  const events = db.prepare(`SELECT e.*, s.booking_no, s.hbl_no, k.consol_no, u.username, u.full_name FROM container_events e LEFT JOIN shipments s ON s.id=e.shipment_id
    LEFT JOIN consols k ON k.id=e.consol_id LEFT JOIN users u ON u.id=e.user_id WHERE e.container_id=? ORDER BY e.event_date DESC, e.id DESC`).all(c.id);
  for (const e of events) e.label = (L.CONTAINER_STATUS[e.event_type] || {}).label || e.event_type;
  const sh = currentShipment(u, c.id, snap.shipment_id);
  // the current job = movements since the container was last idle / newly allocated
  const chron = events.slice().reverse();
  let from = 0;
  for (let i = chron.length - 1; i >= 0; i--) if (['ALLOCATED', 'RELEASED_SHIPPER'].includes(chron[i].event_type)) { from = i; break; }
  const cycle = chron.slice(from);
  const journey = JOURNEY.map(([type, label]) => {
    const e = cycle.filter((x) => x.event_type === type).pop();
    return { type, label, done: !!e, date: e ? e.event_date : null, location: e ? e.location : null,
      expected: !e && type === 'DISCHARGED' && sh ? sh.eta : !e && type === 'ON_BOARD' && sh ? sh.etd : null };
  });
  // "current" step = the last completed one
  let cur = -1; journey.forEach((j, i) => { if (j.done) cur = i; });
  journey.forEach((j, i) => { j.state = j.done ? (i === cur ? 'now' : 'done') : 'todo'; });
  const shipments = db.prepare(`${SHIP_SQL} JOIN shipment_containers sc ON sc.shipment_id=s.id WHERE sc.container_id=? ORDER BY s.id DESC`).all(c.id).filter((s) => S.ownsShipment(u, s));
  return { container: { ...c, status_label: snap.status_label, group: snap.group, days_in_status: snap.days_in_status, last_date: snap.last_date, free_until: snap.free_until, free_days_left: snap.free_days_left, overdue: snap.overdue, free_days: snap.free_days, clock_from: snap.clock_from },
    shipment: sh, shipments, events, journey };
}

module.exports = { search, detail, currentShipment, JOURNEY };
