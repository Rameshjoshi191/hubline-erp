'use strict';
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { db } = require('./db');

const ROLES = {
  admin: 'Administrator',
  management: 'Management (read-only)',
  operations: 'Operations',
  documentation: 'Documentation',
  accounts: 'Accounts',
  sales: 'Sales / Agent liaison',
  agent: 'Agent (external)',
};

const STAFF = ['admin', 'management', 'operations', 'documentation', 'accounts', 'sales'];   // everybody except external agents

// '*' = any signed-in user
const PERMS = {
  dashboard:  { read: '*', write: [] },
  parties:    { read: STAFF, write: ['admin', 'sales', 'accounts', 'operations', 'documentation'] },
  masters:    { read: STAFF, write: ['admin', 'accounts', 'operations'] },
  tariffs:    { read: ['admin', 'management', 'sales', 'accounts', 'operations'], write: ['admin', 'sales'] },
  agreements: { read: ['admin', 'management', 'sales', 'accounts'], write: ['admin', 'sales'] },
  commission: { read: ['admin', 'management', 'accounts', 'sales'], write: ['admin', 'accounts'] },
  shipments:  { read: '*', write: ['admin', 'operations', 'documentation', 'sales'] },        // agents: own shipments only (scoped in the routes)
  containers: { read: '*', write: ['admin', 'operations'] },                                 // agents: containers at their locations / on their shipments
  bl:         { read: '*', write: ['admin', 'operations', 'documentation', 'sales', 'agent'] },   // bills of lading tab; agents edit their own
  movements:  { read: '*', write: ['admin', 'operations', 'agent'] },                        // log / import container movements
  schedules:  { read: '*', write: ['admin', 'operations', 'sales'] },                        // vessel schedules
  mrg:        { read: ['admin', 'management', 'sales', 'accounts'], write: ['admin', 'sales'] },   // month-wise freight, slot cost and margin
  finance:    { read: ['admin', 'management', 'accounts'], write: ['admin', 'accounts'] },
  soa:        { read: ['admin', 'management', 'accounts', 'sales'], write: [] },
  reports:    { read: STAFF, write: [] },
  audit:      { read: ['admin', 'management'], write: [] },
  users:      { read: ['admin'], write: ['admin'] },
  settings:   { read: ['admin'], write: ['admin'] },
};

const can = (role, module, kind) => {
  const p = PERMS[module];
  if (!p) return false;
  const list = p[kind];
  return list === '*' || (Array.isArray(list) && list.includes(role));
};

function permsFor(role) {
  const o = {};
  for (const m of Object.keys(PERMS)) o[m] = { read: can(role, m, 'read'), write: can(role, m, 'write') };
  return o;
}

const SESSION_HOURS = 12;

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const exp = new Date(Date.now() + SESSION_HOURS * 3600 * 1000).toISOString();
  db.prepare('INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)').run(token, userId, exp);
  db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(new Date().toISOString());
  return token;
}

function loadUser(req, _res, next) {
  const token = req.cookies && req.cookies.sid;
  req.user = null;
  if (token) {
    const row = db.prepare(`SELECT u.id,u.username,u.full_name,u.role,u.email,u.must_change_pw,u.active,u.agent_party_id,u.locations,s.expires_at
      FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?`).get(token);
    if (row && row.active && row.expires_at > new Date().toISOString()) req.user = row;
  }
  next();
}

function requireLogin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
  next();
}

// Middleware factory: need(module,'read'|'write')
function need(module, kind = 'read') {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
    if (req.user.must_change_pw && !req.path.startsWith('/change-password')) {
      return res.status(403).json({ error: 'You must change your password before continuing.', code: 'MUST_CHANGE_PW' });
    }
    if (!can(req.user.role, module, kind)) {
      return res.status(403).json({ error: `Your role (${ROLES[req.user.role] || req.user.role}) does not have ${kind} access to ${module}.` });
    }
    next();
  };
}

// Simple in-memory login throttling (per username+ip)
const attempts = new Map();
function throttleKey(req, username) { return `${req.ip}|${String(username || '').toLowerCase()}`; }
function tooManyAttempts(req, username) {
  const k = throttleKey(req, username);
  const a = attempts.get(k);
  if (!a) return false;
  if (Date.now() - a.first > 15 * 60 * 1000) { attempts.delete(k); return false; }
  return a.count >= 8;
}
function recordFailure(req, username) {
  const k = throttleKey(req, username);
  const a = attempts.get(k);
  if (!a || Date.now() - a.first > 15 * 60 * 1000) attempts.set(k, { first: Date.now(), count: 1 });
  else a.count++;
}
function clearFailures(req, username) { attempts.delete(throttleKey(req, username)); }

const hash = (pw) => bcrypt.hashSync(pw, 10);
const verify = (pw, h) => bcrypt.compareSync(pw, h);

// Blocks external agents from staff-only screens that are not scoped per agent
function staffOnly(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
  if (req.user.role === 'agent') return res.status(403).json({ error: 'This area is for HUB LINE staff only.' });
  next();
}

module.exports = { ROLES, PERMS, STAFF, can, permsFor, staffOnly, createSession, loadUser, requireLogin, need, tooManyAttempts, recordFailure, clearFailures, hash, verify };
