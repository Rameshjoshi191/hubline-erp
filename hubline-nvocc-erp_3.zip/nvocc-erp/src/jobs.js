'use strict';
// Background automation - nobody has to remember to do these.
//   1. Every day at the chosen hour: e-mail the container inventory (Excel + PDF) and a short "what needs attention" summary.
//   2. Every day: re-read every saved vessel-schedule link that is set to auto-refresh (changes are detected / applied automatically).
// Runs on a light timer inside the server. State is kept in the settings table so a restart never sends twice.
const { db, getSetting, setSetting, audit, today } = require('./db');
const { xlsxBuffer, XLSX_MIME } = require('./util');

const SYSTEM_USER = { id: null, username: 'system', full_name: 'Automatic job', role: 'admin' };

// local wall-clock in the company's time zone (default UTC+4, Dubai)
function localNow(offsetHours) {
  const d = new Date(Date.now() + offsetHours * 3600 * 1000);
  return { date: d.toISOString().slice(0, 10), hour: d.getUTCHours() };
}
const tzOffset = () => { const n = Number(getSetting('company_tz_offset', '4')); return Number.isFinite(n) ? n : 4; };

async function sendDailyReport(force = false) {
  const SH = require('./share');
  const X = require('./exporters');
  const D = require('./dashboard');
  const to = getSetting('autoreport_to', '');
  if (!to) return { skipped: 'no recipients' };
  if (!SH.mailConfigured()) return { skipped: 'e-mail not set up' };
  const now = localNow(tzOffset());
  if (!force) {
    if (getSetting('autoreport_last', '') === now.date) return { skipped: 'already sent today' };
    const hour = Number(getSetting('autoreport_hour', '8'));
    if (now.hour < (Number.isFinite(hour) ? hour : 8)) return { skipped: 'not time yet' };
  }
  const def = await X.EXPORTS.inventory.build({ date: today() }, SYSTEM_USER);
  const co = getSetting('company_name', 'HUB LINE SHIPPING LLC');
  const xlsx = await xlsxBuffer(def.sheets, { company: co });
  const pdf = await SH.pdfFromSheets({ title: def.title, subtitle: def.subtitle, sheets: def.sheets.slice(0, 2), landscape: true });
  const dash = D.staffDashboard(SYSTEM_USER);
  const e = dash.equipment;
  const lines = [
    `${co} - daily summary for ${now.date}`, '',
    `Equipment: ${e.total} containers in inventory (${e.empty} empty, ${e.laden} laden, ${e.out_of_service} out of service), utilisation ${e.utilisation}%.`,
    `Tracking: ${dash.tracking.in_transit_total} containers in transit, ${dash.tracking.arriving_7d} arriving within 7 days.`,
  ];
  if (dash.receivables) lines.push(`Receivables: ${dash.base_currency} ${Math.round(dash.receivables.total).toLocaleString('en-US')} outstanding, of which ${Math.round(dash.receivables.overdue).toLocaleString('en-US')} overdue.`);
  lines.push('');
  if (dash.actions.length) { lines.push('Needs attention:'); for (const a of dash.actions) lines.push(`- ${a.title}: ${a.count}`); } else lines.push('Nothing needs attention today.');
  lines.push('', 'The container inventory report is attached as Excel and PDF.');
  const n = await SH.sendMail({ to, subject: `${co} - container inventory & daily summary ${now.date}`, text: lines.join('\n'),
    attachments: [{ filename: `Container_Inventory_${today()}.xlsx`, content: xlsx, contentType: XLSX_MIME }, { filename: `Container_Inventory_${today()}.pdf`, content: pdf, contentType: 'application/pdf' }] });
  setSetting('autoreport_last', now.date);
  audit(SYSTEM_USER, 'EMAIL', 'daily-report', null, { to, recipients: n });
  return { sent: n };
}

async function refreshSources(force = false) {
  const SCH = require('./schedules');
  const out = [];
  const cutoff = force ? "datetime('now','+1 day')" : "datetime('now','-23 hours')";
  const rows = db.prepare(`SELECT * FROM schedule_sources WHERE active=1 AND auto_refresh=1 AND (last_run IS NULL OR last_run<=${cutoff})`).all();
  for (const s of rows) {
    const r = await SCH.refreshSource(s, SYSTEM_USER);
    out.push({ id: s.id, name: s.name, ok: r.ok, error: r.error });
  }
  return out;
}

let timer = null, busy = false;
async function tick() {
  if (busy) return;
  busy = true;
  try {
    await sendDailyReport().catch((e) => console.error('[jobs] daily report failed:', e.message));
    await refreshSources().catch((e) => console.error('[jobs] schedule refresh failed:', e.message));
  } finally { busy = false; }
}
function start() {
  if (timer) return;
  timer = setInterval(tick, 10 * 60 * 1000);
  timer.unref();
  setTimeout(tick, 30 * 1000).unref();
}
function stop() { if (timer) clearInterval(timer); timer = null; }

module.exports = { start, stop, tick, sendDailyReport, refreshSources, localNow, SYSTEM_USER };
