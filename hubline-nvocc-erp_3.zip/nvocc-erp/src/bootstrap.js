'use strict';
// Minimal, production-safe starting data. Runs on every start but only inserts what is missing.
const crypto = require('crypto');
const { db, getSetting, setSetting } = require('./db');
const { hash } = require('./auth');

const CURRENCIES = [['AED', 'UAE Dirham'], ['USD', 'US Dollar'], ['EUR', 'Euro'], ['GBP', 'Pound Sterling'], ['INR', 'Indian Rupee'],
  ['CNY', 'Chinese Yuan'], ['SAR', 'Saudi Riyal'], ['KES', 'Kenyan Shilling'], ['PKR', 'Pakistani Rupee'], ['LKR', 'Sri Lankan Rupee']];

const CONTAINER_TYPES = [
  ['20GP', "20' General purpose", 20, 1, 0], ['40GP', "40' General purpose", 40, 2, 0], ['40HC', "40' High cube", 40, 2, 0], ['45HC', "45' High cube", 45, 2.25, 0],
  ['20RF', "20' Reefer", 20, 1, 1], ['40RH', "40' Reefer high cube", 40, 2, 1], ['20OT', "20' Open top", 20, 1, 0], ['40OT', "40' Open top", 40, 2, 0],
  ['20FR', "20' Flat rack", 20, 1, 0], ['40FR', "40' Flat rack", 40, 2, 0], ['20TK', "20' Tank", 20, 1, 0],
];

// code, name, category, side, vat
const CHARGES = [
  ['OF', 'Ocean freight', 'FREIGHT', 'BOTH', 0], ['BAF', 'Bunker adjustment factor', 'FREIGHT', 'BOTH', 0], ['CAF', 'Currency adjustment factor', 'FREIGHT', 'BOTH', 0],
  ['PSS', 'Peak season surcharge', 'FREIGHT', 'BOTH', 0], ['LCL-FRT', 'LCL freight (per CBM/ton)', 'FREIGHT', 'BOTH', 0],
  ['THC-O', 'Terminal handling - origin', 'ORIGIN', 'BOTH', 5], ['THC-D', 'Terminal handling - destination', 'DESTINATION', 'BOTH', 5],
  ['DOC', 'Documentation fee', 'DOC', 'BOTH', 5], ['BLF', 'Bill of lading fee', 'DOC', 'BOTH', 5], ['DO', 'Delivery order fee', 'DESTINATION', 'BOTH', 5],
  ['SEAL', 'Container seal', 'ORIGIN', 'BOTH', 5], ['CFS-O', 'CFS charges - origin', 'ORIGIN', 'BOTH', 5], ['CFS-D', 'CFS charges - destination', 'DESTINATION', 'BOTH', 5],
  ['DEM', 'Demurrage', 'DESTINATION', 'BOTH', 5], ['DET', 'Detention', 'DESTINATION', 'BOTH', 5],
  ['AGT-HDL', 'Agent handling fee', 'OTHER', 'BOTH', 0], ['TRK', 'Trucking / inland haulage', 'OTHER', 'BOTH', 5], ['OTH', 'Other charges', 'OTHER', 'BOTH', 5],
];

const PORTS = [
  ['AEJEA', 'Jebel Ali', 'United Arab Emirates'], ['AEAUH', 'Abu Dhabi (Khalifa)', 'United Arab Emirates'], ['AEDXB', 'Dubai (Port Rashid)', 'United Arab Emirates'],
  ['AESHJ', 'Sharjah', 'United Arab Emirates'], ['AEFJR', 'Fujairah', 'United Arab Emirates'], ['INNSA', 'Nhava Sheva (JNPT)', 'India'], ['INMUN', 'Mundra', 'India'],
  ['INMAA', 'Chennai', 'India'], ['INCOK', 'Cochin', 'India'], ['PKKHI', 'Karachi', 'Pakistan'], ['CNSHA', 'Shanghai', 'China'], ['CNNGB', 'Ningbo', 'China'],
  ['CNSZX', 'Shenzhen', 'China'], ['CNQIN', 'Qingdao', 'China'], ['SGSIN', 'Singapore', 'Singapore'], ['LKCMB', 'Colombo', 'Sri Lanka'], ['OMSLL', 'Salalah', 'Oman'],
  ['SAJED', 'Jeddah', 'Saudi Arabia'], ['SADMM', 'Dammam', 'Saudi Arabia'], ['EGPSD', 'Port Said', 'Egypt'], ['NLRTM', 'Rotterdam', 'Netherlands'],
  ['DEHAM', 'Hamburg', 'Germany'], ['GBFXT', 'Felixstowe', 'United Kingdom'], ['USNYC', 'New York', 'United States'], ['KEMBA', 'Mombasa', 'Kenya'],
  ['TZDAR', 'Dar es Salaam', 'Tanzania'], ['BDCGP', 'Chittagong', 'Bangladesh'],
];

function bootstrap() {
  const insCur = db.prepare('INSERT OR IGNORE INTO currencies(code,name) VALUES(?,?)');
  for (const [c, n] of CURRENCIES) insCur.run(c, n);
  const insCt = db.prepare('INSERT OR IGNORE INTO container_types(code,description,size_ft,teu,is_reefer) VALUES(?,?,?,?,?)');
  for (const c of CONTAINER_TYPES) insCt.run(...c);
  const insCh = db.prepare('INSERT OR IGNORE INTO charge_codes(code,name,category,side,vat_rate) VALUES(?,?,?,?,?)');
  for (const c of CHARGES) insCh.run(...c);
  const insP = db.prepare('INSERT OR IGNORE INTO ports(code,name,country) VALUES(?,?,?)');
  for (const p of PORTS) insP.run(...p);

  const defaults = {
    company_name: 'HUB LINE SHIPPING LLC', base_currency: 'AED', default_vat: '5', default_free_days: '7',
    hbl_terms: 'Received by the Carrier the goods described above in apparent good order and condition unless otherwise stated. Carriage is subject to the terms and conditions of the Carrier\'s bill of lading. Terms overleaf form part of this bill of lading.',
    invoice_footer: 'Payment is due by the due date shown. Please quote the invoice number with your remittance.',
  };
  for (const [k, v] of Object.entries(defaults)) if (getSetting(k) === null) setSetting(k, v);

  // exchange rate for base currency and the AED/USD peg
  const base = getSetting('base_currency', 'AED');
  db.prepare("INSERT OR IGNORE INTO exchange_rates(currency,rate,effective_date) VALUES(?,1,'2000-01-01')").run(base);
  if (base === 'AED') db.prepare("INSERT OR IGNORE INTO exchange_rates(currency,rate,effective_date) VALUES('USD',3.6725,'2000-01-01')").run();

  // first administrator
  let firstRunPassword = null;
  if (!db.prepare('SELECT 1 FROM users LIMIT 1').get()) {
    firstRunPassword = process.env.ADMIN_PASSWORD || crypto.randomBytes(6).toString('base64url');
    db.prepare("INSERT INTO users(username,full_name,role,password_hash,must_change_pw) VALUES('admin','Administrator','admin',?,1)").run(hash(firstRunPassword));
  }
  return { firstRunPassword };
}

module.exports = { bootstrap };
