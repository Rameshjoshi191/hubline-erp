'use strict';
// Sharing: turns the same "sheet" definitions used for Excel into PDF, builds the house B/L as a PDF, and e-mails files.
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const nodemailer = require('nodemailer');
const { getSetting } = require('./db');

const LOGO = path.join(__dirname, '..', 'public', 'img', 'logo.png');
const NAVY = '#1F3A5F', INK = '#1b2733', MUTED = '#5b6b7b', LINE = '#c9d3dd', ZEBRA = '#f3f6f9';

// the built-in PDF fonts only cover Western characters: swap anything else for "?" so a name never breaks the file
const latin = (s) => String(s == null ? '' : s).replace(/[–—−]/g, '-').replace(/[‘’]/g, "'").replace(/[“”]/g, '"').replace(/…/g, '...')
  .replace(/[^\x09\x0A\x0D\x20-\x7E\xA0-\xFF]/g, '?');

function collect(doc) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });
}
const company = () => getSetting('company_name', 'HUB LINE SHIPPING LLC');

function pageHeader(doc, title, sub) {
  const m = doc.page.margins.left, w = doc.page.width - m * 2;
  let x = m;
  if (fs.existsSync(LOGO)) { try { doc.image(LOGO, m, doc.page.margins.top - 6, { height: 30 }); x = m + 96; } catch { /* logo is optional */ } }
  doc.fillColor(INK).font('Helvetica-Bold').fontSize(13).text(latin(company()), x, doc.page.margins.top - 4, { width: w - (x - m) - 150, lineBreak: false });
  doc.fillColor(MUTED).font('Helvetica').fontSize(8).text(latin(sub || ''), x, doc.page.margins.top + 12, { width: w - (x - m) - 150, lineBreak: false });
  doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(12).text(latin(title), m + w - 300, doc.page.margins.top - 2, { width: 300, align: 'right', lineBreak: false });
  doc.fillColor(MUTED).font('Helvetica').fontSize(7.5).text('Generated ' + new Date().toISOString().slice(0, 16).replace('T', ' ') + ' UTC', m + w - 300, doc.page.margins.top + 13, { width: 300, align: 'right', lineBreak: false });
  doc.moveTo(m, doc.page.margins.top + 28).lineTo(m + w, doc.page.margins.top + 28).lineWidth(0.8).strokeColor(NAVY).stroke();
  doc.y = doc.page.margins.top + 36;
}
function pageFooters(doc) {
  const range = doc.bufferedPageRange();
  for (let i = 0; i < range.count; i++) {
    doc.switchToPage(range.start + i);
    const m = doc.page.margins.left, w = doc.page.width - m * 2, y = doc.page.height - 22;
    doc.fillColor(MUTED).font('Helvetica').fontSize(7.5);
    doc.text(latin(company()), m, y, { width: w / 2, lineBreak: false });
    doc.text(`Page ${i + 1} of ${range.count}`, m + w / 2, y, { width: w / 2, align: 'right', lineBreak: false });
  }
}

// ---------------------------------------------------------------- generic tables (PDF twin of an Excel workbook)
// sheets: [{ name, title:[..], columns:[{header,key,width,fmt}], rows:[..], totals:{}, pdfKeys?:[..], pdf?:false }]
async function pdfFromSheets({ title, subtitle, sheets, landscape = true }) {
  const doc = new PDFDocument({ size: 'A4', layout: landscape ? 'landscape' : 'portrait', margin: 30, bufferPages: true, info: { Title: latin(title), Author: latin(company()) } });
  const done = collect(doc);
  const list = sheets.filter((s) => s.pdf !== false);
  const firstTitles = (list[0] && list[0].title) || [];
  pageHeader(doc, title, subtitle);
  const left = doc.page.margins.left, usable = () => doc.page.width - doc.page.margins.left - doc.page.margins.right;
  const bottom = () => doc.page.height - doc.page.margins.bottom - 8;

  list.forEach((sh, si) => {
    let cols = sh.columns;
    if (sh.pdfKeys) cols = sh.pdfKeys.map((k) => sh.columns.find((c) => c.key === k)).filter(Boolean);
    const totalW = cols.reduce((a, c) => a + (c.width || 12), 0) || 1;
    const fs_ = cols.length > 12 ? 6.2 : cols.length > 9 ? 6.8 : 7.6;
    const rowH = fs_ + 7.5;
    const widths = cols.map((c) => ((c.width || 12) / totalW) * usable());
    if (si > 0 && doc.y > bottom() - 90) { doc.addPage(); pageHeader(doc, title, subtitle); }
    if (list.length > 1 || sh.name) {
      doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(10).text(latin(sh.name), left, doc.y, { lineBreak: false });
      doc.y += 14;
    }
    for (const t of (sh.title || []).filter((t) => !firstTitles.includes(t))) { doc.fillColor(MUTED).font('Helvetica').fontSize(8).text(latin(t), left, doc.y, { lineBreak: false }); doc.y += 11; }
    const fmtCell = (c, v) => {
      if (v == null || v === '') return '';
      if (typeof v === 'number') return c.fmt ? v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : (Number.isInteger(v) ? String(v) : String(Math.round(v * 100) / 100));
      return latin(v);
    };
    const drawHead = () => {
      let x = left; const y = doc.y;
      doc.rect(left, y, usable(), rowH + 2).fill(NAVY);
      cols.forEach((c, i) => { doc.fillColor('#ffffff').font('Helvetica-Bold').fontSize(fs_).text(latin(c.header), x + 2, y + 4, { width: widths[i] - 4, height: rowH, ellipsis: true, lineBreak: false, align: isNum(c) ? 'right' : 'left' }); x += widths[i]; });
      doc.y = y + rowH + 2;
    };
    const isNum = (c) => !!c.fmt || (sh.rows.length && typeof sh.rows[0][c.key] === 'number');
    const drawRow = (row, i, bold) => {
      if (doc.y + rowH > bottom()) { doc.addPage(); pageHeader(doc, title, subtitle); drawHead(); }
      let x = left; const y = doc.y;
      if (i % 2 === 1 && !bold) doc.rect(left, y, usable(), rowH).fill(ZEBRA);
      cols.forEach((c, k) => { doc.fillColor(INK).font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(fs_).text(fmtCell(c, row[c.key]), x + 2, y + 3.5, { width: widths[k] - 4, height: rowH, ellipsis: true, lineBreak: false, align: isNum(c) ? 'right' : 'left' }); x += widths[k]; });
      doc.moveTo(left, y + rowH).lineTo(left + usable(), y + rowH).lineWidth(0.3).strokeColor(LINE).stroke();
      doc.y = y + rowH;
    };
    if (doc.y + rowH * 3 > bottom()) { doc.addPage(); pageHeader(doc, title, subtitle); }
    drawHead();
    if (!sh.rows.length) { doc.fillColor(MUTED).font('Helvetica-Oblique').fontSize(8).text('Nothing to show.', left + 2, doc.y + 4, { lineBreak: false }); doc.y += 16; }
    sh.rows.forEach((row, i) => drawRow(row, i, false));
    if (sh.totals) drawRow({ [cols[0].key]: 'Total', ...sh.totals }, 0, true);
    doc.y += 14;
  });
  pageFooters(doc);
  doc.end();
  return done;
}

// ---------------------------------------------------------------- house bill of lading
function boxed(doc, x, y, w, h, label, text, opt = {}) {
  doc.rect(x, y, w, h).lineWidth(0.7).strokeColor(NAVY).stroke();
  doc.fillColor(MUTED).font('Helvetica-Bold').fontSize(6.5).text(latin(label).toUpperCase(), x + 4, y + 3, { width: w - 8, lineBreak: false });
  doc.fillColor(INK).font(opt.bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(opt.size || 8.5).text(latin(text || ''), x + 4, y + 13, { width: w - 8, height: h - 16, ellipsis: true });
}
function drawHbl(doc, s, co = {}) {
  const m = 30, W = doc.page.width - m * 2;
  const draft = !s.hbl_no || ['BOOKED', 'CANCELLED'].includes(s.status);
  if (fs.existsSync(LOGO)) { try { doc.image(LOGO, m, m - 4, { height: 40 }); } catch { /* optional */ } }
  doc.fillColor(INK).font('Helvetica-Bold').fontSize(10).text(latin(co.company_name || company()), m + 124, m, { width: 230 });
  doc.font('Helvetica').fontSize(7.5).fillColor(MUTED).text(latin([co.company_address, [co.company_phone && 'Tel ' + co.company_phone, co.company_email].filter(Boolean).join('  ')].filter(Boolean).join('\n')), m + 124, m + 13, { width: 230 });
  doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(15).text('HOUSE BILL OF LADING', m + W - 240, m, { width: 240, align: 'right' });
  doc.fillColor(INK).fontSize(9).text('B/L no. ' + latin(s.hbl_no || '(draft - not yet issued)'), m + W - 240, m + 20, { width: 240, align: 'right' });
  doc.font('Helvetica').fontSize(7.5).fillColor(MUTED).text(latin(`Booking ${s.booking_no}${s.mbl_no ? '   MBL ' + s.mbl_no : ''}`), m + W - 240, m + 33, { width: 240, align: 'right' });

  const party = (id, name, text, addr) => (name ? name + (addr ? '\n' + addr : '') : text || '');
  let y = m + 58; const half = W / 2;
  boxed(doc, m, y, half, 76, 'Shipper', party(s.shipper_id, s.shipper_name, s.shipper_text, s.shipper_address));
  boxed(doc, m + half, y, half, 76, 'Consignee', party(s.consignee_id, s.consignee_name, s.consignee_text, s.consignee_address));
  y += 76;
  boxed(doc, m, y, half, 62, 'Notify party', party(s.notify_id, s.notify_name, s.notify_text, s.notify_address));
  boxed(doc, m + half, y, half, 62, 'Also notify / delivery agent', s.agent_name || '');
  y += 62;
  const third = W / 3;
  const cells = [['Place of receipt', s.place_of_receipt || s.pol_name], ['Port of loading', s.pol_name], ['Vessel / voyage', [s.vessel, s.voyage].filter(Boolean).join(' / ')],
    ['Port of discharge', s.pod_name], ['Place of delivery', s.place_of_delivery || s.pod_name], ['Freight', s.freight_terms === 'COLLECT' ? 'FREIGHT COLLECT' : 'FREIGHT PREPAID']];
  cells.forEach(([l, v], i) => boxed(doc, m + (i % 3) * third, y + Math.floor(i / 3) * 34, third, 34, l, v, { bold: true }));
  y += 68 + 8;

  doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(8).text("PARTICULARS FURNISHED BY THE SHIPPER", m, y);
  y += 12;
  const cw = [W * 0.27, W * 0.11, W * 0.34, W * 0.14, W * 0.14];
  const heads = ['Marks & numbers / containers', 'Packages', 'Description of goods', 'Gross weight (kg)', 'Measurement (CBM)'];
  doc.rect(m, y, W, 16).fill(NAVY);
  let x = m; heads.forEach((h, i) => { doc.fillColor('#fff').font('Helvetica-Bold').fontSize(7).text(h, x + 3, y + 5, { width: cw[i] - 6, lineBreak: false }); x += cw[i]; });
  y += 16;
  const conts = (s.containers || []).map((c) => `${c.container_no} / ${c.type_code}${c.seal_no ? ' / SEAL ' + c.seal_no : ''}`).join('\n');
  const totalPk = (s.containers || []).reduce((a, c) => a + (c.packages || 0), 0);
  const bodyH = 190;
  doc.rect(m, y, W, bodyH).lineWidth(0.7).strokeColor(NAVY).stroke();
  x = m; cw.forEach((w2) => { x += w2; if (x < m + W - 1) doc.moveTo(x, y).lineTo(x, y + bodyH).lineWidth(0.4).strokeColor(LINE).stroke(); });
  const cell = (i, t, o = {}) => doc.fillColor(INK).font(o.bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(8).text(latin(t), m + cw.slice(0, i).reduce((a, b) => a + b, 0) + 4, y + 6, { width: cw[i] - 8, height: bodyH - 12, align: o.right ? 'right' : 'left', ellipsis: true });
  cell(0, [s.marks, conts].filter(Boolean).join('\n\n'));
  cell(1, `${s.packages != null ? s.packages : totalPk || ''}\n${s.package_type || ''}`, { right: true });
  cell(2, `${s.commodity || ''}\n\n${s.cargo_type === 'FCL' ? "SAID TO CONTAIN - SHIPPER'S LOAD, STOW AND COUNT" : 'LCL CARGO'}`);
  cell(3, s.gross_weight != null ? String(s.gross_weight) : '', { right: true });
  cell(4, s.cbm != null ? String(s.cbm) : '', { right: true });
  y += bodyH + 8;
  boxed(doc, m, y, half, 34, 'Date and place of issue', `${new Date().toISOString().slice(0, 10)}${co.company_address ? ', ' + String(co.company_address).split('\n').pop() : ''}`);
  boxed(doc, m + half, y, half, 34, 'Number of original B/Ls', 'THREE (3)', { bold: true });
  y += 42;
  doc.fillColor(MUTED).font('Helvetica').fontSize(6.6).text(latin(co.hbl_terms || ''), m, y, { width: W, height: 70, ellipsis: true });
  y = doc.page.height - m - 44;
  doc.moveTo(m, y).lineTo(m + 230, y).lineWidth(0.6).strokeColor(INK).stroke();
  doc.moveTo(m + W - 130, y).lineTo(m + W, y).stroke();
  doc.fillColor(INK).font('Helvetica').fontSize(7.5).text(latin('Signed for the Carrier as agent: ' + (co.company_name || company())), m, y + 3, { width: 260 });
  doc.text('Date', m + W - 130, y + 3, { width: 130 });
  if (draft) {
    doc.save(); doc.rotate(-32, { origin: [doc.page.width / 2, doc.page.height / 2] });
    doc.fillColor('#c0392b').opacity(0.13).font('Helvetica-Bold').fontSize(74).text('DRAFT', 60, doc.page.height / 2 - 40, { width: doc.page.width - 120, align: 'center', lineBreak: false });
    doc.restore();
  }
}
// one BL, or several BLs in one PDF (one per page)
async function hblPdf(list, co = {}) {
  const arr = Array.isArray(list) ? list : [list];
  const one = arr[0];
  const doc = new PDFDocument({ size: 'A4', margin: 30, autoFirstPage: false,
    info: { Title: latin(arr.length === 1 ? `BL ${one.hbl_no || one.booking_no}` : `${arr.length} bills of lading`), Author: latin(company()) } });
  const done = collect(doc);
  for (const s of arr) { doc.addPage(); drawHbl(doc, s, co); }
  doc.end();
  return done;
}

// ---------------------------------------------------------------- e-mail
function smtp() {
  const g = (k, env) => process.env[env] || getSetting(k, '') || '';
  const host = g('smtp_host', 'SMTP_HOST');
  if (!host) return null;
  const port = parseInt(g('smtp_port', 'SMTP_PORT') || '587', 10);
  const secureSetting = g('smtp_secure', 'SMTP_SECURE');
  return { host, port, secure: secureSetting ? secureSetting === '1' || secureSetting === 'true' : port === 465,
    user: g('smtp_user', 'SMTP_USER'), pass: g('smtp_pass', 'SMTP_PASS'), from: g('smtp_from', 'SMTP_FROM') };
}
const mailConfigured = () => !!smtp();
async function sendMail({ to, subject, text, attachments = [] }) {
  const c = smtp();
  if (!c) throw Object.assign(new Error('E-mail is not set up yet. Ask your administrator to fill in the e-mail settings under Setup > Company & settings.'), { status: 400 });
  const list = String(to || '').split(/[,;\s]+/).filter(Boolean);
  if (!list.length) throw Object.assign(new Error('Enter at least one e-mail address.'), { status: 400 });
  if (list.length > 10) throw Object.assign(new Error('Please send to at most 10 addresses at a time.'), { status: 400 });
  for (const a of list) if (!/^[^\s@<>()]+@[^\s@<>()]+\.[^\s@<>()]+$/.test(a)) throw Object.assign(new Error(`"${a}" is not a valid e-mail address.`), { status: 400 });
  const tr = nodemailer.createTransport({ host: c.host, port: c.port, secure: c.secure, auth: c.user ? { user: c.user, pass: c.pass } : undefined, connectionTimeout: 15000, greetingTimeout: 15000, socketTimeout: 30000 });
  const from = c.from || c.user || getSetting('company_email', '');
  try {
    await tr.sendMail({ from, to: list.join(', '), subject: String(subject || 'From ' + company()).slice(0, 200), text: String(text || ''), attachments });
  } catch (e) {
    throw Object.assign(new Error('The e-mail could not be sent: ' + String(e.message || e).slice(0, 200) + '. Check the e-mail settings.'), { status: 502 });
  }
  return list.length;
}

module.exports = { pdfFromSheets, hblPdf, sendMail, mailConfigured, latin };
