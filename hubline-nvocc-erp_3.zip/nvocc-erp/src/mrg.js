'use strict';
// MRG = month-wise freight rate, slot cost and margin per lane and container type.
// Margin per box = freight rate - slot cost.  "Actual" boxes are counted straight from the shipments, so nobody has to re-key volumes.
const { db, audit, today, round2, addDays } = require('./db');
const L = require('./logic');
const T = require('./tabular');
const inv = require('./inventory');
const sch = require('./schedules');
const { bad } = require('./util');

const ALIASES = {
  month: ['month', 'period', 'mon', 'month year', 'for month', 'effective month', 'date'],
  carrier: ['carrier', 'line', 'shipping line', 'operator', 'slot provider', 'liner', 'vendor'],
  pol: ['pol', 'port of loading', 'origin', 'from', 'load port'],
  pod: ['pod', 'port of discharge', 'destination', 'to', 'dest', 'discharge port'],
  type: ['type', 'container type', 'size', 'size type', 'equipment', 'eq type', 'cntr type'],
  freight_rate: ['freight', 'freight rate', 'sell', 'sell rate', 'selling', 'selling rate', 'ocean freight', 'rate', 'ofr', 'market rate', 'our rate'],
  slot_cost: ['slot cost', 'slot', 'slot rate', 'buy', 'buy rate', 'buying', 'cost', 'slot price', 'carrier rate', 'net rate', 'net'],
  currency: ['currency', 'ccy', 'cur'],
  committed_slots: ['committed slots', 'slots', 'mqc', 'commitment', 'committed', 'allocation', 'min quantity', 'minimum quantity', 'qty commitment'],
  remarks: ['remarks', 'remark', 'notes', 'note', 'comment'],
};
const FIELDS = [
  { key: 'month', label: 'Month', required: true }, { key: 'pol', label: 'Port of loading' }, { key: 'pod', label: 'Port of discharge' }, { key: 'type', label: 'Container type', required: true },
  { key: 'freight_rate', label: 'Freight rate', required: true }, { key: 'slot_cost', label: 'Slot cost', required: true }, { key: 'carrier', label: 'Carrier / slot provider' },
  { key: 'currency', label: 'Currency' }, { key: 'committed_slots', label: 'Committed slots (MQC)' }, { key: 'remarks', label: 'Remarks' },
];

const monthOf = (raw) => {
  const s = String(raw || '').trim(); if (!s) return null;
  let m;
  if ((m = /^(\d{4})[-/.](\d{1,2})$/.exec(s))) return +m[2] >= 1 && +m[2] <= 12 ? `${m[1]}-${String(m[2]).padStart(2, '0')}` : null;
  if ((m = /^(\d{1,2})[-/.](\d{4})$/.exec(s))) return +m[1] >= 1 && +m[1] <= 12 ? `${m[2]}-${String(m[1]).padStart(2, '0')}` : null;
  const d = T.parseDate(/^[A-Za-z]{3,9}[\s\-/.,]*\d{2,4}$/.test(s) ? '1 ' + s : s);
  return d ? d.slice(0, 7) : null;
};
const monthEnd = (m) => { const d = new Date(m + '-01T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + 1); d.setUTCDate(0); return d.toISOString().slice(0, 10); };
const shiftMonth = (m, n) => { const d = new Date(m + '-01T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + n); return d.toISOString().slice(0, 7); };

// ---------------------------------------------------------------- reading rows (with margin and actual volume)
const SEL = `SELECT m.*, ca.name AS carrier_name, pl.name AS pol_name, pd.name AS pod_name, pl.code AS pol_code, pd.code AS pod_code, t.code AS type_code, t.teu
  FROM mrg_rates m LEFT JOIN parties ca ON ca.id=m.carrier_id LEFT JOIN ports pl ON pl.id=m.pol_id LEFT JOIN ports pd ON pd.id=m.pod_id LEFT JOIN container_types t ON t.id=m.container_type_id`;

function actuals(m) {
  const w = ["s.status<>'CANCELLED'", "substr(COALESCE(s.etd, substr(s.created_at,1,10)),1,7)=@month"], p = { month: m.month };
  if (m.pol_id) { w.push('s.pol_id=@pol'); p.pol = m.pol_id; }
  if (m.pod_id) { w.push('s.pod_id=@pod'); p.pod = m.pod_id; }
  if (m.container_type_id) { w.push('c.type_id=@ty'); p.ty = m.container_type_id; }
  if (m.carrier_id) { w.push('s.carrier_id=@ca'); p.ca = m.carrier_id; }
  const r = db.prepare(`SELECT COUNT(*) boxes, COALESCE(SUM(t.teu),0) teu FROM shipment_containers sc JOIN shipments s ON s.id=sc.shipment_id JOIN containers c ON c.id=sc.container_id
    JOIN container_types t ON t.id=c.type_id WHERE ${w.join(' AND ')}`).get(p);
  return r;
}

function decorate(m) {
  m.margin = round2(m.freight_rate - m.slot_cost);
  m.margin_pct = m.freight_rate ? round2((m.margin / m.freight_rate) * 100) : null;
  const a = actuals(m);
  m.actual_boxes = a.boxes; m.actual_teu = round2(a.teu);
  m.actual_margin = round2(a.boxes * m.margin);
  m.committed_used_pct = m.committed_slots ? Math.round((a.boxes / m.committed_slots) * 100) : null;
  const fx = L.fxRate(m.currency, today());
  m.fx = fx;
  m.actual_margin_base = fx ? round2(m.actual_margin * fx) : null;
  return m;
}

function rows(q = {}) {
  const w = [], p = {};
  if (q.month) { w.push('m.month=@month'); p.month = q.month; }
  if (q.year) { w.push("substr(m.month,1,4)=@year"); p.year = String(q.year); }
  if (q.from) { w.push('m.month>=@from'); p.from = q.from; }
  if (q.to) { w.push('m.month<=@to'); p.to = q.to; }
  if (q.carrier_id) { w.push('m.carrier_id=@ca'); p.ca = q.carrier_id; }
  if (q.pol_id) { w.push('m.pol_id=@pol'); p.pol = q.pol_id; }
  if (q.pod_id) { w.push('m.pod_id=@pod'); p.pod = q.pod_id; }
  if (q.type_id) { w.push('m.container_type_id=@ty'); p.ty = q.type_id; }
  const list = db.prepare(`${SEL} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY m.month DESC, pl.name, pd.name, t.size_ft, t.code, ca.name LIMIT 2000`).all(p);
  return list.map(decorate);
}

// month-by-month summary in base currency
function summary(year) {
  const list = rows({ year });
  const months = {};
  for (const r of list) {
    const fx = r.fx || 1;
    const x = months[r.month] = months[r.month] || { month: r.month, lanes: 0, freight_sum: 0, slot_sum: 0, boxes: 0, margin_total: 0, teu: 0 };
    x.lanes++; x.freight_sum += r.freight_rate * fx; x.slot_sum += r.slot_cost * fx; x.boxes += r.actual_boxes; x.teu += r.actual_teu; x.margin_total += r.actual_margin_base || 0;
  }
  return Object.values(months).sort((a, b) => a.month.localeCompare(b.month)).map((x) => ({ ...x,
    avg_freight: x.lanes ? round2(x.freight_sum / x.lanes) : 0, avg_slot: x.lanes ? round2(x.slot_sum / x.lanes) : 0, avg_margin: x.lanes ? round2((x.freight_sum - x.slot_sum) / x.lanes) : 0,
    margin_total: round2(x.margin_total), teu: round2(x.teu) }));
}

// lane x month grid for one metric
function matrix(year, metric = 'margin') {
  const list = rows({ year });
  const map = new Map();
  for (const r of list) {
    const key = [r.carrier_id || 0, r.pol_id || 0, r.pod_id || 0, r.container_type_id || 0].join('|');
    if (!map.has(key)) map.set(key, { key, carrier_name: r.carrier_name, pol_name: r.pol_name, pod_name: r.pod_name, type_code: r.type_code, currency: r.currency, months: Array(12).fill(null) });
    const v = metric === 'freight' ? r.freight_rate : metric === 'slot' ? r.slot_cost : metric === 'boxes' ? r.actual_boxes : r.margin;
    map.get(key).months[Number(r.month.slice(5)) - 1] = v;
  }
  return [...map.values()].sort((a, b) => String(a.pol_name).localeCompare(String(b.pol_name)) || String(a.pod_name).localeCompare(String(b.pod_name)) || String(a.type_code).localeCompare(String(b.type_code)));
}

// ---------------------------------------------------------------- automation helpers
// copy every rate of one month into another (optionally nudged by a percentage) - existing rows are never touched
function rollForward(from, to, { freight_pct = 0, slot_pct = 0 } = {}, user) {
  if (!/^\d{4}-\d{2}$/.test(from) || !/^\d{4}-\d{2}$/.test(to)) bad('Choose the months to copy from and to.');
  if (from === to) bad('Choose two different months.');
  const src = db.prepare('SELECT * FROM mrg_rates WHERE month=?').all(from);
  if (!src.length) bad(`There are no rates in ${from} to copy.`);
  let created = 0, skipped = 0;
  const ins = db.prepare(`INSERT OR IGNORE INTO mrg_rates(month,carrier_id,pol_id,pod_id,container_type_id,freight_rate,slot_cost,currency,committed_slots,remarks,created_by)
    VALUES(?,?,?,?,?,?,?,?,?,?,?)`);
  db.transaction(() => {
    for (const r of src) {
      const info = ins.run(to, r.carrier_id, r.pol_id, r.pod_id, r.container_type_id, round2(r.freight_rate * (1 + freight_pct / 100)), round2(r.slot_cost * (1 + slot_pct / 100)), r.currency, r.committed_slots, r.remarks, user.id);
      if (info.changes) created++; else skipped++;
    }
  })();
  audit(user, 'MRG_ROLL', 'mrg', to, { from, created, skipped, freight_pct, slot_pct });
  return { created, skipped };
}

// build the month from the tariff book: selling ocean-freight tariffs (SELL) against carrier buy tariffs (BUY) on the same lane and container type
function fromTariffs(month, user) {
  if (!/^\d{4}-\d{2}$/.test(month)) bad('Choose a month.');
  const start = month + '-01', end = monthEnd(month);
  const valid = 'AND (t.valid_from IS NULL OR t.valid_from<=@end) AND (t.valid_to IS NULL OR t.valid_to>=@start) AND t.active=1';
  const sells = db.prepare(`SELECT t.* FROM tariffs t JOIN charge_codes c ON c.id=t.charge_code_id WHERE t.rate_type='SELL' AND t.cargo_type='FCL' AND c.code='OF'
    AND t.pol_id IS NOT NULL AND t.pod_id IS NOT NULL AND t.container_type_id IS NOT NULL ${valid}`).all({ start, end });
  if (!sells.length) bad('There are no selling ocean-freight tariffs for FCL that are valid in this month. Add them under Rates / tariffs first.');
  let created = 0, exists = 0, noBuy = 0;
  const buyQ = db.prepare(`SELECT t.* FROM tariffs t JOIN charge_codes c ON c.id=t.charge_code_id WHERE t.rate_type='BUY' AND t.cargo_type='FCL' AND c.code='OF'
    AND t.pol_id=@pol AND t.pod_id=@pod AND t.container_type_id=@ty ${valid} ORDER BY t.valid_from DESC, t.id DESC LIMIT 1`);
  const ins = db.prepare(`INSERT OR IGNORE INTO mrg_rates(month,carrier_id,pol_id,pod_id,container_type_id,freight_rate,slot_cost,currency,remarks,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)`);
  db.transaction(() => {
    for (const s of sells) {
      const b = buyQ.get({ pol: s.pol_id, pod: s.pod_id, ty: s.container_type_id, start, end });
      let slot = 0, cur = s.currency, note = 'Freight from tariff book';
      if (b) { cur = s.currency; slot = b.currency === s.currency ? b.rate : (() => { try { return L.convert(b.rate, b.currency, s.currency, start); } catch { return b.rate; } })(); note = 'Auto-filled from the tariff book'; }
      else { noBuy++; note = 'Slot cost not in tariff book - please enter'; }
      const info = ins.run(month, b ? b.party_id : null, s.pol_id, s.pod_id, s.container_type_id, s.rate, round2(slot), cur, note, user.id);
      if (info.changes) created++; else exists++;
    }
  })();
  audit(user, 'MRG_FROM_TARIFFS', 'mrg', month, { created, exists, noBuy });
  return { created, exists, missing_slot_cost: noBuy };
}

// ---------------------------------------------------------------- import
function buildPlan(table) {
  const map = table.map;
  for (const [k, msg] of [['month', 'Month'], ['freight_rate', 'Freight rate'], ['slot_cost', 'Slot cost'], ['type', 'Container type']]) if (!(k in map)) return { rows: [], map, summary: { total: 0 }, problem: `No "${msg}" column was found. Choose which column holds it.` };
  const types = db.prepare('SELECT * FROM container_types').all();
  const findPort = sch.portMatcher(), findCarrier = sch.carrierMatcher();
  const curOk = new Set(db.prepare('SELECT code FROM currencies WHERE active=1').all().map((c) => c.code));
  const num = (s) => { const n = Number(String(s).replace(/[, ]/g, '')); return String(s).trim() === '' || Number.isNaN(n) ? null : n; };
  const out = [], seen = new Set();
  table.dataRows.forEach((raw, i) => {
    if (raw.every((v) => !String(v).trim())) return;
    const g = (f) => T.pick(raw, map, f);
    const r = { line: table.rowOffset + i, action: 'ERROR', level: 'error', messages: [] };
    out.push(r);
    const err = (m) => { r.messages.push(m); return r; };
    const month = monthOf(g('month')); if (!month) return err(`Month "${g('month')}" is not understood (use e.g. 2026-03 or Mar 2026)`);
    const ty = inv.mapType(g('type'), types); if (!ty) return err(`Container type "${g('type')}" is not understood`);
    const fr = num(g('freight_rate')), sl = num(g('slot_cost'));
    if (fr == null || fr < 0) return err(`Freight rate "${g('freight_rate')}" is not a number`);
    if (sl == null || sl < 0) return err(`Slot cost "${g('slot_cost')}" is not a number`);
    r.level = 'ok';
    const polT = g('pol'), podT = g('pod'), pol = findPort(polT), pod = findPort(podT);
    if (polT && !pol) return err(`Port of loading "${polT}" is not in your port list`);
    if (podT && !pod) return err(`Port of discharge "${podT}" is not in your port list`);
    const carT = g('carrier'), car = carT ? findCarrier(carT) : null;
    if (carT && !car) { r.messages.push(`Carrier "${carT}" is not a known carrier - left blank`); r.level = 'warn'; }
    let cur = (g('currency') || 'USD').toUpperCase(); if (!curOk.has(cur)) { r.messages.push(`Currency "${cur}" is not set up - USD used`); r.level = 'warn'; cur = 'USD'; }
    const cs = num(g('committed_slots'));
    const val = { month, carrier_id: car ? car.id : null, pol_id: pol ? pol.id : null, pod_id: pod ? pod.id : null, container_type_id: ty.type.id, freight_rate: fr, slot_cost: sl, currency: cur,
      committed_slots: cs != null && cs >= 0 ? Math.round(cs) : null, remarks: g('remarks') || null };
    Object.assign(r, { month, pol_name: pol ? pol.name : '', pod_name: pod ? pod.name : '', type_code: ty.type.code, carrier_name: car ? car.name : '', freight_rate: fr, slot_cost: sl, currency: cur, margin: round2(fr - sl) });
    const key = [month, val.carrier_id || 0, val.pol_id || 0, val.pod_id || 0, val.container_type_id].join('|');
    if (seen.has(key)) { r.messages.push('Same month / lane / type appears twice - the later row wins'); r.level = 'warn'; }
    seen.add(key);
    const cur0 = db.prepare(`SELECT * FROM mrg_rates WHERE month=? AND COALESCE(carrier_id,0)=? AND COALESCE(pol_id,0)=? AND COALESCE(pod_id,0)=? AND COALESCE(container_type_id,0)=?`)
      .get(month, val.carrier_id || 0, val.pol_id || 0, val.pod_id || 0, val.container_type_id);
    if (!cur0) r.action = 'CREATE';
    else if (cur0.freight_rate !== fr || cur0.slot_cost !== sl || cur0.currency !== cur) { r.action = 'UPDATE'; r.messages.push(`Was freight ${cur0.freight_rate} / slot ${cur0.slot_cost}`); }
    else { r.action = 'NOCHANGE'; r.messages.push('Already the same'); }
    r._exec = { val, cur: cur0 };
  });
  const s = { total: out.length, create: 0, update: 0, nochange: 0, error: 0, warn: 0 };
  for (const r of out) { if (r.action === 'CREATE') s.create++; else if (r.action === 'UPDATE') s.update++; else if (r.action === 'NOCHANGE') s.nochange++; else s.error++; if (r.level === 'warn') s.warn++; }
  s.ready = s.create + s.update;
  return { rows: out, map, summary: s };
}
function commitPlan(plan, user) {
  const res = { created: 0, updated: 0 };
  db.transaction(() => {
    for (const r of plan.rows) {
      if (!r._exec) continue;
      const { val, cur } = r._exec;
      if (r.action === 'CREATE') { db.prepare(`INSERT OR REPLACE INTO mrg_rates(month,carrier_id,pol_id,pod_id,container_type_id,freight_rate,slot_cost,currency,committed_slots,remarks,created_by)
        VALUES(@month,@carrier_id,@pol_id,@pod_id,@container_type_id,@freight_rate,@slot_cost,@currency,@committed_slots,@remarks,@by)`).run({ ...val, by: user.id }); res.created++; }
      else if (r.action === 'UPDATE') { db.prepare(`UPDATE mrg_rates SET freight_rate=?, slot_cost=?, currency=?, committed_slots=COALESCE(?,committed_slots), remarks=COALESCE(?,remarks), updated_at=datetime('now') WHERE id=?`)
        .run(val.freight_rate, val.slot_cost, val.currency, val.committed_slots, val.remarks, cur.id); res.updated++; }
    }
  })();
  return res;
}

module.exports = { ALIASES, FIELDS, rows, summary, matrix, rollForward, fromTariffs, buildPlan, commitPlan, monthOf, shiftMonth, monthEnd, decorate };
