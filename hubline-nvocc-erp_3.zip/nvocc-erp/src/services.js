'use strict';
const { db, round2, nextNo, audit, today, addDays } = require('./db');
const L = require('./logic');
const { bad } = require('./util');

// Create a finance document (INV / DN / CN / BILL / COMM) with its lines.
function createDocument(d, user) {
  if (!L.DOC_LABEL[d.doc_type]) bad('Unknown document type.');
  const party = db.prepare('SELECT * FROM parties WHERE id=?').get(d.party_id);
  if (!party) bad('Choose a customer / agent / vendor for this document.');
  if (!d.currency || !db.prepare('SELECT 1 FROM currencies WHERE code=? AND active=1').get(d.currency)) bad('Choose a valid currency.');
  const doc_date = d.doc_date || today();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(doc_date)) bad('Invalid document date.');
  const due = d.due_date || addDays(doc_date, ['BILL', 'COMM'].includes(d.doc_type) ? 0 : (party.credit_days || 0));
  const lines = normaliseLines(d.lines);
  if (d.shipment_id && !db.prepare('SELECT 1 FROM shipments WHERE id=?').get(d.shipment_id)) bad('Shipment not found.');
  const t = L.computeLines(lines);
  const fx = L.fxRate(d.currency, doc_date) || 1;
  const tx = db.transaction(() => {
    const id = db.prepare(`INSERT INTO documents(doc_type,party_id,shipment_id,doc_date,due_date,currency,fx_rate,subtotal,vat_amount,total,status,party_ref,narration,created_by)
      VALUES(?,?,?,?,?,?,?,?,?,?, 'DRAFT', ?,?,?)`)
      .run(d.doc_type, d.party_id, d.shipment_id || null, doc_date, due, d.currency, fx, t.subtotal, t.vat_amount, t.total, d.party_ref || null, d.narration || null, user ? user.id : null).lastInsertRowid;
    writeLines(id, t.lines);
    audit(user, 'CREATE', 'document', id, { type: d.doc_type, party_id: d.party_id, total: t.total, currency: d.currency });
    return id;
  });
  const id = tx();
  if (d.post) postDocument(id, user);
  return id;
}

function normaliseLines(lines) {
  if (!Array.isArray(lines) || !lines.length) bad('Add at least one line.');
  return lines.map((l, i) => {
    if (!String(l.description || '').trim()) bad(`Line ${i + 1}: description is required.`);
    const qty = Number(l.qty), rate = Number(l.rate);
    if (!(qty > 0)) bad(`Line ${i + 1}: quantity must be greater than zero.`);
    if (Number.isNaN(rate) || rate < 0) bad(`Line ${i + 1}: rate cannot be negative.`);
    const vat = Number(l.vat_rate || 0);
    if (vat < 0 || vat > 100) bad(`Line ${i + 1}: VAT rate must be between 0 and 100.`);
    return { charge_code_id: l.charge_code_id ? Number(l.charge_code_id) : null, description: String(l.description).trim(), qty, unit: l.unit || null, rate, vat_rate: vat };
  });
}

function writeLines(docId, lines) {
  db.prepare('DELETE FROM document_lines WHERE document_id=?').run(docId);
  const ins = db.prepare('INSERT INTO document_lines(document_id,charge_code_id,description,qty,unit,rate,amount,vat_rate,vat_amount) VALUES(?,?,?,?,?,?,?,?,?)');
  for (const l of lines) ins.run(docId, l.charge_code_id, l.description, l.qty, l.unit, l.rate, l.amount, l.vat_rate, l.vat_amount);
}

function updateDraftDocument(id, d, user) {
  const cur = db.prepare('SELECT * FROM documents WHERE id=?').get(id);
  if (!cur) bad('Document not found', 404);
  if (cur.status !== 'DRAFT') bad('Only draft documents can be edited. Cancel it or issue a credit note instead.');
  const lines = normaliseLines(d.lines);
  const t = L.computeLines(lines);
  const doc_date = d.doc_date || cur.doc_date;
  db.transaction(() => {
    db.prepare(`UPDATE documents SET party_id=?, shipment_id=?, doc_date=?, due_date=?, currency=?, fx_rate=?, subtotal=?, vat_amount=?, total=?, party_ref=?, narration=? WHERE id=?`)
      .run(d.party_id || cur.party_id, d.shipment_id || null, doc_date, d.due_date || cur.due_date, d.currency || cur.currency, L.fxRate(d.currency || cur.currency, doc_date) || 1,
        t.subtotal, t.vat_amount, t.total, d.party_ref || null, d.narration || null, id);
    writeLines(id, t.lines);
  })();
  audit(user, 'UPDATE', 'document', id, { total: t.total });
}

function postDocument(id, user) {
  const d = db.prepare('SELECT * FROM documents WHERE id=?').get(id);
  if (!d) bad('Document not found', 404);
  if (d.status !== 'DRAFT') bad('Only draft documents can be posted.');
  const lines = db.prepare('SELECT * FROM document_lines WHERE document_id=?').all(id);
  if (!lines.length) bad('Add at least one line before posting.');
  const t = L.computeLines(lines);
  if (!(t.total > 0)) bad('The document total must be greater than zero.');
  const fx = L.fxRate(d.currency, d.doc_date);
  if (!fx) bad(`No exchange rate for ${d.currency}. Add it under Setup > Exchange rates first.`);
  db.transaction(() => {
    const no = d.doc_no || nextNo(d.doc_type, d.doc_date);
    db.prepare("UPDATE documents SET doc_no=?, fx_rate=?, subtotal=?, vat_amount=?, total=?, status='POSTED', posted_at=datetime('now') WHERE id=?")
      .run(no, fx, t.subtotal, t.vat_amount, t.total, id);
  })();
  const no = db.prepare('SELECT doc_no FROM documents WHERE id=?').get(id).doc_no;
  audit(user, 'POST', 'document', id, { doc_no: no, total: t.total, currency: d.currency });
  return no;
}

function cancelDocument(id, user, reason) {
  const d = db.prepare('SELECT * FROM documents WHERE id=?').get(id);
  if (!d) bad('Document not found', 404);
  if (d.status === 'CANCELLED') bad('Already cancelled.');
  if (d.status === 'POSTED') {
    const used = db.prepare(`SELECT COUNT(*) n FROM allocations WHERE to_doc_id=? OR (from_type='DOC' AND from_id=?)`).get(id, id).n;
    if (used) bad('This document has payments or credit notes applied to it. Remove those allocations first (cancel the receipt/payment).');
    const stmt = db.prepare("SELECT stmt_no FROM commission_statements WHERE document_id=? AND status='POSTED'").get(id);
    if (stmt) bad(`This document belongs to commission statement ${stmt.stmt_no}. Cancel the statement instead.`);
  }
  db.prepare("UPDATE documents SET status='CANCELLED' WHERE id=?").run(id);
  audit(user, 'CANCEL', 'document', id, reason || null);
}

module.exports = { createDocument, updateDraftDocument, postDocument, cancelDocument, writeLines, normaliseLines };
