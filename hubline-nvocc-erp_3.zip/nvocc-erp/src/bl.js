'use strict';
// Bills of lading: the register (list), one full BL, and the rules for who may edit what.
const { db } = require('./db');
const A = require('./auth');
const S = require('./scope');
const L = require('./logic');

const firstLine = (s) => String(s || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean)[0] || '';

// fields an agent may change on their own BL (never the billing customer, agent, consol, remarks ...)
const AGENT_FIELDS = ['shipper_text', 'consignee_text', 'notify_text', 'place_of_receipt', 'place_of_delivery', 'commodity', 'marks', 'packages', 'package_type', 'gross_weight', 'cbm'];
// extra fields an agent may set when creating a booking request
const AGENT_NEW_FIELDS = [...AGENT_FIELDS, 'cargo_type', 'pol_id', 'pod_id', 'vessel', 'voyage', 'etd', 'eta', 'freight_terms', 'incoterm', 'carrier_id'];
// fields staff may change from the BL screen
const STAFF_FIELDS = ['shipper_id', 'consignee_id', 'notify_id', 'shipper_text', 'consignee_text', 'notify_text', 'pol_id', 'pod_id', 'place_of_receipt', 'place_of_delivery',
  'vessel', 'voyage', 'etd', 'eta', 'carrier_id', 'freight_terms', 'incoterm', 'commodity', 'marks', 'packages', 'package_type', 'gross_weight', 'cbm', 'remarks', 'cargo_type'];

const FROM = `FROM shipments s
  LEFT JOIN parties cu ON cu.id=s.customer_id LEFT JOIN parties sh ON sh.id=s.shipper_id LEFT JOIN parties co ON co.id=s.consignee_id
  LEFT JOIN parties nt ON nt.id=s.notify_id LEFT JOIN parties ag ON ag.id=s.agent_id LEFT JOIN parties ca ON ca.id=s.carrier_id
  LEFT JOIN ports pl ON pl.id=s.pol_id LEFT JOIN ports pd ON pd.id=s.pod_id LEFT JOIN consols k ON k.id=s.consol_id`;

function blRows(u, q = {}) {
  const w = [], p = {};
  const sc = S.shipmentSql(u); if (sc) w.push(sc);
  if (q.q) {
    w.push(`(s.booking_no LIKE @q OR s.hbl_no LIKE @q OR k.mbl_no LIKE @q OR sh.name LIKE @q OR s.shipper_text LIKE @q OR co.name LIKE @q OR s.consignee_text LIKE @q OR nt.name LIKE @q OR s.notify_text LIKE @q
      OR s.vessel LIKE @q OR s.commodity LIKE @q OR EXISTS(SELECT 1 FROM shipment_containers x JOIN containers c ON c.id=x.container_id WHERE x.shipment_id=s.id AND c.container_no LIKE @q))`);
    p.q = `%${q.q}%`;
  }
  if (q.status) { w.push('s.status=@st'); p.st = q.status; }
  if (q.open === '1') w.push("s.status NOT IN ('CLOSED','CANCELLED')");
  if (q.issued === '1') w.push('s.hbl_no IS NOT NULL');
  if (q.agent_id && !S.isAgent(u)) { w.push('s.agent_id=@ag'); p.ag = q.agent_id; }
  if (q.vessel) { w.push('s.vessel LIKE @ve'); p.ve = `%${q.vessel}%`; }
  if (q.from) { w.push('COALESCE(s.etd, substr(s.created_at,1,10))>=@from'); p.from = q.from; }
  if (q.to) { w.push('COALESCE(s.etd, substr(s.created_at,1,10))<=@to'); p.to = q.to; }
  if (q.incomplete === '1') w.push("s.status IN ('BOOKED','CONFIRMED') AND ((COALESCE(s.shipper_text,'')='' AND s.shipper_id IS NULL) OR (COALESCE(s.consignee_text,'')='' AND s.consignee_id IS NULL) OR COALESCE(s.commodity,'')='' OR s.gross_weight IS NULL)");
  if (q.review === '1' && !S.isAgent(u)) w.push('s.agent_edit_at IS NOT NULL AND (s.reviewed_at IS NULL OR s.reviewed_at < s.agent_edit_at)');
  const staff = !S.isAgent(u);
  const rows = db.prepare(`SELECT s.id, s.booking_no, s.hbl_no, s.status, s.cargo_type, s.agent_id, ag.name AS agent_name, ${staff ? 'cu.name AS customer_name,' : ''}
      COALESCE(sh.name, s.shipper_text) AS shipper, COALESCE(co.name, s.consignee_text) AS consignee, COALESCE(nt.name, s.notify_text) AS notify,
      pl.name AS pol_name, pd.name AS pod_name, s.vessel, s.voyage, s.etd, s.eta, s.commodity, s.packages, s.package_type, s.gross_weight, s.cbm, s.freight_terms, s.incoterm, k.mbl_no, k.consol_no,
      s.agent_edit_at, s.agent_edit_by, s.reviewed_at,
      (s.agent_edit_at IS NOT NULL AND (s.reviewed_at IS NULL OR s.reviewed_at < s.agent_edit_at)) AS needs_review,
      (SELECT COUNT(*) FROM shipment_containers x WHERE x.shipment_id=s.id) AS container_count,
      (SELECT group_concat(c.container_no, ', ') FROM shipment_containers x JOIN containers c ON c.id=x.container_id WHERE x.shipment_id=s.id) AS container_nos
    ${FROM} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY s.id DESC LIMIT ${Math.min(parseInt(q.limit || '500', 10) || 500, 5000)}`).all(p);
  for (const r of rows) { r.shipper = firstLine(r.shipper); r.consignee = firstLine(r.consignee); r.notify = firstLine(r.notify); r.needs_review = !!r.needs_review; }
  return rows;
}

// who can change this BL right now, and why not
function editRights(u, s) {
  if (!A.can(u.role, 'bl', 'write')) return { edit: false, reason: 'Your role cannot edit bills of lading.' };
  if (['CLOSED', 'CANCELLED'].includes(s.status)) return { edit: false, reason: `A ${s.status.toLowerCase()} shipment cannot be edited.` };
  if (S.isAgent(u)) {
    if (!S.ownsShipment(u, s)) return { edit: false, reason: 'This is not your shipment.' };
    if (!['BOOKED', 'CONFIRMED'].includes(s.status)) return { edit: false, reason: 'The vessel has sailed - ask HUB LINE documentation to amend the BL.' };
    return { edit: true, fields: AGENT_FIELDS };
  }
  return { edit: true, fields: STAFF_FIELDS };
}

function blFull(u, id) {
  const s = db.prepare(`SELECT s.*, cu.name AS customer_name, sh.name AS shipper_name, co.name AS consignee_name, nt.name AS notify_name,
      sh.address AS shipper_address, co.address AS consignee_address, nt.address AS notify_address,
      ag.name AS agent_name, ca.name AS carrier_name, pl.name AS pol_name, pd.name AS pod_name, k.consol_no, k.mbl_no
    ${FROM} WHERE s.id=?`).get(id);
  if (!s || !S.ownsShipment(u, s)) return null;
  s.containers = db.prepare(`SELECT sc.*, c.container_no, c.status, c.location, t.code AS type_code, t.teu FROM shipment_containers sc
    JOIN containers c ON c.id=sc.container_id JOIN container_types t ON t.id=c.type_id WHERE sc.shipment_id=? ORDER BY c.container_no`).all(s.id);
  for (const c of s.containers) c.status_label = (L.CONTAINER_STATUS[c.status] || {}).label || c.status;
  s.needs_review = !!(s.agent_edit_at && (!s.reviewed_at || s.reviewed_at < s.agent_edit_at));
  s.rights = editRights(u, s);
  if (S.isAgent(u)) { delete s.customer_name; delete s.customer_id; delete s.remarks; }
  return s;
}

module.exports = { blRows, blFull, editRights, AGENT_FIELDS, AGENT_NEW_FIELDS, STAFF_FIELDS };
