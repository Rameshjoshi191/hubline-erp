'use strict';
// Vessel schedules: import plan (Excel / CSV / pasted / web link), saved link sources, change tracking and pushing changes to operations.
const http = require('http');
const https = require('https');
const dns = require('dns');
const net = require('net');
const { db, audit, getSetting, today, addDays } = require('./db');
const T = require('./tabular');
const { bad } = require('./util');

const ALIASES = {
  carrier: ['carrier', 'line', 'shipping line', 'operator', 'service provider', 'liner', 'carrier name'],
  service: ['service', 'service name', 'loop', 'string', 'rotation', 'service code'],
  vessel: ['vessel', 'vessel name', 'ship', 'mother vessel', 'vsl', 'vessel / voyage name', 'ship name'],
  voyage: ['voyage', 'voy', 'voyage no', 'voy no', 'voyage number', 'voyage ref', 'voy.', 'voyage code'],
  pol: ['pol', 'port of loading', 'load port', 'loading port', 'origin', 'from', 'departure port', 'origin port'],
  pod: ['pod', 'port of discharge', 'discharge port', 'destination', 'to', 'arrival port', 'dest', 'destination port'],
  cutoff_date: ['cut off', 'cutoff', 'cy cut off', 'cy cutoff', 'cy cut-off', 'closing', 'closing date', 'cargo cutoff', 'cargo cut off', 'cut-off date', 'cutoff date', 'gate cut off', 'port cut off'],
  etd: ['etd', 'departure', 'sailing', 'sailing date', 'departure date', 'etd pol', 'etd date', 'sails', 'depart'],
  eta: ['eta', 'arrival', 'arrival date', 'eta pod', 'eta date', 'arrives', 'arrive'],
  transit_days: ['transit', 'transit days', 'transit time', 'tt', 'days'],
  remarks: ['remarks', 'remark', 'notes', 'note', 'comment', 'comments'],
};
const FIELDS = [
  { key: 'vessel', label: 'Vessel', required: true }, { key: 'voyage', label: 'Voyage' }, { key: 'pol', label: 'Port of loading' }, { key: 'pod', label: 'Port of discharge' },
  { key: 'etd', label: 'ETD (sailing)', required: true }, { key: 'eta', label: 'ETA' }, { key: 'cutoff_date', label: 'Cut-off' }, { key: 'carrier', label: 'Carrier / line' },
  { key: 'service', label: 'Service / loop' }, { key: 'transit_days', label: 'Transit days' }, { key: 'remarks', label: 'Remarks' },
];

const nrm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

// ---------------------------------------------------------------- port & carrier matching
function portMatcher() {
  const ports = db.prepare('SELECT id, code, name FROM ports').all();
  const cache = new Map();
  return (text) => {
    const raw = String(text || '').trim();
    if (!raw) return null;
    if (cache.has(raw)) return cache.get(raw);
    let hit = null;
    const code = /\b([A-Za-z]{2}[A-Za-z0-9]{3})\b/.exec(raw.replace(/[()]/g, ' '));
    if (code) hit = ports.find((p) => p.code === code[1].toUpperCase());
    const n = nrm(raw);
    if (!hit) hit = ports.find((p) => nrm(p.name) === n);
    if (!hit) hit = ports.find((p) => n.length > 2 && (n.startsWith(nrm(p.name) + ' ') || nrm(p.name).startsWith(n + ' ') || n === nrm(p.name.split('(')[0])));
    if (!hit) hit = ports.find((p) => nrm(p.name).length > 3 && n.includes(nrm(p.name.split('(')[0])));
    cache.set(raw, hit || null);
    return hit || null;
  };
}
function carrierMatcher() {
  const list = db.prepare('SELECT id, name FROM parties WHERE is_carrier=1').all();
  return (text) => { const n = nrm(text); if (!n) return null; return list.find((p) => nrm(p.name) === n) || list.find((p) => nrm(p.name).includes(n) || n.includes(nrm(p.name))) || null; };
}
const sigOf = (v, pol, pod) => [String(v.vessel).toUpperCase().trim(), String(v.voyage || '').toUpperCase().trim(), pol.id ? 'P' + pol.id : String(pol.text || '').toUpperCase(), pod.id ? 'P' + pod.id : String(pod.text || '').toUpperCase()].join('|');

function dateOf(raw, today0) {
  if (!raw) return { v: null };
  const y = Number(today0.slice(0, 4));
  let p = T.parseDate(raw, { defaultYear: y });
  if (!p) return { err: true };
  if (!/\d{4}/.test(String(raw)) && p < addDays(today0, -180)) p = T.parseDate(raw, { defaultYear: y + 1 });
  return { v: p };
}

// ---------------------------------------------------------------- plan
function buildPlan(table, options = {}) {
  const map = table.map;
  if (!('vessel' in map)) return { rows: [], map, summary: { total: 0 }, problem: 'No "Vessel" column was found. Choose which column holds the vessel name.' };
  if (!('etd' in map) && !('eta' in map)) return { rows: [], map, summary: { total: 0 }, problem: 'No date column was found. Choose which column holds the ETD (sailing date).' };
  const findPort = portMatcher(), findCarrier = carrierMatcher(), t0 = today();
  const defCarrier = options.carrier_id ? db.prepare('SELECT id, name FROM parties WHERE id=?').get(options.carrier_id) : null;
  const rows = [], seen = new Set();
  const get = db.prepare('SELECT * FROM vessel_schedules WHERE sig=?');
  table.dataRows.forEach((raw, i) => {
    const g = (f) => T.pick(raw, map, f);
    if (raw.every((v) => !String(v).trim())) return;
    const r = { line: table.rowOffset + i, action: 'ERROR', level: 'error', messages: [], vessel: g('vessel').toUpperCase(), voyage: g('voyage').toUpperCase() };
    rows.push(r);
    const err = (m) => { r.messages.push(m); return r; };
    if (!r.vessel) return err('Vessel name is empty');
    const e = dateOf(g('etd'), t0), a = dateOf(g('eta'), t0), c = dateOf(g('cutoff_date'), t0);
    if (e.err) return err(`ETD "${g('etd')}" is not a date`); if (a.err) return err(`ETA "${g('eta')}" is not a date`); if (c.err) return err(`Cut-off "${g('cutoff_date')}" is not a date`);
    r.etd = e.v; r.eta = a.v; r.cutoff_date = c.v;
    if (!r.etd && !r.eta) return err('Needs an ETD or an ETA');
    if (r.etd && r.eta && r.eta < r.etd) return err('ETA is before ETD');
    r.level = 'ok';
    const pol = findPort(g('pol')), pod = findPort(g('pod'));
    const polT = g('pol'), podT = g('pod');
    if (polT && !pol) { r.messages.push(`Port "${polT}" is not in your port list - kept as text`); r.level = 'warn'; }
    if (podT && !pod) { r.messages.push(`Port "${podT}" is not in your port list - kept as text`); r.level = 'warn'; }
    r.pol_name = pol ? pol.name : polT; r.pod_name = pod ? pod.name : podT;
    const carT = g('carrier'); const car = carT ? findCarrier(carT) : defCarrier;
    if (carT && !car) { r.messages.push(`Carrier "${carT}" is not a known carrier - kept as text`); r.level = 'warn'; }
    r.carrier_name = car ? car.name : carT;
    const val = { vessel: r.vessel, voyage: r.voyage, carrier_id: car ? car.id : null, carrier_text: car ? null : (carT || null), service: g('service') || null,
      pol_id: pol ? pol.id : null, pol_text: pol ? null : (polT || null), pod_id: pod ? pod.id : null, pod_text: pod ? null : (podT || null),
      cutoff_date: r.cutoff_date, etd: r.etd, eta: r.eta, transit_days: null, remarks: g('remarks') || null };
    const td = parseInt(g('transit_days'), 10);
    val.transit_days = !Number.isNaN(td) && td > 0 ? td : (r.etd && r.eta ? Math.round((new Date(r.eta) - new Date(r.etd)) / 86400000) : null);
    const sig = sigOf(val, { id: val.pol_id, text: val.pol_text }, { id: val.pod_id, text: val.pod_text });
    if (seen.has(sig)) { r.messages.push('Same vessel / voyage / route appears twice in the file - the later row wins'); r.level = 'warn'; }
    seen.add(sig);
    const cur = get.get(sig);
    if (!cur) { r.action = 'CREATE'; }
    else {
      const ch = {};
      for (const k of ['etd', 'eta', 'cutoff_date']) if (val[k] && val[k] !== cur[k]) ch[k] = { from: cur[k], to: val[k] };
      for (const k of ['service', 'remarks', 'carrier_id']) if (val[k] && val[k] !== cur[k]) ch[k] = { from: cur[k], to: val[k] };
      if (Object.keys(ch).length) {
        r.action = 'UPDATE'; r.changes = ch;
        const dch = Object.entries(ch).filter(([k]) => ['etd', 'eta', 'cutoff_date'].includes(k)).map(([k, v]) => `${k.replace('_date', '').toUpperCase()} ${v.from || '-'} to ${v.to}`).join(', ');
        r.messages.push(dch ? 'Changes: ' + dch : 'Details updated');
      }
      else { r.action = 'NOCHANGE'; r.messages.push('Already up to date'); }
    }
    r._exec = { sig, val, cur };
  });
  const summary = { total: rows.length, create: 0, update: 0, nochange: 0, error: 0, warn: 0 };
  for (const r of rows) { if (r.action === 'CREATE') summary.create++; else if (r.action === 'UPDATE') summary.update++; else if (r.action === 'NOCHANGE') summary.nochange++; else summary.error++; if (r.level === 'warn') summary.warn++; }
  summary.ready = summary.create + summary.update;
  const srcOk = options.source_id && db.prepare('SELECT 1 FROM schedule_sources WHERE id=?').get(options.source_id);
  return { rows, map, summary, opt: { carrier_id: options.carrier_id || '', source_id: srcOk ? Number(options.source_id) : null, source: srcOk ? 'LINK' : 'IMPORT' } };
}

function commitPlan(plan, user, { source = 'IMPORT', source_id = null } = {}) {
  const out = { created: 0, updated: 0, changes: 0, applied: { consols: 0, shipments: 0 } };
  const autoApply = getSetting('auto_apply_schedule_changes', '') === '1';
  db.transaction(() => {
    for (const r of plan.rows) {
      if (!r._exec || !['CREATE', 'UPDATE'].includes(r.action)) continue;
      const { sig, val, cur } = r._exec;
      if (!cur) {
        db.prepare(`INSERT INTO vessel_schedules(sig,carrier_id,carrier_text,service,vessel,voyage,pol_id,pol_text,pod_id,pod_text,cutoff_date,etd,eta,transit_days,remarks,source,source_id)
          VALUES(@sig,@carrier_id,@carrier_text,@service,@vessel,@voyage,@pol_id,@pol_text,@pod_id,@pod_text,@cutoff_date,@etd,@eta,@transit_days,@remarks,@source,@source_id)
          ON CONFLICT(sig) DO NOTHING`).run({ sig, ...val, source, source_id });
        out.created++;
      } else {
        const now = db.prepare('SELECT * FROM vessel_schedules WHERE sig=?').get(sig);
        db.prepare(`UPDATE vessel_schedules SET carrier_id=COALESCE(@carrier_id,carrier_id), carrier_text=COALESCE(@carrier_text,carrier_text), service=COALESCE(@service,service),
          cutoff_date=COALESCE(@cutoff_date,cutoff_date), etd=COALESCE(@etd,etd), eta=COALESCE(@eta,eta), transit_days=COALESCE(@transit_days,transit_days), remarks=COALESCE(@remarks,remarks),
          active=1, updated_at=datetime('now') WHERE sig=@sig`).run({ sig, ...val });
        out.updated++;
        let changed = false;
        for (const k of ['etd', 'eta', 'cutoff_date']) if (val[k] && val[k] !== now[k]) {
          db.prepare('INSERT INTO schedule_changes(schedule_id,field,old_value,new_value) VALUES(?,?,?,?)').run(now.id, k, now[k], val[k]); out.changes++; changed = true;
        }
        if (changed && autoApply) { const ap = applyToOperations(now.id, user); out.applied.consols += ap.consols; out.applied.shipments += ap.shipments; }
      }
    }
  })();
  return out;
}

// ---------------------------------------------------------------- pushing a schedule (new dates) into consols / bookings that use the same vessel + voyage
function affected(sc) {
  if (!sc.voyage) return { consols: [], shipments: [] };
  const consols = db.prepare(`SELECT id, consol_no, etd, eta, cutoff_date FROM consols WHERE upper(vessel)=upper(?) AND upper(voyage)=upper(?) AND status IN ('PLANNED','CLOSED')
    AND (? IS NULL OR pol_id IS NULL OR pol_id=?)`).all(sc.vessel, sc.voyage, sc.pol_id, sc.pol_id);
  const shipments = db.prepare(`SELECT id, booking_no, etd, eta FROM shipments WHERE consol_id IS NULL AND upper(vessel)=upper(?) AND upper(voyage)=upper(?) AND status IN ('BOOKED','CONFIRMED')
    AND (? IS NULL OR pol_id IS NULL OR pol_id=?)`).all(sc.vessel, sc.voyage, sc.pol_id, sc.pol_id);
  return { consols, shipments };
}
function applyToOperations(scheduleId, user) {
  const sc = db.prepare('SELECT * FROM vessel_schedules WHERE id=?').get(scheduleId);
  if (!sc) return { consols: 0, shipments: 0 };
  const a = affected(sc);
  let nC = 0, nS = 0;
  db.transaction(() => {
    for (const k of a.consols) {
      db.prepare('UPDATE consols SET etd=COALESCE(?,etd), eta=COALESCE(?,eta), cutoff_date=COALESCE(?,cutoff_date) WHERE id=?').run(sc.etd, sc.eta, sc.cutoff_date, k.id);
      db.prepare("UPDATE shipments SET etd=COALESCE(?,etd), eta=COALESCE(?,eta) WHERE consol_id=? AND status IN ('BOOKED','CONFIRMED')").run(sc.etd, sc.eta, k.id);
      audit(user, 'SCHEDULE_UPDATE', 'consol', k.id, { etd: sc.etd, eta: sc.eta, cutoff: sc.cutoff_date, vessel: sc.vessel, voyage: sc.voyage });
      nC++;
    }
    for (const s of a.shipments) {
      db.prepare('UPDATE shipments SET etd=COALESCE(?,etd), eta=COALESCE(?,eta) WHERE id=?').run(sc.etd, sc.eta, s.id);
      audit(user, 'SCHEDULE_UPDATE', 'shipment', s.id, { etd: sc.etd, eta: sc.eta, vessel: sc.vessel, voyage: sc.voyage });
      nS++;
    }
    db.prepare('UPDATE schedule_changes SET applied=1 WHERE schedule_id=? AND applied=0').run(sc.id);
  })();
  return { consols: nC, shipments: nS };
}

// ---------------------------------------------------------------- reading a web link (spreadsheet file or HTML table) safely
const ALLOW_PRIVATE = process.env.ALLOW_PRIVATE_FETCH === '1';   // for automated tests only
function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)
      || (a === 192 && b === 0) || (a === 198 && (b === 18 || b === 19)) || a >= 224;
  }
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase();
    const m = /^::ffff:(\d+\.\d+\.\d+\.\d+)$/.exec(l);
    if (m) return isPrivateIp(m[1]);
    return l === '::1' || l === '::' || l.startsWith('fe8') || l.startsWith('fe9') || l.startsWith('fea') || l.startsWith('feb') || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('ff');
  }
  return true;
}
function safeLookup(hostname, options, cb) {
  if (typeof options === 'function') { cb = options; options = {}; }
  dns.lookup(hostname, { ...options, all: true }, (err, addrs) => {
    if (err) return cb(err);
    if (!ALLOW_PRIVATE && addrs.some((a) => isPrivateIp(a.address))) return cb(new Error('That address is not allowed (it points to a private network).'));
    if (options && options.all) return cb(null, addrs);
    cb(null, addrs[0].address, addrs[0].family);
  });
}
function fetchOnce(url, timeoutMs, maxBytes) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(url); } catch { return reject(new Error('That is not a valid web address.')); }
    if (!['http:', 'https:'].includes(u.protocol)) return reject(new Error('Only http:// and https:// links are allowed.'));
    if (u.username || u.password) return reject(new Error('Links with a user name / password are not allowed.'));
    const port = Number(u.port || (u.protocol === 'https:' ? 443 : 80));
    if (!ALLOW_PRIVATE && ![80, 443, 8080, 8443].includes(port)) return reject(new Error('That web port is not allowed.'));
    if (net.isIP(u.hostname.replace(/^\[|\]$/g, '')) && !ALLOW_PRIVATE && isPrivateIp(u.hostname.replace(/^\[|\]$/g, ''))) return reject(new Error('That address is not allowed (it points to a private network).'));
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request(u, { method: 'GET', lookup: safeLookup, timeout: timeoutMs, headers: { 'User-Agent': 'HubLineERP-ScheduleImport/1.0', 'Accept': '*/*', 'Accept-Encoding': 'identity' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) { res.resume(); return resolve({ redirect: new URL(res.headers.location, u).toString() }); }
      if (res.statusCode < 200 || res.statusCode >= 300) { res.resume(); return reject(new Error(`The website answered with an error (${res.statusCode}).`)); }
      const chunks = []; let size = 0;
      res.on('data', (c) => { size += c.length; if (size > maxBytes) { req.destroy(new Error('That file is too large (limit 8 MB).')); } else chunks.push(c); });
      res.on('end', () => resolve({ body: Buffer.concat(chunks), type: String(res.headers['content-type'] || '').toLowerCase(), url: u.toString() }));
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('The website took too long to answer.')));
    req.on('error', (e) => reject(e));
    req.end();
  });
}
async function safeFetch(url, { timeoutMs = 15000, maxBytes = 8 * 1024 * 1024, hops = 4 } = {}) {
  let cur = url;
  for (let i = 0; i <= hops; i++) {
    const r = await fetchOnce(cur, timeoutMs, maxBytes);
    if (r.redirect) { cur = r.redirect; continue; }
    return r;
  }
  throw new Error('The link redirects too many times.');
}

const decodeEntities = (s) => String(s).replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'")
  .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n))).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCharCode(parseInt(n, 16)));
const stripTags = (s) => decodeEntities(String(s).replace(/<br\s*\/?>/gi, ' ').replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
function htmlTables(html) {
  const out = [];
  const tre = /<table[\s\S]*?<\/table>/gi; let m;
  while ((m = tre.exec(html))) {
    const rows = [];
    for (const tr of m[0].match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const cells = (tr.match(/<t[hd][\s\S]*?<\/t[hd]>/gi) || []).map((c) => stripTags(c));
      if (cells.some((c) => c)) rows.push(cells);
    }
    if (rows.length > 1) out.push(rows);
  }
  return out;
}
function fileLinks(html, base) {
  const out = new Set(); const re = /href\s*=\s*["']([^"']+\.(?:xlsx|csv)(?:\?[^"']*)?)["']/gi; let m;
  while ((m = re.exec(html))) { try { out.add(new URL(decodeEntities(m[1]), base).toString()); } catch { /* ignore */ } }
  return [...out].slice(0, 12);
}

// -> { rows } (a table ready for the wizard) or { candidates:[urls] }
async function readLink(url) {
  const r = await safeFetch(url);
  const isFile = /spreadsheetml|excel|csv|octet-stream/.test(r.type) || /\.(xlsx|csv)(\?|$)/i.test(r.url) || (r.body[0] === 0x50 && r.body[1] === 0x4b);
  if (isFile) return { rows: await T.readTable(r.body, /\.csv/i.test(r.url) ? 'x.csv' : /\.xlsx/i.test(r.url) ? 'x.xlsx' : ''), filename: r.url.split('?')[0].split('/').pop() || 'link' };
  const html = r.body.toString('utf8');
  let best = null;
  for (const t of htmlTables(html)) {
    const h = T.detectHeader(t, ALIASES);
    if (h == null) continue;
    const score = Object.keys(T.autoMap(t[h], ALIASES)).length;
    if (score >= 2 && (!best || score > best.score || (score === best.score && t.length > best.rows.length))) best = { rows: t, score };
  }
  if (best) return { rows: best.rows, filename: new URL(r.url).host };
  const c = fileLinks(html, r.url);
  if (c.length) return { candidates: c };
  throw Object.assign(new Error('This page does not contain a schedule table we can read. Many carrier sites build the table with JavaScript. Look for a "Download schedule" (Excel / CSV) link on the site, then paste that file link here - or download the file and upload it.'), { status: 422 });
}

// refresh a saved link source end-to-end (used by the button and by the daily job)
async function refreshSource(src, user) {
  try {
    const r = await readLink(src.url);
    if (!r.rows) throw new Error('The page lists several files - open the link once in the wizard and pick the right file.');
    const table = T.structure(r.rows, ALIASES);
    const plan = buildPlan(table, { carrier_id: src.carrier_id });
    if (plan.problem) throw new Error(plan.problem);
    const res = plan.summary.ready ? commitPlan(plan, user, { source: 'LINK', source_id: src.id }) : { created: 0, updated: 0, changes: 0, applied: { consols: 0, shipments: 0 } };
    db.prepare("UPDATE schedule_sources SET last_run=datetime('now'), last_status=?, last_count=? WHERE id=?").run(`OK - ${res.created} new, ${res.updated} changed, ${plan.summary.nochange} unchanged${plan.summary.error ? `, ${plan.summary.error} rows skipped` : ''}`, plan.summary.total, src.id);
    return { ok: true, ...res, summary: plan.summary };
  } catch (e) {
    db.prepare("UPDATE schedule_sources SET last_run=datetime('now'), last_status=?, last_count=NULL WHERE id=?").run('FAILED - ' + String(e.message).slice(0, 200), src.id);
    return { ok: false, error: e.message };
  }
}

// ---------------------------------------------------------------- listing
function list(q = {}) {
  const w = [], p = {};
  if (q.q) { w.push('(v.vessel LIKE @q OR v.voyage LIKE @q OR v.service LIKE @q OR v.pol_text LIKE @q OR v.pod_text LIKE @q OR pl.name LIKE @q OR pd.name LIKE @q OR ca.name LIKE @q OR v.carrier_text LIKE @q)'); p.q = `%${q.q}%`; }
  if (q.pol_id) { w.push('v.pol_id=@pol'); p.pol = q.pol_id; }
  if (q.pod_id) { w.push('v.pod_id=@pod'); p.pod = q.pod_id; }
  if (q.carrier_id) { w.push('v.carrier_id=@car'); p.car = q.carrier_id; }
  if (q.from) { w.push('COALESCE(v.etd,v.eta)>=@from'); p.from = q.from; }
  if (q.to) { w.push('COALESCE(v.etd,v.eta)<=@to'); p.to = q.to; }
  if (q.upcoming === '1') { w.push('COALESCE(v.etd,v.eta)>=@today'); p.today = today(); }
  if (q.active !== 'all') w.push('v.active=1');
  return db.prepare(`SELECT v.*, COALESCE(ca.name, v.carrier_text) AS carrier_name, COALESCE(pl.name, v.pol_text) AS pol_name, COALESCE(pd.name, v.pod_text) AS pod_name
    FROM vessel_schedules v LEFT JOIN parties ca ON ca.id=v.carrier_id LEFT JOIN ports pl ON pl.id=v.pol_id LEFT JOIN ports pd ON pd.id=v.pod_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY COALESCE(v.etd,v.eta), v.vessel LIMIT ${Math.min(parseInt(q.limit || '1000', 10) || 1000, 5000)}`).all(p);
}

module.exports = { ALIASES, FIELDS, buildPlan, commitPlan, affected, applyToOperations, readLink, refreshSource, list, safeFetch, isPrivateIp, sigOf, portMatcher, carrierMatcher };
