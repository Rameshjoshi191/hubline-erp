'use strict';
// Used by `SEED_DEMO=1 npm start` (e.g. on a free hosting plan whose disk is wiped on restart):
// if the database is missing or holds no customers/agents yet, load the demo data before the server starts.
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

module.exports = function autoSeed() {
  const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
  const DB_FILE = process.env.DB_FILE || path.join(DATA_DIR, 'nvocc.db');
  let empty = true;
  if (fs.existsSync(DB_FILE)) {
    const Database = require('better-sqlite3');
    const d = new Database(DB_FILE, { readonly: true });
    try { empty = d.prepare('SELECT COUNT(*) n FROM parties').get().n === 0; } catch { empty = true; } finally { d.close(); }
  }
  if (!empty) return;
  console.log('SEED_DEMO=1 and the database is empty: loading demo data...');
  execFileSync(process.execPath, [path.join(__dirname, 'seed-demo.js')], { stdio: 'inherit', env: process.env });
};
