'use strict';
// Slot operators' sailing schedules with the slot rate and surcharges (reefer, DG, flexi, BAF, EWRS).
// Each operator sends an Excel sheet; it is loaded through the import wizard and read by Trade / sales when they quote.
const { db, today, addDays } = require('./db');
const T = require('./tabular');
const SCH = require('./schedules');

const ALIASES = {
  operator: ['slot operator', 'operator', 'slot owner', 'slot provider', 'carrier', 'line', 'shipping line', 'vessel operator', 'service provider', 'liner'],
  vessel: ['vessel', 'vessel name', 'voa', 'voa name', 'vsl', 'vsl name', 'ship', 'ship name', 'mother vessel', 'vessel / voyage name'],
  voyage: ['voyage', 'voy', 'voy no', 'voyage no', 'voyage number', 'voy.', 'voyage ref', 'voyage code'],
  week: ['week', 'wk', 'week no', 'week number', 'sailing week', 'cw', 'calendar week'],
  month: ['month', 'sailing month', 'mth'],
  etd: ['etd', 'date', 'sailing date', 'sailing', 'departure', 'departure date', 'etd pol', 'etd date', 'sails'],
  eta: ['eta', 'arrival', 'arrival date', 'eta pod', 'eta date'],
  pol: ['pol', 'port of loading', 'load port', 'loading port', 'origin', 'from', 'origin port'],
  pod: ['pod', 'port of discharge', 'discharge port', 'destination', 'to', 'dest', 'destination port'],
  routing: ['routing', 'route', 'via', 'rotation', 'transhipment port', 'ts port', 'service routing'],
  transit_days: ['transit', 'transit days', 'transit time', 'tt', 't/t', 'days'],
  currency: ['currency', 'ccy', 'cur'],
  slot_rate: ['slot rate', 'slot cost', 'slot', 'rate', 'basic rate', 'freight rate', 'ocean freight', 'o/f', 'slot rate per teu', 'slot rate per container'],
  reefer_surcharge: ['reefer surcharge', 'reefer surchg', 'reefer surch', 'reefer sur', 'rf surcharge', 'rf surchg', 'reefer', 'rf'],
  dg_surcharge: ['dg surcharge', 'dg surchg', 'dg surch', 'dg sur', 'dangerous goods surcharge', 'imo surcharge', 'dg'],
  flexi_surcharge: ['flexi surcharge', 'flexi surchg', 'flexi surch', 'flexi sur', 'flexitank surcharge', 'flexi tank surcharge', 'flexi'],
  baf: ['baf', 'bunker', 'bunker surcharge', 'bunker adjustment factor', 'fuel surcharge'],
  ewrs: ['ewrs', 'emergency war risk surcharge', 'war risk surcharge', 'war risk', 'ewr'],
  remarks: ['remarks', 'remark', 'notes', 'note', 'comment', 'comments'],
};
const FIELDS = [
  { key: 'operator', label: 'Slot operator' }, { key: 'vessel', label: 'Vessel (VOA) name', required: true }, { key: 'voyage', label: 'Voyage' }, { key: 'week', label: 'Week' },
  { key: 'etd', label: 'ETD / sailing date', required: true }, { key: 'month', label: 'Month (if there is no date)' }, { key: 'eta', label: 'ETA' },
  { key: 'pol', label: 'Port of loading' }, { key: 'pod', label: 'Port of discharge' }, { key: 'routing', label: 'Routing / via' }, { key: 'transit_days', label: 'Transit days' },
  { key: 'currency', label: 'Currency' }, { key: 'slot_rate', label: 'Slot rate' }, { key: 'reefer_surcharge', label: 'Reefer surcharge' }, { key: 'dg_surcharge', label: 'DG surcharge' },
  { key: 'flexi_surcharge', label: 'Flexi surcharge' }, { key: 'baf', label: 'BAF' }, { key: 'ewrs', label: 'EWRS' }, { key: 'remarks', label: 'Remarks' },
];
const RATE_KEYS = ['slot_rate', 'reefer_surcharge', 'dg_surcharge', 'flexi_surcharge', 'baf', 'ewrs'];
const RATE_LABEL = { slot_rate: 'Slot rate', reefer_surcharge: 'Reefer surcharge', dg_surcharge: 'DG surcharge', flexi_surcharge: 'Flexi surcharge', baf: 'BAF', ewrs: 'EWRS' };

// ---------------------------------------------------------------- small parsers
function isoWeek(dateStr) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  return Math.ceil(((d - Date.UTC(d.getUTCFullYear(), 0, 1)) / 86400000 + 1) / 7);
}
const weekLabel = (n) => 'W' + String(n).padStart(2, '0');
// "W41", "41", "Wk 41", "2026-W41" -> "W41"; anything else -> null
function normWeek(raw) {
  const groups = String(raw == null ? '' : raw).match(/\d+/g);
  const g = groups && groups.find((x) => x.length <= 2);
  const n = g ? Number(g) : 0;
  return n >= 1 && n <= 53 ? weekLabel(n) : null;
}
// "850", "1,200.50", "USD 85", "$85", "85/TEU" -> number; "-", "n/a" -> nothing; "nil", "free", "included" -> 0; anything else is an error
function numOf(raw) {
  const s = String(raw == null ? '' : raw).trim();
  if (!s || /^(-+|na|n\/a|tbc|tba)$/i.test(s)) return { v: null };
  if (/^(nil|free|waived|incl\.?|included|zero)$/i.test(s)) return { v: 0 };
  const m = /^([A-Za-z$€£₹]{1,4})?\s*(-?[\d,]*\.?\d+)\s*(?:\/?\s*[A-Za-z%]{0,6})?$/.exec(s);
  if (!m) return { err: true };
  const n = Number(m[2].replace(/,/g, ''));
  if (!Number.isFinite(n) || n < 0) return { err: true };
  return { v: Math.round(n * 10000) / 10000 };
}
function dateOf(raw, t0) {
  if (!raw) return { v: null };
  const y = Number(t0.slice(0, 4));
  let p = T.parseDate(raw, { defaultYear: y });
  if (!p) return { err: true };
  if (!/\d{4}/.test(String(raw)) && p < addDays(t0, -180)) p = T.parseDate(raw, { defaultYear: y + 1 });
  return { v: p };
}
// "2026-10", "Oct 2026", "October-26", "Oct" (this year), or a full date -> "YYYY-MM"
function monthOf(raw) {
  const s = String(raw == null ? '' : raw).trim();
  if (!s) return { v: null };
  let m = /^(\d{4})[-/.](\d{1,2})$/.exec(s);
  if (m) return +m[2] >= 1 && +m[2] <= 12 ? { v: `${m[1]}-${String(+m[2]).padStart(2, '0')}` } : { err: true };
  const full = T.parseDate(s);
  if (full) return { v: full.slice(0, 7) };
  const p = T.parseDate('1 ' + s.replace(/[-/.,]+/g, ' '), { defaultYear: Number(today().slice(0, 4)) });
  return p ? { v: p.slice(0, 7) } : { err: true };
}
const sigOf = (v) => [
  v.operator_id ? 'O' + v.operator_id : String(v.operator_text || '').toUpperCase().trim(), String(v.vessel).toUpperCase().trim(),
  String(v.voyage || v.etd || v.month || '').toUpperCase().trim(),
  v.pol_id ? 'P' + v.pol_id : String(v.pol_text || '').toUpperCase().trim(), v.pod_id ? 'P' + v.pod_id : String(v.pod_text || '').toUpperCase().trim(),
].join('|');

// ---------------------------------------------------------------- import plan
function buildPlan(table, options = {}) {
  const map = table.map;
  if (!('vessel' in map)) return { rows: [], map, summary: { total: 0 }, problem: 'No "Vessel" column was found. Choose which column holds the vessel (VOA) name.' };
  if (!('etd' in map) && !('month' in map)) return { rows: [], map, summary: { total: 0 }, problem: 'No date column was found. Choose which column holds the ETD (sailing date) - or the month.' };
  const findPort = SCH.portMatcher(), findOp = SCH.carrierMatcher(), t0 = today();
  const defOp = options.operator_id ? db.prepare('SELECT id, name FROM parties WHERE id=?').get(options.operator_id) : null;
  const defCur = /^[A-Za-z]{3}$/.test(options.currency || '') ? String(options.currency).toUpperCase() : 'USD';
  const rows = [], seen = new Set();
  const get = db.prepare('SELECT * FROM slot_schedules WHERE sig=?');
  table.dataRows.forEach((raw, i) => {
    const g = (f) => T.pick(raw, map, f);
    if (raw.every((v) => !String(v).trim())) return;
    const r = { line: table.rowOffset + i, action: 'ERROR', level: 'error', messages: [], vessel: g('vessel').toUpperCase(), voyage: g('voyage').toUpperCase() };
    rows.push(r);
    const err = (m) => { r.messages.push(m); r.level = 'error'; r.action = 'ERROR'; return r; };
    const warn = (m) => { r.messages.push(m); if (r.level === 'ok') r.level = 'warn'; };
    if (!r.vessel) return err('Vessel name is empty');
    const e = dateOf(g('etd'), t0), a = dateOf(g('eta'), t0), mo = monthOf(g('month'));
    if (e.err) return err(`ETD "${g('etd')}" is not a date`);
    if (a.err) return err(`ETA "${g('eta')}" is not a date`);
    if (mo.err) return err(`Month "${g('month')}" is not a month`);
    r.etd = e.v; r.eta = a.v;
    r.month = r.etd ? r.etd.slice(0, 7) : mo.v;
    if (!r.month) return err('Needs an ETD (sailing date) or a month');
    if (r.etd && r.eta && r.eta < r.etd) return err('ETA is before ETD');
    r.level = 'ok';
    if (r.etd && mo.v && mo.v !== r.month) warn(`The month column says ${mo.v} but the ETD is in ${r.month} - the ETD is used`);
    let week = normWeek(g('week'));
    if (g('week') && !week) warn(`Week "${g('week')}" is not a week number - worked out from the ETD`);
    if (!week && r.etd) week = weekLabel(isoWeek(r.etd));
    r.week = week;
    const rates = {};
    for (const k of RATE_KEYS) {
      const n = numOf(g(k));
      if (n.err) return err(`${RATE_LABEL[k]} "${g(k)}" is not an amount`);
      rates[k] = n.v;
    }
    if (rates.slot_rate == null && !RATE_KEYS.some((k) => rates[k] != null)) warn('No slot rate or surcharge on this row');
    let currency = defCur;
    if (g('currency')) {
      if (!/^[A-Za-z]{3}$/.test(g('currency'))) return err(`Currency "${g('currency')}" must be a 3-letter code such as USD`);
      currency = g('currency').toUpperCase();
    }
    const pol = findPort(g('pol')), pod = findPort(g('pod')), polT = g('pol'), podT = g('pod');
    if (polT && !pol) warn(`Port "${polT}" is not in your port list - kept as text`);
    if (podT && !pod) warn(`Port "${podT}" is not in your port list - kept as text`);
    r.pol_name = pol ? pol.name : polT; r.pod_name = pod ? pod.name : podT;
    const opT = g('operator'), op = opT ? findOp(opT) : defOp;
    if (opT && !op) warn(`Slot operator "${opT}" is not a known carrier - kept as text`);
    if (!opT && !defOp) warn('No slot operator given - choose one in the options above or add an operator column');
    r.operator_name = op ? op.name : opT;
    const td = parseInt(g('transit_days'), 10);
    const val = {
      operator_id: op ? op.id : null, operator_text: op ? null : (opT || null), vessel: r.vessel, voyage: r.voyage || null, week: r.week, month: r.month, etd: r.etd, eta: r.eta,
      pol_id: pol ? pol.id : null, pol_text: pol ? null : (polT || null), pod_id: pod ? pod.id : null, pod_text: pod ? null : (podT || null),
      routing: g('routing') || null, transit_days: !Number.isNaN(td) && td > 0 ? td : (r.etd && r.eta ? Math.round((new Date(r.eta) - new Date(r.etd)) / 86400000) : null),
      currency, ...rates, remarks: g('remarks') || null,
    };
    Object.assign(r, rates, { currency });
    const sig = sigOf(val);
    if (seen.has(sig)) warn('Same operator / vessel / voyage / route appears twice in the file - the later row wins');
    seen.add(sig);
    const cur = get.get(sig);
    if (!cur) r.action = 'CREATE';
    else {
      const ch = {};
      for (const k of [...RATE_KEYS, 'week', 'etd', 'eta', 'routing', 'transit_days', 'currency', 'remarks']) if (val[k] != null && val[k] !== cur[k]) ch[k] = { from: cur[k], to: val[k] };
      if (Object.keys(ch).length) {
        r.action = 'UPDATE'; r.changes = ch;
        const rc = Object.entries(ch).filter(([k]) => RATE_KEYS.includes(k)).map(([k, v]) => `${RATE_LABEL[k]} ${v.from == null ? '-' : v.from} to ${v.to}`);
        r.messages.push(rc.length ? 'Changes: ' + rc.join(', ') : 'Details updated');
      } else { r.action = 'NOCHANGE'; r.messages.push('Already up to date'); }
    }
    r._exec = { sig, val, cur };
  });
  const summary = { total: rows.length, create: 0, update: 0, nochange: 0, error: 0, warn: 0 };
  for (const r of rows) {
    if (r.action === 'CREATE') summary.create++; else if (r.action === 'UPDATE') summary.update++; else if (r.action === 'NOCHANGE') summary.nochange++; else summary.error++;
    if (r.level === 'warn') summary.warn++;
  }
  summary.ready = summary.create + summary.update;
  return { rows, map, summary, opt: { operator_id: options.operator_id || '', currency: defCur } };
}

function commitPlan(plan, user) {
  const out = { created: 0, updated: 0 };
  db.transaction(() => {
    for (const r of plan.rows) {
      if (!r._exec || !['CREATE', 'UPDATE'].includes(r.action)) continue;
      const { sig, val, cur } = r._exec;
      if (!cur) {
        db.prepare(`INSERT INTO slot_schedules(sig,operator_id,operator_text,vessel,voyage,week,month,etd,eta,pol_id,pol_text,pod_id,pod_text,routing,transit_days,currency,
            slot_rate,reefer_surcharge,dg_surcharge,flexi_surcharge,baf,ewrs,remarks,source,created_by)
          VALUES(@sig,@operator_id,@operator_text,@vessel,@voyage,@week,@month,@etd,@eta,@pol_id,@pol_text,@pod_id,@pod_text,@routing,@transit_days,@currency,
            @slot_rate,@reefer_surcharge,@dg_surcharge,@flexi_surcharge,@baf,@ewrs,@remarks,'IMPORT',@created_by) ON CONFLICT(sig) DO NOTHING`).run({ sig, ...val, created_by: user ? user.id : null });
        out.created++;
      } else {
        // a blank cell in the file keeps what is already saved; type 0 to clear a surcharge
        db.prepare(`UPDATE slot_schedules SET week=COALESCE(@week,week), month=@month, etd=COALESCE(@etd,etd), eta=COALESCE(@eta,eta), routing=COALESCE(@routing,routing),
            transit_days=COALESCE(@transit_days,transit_days), currency=@currency, slot_rate=COALESCE(@slot_rate,slot_rate), reefer_surcharge=COALESCE(@reefer_surcharge,reefer_surcharge),
            dg_surcharge=COALESCE(@dg_surcharge,dg_surcharge), flexi_surcharge=COALESCE(@flexi_surcharge,flexi_surcharge), baf=COALESCE(@baf,baf), ewrs=COALESCE(@ewrs,ewrs),
            remarks=COALESCE(@remarks,remarks), active=1, updated_at=datetime('now') WHERE sig=@sig`).run({ sig, ...val });
        out.updated++;
      }
    }
  })();
  return out;
}

// ---------------------------------------------------------------- listing (month-wise by default)
function list(q = {}) {
  const w = [], p = {};
  if (q.q) {
    w.push(`(s.vessel LIKE @q OR s.voyage LIKE @q OR s.routing LIKE @q OR s.week LIKE @q OR s.pol_text LIKE @q OR s.pod_text LIKE @q OR pl.name LIKE @q OR pd.name LIKE @q
      OR ca.name LIKE @q OR s.operator_text LIKE @q OR s.remarks LIKE @q)`); p.q = `%${q.q}%`;
  }
  if (q.operator_id) { w.push('s.operator_id=@op'); p.op = q.operator_id; }
  if (q.pol_id) { w.push('s.pol_id=@pol'); p.pol = q.pol_id; }
  if (q.pod_id) { w.push('s.pod_id=@pod'); p.pod = q.pod_id; }
  if (q.month) { w.push('s.month=@month'); p.month = q.month; }
  if (q.week) { w.push('s.week=@week'); p.week = String(q.week).toUpperCase().startsWith('W') ? String(q.week).toUpperCase() : weekLabel(parseInt(q.week, 10) || 0); }
  if (q.from) { w.push('COALESCE(s.etd, s.month||\'-01\')>=@from'); p.from = q.from; }
  if (q.to) { w.push('COALESCE(s.etd, s.month||\'-01\')<=@to'); p.to = q.to; }
  if (q.upcoming === '1') { w.push('s.month>=@thisMonth AND COALESCE(s.etd, s.month||\'-31\')>=@today'); p.thisMonth = today().slice(0, 7); p.today = today(); }
  if (q.active !== 'all') w.push('s.active=1');
  return db.prepare(`SELECT s.*, COALESCE(ca.name, s.operator_text) AS operator_name, COALESCE(pl.name, s.pol_text) AS pol_name, COALESCE(pd.name, s.pod_text) AS pod_name
    FROM slot_schedules s LEFT JOIN parties ca ON ca.id=s.operator_id LEFT JOIN ports pl ON pl.id=s.pol_id LEFT JOIN ports pd ON pd.id=s.pod_id
    ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY s.month, COALESCE(s.etd, s.month||'-01'), operator_name, s.vessel LIMIT ${Math.min(parseInt(q.limit || '2000', 10) || 2000, 5000)}`).all(p);
}
function months() {
  return db.prepare('SELECT month, COUNT(*) AS n FROM slot_schedules WHERE active=1 GROUP BY month ORDER BY month').all();
}

module.exports = { ALIASES, FIELDS, RATE_KEYS, RATE_LABEL, buildPlan, commitPlan, list, months, sigOf, isoWeek, weekLabel, normWeek, monthOf };
