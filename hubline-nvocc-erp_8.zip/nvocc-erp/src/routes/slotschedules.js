'use strict';
// Slot operators' schedules with slot rate and surcharges: Excel / CSV / paste import wizard, list, manual add / edit / delete.
const express = require('express');
const { db, audit } = require('../db');
const { need } = require('../auth');
const { bad, extract, insertRow, diff } = require('../util');
const kit = require('../importkit');
const SS = require('../slotschedules');

const r = express.Router();

kit.mount(r, {
  path: 'slot-schedules', module: 'slotrates', entity: 'slot_schedule', aliases: SS.ALIASES, fields: SS.FIELDS, templateName: 'Slot_schedule_template.xlsx',
  template: () => [
    { name: 'Schedule', columns: [['Slot operator', 20], ['Vessel', 22], ['Voyage', 10], ['Week', 8], ['ETD', 13], ['ETA', 13], ['POL', 20], ['POD', 20], ['Routing', 26], ['Transit days', 10], ['Currency', 9],
      ['Slot rate', 11], ['Reefer surcharge', 14], ['DG surcharge', 13], ['Flexi surcharge', 14], ['BAF', 9], ['EWRS', 9], ['Remarks', 26]].map(([header, width]) => ({ header, key: header, width })), rows: [] },
    { name: 'How to fill', title: ['How to fill the Schedule sheet', 'One row per sailing. Vessel and ETD (or Month) are compulsory.'], columns: [{ header: 'Column', key: 'a', width: 20 }, { header: 'What to type', key: 'b', width: 90 }], rows: [
      { a: 'Slot operator', b: 'The line that gives you the slot (matched to your carriers). Leave it out if you load one operator\'s sheet at a time and choose the operator in the wizard.' },
      { a: 'Vessel', b: 'Vessel (VOA) name, e.g. BLUE HORIZON. Add the Voyage in its own column.' },
      { a: 'Week', b: 'W41 or 41. Left empty, it is worked out from the ETD.' },
      { a: 'ETD / ETA', b: 'Any normal date: 2026-10-14, 14/10/2026, 14-Oct-2026. The month the sailing belongs to is taken from the ETD. Without an ETD you can type a Month column instead (Oct 2026).' },
      { a: 'POL / POD / Routing', b: 'Port name or UN/LOCODE (Jebel Ali or AEJEA). Routing is free text, e.g. "Jebel Ali - Salalah - Mombasa" or "Direct".' },
      { a: 'Slot rate and surcharges', b: 'Numbers only (USD 850 or 850 both work). Reefer, DG, Flexi, BAF, EWRS. Leave a cell blank when the operator did not quote it - blank keeps what is already saved, type 0 to clear it.' },
      { a: 'Loading again', b: 'Load the same sheet again when rates change - sailings are matched on operator + vessel + voyage + ports, and only the changes are saved.' }] },
  ],
  plan: (table, options) => SS.buildPlan(table, options),
  commit: (plan, user) => SS.commitPlan(plan, user),
});

r.get('/slot-schedules', need('slotrates', 'read'), (req, res) => res.json(SS.list(req.query)));
r.get('/slot-schedules/months', need('slotrates', 'read'), (_req, res) => res.json(SS.months()));

const FIELDS = [
  { name: 'operator_id', type: 'int' }, { name: 'vessel', type: 'upper', required: true, label: 'Vessel' }, { name: 'voyage', type: 'upper' }, { name: 'week' },
  { name: 'etd', type: 'date', required: true, label: 'ETD' }, { name: 'eta', type: 'date' }, { name: 'pol_id', type: 'int' }, { name: 'pod_id', type: 'int' }, { name: 'routing' },
  { name: 'transit_days', type: 'int' }, { name: 'currency', type: 'upper', def: 'USD' },
  { name: 'slot_rate', type: 'real' }, { name: 'reefer_surcharge', type: 'real' }, { name: 'dg_surcharge', type: 'real' }, { name: 'flexi_surcharge', type: 'real' },
  { name: 'baf', type: 'real' }, { name: 'ewrs', type: 'real' }, { name: 'remarks' }, { name: 'active', type: 'bool', def: 1 },
];
function check(v) {
  if (v.etd && v.eta && v.eta < v.etd) bad('ETA is before ETD.');
  if (v.pol_id && v.pod_id && v.pol_id === v.pod_id) bad('Port of loading and discharge cannot be the same.');
  if (v.currency && !/^[A-Z]{3}$/.test(v.currency)) bad('Currency must be a 3-letter code such as USD.');
  for (const k of SS.RATE_KEYS) if (v[k] != null && v[k] < 0) bad(`${SS.RATE_LABEL[k]} cannot be negative.`);
  if (v.week) { const w = SS.normWeek(v.week); if (!w) bad('Week must be a number from 1 to 53, e.g. W41.'); v.week = w; }
}
function finish(v) {
  v.month = v.etd.slice(0, 7);
  if (!v.week) v.week = SS.weekLabel(SS.isoWeek(v.etd));
  if (v.etd && v.eta && !v.transit_days) v.transit_days = Math.round((new Date(v.eta) - new Date(v.etd)) / 86400000);
  v.sig = SS.sigOf(v);
  return v;
}
r.post('/slot-schedules', need('slotrates', 'write'), (req, res) => {
  const v = extract(req.body, FIELDS); check(v); finish(v);
  v.source = 'MANUAL'; v.created_by = req.user.id;
  if (db.prepare('SELECT 1 FROM slot_schedules WHERE sig=?').get(v.sig)) bad('This operator / vessel / voyage / route is already in the list - edit it instead.', 409);
  const id = insertRow('slot_schedules', v);
  audit(req.user, 'CREATE', 'slot_schedule', id, { vessel: v.vessel, voyage: v.voyage, month: v.month });
  res.json({ id });
});
r.put('/slot-schedules/:id', need('slotrates', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM slot_schedules WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, FIELDS, { partial: true });
  const m = { ...cur, ...v }; check(m); if (v.week !== undefined) v.week = m.week;
  if (!m.etd) bad('ETD is required.');
  const full = finish({ ...m, week: v.week !== undefined ? m.week : cur.week });
  const upd = { ...v, month: full.month, week: full.week, transit_days: full.transit_days, sig: full.sig };
  if (full.sig !== cur.sig && db.prepare('SELECT 1 FROM slot_schedules WHERE sig=? AND id<>?').get(full.sig, cur.id)) bad('Another line already has this operator / vessel / voyage / route.', 409);
  const cols = Object.keys(upd);
  db.prepare(`UPDATE slot_schedules SET ${cols.map((c) => `${c}=@${c}`).join(',')}, updated_at=datetime('now') WHERE id=@__id`).run({ ...upd, __id: cur.id });
  audit(req.user, 'UPDATE', 'slot_schedule', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.delete('/slot-schedules/:id', need('slotrates', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM slot_schedules WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  db.prepare('DELETE FROM slot_schedules WHERE id=?').run(cur.id);
  audit(req.user, 'DELETE', 'slot_schedule', cur.id, { vessel: cur.vessel, voyage: cur.voyage });
  res.json({ ok: true });
});

module.exports = r;
