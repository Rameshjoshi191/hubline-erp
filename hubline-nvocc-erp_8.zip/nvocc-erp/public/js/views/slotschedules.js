// Slot schedules & rates: each slot operator's sailings with slot rate and surcharges, loaded from their Excel sheets and read month-wise by Trade / sales.
import { api, esc, $, on, qs, tbl, pageHead, money, date, badge, formModal, confirmBox, toast, opts, can, int, debounce } from '../core.js';
import { icon } from '../icons.js';
import { importWizard, tilesFor } from '../importui.js';
import { shareBtn, wireShare } from '../share.js';

const operatorOpts = () => opts.parties('carrier');
const monthLabel = (m) => (m ? new Date(m + '-01T00:00:00Z').toLocaleString('en-GB', { month: 'long', year: 'numeric', timeZone: 'UTC' }) : 'No month');
const RATES = [['slot_rate', 'Slot rate'], ['reefer_surcharge', 'Reefer surchg'], ['dg_surcharge', 'DG surchg'], ['flexi_surcharge', 'Flexi surchg'], ['baf', 'BAF'], ['ewrs', 'EWRS']];
const rateTxt = (v) => (v == null ? '' : new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(Number(v)));   // 850 / 1,250.5 - no forced .00 so the columns stay narrow
const amt = (v) => (v == null ? '<span class="muted">-</span>' : rateTxt(v));

// ---------------------------------------------------------------- the upload wizard (one operator's sheet at a time, as many times as you like)
export function loadSchedule() {
  return importWizard({
    title: 'Upload slot operator schedule', base: '/slot-schedules', noun: 'sailings', defaults: { currency: 'USD' },
    intro: 'Upload the sailing schedule your slot operator sent - one sheet per operator, as many operators as you need. It should have the vessel, ETD, ports and the slot rate with its surcharges. Loading the same sheet again later only saves what changed.',
    pasteHint: 'Copy the rows from the operator\'s Excel sheet and paste them here. The vessel and ETD (or month) are needed; week, ports, routing, transit, slot rate, reefer / DG / flexi surcharge, BAF and EWRS are read if present.',
    options: [
      { name: 'operator_id', label: 'Slot operator (when the sheet does not list one)', type: 'select', options: operatorOpts, span: 3 },
      { name: 'currency', label: 'Currency (when the sheet does not list one)', type: 'select', options: opts.currencies, noEmpty: true, span: 1 },
    ], optionsTitle: 'If the sheet does not say which operator or currency',
    cols: [
      { label: 'Operator / vessel', render: (r) => `<b>${esc(r.vessel)}</b> <span class="muted small">${esc(r.voyage || '')}</span><div class="muted small">${esc(r.operator_name || '')}</div>` },
      { label: 'Week / ETD', render: (r) => `${esc(r.week || '')}<div class="muted small">${r.etd ? date(r.etd) : esc(r.month || '')}</div>` },
      { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` },
      { label: 'Rates', render: (r) => `<span class="small">${RATES.map(([k, l]) => (r[k] != null ? `${esc(l)} <b>${money(r[k])}</b>` : '')).filter(Boolean).join(' &middot; ') || '<span class="muted">none</span>'} ${esc(r.currency || '')}</span>` },
    ],
    tiles: tilesFor([['create', 'New sailings', 'ok'], ['update', 'Changed', 'warn'], ['nochange', 'Unchanged', ''], ['error', 'Errors', 'bad']]),
    saveLabel: (s) => `Save ${int(s.ready)} sailing${s.ready === 1 ? '' : 's'}`,
    doneHtml: (r) => `<h2>Schedule loaded</h2><p class="muted">${r.created} new &middot; ${r.updated} changed. Trade can now see these sailings and rates under <b>Slot schedules &amp; rates</b>.</p>`,
    nextLinks: [['Slot schedules & rates', '#/slot-schedules']],
  });
}

// ---------------------------------------------------------------- the page
export async function list(root) {
  const canW = can('slotrates', 'write');
  const f = { q: '', operator_id: '', month: '', pol_id: '', pod_id: '', upcoming: '1' };
  let rows = [];
  root.innerHTML = `${pageHead('Slot schedules & rates', 'Sailings of every slot operator with the slot rate and surcharges, month by month. Upload each operator\'s Excel sheet and the whole team reads it here.',
    `${canW ? `<button class="btn primary" data-act="load">${icon('upload', 16)} Upload schedule</button><button class="btn" data-act="add">${icon('plus', 16)} Add sailing</button>` : ''}${shareBtn()}`)}
    <div class="toolbar no-print"><input type="text" class="search" placeholder="Search vessel, voyage, operator, port, routing, week…" data-f="q">
      <select data-f="operator_id"><option value="">All slot operators</option>${operatorOpts().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="month"><option value="">All months</option></select>
      <select data-f="pol_id"><option value="">Any loading port</option>${opts.ports().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="pod_id"><option value="">Any discharge port</option>${opts.ports().map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <label class="chip on"><input type="checkbox" data-f="upcoming" checked hidden> Upcoming only</label></div>
    <div data-out></div>`;
  const out = $('[data-out]', root);
  const monthSel = $('[data-f=month]', root);

  async function paintMonths() {
    const ms = await api('GET', '/slot-schedules/months');
    monthSel.innerHTML = `<option value="">All months</option>${ms.map((m) => `<option value="${m.month}" ${f.month === m.month ? 'selected' : ''}>${esc(monthLabel(m.month))} (${m.n})</option>`).join('')}`;
  }
  const cols = () => [
    { label: 'Slot operator', render: (r) => esc(r.operator_name || '') },
    { label: 'Vessel / voyage', render: (r) => `<b>${esc(r.vessel)}</b><div class="muted small">${esc(r.voyage || '')}</div>` },
    { label: 'ETD / week', cls: 'nowrap', render: (r) => `${r.etd ? `<b>${date(r.etd)}</b>` : '<span class="muted">-</span>'}<div class="muted small">${esc(r.week || '')}</div>` },
    { label: 'POL / POD / routing', render: (r) => `<div>${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}</div><div class="muted small">${[r.routing, r.transit_days ? r.transit_days + ' days' : ''].filter(Boolean).map(esc).join(' &middot; ')}</div>` },
    { label: 'Slot rate', num: true, render: (r) => `<b>${r.slot_rate == null ? '-' : rateTxt(r.slot_rate)}</b> <span class="muted small">${esc(r.currency)}</span>` },
    ...RATES.slice(1).map(([k, l]) => ({ label: l, num: true, render: (r) => amt(r[k]) })),
    ...(canW ? [{ label: '', cls: 'nowrap', render: (r) => `<button class="btn sm ghost" data-edit="${r.id}">${icon('edit', 14)}</button><button class="btn sm ghost" data-del="${r.id}" title="Delete">&#10005;</button>` }] : []),
  ];
  async function load() {
    rows = await api('GET', '/slot-schedules' + qs(f));
    if (!rows.length) { out.innerHTML = `<div class="card"><div class="empty">${canW ? 'No slot schedules yet. Use “Upload schedule” to load an operator\'s Excel sheet.' : 'No slot schedules have been loaded yet.'}</div></div>`; return; }
    const groups = new Map();
    for (const r of rows) { if (!groups.has(r.month)) groups.set(r.month, []); groups.get(r.month).push(r); }
    const ops = new Set(rows.map((r) => r.operator_name || ''));
    out.innerHTML = `<div class="muted small" style="margin:0 2px 10px">${int(rows.length)} sailing${rows.length === 1 ? '' : 's'} &middot; ${ops.size} operator${ops.size === 1 ? '' : 's'} &middot; ${groups.size} month${groups.size === 1 ? '' : 's'}${rows.length >= 2000 ? ' &middot; showing the first 2,000 - narrow the filters to see more' : ''}</div>
      ${[...groups].map(([m, list]) => `<div class="card"><div class="card-h"><h2>${icon('calendar', 16)} ${esc(monthLabel(m))}</h2>${badge(`${list.length} sailing${list.length === 1 ? '' : 's'}`, '')}</div>${tbl({ rows: list, cols: cols(), compact: true })}</div>`).join('')}`;
  }
  const refreshAll = () => Promise.all([paintMonths(), load()]).catch((e) => toast(e.message, 'bad'));
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')), 250);
  root.addEventListener('input', (e) => {
    const k = e.target.dataset.f; if (!k) return;
    f[k] = e.target.type === 'checkbox' ? (e.target.checked ? '1' : '0') : e.target.value;
    if (e.target.type === 'checkbox') e.target.closest('.chip').classList.toggle('on', e.target.checked);
    reload();
  });
  wireShare(root, () => ({ kind: 'slotschedules', params: { ...f, upcoming: f.upcoming === '1' ? '1' : '0' }, title: 'Share slot schedules & rates', what: 'the slot schedules and rates', defaultSubject: 'Slot schedules & rates - HUB LINE SHIPPING' }));

  const fields = () => [
    { name: 'operator_id', label: 'Slot operator', type: 'combo', options: operatorOpts, span: 2 }, { name: 'vessel', label: 'Vessel (VOA) name', required: true, span: 1 }, { name: 'voyage', label: 'Voyage', span: 1 },
    { name: 'etd', label: 'ETD', type: 'date', required: true }, { name: 'eta', label: 'ETA', type: 'date' }, { name: 'week', label: 'Week', placeholder: 'W41 - from the ETD if empty' }, { name: 'transit_days', label: 'Transit days', type: 'number', min: 0 },
    { name: 'pol_id', label: 'Port of loading', type: 'combo', options: opts.ports, span: 2 }, { name: 'pod_id', label: 'Port of discharge', type: 'combo', options: opts.ports, span: 2 },
    { name: 'routing', label: 'Routing / via', span: 3, placeholder: 'e.g. Jebel Ali - Salalah - Mombasa' }, { name: 'currency', label: 'Currency', type: 'select', options: opts.currencies, noEmpty: true },
    ...RATES.map(([k, l]) => ({ name: k, label: l, type: 'number', min: 0, span: 1 })), { name: 'remarks', label: 'Remarks', span: 4 },
  ];
  on(root, 'click', '[data-act=load]', async () => { const r = await loadSchedule(); if (r) refreshAll(); });
  on(root, 'click', '[data-act=add]', async () => {
    const r = await formModal({ title: 'Add sailing', size: 'wide', fields: fields(), values: { currency: 'USD' }, onSubmit: (v) => api('POST', '/slot-schedules', v) });
    if (r) { toast('Sailing added', 'ok'); refreshAll(); }
  });
  on(root, 'click', '[data-edit]', async (_e, el) => {
    const row = rows.find((x) => String(x.id) === el.dataset.edit);
    const r = await formModal({ title: `Edit ${row.vessel} ${row.voyage || ''}`, size: 'wide', fields: fields(), values: row, onSubmit: (v) => api('PUT', `/slot-schedules/${row.id}`, v) });
    if (r) { toast('Saved', 'ok'); refreshAll(); }
  });
  on(root, 'click', '[data-del]', async (_e, el) => {
    if (await confirmBox('Delete this sailing and its rates from the list?', { danger: true, ok: 'Delete' })) { try { await api('DELETE', `/slot-schedules/${el.dataset.del}`); refreshAll(); } catch (e) { toast(e.message, 'bad'); } }
  });
  await refreshAll();
}
