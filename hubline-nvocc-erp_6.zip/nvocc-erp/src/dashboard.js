'use strict';
// Dashboard data: equipment, receivables, container tracking and an "action centre" that tells people what needs attention,
// so nobody has to hunt through lists. Staff and external agents get their own version.
const { db, today, addDays, round2, daysBetween } = require('./db');
const A = require('./auth');
const S = require('./scope');
const L = require('./logic');
const TR = require('./track');
const SCH = require('./schedules');

const monthOf = (t, back = 0) => { const d = new Date(t + 'T00:00:00Z'); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() - back); return d.toISOString().slice(0, 7); };
const act = (list, key, severity, title, detail, count, href) => { if (count > 0) list.push({ key, severity, title, detail, count, href }); };

function equipment(snap) {
  const e = { total: snap.length, empty: 0, laden: 0, out_of_service: 0, overdue: 0, expiring: 0, idle_14: 0, teu: 0, by_type: [], by_status: {}, top_locations: [] };
  const types = {}, locs = {};
  for (const c of snap) {
    e.teu += c.teu;
    const t = types[c.type_code] = types[c.type_code] || { type_code: c.type_code, total: 0, empty: 0, laden: 0, out_of_service: 0 };
    const l = locs[c.location || '(no location)'] = locs[c.location || '(no location)'] || { location: c.location || '(no location)', total: 0, empty: 0, laden: 0 };
    t.total++; l.total++;
    if (c.group === 'EMPTY') { e.empty++; t.empty++; l.empty++; if (c.days_in_status > 14) e.idle_14++; } else if (c.group === 'LADEN') { e.laden++; t.laden++; l.laden++; } else { e.out_of_service++; t.out_of_service++; }
    if (c.overdue) e.overdue++; else if (c.free_days_left != null && c.free_days_left <= 2) e.expiring++;
    e.by_status[c.status] = (e.by_status[c.status] || 0) + 1;
  }
  e.teu = round2(e.teu);
  const inSvc = e.total - e.out_of_service;
  e.utilisation = inSvc ? Math.round((e.laden / inSvc) * 100) : 0;
  e.by_type = Object.values(types).sort((a, b) => b.total - a.total);
  e.top_locations = Object.values(locs).sort((a, b) => b.total - a.total).slice(0, 6);
  return e;
}

function tracking(snap, user) {
  const t = today();
  const onBoard = snap.filter((c) => c.status === 'ON_BOARD');
  const rows = onBoard.map((c) => {
    const sh = TR.currentShipment(user, c.id, c.shipment_id);
    return { id: c.id, container_no: c.container_no, type_code: c.type_code, vessel: sh && sh.vessel, voyage: sh && sh.voyage, pod_name: sh && sh.pod_name, pol_name: sh && sh.pol_name, eta: sh && sh.eta,
      days_to_eta: sh && sh.eta ? daysBetween(t, sh.eta) : null, booking_no: sh && sh.booking_no, since: c.last_date };
  }).sort((a, b) => String(a.eta || '9999').localeCompare(String(b.eta || '9999')));
  const recent = db.prepare(`SELECT e.id, e.event_date, e.event_type, e.location, c.id AS container_id, c.container_no, u.full_name AS by_user
    FROM container_events e JOIN containers c ON c.id=e.container_id LEFT JOIN users u ON u.id=e.user_id ORDER BY e.id DESC LIMIT ${S.isAgent(user) ? 300 : 8}`).all();
  let rec = recent;
  if (S.isAgent(user)) { const mine = S.agentContainerIds(user); rec = recent.filter((x) => mine.has(x.container_id) || S.locationAllowed(user, x.location)).slice(0, 8); }
  for (const x of rec) x.label = (L.CONTAINER_STATUS[x.event_type] || {}).label || x.event_type;
  return { in_transit: rows.slice(0, 8), in_transit_total: rows.length, arriving_7d: rows.filter((r) => r.days_to_eta != null && r.days_to_eta <= 7).length, recent_movements: rec };
}

function receivables(t) {
  const b = { not_due: 0, d1_30: 0, d31_60: 0, d61_90: 0, d90_plus: 0 }, debtors = {};
  let recv = 0, pay = 0;
  for (const it of L.openItems({ to: t })) {
    const fx = L.fxRate(it.currency, t) || 1, base = it.signed * fx;
    if (base > 0) {
      recv += base;
      const bk = it.kind === 'DOC' ? (() => { const late = daysBetween(it.due_date, t); return late <= 0 ? 'not_due' : late <= 30 ? 'd1_30' : late <= 60 ? 'd31_60' : late <= 90 ? 'd61_90' : 'd90_plus'; })() : 'not_due';
      b[bk] += base;
      const d = debtors[it.party_id] = debtors[it.party_id] || { party_id: it.party_id, name: it.party_name, outstanding: 0, overdue: 0 };
      d.outstanding += base; if (bk !== 'not_due') d.overdue += base;
    } else pay += -base;
  }
  const overdue = b.d1_30 + b.d31_60 + b.d61_90 + b.d90_plus;
  const since = addDays(t, -30);
  let collected = 0;
  for (const p of db.prepare("SELECT currency, amount FROM payments WHERE direction='RECEIPT' AND status='POSTED' AND pay_date>=?").all(since)) collected += p.amount * (L.fxRate(p.currency, t) || 1);
  return { total: round2(recv), overdue: round2(overdue), payable: round2(pay), collected_30d: round2(collected),
    buckets: Object.fromEntries(Object.entries(b).map(([k, v]) => [k, round2(v)])),
    top_debtors: Object.values(debtors).sort((a, c) => c.outstanding - a.outstanding).slice(0, 5).map((d) => ({ ...d, outstanding: round2(d.outstanding), overdue: round2(d.overdue) })),
    draft_documents: db.prepare("SELECT COUNT(*) n FROM documents WHERE status='DRAFT'").get().n,
    draft_commissions: db.prepare("SELECT COUNT(*) n FROM commission_statements WHERE status='DRAFT'").get().n };
}

function staffDashboard(user) {
  const t = today();
  const out = { role: 'staff', base_currency: L.baseCurrency(), today: t };
  out.shipments_by_status = db.prepare('SELECT status, COUNT(*) n FROM shipments GROUP BY status').all();
  const stats = (m) => db.prepare(`SELECT COUNT(*) n, COALESCE(SUM((SELECT SUM(ty.teu) FROM shipment_containers sc JOIN containers c ON c.id=sc.container_id JOIN container_types ty ON ty.id=c.type_id WHERE sc.shipment_id=s.id)),0) teu
    FROM shipments s WHERE s.status<>'CANCELLED' AND substr(COALESCE(s.etd,s.created_at),1,7)=?`).get(m);
  out.this_month = stats(monthOf(t)); out.last_month = stats(monthOf(t, 1));
  const snap = L.containerSnapshot(t, { inventoryOnly: true });
  out.equipment = equipment(snap);
  out.tracking = tracking(snap, user);
  out.overdue_containers = snap.filter((c) => c.overdue).sort((a, b) => a.free_days_left - b.free_days_left).slice(0, 6)
    .map((c) => ({ id: c.id, container_no: c.container_no, location: c.location, free_days_left: c.free_days_left, booking_no: c.booking_no }));
  const fin = A.can(user.role, 'finance', 'read');
  if (fin) out.receivables = receivables(t);

  // ---- action centre
  const list = [];
  const q = (sql, ...p) => db.prepare(sql).get(...p).n;
  act(list, 'freetime', 'bad', 'Containers past free time', 'Detention / demurrage is accruing - collect or return them', out.equipment.overdue, '#/containers?overdue=1');
  act(list, 'freetime2', 'warn', 'Free time ends within 2 days', 'Arrange delivery or return before charges start', out.equipment.expiring, '#/inventory-report');
  act(list, 'unconfirmed', 'warn', 'Bookings sailing within 3 days that are not confirmed', 'Confirm them (issue the HBL) or cancel', q("SELECT COUNT(*) n FROM shipments WHERE status='BOOKED' AND etd IS NOT NULL AND etd<=?", addDays(t, 3)), '#/shipments?status=BOOKED');
  act(list, 'nocont', 'warn', 'Confirmed FCL shipments with no container yet', 'Allocate containers before the cut-off', q("SELECT COUNT(*) n FROM shipments s WHERE s.status='CONFIRMED' AND s.cargo_type='FCL' AND NOT EXISTS(SELECT 1 FROM shipment_containers x WHERE x.shipment_id=s.id) AND (s.etd IS NULL OR s.etd<=?)", addDays(t, 7)), '#/shipments?status=CONFIRMED');
  act(list, 'late', 'warn', 'Sailed shipments past their ETA', 'Mark them arrived or update the ETA', q("SELECT COUNT(*) n FROM shipments WHERE status='SAILED' AND eta IS NOT NULL AND eta<?", t), '#/shipments?status=SAILED');
  if (A.can(user.role, 'bl', 'read')) act(list, 'blreview', 'info', 'Bills of lading changed by agents', 'Check what the agent changed, then mark it reviewed', q("SELECT COUNT(*) n FROM shipments WHERE agent_edit_at IS NOT NULL AND (reviewed_at IS NULL OR reviewed_at<agent_edit_at)"), '#/bls?review=1');
  if (A.can(user.role, 'schedules', 'read')) {
    let n = 0;
    for (const x of db.prepare('SELECT DISTINCT c.schedule_id, v.vessel, v.voyage, v.pol_id FROM schedule_changes c JOIN vessel_schedules v ON v.id=c.schedule_id WHERE c.applied=0 AND c.dismissed=0').all()) {
      const a = SCH.affected(x); if (a.consols.length || a.shipments.length) n++;
    }
    act(list, 'schedchg', 'warn', 'Vessel schedule dates changed', 'Your bookings / master BLs still show the old dates - review and apply', n, '#/schedules?changes=1');
  }
  if (fin) {
    act(list, 'overdue', 'bad', `Overdue receivables (${out.base_currency} ${out.receivables.overdue.toLocaleString('en-US', { maximumFractionDigits: 0 })})`, 'Send reminders / statements', out.receivables.overdue > 0 ? out.receivables.top_debtors.filter((d) => d.overdue > 0).length : 0, '#/ageing');
    act(list, 'drafts', 'info', 'Draft invoices / commission waiting to be posted', 'Post them so they reach the ledger', out.receivables.draft_documents + out.receivables.draft_commissions, '#/documents?status=DRAFT');
  }
  if (A.can(user.role, 'agreements', 'read')) {
    act(list, 'agrexp', 'bad', 'Agency agreements expired', 'Renew or terminate', q("SELECT COUNT(*) n FROM agreements WHERE status='ACTIVE' AND end_date IS NOT NULL AND end_date<?", t), '#/agreements');
    act(list, 'agrsoon', 'warn', 'Agency agreements expiring within 60 days', 'Start the renewal', q("SELECT COUNT(*) n FROM agreements WHERE status='ACTIVE' AND end_date IS NOT NULL AND end_date>=? AND end_date<=?", t, addDays(t, 60)), '#/agreements');
  }
  act(list, 'idle', 'info', 'Empty containers idle for more than 14 days', 'Reposition, sell space or off-hire', out.equipment.idle_14, '#/containers?group=EMPTY');
  if (A.can(user.role, 'mrg', 'write') && !q('SELECT COUNT(*) n FROM mrg_rates WHERE month=?', monthOf(t))) {
    act(list, 'mrg', 'info', "This month's freight rate & slot cost are not set", 'Copy last month forward or fill them from the tariff book in one click', 1, '#/mrg');
  }
  const sev = { bad: 0, warn: 1, info: 2 };
  out.actions = list.sort((a, b) => sev[a.severity] - sev[b.severity]);
  return out;
}

function agentDashboard(user) {
  const t = today();
  const out = { role: 'agent', today: t, agent_name: (db.prepare('SELECT name FROM parties WHERE id=?').get(user.agent_party_id) || {}).name || '', locations: user.locations || '' };
  const snap = S.filterContainers(user, L.containerSnapshot(t, { inventoryOnly: true }));
  out.equipment = equipment(snap);
  out.tracking = tracking(snap, user);
  out.shipments_by_status = db.prepare('SELECT status, COUNT(*) n FROM shipments WHERE agent_id=? GROUP BY status').all(Number(user.agent_party_id) || -1);
  const list = [];
  const aid = Number(user.agent_party_id) || -1;
  const n = (sql, ...p) => db.prepare(sql).get(...p).n;
  act(list, 'freetime', 'bad', 'Containers past free time at your locations', 'Please arrange delivery or return', out.equipment.overdue, '#/containers?overdue=1');
  act(list, 'blinc', 'warn', 'Bookings whose BL details are incomplete', 'Add shipper / consignee, goods and weight so HUB LINE can issue the BL', n(`SELECT COUNT(*) n FROM shipments WHERE agent_id=? AND status IN ('BOOKED','CONFIRMED')
    AND (COALESCE(shipper_text,'')='' AND shipper_id IS NULL OR COALESCE(consignee_text,'')='' AND consignee_id IS NULL OR COALESCE(commodity,'')='' OR gross_weight IS NULL)`, aid), '#/bls?incomplete=1');
  act(list, 'arriving', 'info', 'Containers arriving within 7 days', 'Expect them at your port', out.tracking.arriving_7d, '#/track');
  out.actions = list;
  return out;
}

// ---------------------------------------------------------------- per-module dashboards (left-nav "<Module> dashboard" pages)
function financeDash(user) {
  const t = today();
  const r = receivables(t);
  const docStats = db.prepare("SELECT doc_type, COUNT(*) n, COALESCE(SUM(CASE WHEN status='DRAFT' THEN 1 ELSE 0 END),0) draft FROM documents GROUP BY doc_type").all();
  const recentDocuments = db.prepare(`SELECT d.id, d.doc_no, d.doc_type, d.doc_date, d.currency, d.total, d.status, p.name AS party_name
    FROM documents d JOIN parties p ON p.id=d.party_id ORDER BY d.id DESC LIMIT 6`).all();
  const recentPayments = db.prepare(`SELECT p.id, p.pay_no, p.direction, p.pay_date, p.currency, p.amount, pt.name AS party_name
    FROM payments p JOIN parties pt ON pt.id=p.party_id WHERE p.status='POSTED' ORDER BY p.id DESC LIMIT 6`).all();
  const commission = db.prepare("SELECT status, COUNT(*) n, COALESCE(SUM(total),0) total FROM commission_statements GROUP BY status").all();
  const mrgSet = !!db.prepare('SELECT COUNT(*) n FROM mrg_rates WHERE month=?').get(monthOf(t)).n;
  const list = [];
  act(list, 'overdue', 'bad', `Overdue receivables (${L.baseCurrency()} ${r.overdue.toLocaleString('en-US', { maximumFractionDigits: 0 })})`, 'Send reminders / statements', r.overdue > 0 ? r.top_debtors.filter((d) => d.overdue > 0).length : 0, '#/ageing');
  act(list, 'drafts', 'info', 'Draft invoices / notes waiting to be posted', 'Post them so they reach the ledger', r.draft_documents, '#/documents?status=DRAFT');
  act(list, 'draftcomm', 'info', 'Draft commission statements', 'Review and post them', r.draft_commissions, '#/commissions?status=DRAFT');
  if (!mrgSet) act(list, 'mrg', 'warn', "This month's freight rate & slot cost are not set", 'Copy last month forward or fill them from the tariff book', 1, '#/mrg');
  return { today: t, base_currency: L.baseCurrency(), receivables: r, doc_stats: docStats, recent_documents: recentDocuments, recent_payments: recentPayments, commission, mrg_set: mrgSet, actions: list };
}

function operationsDash() {
  const t = today();
  const shipments_by_status = db.prepare('SELECT status, COUNT(*) n FROM shipments GROUP BY status').all();
  const stats = (m) => db.prepare(`SELECT COUNT(*) n, COALESCE(SUM((SELECT SUM(ty.teu) FROM shipment_containers sc JOIN containers c ON c.id=sc.container_id JOIN container_types ty ON ty.id=c.type_id WHERE sc.shipment_id=s.id)),0) teu
    FROM shipments s WHERE s.status<>'CANCELLED' AND substr(COALESCE(s.etd,s.created_at),1,7)=?`).get(m);
  const this_month = stats(monthOf(t)), last_month = stats(monthOf(t, 1));
  const recent = db.prepare(`SELECT s.id, s.booking_no, s.hbl_no, s.status, s.cargo_type, s.vessel, s.voyage, s.etd, s.eta, p.name AS customer_name
    FROM shipments s LEFT JOIN parties p ON p.id=s.customer_id ORDER BY s.id DESC LIMIT 6`).all();
  const consols_open = db.prepare("SELECT COUNT(*) n FROM consols WHERE status NOT IN ('COMPLETED','CANCELLED')").get().n;
  const list = [];
  const q = (sql, ...p) => db.prepare(sql).get(...p).n;
  act(list, 'unconfirmed', 'warn', 'Bookings sailing within 3 days that are not confirmed', 'Confirm them (issue the HBL) or cancel', q("SELECT COUNT(*) n FROM shipments WHERE status='BOOKED' AND etd IS NOT NULL AND etd<=?", addDays(t, 3)), '#/shipments?status=BOOKED');
  act(list, 'nocont', 'warn', 'Confirmed FCL shipments with no container yet', 'Allocate containers before the cut-off', q("SELECT COUNT(*) n FROM shipments s WHERE s.status='CONFIRMED' AND s.cargo_type='FCL' AND NOT EXISTS(SELECT 1 FROM shipment_containers x WHERE x.shipment_id=s.id) AND (s.etd IS NULL OR s.etd<=?)", addDays(t, 7)), '#/shipments?status=CONFIRMED');
  act(list, 'late', 'warn', 'Sailed shipments past their ETA', 'Mark them arrived or update the ETA', q("SELECT COUNT(*) n FROM shipments WHERE status='SAILED' AND eta IS NOT NULL AND eta<?", t), '#/shipments?status=SAILED');
  return { today: t, shipments_by_status, this_month, last_month, recent, consols_open, actions: list };
}

function documentationDash(user) {
  const t = today(), agent = S.isAgent(user);
  const aid = Number(user.agent_party_id) || -1;
  const where = agent ? 'WHERE s.agent_id=?' : '';
  const args = agent ? [aid] : [];
  const by_status = db.prepare(`SELECT s.status, COUNT(*) n FROM shipments s ${where} GROUP BY s.status`).all(...args);
  const issued_this_month = db.prepare(`SELECT COUNT(*) n FROM shipments s ${where ? where + ' AND' : 'WHERE'} substr(s.created_at,1,7)=?`).get(...args, monthOf(t)).n;
  const pending_review = db.prepare(`SELECT COUNT(*) n FROM shipments s ${where ? where + ' AND' : 'WHERE'} s.agent_edit_at IS NOT NULL AND (s.reviewed_at IS NULL OR s.reviewed_at<s.agent_edit_at)`).get(...args).n;
  const recent = db.prepare(`SELECT s.id, s.booking_no, s.hbl_no, s.status, s.vessel, s.voyage, s.etd, p.name AS customer_name
    FROM shipments s LEFT JOIN parties p ON p.id=s.customer_id ${where} ORDER BY s.id DESC LIMIT 6`).all(...args);
  const list = [];
  if (agent) {
    const n = (sql, ...p) => db.prepare(sql).get(...p).n;
    act(list, 'blinc', 'warn', 'Bookings whose BL details are incomplete', 'Add shipper / consignee, goods and weight so HUB LINE can issue the BL', n(`SELECT COUNT(*) n FROM shipments WHERE agent_id=? AND status IN ('BOOKED','CONFIRMED')
      AND (COALESCE(shipper_text,'')='' AND shipper_id IS NULL OR COALESCE(consignee_text,'')='' AND consignee_id IS NULL OR COALESCE(commodity,'')='' OR gross_weight IS NULL)`, aid), '#/bls?incomplete=1');
  } else {
    act(list, 'blreview', 'info', 'Bills of lading changed by agents', 'Check what the agent changed, then mark it reviewed', pending_review, '#/bls?review=1');
  }
  return { today: t, role: agent ? 'agent' : 'staff', by_status, issued_this_month, pending_review, recent, actions: list };
}

function equipmentDash(user) {
  const t = today(), agent = S.isAgent(user);
  const snap0 = L.containerSnapshot(t, { inventoryOnly: true });
  const snap = agent ? S.filterContainers(user, snap0) : snap0;
  const e = equipment(snap);
  const tr = tracking(snap, user);
  const overdue_containers = snap.filter((c) => c.overdue).sort((a, b) => a.free_days_left - b.free_days_left).slice(0, 8)
    .map((c) => ({ id: c.id, container_no: c.container_no, location: c.location, free_days_left: c.free_days_left, booking_no: c.booking_no }));
  const list = [];
  act(list, 'freetime', 'bad', 'Containers past free time', 'Detention / demurrage is accruing - collect or return them', e.overdue, '#/containers?overdue=1');
  act(list, 'freetime2', 'warn', 'Free time ends within 2 days', 'Arrange delivery or return before charges start', e.expiring, agent ? '#/containers' : '#/inventory-report');
  if (!agent) act(list, 'idle', 'info', 'Empty containers idle for more than 14 days', 'Reposition, sell space or off-hire', e.idle_14, '#/containers?group=EMPTY');
  return { today: t, role: agent ? 'agent' : 'staff', equipment: e, tracking: tr, overdue_containers, actions: list };
}

function tradeDash() {
  const t = today();
  const active_agents = db.prepare('SELECT COUNT(*) n FROM parties WHERE is_agent=1 AND active=1').get().n;
  const active_customers = db.prepare('SELECT COUNT(*) n FROM parties WHERE is_customer=1 AND active=1').get().n;
  const active_tariffs = db.prepare('SELECT COUNT(*) n FROM tariffs WHERE active=1').get().n;
  const agreements_by_status = db.prepare(`SELECT CASE WHEN status='ACTIVE' AND end_date IS NOT NULL AND end_date<? THEN 'EXPIRED' ELSE status END AS status, COUNT(*) n
    FROM agreements GROUP BY 1`).all(t);
  const expiring_soon = db.prepare(`SELECT a.id, a.agreement_no, a.title, a.end_date, p.name AS agent_name FROM agreements a JOIN parties p ON p.id=a.agent_id
    WHERE a.status='ACTIVE' AND a.end_date IS NOT NULL AND a.end_date>=? AND a.end_date<=? ORDER BY a.end_date LIMIT 6`).all(t, addDays(t, 60));
  const top_agents = db.prepare(`SELECT p.id, p.name, COUNT(*) n, COALESCE(SUM(cs.total),0) total FROM commission_statements cs JOIN parties p ON p.id=cs.agent_id
    WHERE cs.status='POSTED' GROUP BY p.id ORDER BY total DESC LIMIT 5`).all();
  const list = [];
  const q = (sql, ...p) => db.prepare(sql).get(...p).n;
  act(list, 'agrexp', 'bad', 'Agency agreements expired', 'Renew or terminate', q("SELECT COUNT(*) n FROM agreements WHERE status='ACTIVE' AND end_date IS NOT NULL AND end_date<?", t), '#/agreements');
  act(list, 'agrsoon', 'warn', 'Agency agreements expiring within 60 days', 'Start the renewal', expiring_soon.length, '#/agreements');
  return { today: t, active_agents, active_customers, active_tariffs, agreements_by_status, expiring_soon, top_agents, actions: list };
}

function vesselDash(user) {
  const t = today();
  const upcoming = db.prepare(`SELECT v.id, v.vessel, v.voyage, v.etd, v.eta, v.cutoff_date, COALESCE(ca.name, v.carrier_text) AS carrier_name,
      COALESCE(pl.name, v.pol_text) AS pol_name, COALESCE(pd.name, v.pod_text) AS pod_name
    FROM vessel_schedules v LEFT JOIN parties ca ON ca.id=v.carrier_id LEFT JOIN ports pl ON pl.id=v.pol_id LEFT JOIN ports pd ON pd.id=v.pod_id
    WHERE v.active=1 AND v.etd>=? ORDER BY v.etd LIMIT 8`).all(t);
  const added_7d = db.prepare("SELECT COUNT(*) n FROM vessel_schedules WHERE active=1 AND substr(created_at,1,10)>=?").get(addDays(t, -7)).n;
  const sources = A.can(user.role, 'schedules', 'write') ? db.prepare('SELECT id, name, auto_refresh, last_run, last_status, last_count FROM schedule_sources WHERE active=1 ORDER BY id').all() : [];
  let changed = 0;
  if (A.can(user.role, 'schedules', 'read')) {
    for (const x of db.prepare('SELECT DISTINCT c.schedule_id, v.vessel, v.voyage, v.pol_id FROM schedule_changes c JOIN vessel_schedules v ON v.id=c.schedule_id WHERE c.applied=0 AND c.dismissed=0').all()) {
      const a = SCH.affected(x); if (a.consols.length || a.shipments.length) changed++;
    }
  }
  const list = [];
  act(list, 'schedchg', 'warn', 'Vessel schedule dates changed', 'Your bookings / master BLs still show the old dates - review and apply', changed, '#/schedules?changes=1');
  return { today: t, upcoming, added_7d, sources, actions: list };
}

module.exports = {
  staffDashboard, agentDashboard,
  moduleDash: { finance: financeDash, operations: operationsDash, documentation: documentationDash, equipment: equipmentDash, trade: tradeDash, vessel: vesselDash },
};
