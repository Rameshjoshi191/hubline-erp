'use strict';
// Storage / demurrage / detention, auto-calculated from the tariff. A container past its free time accrues a daily
// charge; this screen suggests, for each overdue container, the days not yet billed and the applicable tariff rate,
// and raises a draft debit note for them. Already-billed days are tracked in detention_invoices so the next run
// only bills the new days.
const express = require('express');
const { db, audit, today, round2, daysBetween, addDays } = require('../db');
const { need } = require('../auth');
const { bad } = require('../util');
const L = require('../logic');
const S = require('../services');

const r = express.Router();

// most specific SELL tariff for STOR / DET / DEM, PER_DAY, for this container/shipment
function lookupRate(shipment, containerTypeId) {
  const date = today();
  const rows = db.prepare(`SELECT t.*, cc.code AS charge_code FROM tariffs t JOIN charge_codes cc ON cc.id=t.charge_code_id
    WHERE t.active=1 AND t.rate_type='SELL' AND t.unit='PER_DAY' AND cc.code IN ('STOR','DET','DEM')
      AND (t.valid_from IS NULL OR t.valid_from<=@d) AND (t.valid_to IS NULL OR t.valid_to>=@d)
      AND (t.pol_id IS NULL OR t.pol_id=@pol) AND (t.pod_id IS NULL OR t.pod_id=@pod)
      AND (t.container_type_id IS NULL OR t.container_type_id=@ctype)
      AND (t.party_id IS NULL OR t.party_id IN (@p1,@p2))`)
    .all({ d: date, pol: shipment ? shipment.pol_id || 0 : 0, pod: shipment ? shipment.pod_id || 0 : 0, ctype: containerTypeId || 0, p1: shipment ? shipment.customer_id || 0 : 0, p2: shipment ? shipment.agent_id || 0 : 0 });
  if (!rows.length) return null;
  const score = (t) => (t.party_id ? 4 : 0) + (t.pol_id ? 1 : 0) + (t.pod_id ? 1 : 0) + (t.container_type_id ? 1 : 0);
  rows.sort((a, b) => score(b) - score(a) || b.id - a.id);
  return rows[0];
}

function pendingRows(asOf) {
  asOf = asOf || today();
  const snap = L.containerSnapshot(asOf, { inventoryOnly: true }).filter((c) => c.overdue);
  const out = [];
  for (const c of snap) {
    const lastBilled = db.prepare('SELECT MAX(to_date) AS d FROM detention_invoices WHERE container_id=?').get(c.id).d;
    const from = lastBilled ? addDays(lastBilled, 1) : addDays(c.free_until, 1);
    if (from > asOf) continue;
    const days = daysBetween(from, asOf) + 1;
    if (days <= 0) continue;
    const shipment = c.shipment_id ? db.prepare('SELECT * FROM shipments WHERE id=?').get(c.shipment_id) : null;
    const tariff = lookupRate(shipment, c.type_id);
    out.push({
      container_id: c.id, container_no: c.container_no, type_code: c.type_code, location: c.location,
      shipment_id: c.shipment_id, booking_no: c.booking_no, hbl_no: c.hbl_no,
      customer_id: shipment ? shipment.customer_id : null, free_until: c.free_until, from, to: asOf, days,
      rate: tariff ? tariff.rate : null, currency: tariff ? tariff.currency : null, charge_code_id: tariff ? tariff.charge_code_id : null, charge_code: tariff ? tariff.charge_code : null,
      amount: tariff ? round2(tariff.rate * days) : null,
      issue: !shipment ? 'No shipment is linked to this container - cannot determine who to bill.' : !tariff ? 'No PER_DAY storage/detention tariff found for this lane and container type.' : null,
    });
  }
  return out;
}

r.get('/detention/pending', need('containers', 'read'), (req, res) => res.json(pendingRows(req.query.as_of)));

r.post('/detention/charge', need('finance', 'write'), (req, res) => {
  const asOf = req.body.as_of || today();
  const row = pendingRows(asOf).find((x) => x.container_id === Number(req.body.container_id));
  if (!row) bad('That container has nothing pending to bill as at this date.');
  if (row.issue) bad(row.issue);
  const docId = S.createDocument({
    doc_type: 'DN', party_id: row.customer_id, shipment_id: row.shipment_id, doc_date: asOf, currency: row.currency,
    narration: `Storage / detention - container ${row.container_no}, ${row.days} day(s) from ${row.from} to ${row.to}`,
    lines: [{ charge_code_id: row.charge_code_id, description: `${row.charge_code} - container ${row.container_no} (${row.days} day(s) over free time)`, qty: row.days, unit: 'PER_DAY', rate: row.rate, vat_rate: 0 }],
  }, req.user);
  db.prepare('INSERT INTO detention_invoices(container_id,shipment_id,document_id,from_date,to_date,days,rate,amount,currency,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run(row.container_id, row.shipment_id, docId, row.from, row.to, row.days, row.rate, row.amount, row.currency, req.user.id);
  audit(req.user, 'CHARGE', 'detention', row.container_id, { document_id: docId, days: row.days, amount: row.amount });
  res.json({ ok: true, document_id: docId });
});

r.post('/detention/charge-bulk', need('finance', 'write'), (req, res) => {
  const ids = Array.isArray(req.body.container_ids) ? req.body.container_ids.map(Number) : bad('Select at least one container.');
  const asOf = req.body.as_of || today();
  const pending = pendingRows(asOf);
  const created = [], skipped = [];
  for (const id of ids) {
    const row = pending.find((x) => x.container_id === id);
    if (!row || row.issue) { skipped.push({ container_id: id, reason: row ? row.issue : 'Nothing pending' }); continue; }
    const docId = S.createDocument({
      doc_type: 'DN', party_id: row.customer_id, shipment_id: row.shipment_id, doc_date: asOf, currency: row.currency,
      narration: `Storage / detention - container ${row.container_no}, ${row.days} day(s) from ${row.from} to ${row.to}`,
      lines: [{ charge_code_id: row.charge_code_id, description: `${row.charge_code} - container ${row.container_no} (${row.days} day(s) over free time)`, qty: row.days, unit: 'PER_DAY', rate: row.rate, vat_rate: 0 }],
    }, req.user);
    db.prepare('INSERT INTO detention_invoices(container_id,shipment_id,document_id,from_date,to_date,days,rate,amount,currency,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)')
      .run(row.container_id, row.shipment_id, docId, row.from, row.to, row.days, row.rate, row.amount, row.currency, req.user.id);
    created.push({ container_id: id, document_id: docId });
  }
  audit(req.user, 'BULK_CHARGE', 'detention', null, { created: created.length, skipped: skipped.length });
  res.json({ created, skipped });
});

module.exports = r;
