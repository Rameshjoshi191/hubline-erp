'use strict';
// Leased containers: lease contract terms (lessor, committed period and rate, the per-day rate after that period,
// one-way vs round-trip, pickup / drop-off locations) and which containers sit under each lease.
const express = require('express');
const { db, audit, today, round2, daysBetween, addDays } = require('../db');
const { need } = require('../auth');
const { bad, extract, insertRow, updateRow, diff } = require('../util');

const r = express.Router();

function costInfo(lease, asOf) {
  asOf = asOf || today();
  const end = asOf < lease.start_date ? lease.start_date : asOf;
  const periodEnd = addDays(lease.start_date, lease.committed_period_days - 1);
  const phase = lease.status === 'CLOSED' && lease.end_date ? (lease.end_date <= periodEnd ? 'COMMITTED' : 'AFTER_PERIOD') : (end <= periodEnd ? 'COMMITTED' : 'AFTER_PERIOD');
  const closeAt = lease.status === 'CLOSED' && lease.end_date ? lease.end_date : end;
  let cost = 0;
  const committedDays = Math.max(0, Math.min(daysBetween(lease.start_date, closeAt) + 1, lease.committed_period_days));
  cost += committedDays * lease.period_rate_per_day;
  const afterDays = Math.max(0, daysBetween(periodEnd, closeAt));
  cost += afterDays * lease.after_period_rate_per_day;
  return { phase, period_end: periodEnd, days_elapsed: daysBetween(lease.start_date, closeAt) + 1, cost_to_date: round2(cost) };
}

const LEASE_SELECT = `SELECT l.*, p.name AS lessor_name, t.code AS container_type_code, u.full_name AS created_by_name,
    (SELECT COUNT(*) FROM containers c WHERE c.lease_id=l.id) AS container_count
  FROM container_leases l JOIN parties p ON p.id=l.lessor_id LEFT JOIN container_types t ON t.id=l.container_type_id LEFT JOIN users u ON u.id=l.created_by`;

r.get('/leases', need('leases', 'read'), (req, res) => {
  const w = [], p = {};
  if (req.query.status) { w.push('l.status=@st'); p.st = req.query.status; }
  if (req.query.q) { w.push('(l.lease_no LIKE @q OR p.name LIKE @q)'); p.q = `%${req.query.q}%`; }
  const rows = db.prepare(`${LEASE_SELECT} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY l.id DESC`).all(p);
  for (const x of rows) Object.assign(x, costInfo(x));
  res.json(rows);
});
r.get('/leases/:id', need('leases', 'read'), (req, res) => {
  const l = db.prepare(`${LEASE_SELECT} WHERE l.id=?`).get(req.params.id);
  if (!l) bad('Not found', 404);
  Object.assign(l, costInfo(l));
  l.containers = db.prepare(`SELECT c.id, c.container_no, c.status, c.location, t.code AS type_code FROM containers c JOIN container_types t ON t.id=c.type_id WHERE c.lease_id=? ORDER BY c.container_no`).all(l.id);
  res.json(l);
});

const LEASE_FIELDS = [
  { name: 'lessor_id', type: 'int', required: true, label: 'Lessor' }, { name: 'lease_type', type: 'upper', def: 'ONE_WAY' },
  { name: 'container_type_id', type: 'int' }, { name: 'start_date', type: 'date', required: true, label: 'Lease start date' },
  { name: 'committed_period_days', type: 'int', required: true, label: 'Committed period (days)' },
  { name: 'period_rate_per_day', type: 'real', required: true, label: 'Rate per day during the committed period' },
  { name: 'after_period_rate_per_day', type: 'real', required: true, label: 'Rate per day after the committed period' },
  { name: 'currency', type: 'upper', def: 'USD' }, { name: 'pickup_location' }, { name: 'dropoff_location' }, { name: 'remarks' },
];
function checkLease(v) {
  if (v.lease_type && !['ONE_WAY', 'ROUND_TRIP'].includes(v.lease_type)) bad('Lease type must be one-way or round-trip.');
  if (v.committed_period_days != null && v.committed_period_days < 0) bad('Committed period cannot be negative.');
  for (const k of ['period_rate_per_day', 'after_period_rate_per_day']) if (v[k] != null && v[k] < 0) bad('Rates cannot be negative.');
}
r.post('/leases', need('leases', 'write'), (req, res) => {
  const v = extract(req.body, LEASE_FIELDS); checkLease(v);
  const p = db.prepare('SELECT is_vendor, is_carrier, name FROM parties WHERE id=?').get(v.lessor_id);
  if (!p) bad('Choose the lessor.');
  v.created_by = req.user.id;
  const no = 'LSE-' + String(Date.now()).slice(-8);
  v.lease_no = no;
  const id = insertRow('container_leases', v);
  audit(req.user, 'CREATE', 'container_lease', id, { lease_no: no, lessor_id: v.lessor_id });
  res.json({ id, lease_no: no });
});
r.put('/leases/:id', need('leases', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM container_leases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (cur.status === 'CLOSED') bad('This lease is closed.');
  const v = extract(req.body, LEASE_FIELDS, { partial: true }); checkLease(v);
  updateRow('container_leases', cur.id, v);
  audit(req.user, 'UPDATE', 'container_lease', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.post('/leases/:id/close', need('leases', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM container_leases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (cur.status === 'CLOSED') bad('Already closed.');
  const end_date = req.body.end_date || today();
  if (end_date < cur.start_date) bad('End date is before the lease start date.');
  db.prepare("UPDATE container_leases SET status='CLOSED', end_date=? WHERE id=?").run(end_date, cur.id);
  audit(req.user, 'CLOSE', 'container_lease', cur.id, { end_date });
  res.json({ ok: true });
});
r.delete('/leases/:id', need('leases', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM container_leases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (db.prepare('SELECT 1 FROM containers WHERE lease_id=?').get(cur.id)) bad('Containers are attached to this lease. Detach them first.');
  db.prepare('DELETE FROM container_leases WHERE id=?').run(cur.id);
  audit(req.user, 'DELETE', 'container_lease', cur.id);
  res.json({ ok: true });
});

// -------------------------------------------------------------- attach / detach containers
r.post('/leases/:id/containers', need('leases', 'write'), (req, res) => {
  const lease = db.prepare('SELECT * FROM container_leases WHERE id=?').get(req.params.id);
  if (!lease) bad('Not found', 404);
  if (lease.status === 'CLOSED') bad('This lease is closed.');
  const c = db.prepare('SELECT * FROM containers WHERE id=?').get(req.body.container_id);
  if (!c) bad('Choose a container.');
  if (c.lease_id && c.lease_id !== lease.id) bad('That container is already attached to another lease.');
  db.prepare("UPDATE containers SET lease_id=?, ownership='LEASED', owner_id=? WHERE id=?").run(lease.id, lease.lessor_id, c.id);
  audit(req.user, 'ATTACH', 'container_lease', lease.id, { container: c.container_no });
  res.json({ ok: true });
});
r.delete('/leases/:id/containers/:cid', need('leases', 'write'), (req, res) => {
  const lease = db.prepare('SELECT * FROM container_leases WHERE id=?').get(req.params.id);
  if (!lease) bad('Not found', 404);
  const c = db.prepare('SELECT * FROM containers WHERE id=? AND lease_id=?').get(req.params.cid, lease.id);
  if (!c) bad('That container is not on this lease.', 404);
  db.prepare('UPDATE containers SET lease_id=NULL WHERE id=?').run(c.id);
  audit(req.user, 'DETACH', 'container_lease', lease.id, { container: c.container_no });
  res.json({ ok: true });
});

module.exports = r;
