'use strict';
// KYC / compliance: staff create a case for a customer or vendor, upload the party's documents (file or link),
// fill the compliance form, then an administrator approves or rejects it. Only an approved case clears the party
// for new bookings/billing once it has an active case (see assertKycOk in ops.js / services.js) - a party that was
// never put through KYC is never blocked, so existing data is unaffected.
const express = require('express');
const { db, audit, today } = require('../db');
const A = require('../auth');
const { need } = A;
const { bad, extract, insertRow } = require('../util');

const r = express.Router();

const DOC_TYPES = ['TRADE_LICENSE', 'PASSPORT', 'COMPLIANCE_FORM', 'OTHER'];
const CASE_SELECT = `SELECT c.*, p.name AS party_name, p.code AS party_code, p.is_customer, p.is_vendor, p.is_carrier, p.is_agent,
    cru.full_name AS created_by_name, su.full_name AS submitted_by_name, ru.full_name AS reviewed_by_name,
    (SELECT COUNT(*) FROM kyc_documents d WHERE d.case_id=c.id) AS document_count
  FROM kyc_cases c JOIN parties p ON p.id=c.party_id
  LEFT JOIN users cru ON cru.id=c.created_by LEFT JOIN users su ON su.id=c.submitted_by LEFT JOIN users ru ON ru.id=c.reviewed_by`;

r.get('/kyc/cases', need('kyc', 'read'), (req, res) => {
  const w = [], p = {};
  if (req.query.party_id) { w.push('c.party_id=@party'); p.party = req.query.party_id; }
  if (req.query.status) { w.push('c.status=@st'); p.st = req.query.status; }
  if (req.query.q) { w.push('(p.name LIKE @q OR p.code LIKE @q OR c.legal_name LIKE @q)'); p.q = `%${req.query.q}%`; }
  res.json(db.prepare(`${CASE_SELECT} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY c.id DESC`).all(p));
});

r.get('/kyc/cases/:id', need('kyc', 'read'), (req, res) => {
  const c = db.prepare(`${CASE_SELECT} WHERE c.id=?`).get(req.params.id);
  if (!c) bad('Not found', 404);
  c.documents = db.prepare(`SELECT d.id, d.case_id, d.doc_type, d.method, d.filename, d.mime, d.link_url, d.remarks, d.uploaded_at, u.full_name AS uploaded_by_name
    FROM kyc_documents d LEFT JOIN users u ON u.id=d.uploaded_by WHERE d.case_id=? ORDER BY d.id`).all(c.id);
  res.json(c);
});

const CASE_FIELDS = [
  { name: 'party_id', type: 'int', required: true, label: 'Customer / vendor' },
  { name: 'legal_name' }, { name: 'reg_no' }, { name: 'tax_no' }, { name: 'country' }, { name: 'compliance_notes' },
];
function checkCaseParty(partyId) {
  const p = db.prepare('SELECT * FROM parties WHERE id=?').get(partyId);
  if (!p) bad('Party not found.');
  if (!p.is_customer && !p.is_vendor) bad('KYC cases are for customers and vendors. Mark the party as a customer or vendor first.');
  return p;
}

r.post('/kyc/cases', need('kyc', 'write'), (req, res) => {
  const v = extract(req.body, CASE_FIELDS);
  checkCaseParty(v.party_id);
  if (db.prepare("SELECT 1 FROM kyc_cases WHERE party_id=? AND status IN ('PENDING','SUBMITTED')").get(v.party_id)) bad('There is already an open KYC case for this party.', 409);
  v.created_by = req.user.id;
  const id = db.transaction(() => {
    const cid = insertRow('kyc_cases', v);
    db.prepare("UPDATE parties SET kyc_status='PENDING' WHERE id=?").run(v.party_id);
    return cid;
  })();
  audit(req.user, 'CREATE', 'kyc_case', id, { party_id: v.party_id });
  res.json({ id });
});

r.put('/kyc/cases/:id', need('kyc', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM kyc_cases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (!['PENDING', 'SUBMITTED'].includes(cur.status)) bad('This case has been decided and can no longer be edited. Start a new case instead.');
  const v = extract(req.body, CASE_FIELDS.filter((f) => f.name !== 'party_id'), { partial: true });
  const cols = Object.keys(v);
  if (cols.length) db.prepare(`UPDATE kyc_cases SET ${cols.map((c) => `${c}=@${c}`).join(',')} WHERE id=@__id`).run({ ...v, __id: cur.id });
  audit(req.user, 'UPDATE', 'kyc_case', cur.id, v);
  res.json({ ok: true });
});

// -------------------------------------------------------------- documents (staff upload on the party's behalf)
// Raw file upload: POST /kyc/cases/:id/documents?doc_type=TRADE_LICENSE  (body = the file bytes, X-Filename header set by the client)
r.post('/kyc/cases/:id/documents', need('kyc', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM kyc_cases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (!['PENDING', 'SUBMITTED'].includes(cur.status)) bad('This case has been decided. Start a new case to upload further documents.');
  const docType = String(req.query.doc_type || 'OTHER').toUpperCase();
  if (!DOC_TYPES.includes(docType)) bad('Unknown document type.');
  if (!Buffer.isBuffer(req.body) || !req.body.length) bad('Choose a file to upload.');
  if (req.body.length > 8 * 1024 * 1024) bad('That file is too large (limit 8 MB).');
  let filename = '';
  try { filename = decodeURIComponent(req.get('X-Filename') || ''); } catch { filename = ''; }
  const mime = req.get('Content-Type') || 'application/octet-stream';
  const id = db.prepare('INSERT INTO kyc_documents(case_id,doc_type,method,filename,mime,data,uploaded_by) VALUES(?,?,\'FILE\',?,?,?,?)')
    .run(cur.id, docType, filename || 'document', mime, req.body, req.user.id).lastInsertRowid;
  audit(req.user, 'UPLOAD', 'kyc_document', id, { case_id: cur.id, doc_type: docType, filename });
  res.json({ id });
});
// Link method: POST /kyc/cases/:id/documents/link  { doc_type, link_url, remarks }
r.post('/kyc/cases/:id/documents/link', need('kyc', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM kyc_cases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (!['PENDING', 'SUBMITTED'].includes(cur.status)) bad('This case has been decided. Start a new case to add further documents.');
  const docType = String(req.body.doc_type || 'OTHER').toUpperCase();
  if (!DOC_TYPES.includes(docType)) bad('Unknown document type.');
  const url = String(req.body.link_url || '').trim();
  try { const u = new URL(url); if (!['http:', 'https:'].includes(u.protocol)) throw new Error(); } catch { bad('Enter a valid http:// or https:// link.'); }
  const id = db.prepare("INSERT INTO kyc_documents(case_id,doc_type,method,link_url,remarks,uploaded_by) VALUES(?,?,'LINK',?,?,?)")
    .run(cur.id, docType, url, req.body.remarks || null, req.user.id).lastInsertRowid;
  audit(req.user, 'UPLOAD', 'kyc_document', id, { case_id: cur.id, doc_type: docType, link: url });
  res.json({ id });
});
r.get('/kyc/documents/:id/download', need('kyc', 'read'), (req, res) => {
  const d = db.prepare('SELECT * FROM kyc_documents WHERE id=?').get(req.params.id);
  if (!d) bad('Not found', 404);
  if (d.method !== 'FILE' || !d.data) bad('This item is a link, not an uploaded file.');
  res.setHeader('Content-Type', d.mime || 'application/octet-stream');
  res.setHeader('Content-Disposition', `inline; filename="${String(d.filename || 'document').replace(/[^\w.\-]+/g, '_')}"`);
  res.end(d.data);
});
r.delete('/kyc/documents/:id', need('kyc', 'write'), (req, res) => {
  const d = db.prepare('SELECT d.*, c.status AS case_status FROM kyc_documents d JOIN kyc_cases c ON c.id=d.case_id WHERE d.id=?').get(req.params.id);
  if (!d) bad('Not found', 404);
  if (!['PENDING', 'SUBMITTED'].includes(d.case_status)) bad('This case has been decided and its documents can no longer be changed.');
  db.prepare('DELETE FROM kyc_documents WHERE id=?').run(d.id);
  audit(req.user, 'DELETE', 'kyc_document', d.id, { case_id: d.case_id });
  res.json({ ok: true });
});

// -------------------------------------------------------------- workflow
r.post('/kyc/cases/:id/submit', need('kyc', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM kyc_cases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (cur.status !== 'PENDING') bad('Only a pending case can be submitted.');
  const n = db.prepare('SELECT COUNT(*) n FROM kyc_documents WHERE case_id=?').get(cur.id).n;
  if (!n) bad('Upload at least one document (e.g. trade licence or compliance form) before submitting.');
  db.transaction(() => {
    db.prepare("UPDATE kyc_cases SET status='SUBMITTED', submitted_by=?, submitted_at=datetime('now') WHERE id=?").run(req.user.id, cur.id);
    db.prepare("UPDATE parties SET kyc_status='SUBMITTED' WHERE id=?").run(cur.party_id);
  })();
  audit(req.user, 'SUBMIT', 'kyc_case', cur.id);
  res.json({ ok: true });
});
// approval is restricted to administrators, regardless of the 'kyc' write permission
r.post('/kyc/cases/:id/approve', need('kyc', 'write'), (req, res) => {
  if (req.user.role !== 'admin') bad('Only an administrator can approve a KYC case.', 403);
  const cur = db.prepare('SELECT * FROM kyc_cases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (cur.status !== 'SUBMITTED') bad('Only a submitted case can be approved.');
  db.transaction(() => {
    db.prepare("UPDATE kyc_cases SET status='APPROVED', reviewed_by=?, reviewed_at=datetime('now') WHERE id=?").run(req.user.id, cur.id);
    db.prepare("UPDATE parties SET kyc_status='APPROVED' WHERE id=?").run(cur.party_id);
  })();
  audit(req.user, 'APPROVE', 'kyc_case', cur.id);
  res.json({ ok: true });
});
r.post('/kyc/cases/:id/reject', need('kyc', 'write'), (req, res) => {
  if (req.user.role !== 'admin') bad('Only an administrator can reject a KYC case.', 403);
  const cur = db.prepare('SELECT * FROM kyc_cases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (cur.status !== 'SUBMITTED') bad('Only a submitted case can be rejected.');
  if (!String(req.body.reason || '').trim()) bad('Enter a reason for rejecting this case.');
  db.transaction(() => {
    db.prepare("UPDATE kyc_cases SET status='REJECTED', reviewed_by=?, reviewed_at=datetime('now'), reject_reason=? WHERE id=?").run(req.user.id, req.body.reason, cur.id);
    db.prepare("UPDATE parties SET kyc_status='REJECTED' WHERE id=?").run(cur.party_id);
  })();
  audit(req.user, 'REJECT', 'kyc_case', cur.id, { reason: req.body.reason });
  res.json({ ok: true });
});
// re-open a rejected case for another attempt, without losing history (a new case is started)
r.post('/kyc/cases/:id/reopen', need('kyc', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM kyc_cases WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  if (cur.status !== 'REJECTED') bad('Only a rejected case can be reopened.');
  const id = db.transaction(() => {
    const nid = insertRow('kyc_cases', { party_id: cur.party_id, legal_name: cur.legal_name, reg_no: cur.reg_no, tax_no: cur.tax_no, country: cur.country, compliance_notes: cur.compliance_notes, created_by: req.user.id });
    db.prepare("UPDATE parties SET kyc_status='PENDING' WHERE id=?").run(cur.party_id);
    return nid;
  })();
  audit(req.user, 'REOPEN', 'kyc_case', cur.id, { new_case: id });
  res.json({ id });
});

module.exports = r;
module.exports.DOC_TYPES = DOC_TYPES;
