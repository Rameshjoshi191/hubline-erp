'use strict';
// Vessels master (incl. flag), slot management, dead freight and carrier slot invoices / reconciliation.
const express = require('express');
const { db, audit, today, round2 } = require('../db');
const { need } = require('../auth');
const { bad, crud, extract, insertRow, updateRow, diff } = require('../util');
const S = require('../services');

const r = express.Router();

// ---------------------------------------------------------------- vessels master (name, flag, IMO, carrier)
crud(r, {
  path: 'vessels', table: 'vessels', module: 'slots', search: ['name', 'flag', 'imo_no', 'call_sign'], order: 'name', entity: 'vessel',
  fields: [
    { name: 'name', type: 'upper', required: true, label: 'Vessel name' }, { name: 'flag', label: 'Flag' },
    { name: 'imo_no', label: 'IMO no.' }, { name: 'call_sign', label: 'Call sign' }, { name: 'carrier_id', type: 'int' },
    { name: 'teu_capacity', type: 'int' }, { name: 'remarks' }, { name: 'active', type: 'bool', def: 1 },
  ],
});
r.get('/vessels/:id/slots', need('slots', 'read'), (req, res) => {
  const v = db.prepare('SELECT * FROM vessels WHERE id=?').get(req.params.id);
  if (!v) bad('Not found', 404);
  res.json(db.prepare('SELECT id, vessel, voyage, etd FROM vessel_slots WHERE vessel_id=? ORDER BY etd DESC').all(v.id));
});

// ---------------------------------------------------------------- slot usage (how many TEU of a vessel/voyage/lane are actually loaded)
function usedTeu(vessel, voyage, pol_id, pod_id) {
  const r1 = db.prepare(`SELECT COALESCE(SUM(t.teu),0) AS teu FROM shipment_containers sc
    JOIN shipments s ON s.id=sc.shipment_id JOIN containers c ON c.id=sc.container_id JOIN container_types t ON t.id=c.type_id
    WHERE s.status<>'CANCELLED' AND upper(s.vessel)=upper(?) AND upper(COALESCE(s.voyage,''))=upper(?)
      AND (? IS NULL OR s.pol_id IS NULL OR s.pol_id=?) AND (? IS NULL OR s.pod_id IS NULL OR s.pod_id=?)`)
    .get(vessel, voyage || '', pol_id || null, pol_id, pod_id || null, pod_id);
  return round2(r1.teu);
}

const SLOT_SELECT = `SELECT sl.*, ca.name AS carrier_name, pl.name AS pol_name, pd.name AS pod_name, ve.flag AS vessel_flag,
    (SELECT COALESCE(SUM(amount*1.0),0) FROM carrier_slot_invoices i WHERE i.slot_id=sl.id) AS invoiced_total,
    (SELECT COUNT(*) FROM carrier_slot_invoices i WHERE i.slot_id=sl.id) AS invoice_count
  FROM vessel_slots sl LEFT JOIN parties ca ON ca.id=sl.carrier_id LEFT JOIN ports pl ON pl.id=sl.pol_id LEFT JOIN ports pd ON pd.id=sl.pod_id
  LEFT JOIN vessels ve ON ve.id=sl.vessel_id`;

function decorateSlot(s) {
  s.used_teu = usedTeu(s.vessel, s.voyage, s.pol_id, s.pod_id);
  s.unused_teu = round2(Math.max(0, s.booked_teu - s.used_teu));
  s.dead_freight = round2(s.unused_teu * s.slot_cost_per_teu);
  s.expected_cost = round2(s.booked_teu * s.slot_cost_per_teu);
  s.invoiced_total = round2(s.invoiced_total);
  s.variance = round2(s.invoiced_total - s.expected_cost);   // 0 = reconciled; +ve = carrier over-billed; -ve = under-billed vs. the committed slot cost
  return s;
}

r.get('/vessel-slots', need('slots', 'read'), (req, res) => {
  const w = [], p = {};
  if (req.query.q) { w.push('(sl.vessel LIKE @q OR sl.voyage LIKE @q OR ca.name LIKE @q)'); p.q = `%${req.query.q}%`; }
  if (req.query.carrier_id) { w.push('sl.carrier_id=@c'); p.c = req.query.carrier_id; }
  const rows = db.prepare(`${SLOT_SELECT} ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY sl.etd DESC, sl.id DESC LIMIT 500`).all(p);
  res.json(rows.map(decorateSlot));
});
r.get('/vessel-slots/:id', need('slots', 'read'), (req, res) => {
  const s = db.prepare(`${SLOT_SELECT} WHERE sl.id=?`).get(req.params.id);
  if (!s) bad('Not found', 404);
  decorateSlot(s);
  s.invoices = db.prepare(`SELECT i.*, u.full_name AS created_by_name FROM carrier_slot_invoices i LEFT JOIN users u ON u.id=i.created_by WHERE i.slot_id=? ORDER BY i.invoice_date DESC, i.id DESC`).all(s.id);
  res.json(s);
});

const SLOT_FIELDS = [
  { name: 'vessel', type: 'upper', required: true, label: 'Vessel' }, { name: 'voyage', type: 'upper', required: true, label: 'Voyage' },
  { name: 'vessel_id', type: 'int' }, { name: 'carrier_id', type: 'int' }, { name: 'pol_id', type: 'int' }, { name: 'pod_id', type: 'int' },
  { name: 'booked_teu', type: 'real', required: true, label: 'Booked (committed) TEU' }, { name: 'slot_cost_per_teu', type: 'real', required: true, label: 'Slot cost per TEU' },
  { name: 'currency', type: 'upper', def: 'USD' }, { name: 'etd', type: 'date' }, { name: 'remarks' },
];
function checkSlot(v) {
  if (v.booked_teu != null && v.booked_teu < 0) bad('Booked TEU cannot be negative.');
  if (v.slot_cost_per_teu != null && v.slot_cost_per_teu < 0) bad('Slot cost cannot be negative.');
}
r.post('/vessel-slots', need('slots', 'write'), (req, res) => {
  const v = extract(req.body, SLOT_FIELDS); checkSlot(v);
  v.created_by = req.user.id;
  if (db.prepare('SELECT 1 FROM vessel_slots WHERE vessel=? AND voyage=? AND COALESCE(pol_id,0)=COALESCE(?,0) AND COALESCE(pod_id,0)=COALESCE(?,0)').get(v.vessel, v.voyage, v.pol_id, v.pod_id))
    bad('A slot allocation for this vessel / voyage / lane already exists.', 409);
  const id = insertRow('vessel_slots', v);
  audit(req.user, 'CREATE', 'vessel_slot', id, { vessel: v.vessel, voyage: v.voyage });
  res.json({ id });
});
r.put('/vessel-slots/:id', need('slots', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM vessel_slots WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  const v = extract(req.body, SLOT_FIELDS, { partial: true }); checkSlot(v);
  updateRow('vessel_slots', cur.id, v);
  audit(req.user, 'UPDATE', 'vessel_slot', cur.id, diff(cur, v));
  res.json({ ok: true });
});
r.delete('/vessel-slots/:id', need('slots', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM vessel_slots WHERE id=?').get(req.params.id);
  if (!cur) bad('Not found', 404);
  db.prepare('DELETE FROM vessel_slots WHERE id=?').run(cur.id);
  audit(req.user, 'DELETE', 'vessel_slot', cur.id);
  res.json({ ok: true });
});

// ---------------------------------------------------------------- carrier slot invoices (+ reconciliation)
r.post('/vessel-slots/:id/invoices', need('slots', 'write'), (req, res) => {
  const slot = db.prepare('SELECT * FROM vessel_slots WHERE id=?').get(req.params.id);
  if (!slot) bad('Not found', 404);
  const amount = round2(Number(req.body.amount));
  if (!(amount > 0)) bad('Enter the invoiced amount.');
  const currency = String(req.body.currency || slot.currency).toUpperCase();
  const invoice_date = req.body.invoice_date || today();
  let documentId = null;
  const tx = db.transaction(() => {
    if (slot.carrier_id && req.body.create_bill) {
      documentId = S.createDocument({
        doc_type: 'BILL', party_id: slot.carrier_id, doc_date: invoice_date, currency,
        party_ref: req.body.invoice_no || null,
        narration: `Carrier slot invoice - ${slot.vessel} / ${slot.voyage}`,
        lines: [{ description: `Slot cost - ${slot.vessel} / ${slot.voyage}`, qty: 1, rate: amount, vat_rate: 0 }],
      }, req.user);
    }
    return db.prepare('INSERT INTO carrier_slot_invoices(slot_id,invoice_no,invoice_date,amount,currency,document_id,remarks,created_by) VALUES(?,?,?,?,?,?,?,?)')
      .run(slot.id, req.body.invoice_no || null, invoice_date, amount, currency, documentId, req.body.remarks || null, req.user.id).lastInsertRowid;
  });
  const id = tx();
  audit(req.user, 'CREATE', 'carrier_slot_invoice', id, { slot_id: slot.id, amount, currency, document_id: documentId });
  res.json({ id, document_id: documentId });
});
r.delete('/vessel-slots/:id/invoices/:iid', need('slots', 'write'), (req, res) => {
  const inv = db.prepare('SELECT * FROM carrier_slot_invoices WHERE id=? AND slot_id=?').get(req.params.iid, req.params.id);
  if (!inv) bad('Not found', 404);
  db.prepare('DELETE FROM carrier_slot_invoices WHERE id=?').run(inv.id);
  audit(req.user, 'DELETE', 'carrier_slot_invoice', inv.id);
  res.json({ ok: true });
});

module.exports = r;
