# HUB LINE ERP — User & Administrator Guide

Version 0.4 · NVOCC operations, agents, container tracking, KYC/compliance, vessel slot management, leased containers and finance

This guide explains how to set the system up, how each team member uses it day to day, and how an administrator keeps it running. It is written for the people who will use the system, not for programmers. Technical installation and hosting steps are in [README.md](../README.md) and [DEPLOY.md](../DEPLOY.md).

**Contents**

1. [What the system does](#1-what-the-system-does)
2. [Signing in and finding your way around](#2-signing-in-and-finding-your-way-around)
3. [Roles and what each can do](#3-roles-and-what-each-can-do)
4. [First-time setup checklist (administrator)](#4-first-time-setup-checklist-administrator)
5. [Customers, agents, vendors and carriers](#5-customers-agents-vendors-and-carriers)
6. [KYC & compliance](#6-kyc--compliance)
7. [Rates / tariffs](#7-rates--tariffs)
8. [Shipments: from booking to delivery](#8-shipments-from-booking-to-delivery)
9. [Master BL / consolidation (LCL)](#9-master-bl--consolidation-lcl)
10. [Container inventory and tracking](#10-container-inventory-and-tracking)
11. [Container enquiry and movement updates](#11-container-enquiry-and-movement-updates)
12. [Leased containers](#12-leased-containers)
13. [Storage & detention: automatic tariff-based billing](#13-storage--detention-automatic-tariff-based-billing)
14. [Bills of lading tab](#14-bills-of-lading-tab)
15. [Vessel schedules](#15-vessel-schedules)
16. [Vessel slot management, dead freight & carrier invoices](#16-vessel-slot-management-dead-freight--carrier-invoices)
17. [MRG — month-wise freight rates and slot cost](#17-mrg--month-wise-freight-rates-and-slot-cost)
18. [External agents: the agent portal](#18-external-agents-the-agent-portal)
19. [Sharing by Excel, PDF and e-mail](#19-sharing-by-excel-pdf-and-e-mail)
20. [Automation: less manual work](#20-automation-less-manual-work)
21. [Agents and agency agreements](#21-agents-and-agency-agreements)
22. [Agency commission](#22-agency-commission)
23. [Finance: invoices, bills, receipts and payments](#23-finance-invoices-bills-receipts-and-payments)
24. [Statement of account (SOA) and ageing](#24-statement-of-account-soa-and-ageing)
25. [Reports: profit, sales performance and container history](#25-reports-profit-sales-performance-and-container-history)
26. [Administration: users, audit log, backup](#26-administration-users-audit-log-backup)
27. [Accounting rules and assumptions](#27-accounting-rules-and-assumptions)
28. [Troubleshooting and FAQ](#28-troubleshooting-and-faq)
29. [Glossary](#29-glossary)
30. [Known limits and roadmap](#30-known-limits-and-roadmap)

---

## 1. What the system does

HUB LINE ERP is a web application for a non-vessel-operating common carrier (NVOCC) or consolidator. It follows one job from the first booking to the final payment, and keeps four things consistent with each other: the shipment, the containers it uses, the money it earns and costs, and the commission owed to the overseas agent.

| Area | What you can do |
|---|---|
| **Shipments** | Create FCL and LCL bookings, confirm them (which issues the house B/L number), then record sailing, arrival, delivery and closing. Print the booking confirmation and the house B/L. |
| **Master BL / consolidation** | Group LCL house shipments under one master B/L and move them through sailing and arrival together. |
| **Container inventory** | Keep every container, its type, status and location. Log movements, see the inventory as it stood on any date, and watch free-time (detention) clocks. Update it from an Excel file, and answer "where is this container?" in the **Container enquiry** ([section 11](#11-container-enquiry-and-movement-updates)). |
| **Bills of lading** | One tab to search, view, edit, download (PDF / Excel) and share every bill of lading ([section 14](#14-bills-of-lading-tab)). |
| **Vessel schedules** | Load sailing schedules from Excel or a shipping line's web link; date changes flow to your bookings ([section 15](#15-vessel-schedules)). |
| **MRG** | Month-wise freight rate, slot cost and margin per lane and container type, against committed slots ([section 17](#17-mrg--month-wise-freight-rates-and-slot-cost)). |
| **Agent portal** | Your agents sign in to update container movements at their own locations and to view and complete their bills of lading ([section 18](#18-external-agents-the-agent-portal)). |
| **Sharing** | Send or download what is on screen as Excel or PDF, or e-mail it, from any list ([section 19](#19-sharing-by-excel-pdf-and-e-mail)). |
| **Agents and agreements** | Keep agent profiles and agency agreements with validity dates, territory, exclusivity, payment terms, credit limit and editable clauses. |
| **Agency commission** | Define commission rules per agreement, calculate statements per period, review and adjust them, and post them to the agent's account. |
| **Customers and parties** | One master list for customers, agents, vendors and carriers, with credit terms and tax numbers. |
| **KYC & compliance** | Staff upload a customer's or vendor's trade licence, ID or compliance form (file or link) on their behalf; an administrator approves or rejects the case before new bookings or invoices for that party are allowed ([section 6](#6-kyc--compliance)). |
| **Rates / tariffs** | Store sell and buy rates by route, cargo and container type, and pull them into invoices. |
| **Leased containers** | Lease contracts per lessor — committed-period rate, the daily rate that applies after it, one-way or round-trip, pickup and drop-off locations — and which containers sit under each lease ([section 12](#12-leased-containers)). |
| **Storage & detention** | Automatically works out, from the tariff book, which containers are overdue on free time and raises the debit note for the unbilled days ([section 13](#13-storage--detention-automatic-tariff-based-billing)). |
| **Vessel slot management** | Vessel master data with flag; booked vs. used slots per vessel/voyage, dead freight on unused slots, carrier slot invoices and reconciliation ([section 16](#16-vessel-slot-management-dead-freight--carrier-invoices)). |
| **Finance** | Invoices, debit notes, credit notes and vendor bills; receipts and payments; allocation of money to documents; netting; multi-currency with reporting in your base currency. |
| **Statement of account** | Full-ledger or open-item statements with ageing, printable and exportable to Excel. |
| **Reports** | Dashboard, shipment register with job-wise profit, sales performance, container history, ageing, daily container inventory report ([section 25](#25-reports-profit-sales-performance-and-container-history)). |
| **Administration** | Users and roles (including a Transhipment role), company settings, ports, container types, charge codes, currencies and rates, audit log, database backup. |
| **Who did what** | Every booking, bill of lading, agreement and finance document records who created it and who last edited it, visible on its own page. |

The system is an **operational sub-ledger**. It is not a general ledger, and it does not replace your statutory accounting package (see [section 27](#27-accounting-rules-and-assumptions)).

---

## 2. Signing in and finding your way around

### Signing in

Open the web address your administrator gave you and enter your username and password. Sessions last 12 hours. After eight wrong attempts in fifteen minutes the account is locked for a while; wait and try again, or ask the administrator.

If your administrator created your account or reset your password, the system asks you to choose a new password immediately. Use a long password that you do not use anywhere else.

### The screen

* **Left menu** — grouped by module: Overview, Finance, Operations, Documentation, Equipment, Trade, Vessel, Reports, User guide and Setup. You only see the groups and pages your role is allowed to open. On a phone or tablet, tap the menu icon at the top left.
* **Module dashboards** — Finance, Operations, Documentation, Equipment, Trade and Vessel each start with their own "**<Module> dashboard**" page: the live numbers and action items for that module only, with shortcut buttons to its screens and a **User guide** button. Use these instead of hunting through the main Dashboard when you only care about one area.
* **User guide (in the app)** — the **User guide** item in the left menu opens a step-by-step guide for each module, the same content summarised in sections 6–20 of this document, without leaving the app.
* **Search box (top)** — type a booking number, HBL number, container number or customer name. A container number (four letters and six or seven digits) opens the **Container enquiry**; anything else searches the shipment register. Agents' searches go to the enquiry or to their bills of lading.
* **Top-right icons** — switch between light and dark theme, change your password, sign out.
* **Tables** — click a row to open it. Most lists have filters above the table and an **Export Excel** button.
* **Dialogs** — forms open in a window on top of the page. Required fields are marked. Nothing is saved until you press the blue button at the bottom.
* **Working in more than one tab** — you can open the application in two or more browser tabs (or windows) at the same time and work in each independently, for example one tab on a booking and another on the finance register. Each tab keeps its own place; sign-in and sign-out apply to the browser, not to a single tab.

### Dashboard

The first page after signing in, kept deliberately clean:

* **Four tiles** — open shipments, TEU this month against last month, containers in the fleet, and containers past free time.
* **Needs your attention** — the action centre: a short, colour-coded list of what to do next, each line opening the right page ([section 20](#20-automation-less-manual-work)).
* **Equipment** — total containers with empty / laden / out-of-service split, past-free-time warning, breakdown by container type and where the boxes are (by location).
* **Receivables** (users with finance access) — total outstanding in your base currency, ageing buckets, overdue, collected in the last 30 days, what you owe, the biggest balances, and drafts waiting to be posted.
* **Container tracking** — boxes on the water, arrivals in the next 7 days with ETA, and the latest movements. Click any container to see its journey.
* **Shipment pipeline** — Booked, Confirmed, At sea, Arrived, Delivered.

Agents see the same layout limited to their own equipment, tracking and shipments. The buttons at the top (**New booking**, **Update movements**, **Container enquiry**, **Inventory report**) are shortcuts.

---

## 3. Roles and what each can do

Every user has exactly one role. **R** means can view, **RW** means can view and change, **–** means the page is hidden. Column headings: Admin = Administrator, Mgmt = Management (read-only), Ops = Operations, Docs = Documentation, Sales = Sales / Agent liaison, Trans = Transhipment.

| Area | Admin | Mgmt | Ops | Docs | Accounts | Sales | Trans |
|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| Dashboard | R | R | R | R | R | R | R |
| Customers & parties | RW | R | RW | RW | RW | RW | – |
| KYC & compliance | RW | – | RW | RW | RW | RW | R |
| Ports, container types, charge codes, currencies | RW | R | RW | R | RW | R | – |
| Rates / tariffs | RW | R | R | – | R | RW | R |
| Agents and agency agreements | RW | R | – | – | R | RW | R |
| Agency commission | RW | R | – | – | RW | R | R |
| Shipments and master BLs | RW | R | RW | RW | R | RW | RW |
| Container inventory | RW | R | RW | R | R | R | R |
| Container movements (log / Excel upload) | RW | – | RW | – | – | – | RW |
| Leased containers | RW | R | RW | – | R | R | – |
| Storage & detention (raise invoices) | RW | R | R | – | RW | R | R |
| Bills of lading tab | RW | R | RW | RW | R | RW | RW |
| Vessel schedules | RW | R | RW | R | R | RW | RW |
| Vessel master, slot management & dead freight | RW | R | RW | R | R | RW | RW |
| MRG (freight, slot cost, margin) | RW | R | – | – | R | RW | R |
| Invoices, bills, receipts, payments, ageing | RW | R | – | – | RW | – | R |
| Statement of account | R | R | – | – | R | R | R |
| Reports (incl. sales performance, container history) | R | R | R | R | R | R | R |
| Audit log | R | R | – | – | – | – | – |
| Users, company settings, backup | RW | – | – | – | – | – | – |

**Management** is a read-only role for directors and owners: they can see everything except user administration, but cannot change anything.

**Transhipment** sits between Management and the operational roles: it has the same broad, read-only view of finance, trade and reports as Management, but can additionally create and change vessel schedules, slot allocations, shipments/bookings, container movements and bills of lading — the areas a transhipment desk actually works in day to day. It cannot write to finance, tariffs, parties, users or leased containers.

**Agent (external)** is a separate role for your agents' own staff. It is not part of the table above because an agent sees only a small, scoped part of the system: containers at their assigned locations and on their own shipments, their own bills of lading, vessel schedules, the enquiry and the movement update pages. It never sees invoices, rates, MRG, other agents or users (see [section 18](#18-external-agents-the-agent-portal)).

The system enforces these rules on the server, so hiding a button is not the only protection; a user who is not allowed to do something gets a clear message saying which role is needed.

---

## 4. First-time setup checklist (administrator)

Work through these in order. Each page is under **Setup** in the left menu unless stated.

1. **Change the administrator password.** On first sign-in you are forced to. Store it safely.
2. **Company & settings.** Enter the company name, address, phone, email and tax registration number (TRN). Add the bank details that should print on invoices. Confirm the base currency (AED by default; it cannot be changed once documents are posted), the standard VAT rate, the default free days at destination (used to pre-fill the arrival dialog), the invoice footer and the house B/L terms and conditions text.
3. **Users & roles.** Create one login per person. Never share a login: the audit log records who did what. Use the new **Transhipment** role for a transhipment desk that needs to work in vessel schedules, slot management, bookings, container movements and bills of lading, but should not see finance or tariffs ([section 3](#3-roles-and-what-each-can-do)).
4. **Ports.** A starter list is loaded, using UN/LOCODE codes (for example AEJEA for Jebel Ali). Add the ports you trade with.
5. **Container types.** Check the starter list (20GP, 40GP, 40HC and so on) and its size and TEU factor. TEU is used in reports and commission, so make sure a 20-foot is 1 and a 40-foot is 2.
6. **Charge codes.** Review the standard charges (ocean freight, THC, documentation and so on), whether each is used on invoices, bills or both, and its default VAT rate. The starter set applies 5% to local charges and 0% to ocean freight. **Confirm the VAT treatment with your accountant** and edit accordingly.
7. **Currencies & rates.** Add the currencies you invoice or pay in and enter an exchange rate to the base currency with an effective date. USD to AED is pre-set at 3.6725; the other rates shown are only examples, so enter your own.
8. **Parties.** Add your carriers, agents, customers and vendors ([section 5](#5-customers-agents-vendors-and-carriers)).
9. **Container inventory.** Add the containers you own or lease ([section 10](#10-container-inventory-and-tracking)). Use **Bulk add** for many at once, or **Update from Excel** to load your existing stock list ([section 11](#11-container-enquiry-and-movement-updates)).
10. **Tariffs and agent agreements.** Enter your sell and buy rates and each agent's agreement and commission rules. If you want storage/detention to be billed automatically ([section 13](#13-storage--detention-automatic-tariff-based-billing)), add at least one **sell** tariff for a **Storage**, **Detention** or **Demurrage** charge with the unit **Per day**.

Document numbers such as BKG-2026-00001 are generated automatically. Numbers restart each year.

**Trying it first.** If your administrator loaded the demo data, you can practise on realistic shipments, invoices and agreements before entering real ones. Demo data must be removed before going live (see the README).

---

## 5. Customers, agents, vendors and carriers

**Customers & parties** holds one record for every company you deal with. A single record can carry more than one role, for example a company that is both a customer and a vendor. Each party has a code (CU-, AG-, VN-, CR- prefixes), address, contact details, tax number, credit days and credit limit.

* **Add:** press **+ New party**, fill in the name, tick the roles that apply and save.
* **Edit:** open the party and press **Edit**.
* The party page shows the party's documents and account position.
* Credit days set here decide the due date on invoices, and therefore the ageing buckets.

Agents also have a dedicated **Agents** page (see [section 21](#21-agents-and-agency-agreements)); an agent is just a party with the agent role.

A customer's or vendor's KYC/compliance status shows as a badge on its party page — see the next section.

---

## 6. KYC & compliance

Before you book or bill a customer or vendor whose compliance you need to control, your own staff put the party through a **KYC case**: they upload the party's documents and fill the compliance form on the party's behalf, and an administrator approves or rejects it. This is staff-assisted, not a public self-service link — the party never signs in.

### Starting a case

**Trade → KYC & compliance → + New KYC case.** Choose the customer or vendor, and optionally fill in the legal/registered name, registration number, tax/VAT number, country and compliance notes. The case starts as **Pending**.

### Adding documents

On the case page, **Upload file** attaches a PDF, JPG or PNG (trade licence, passport/ID, the filled-in compliance form, or any other document), and **Add link** records a web or shared-drive link instead when the document already lives elsewhere. Add as many as you need; each shows who added it and when.

### Submitting and deciding

* **Submit for approval** — available once at least one document is on the case. This moves it to **Submitted** and hands it to an administrator.
* **Approve** / **Reject** — administrator only, even for a user whose role can otherwise edit KYC cases. Rejecting requires a reason, which is shown on the case.
* **Reopen** — on a rejected case, starts a fresh Pending case pre-filled with the same legal details, without losing the history of the rejected attempt.

### What approval controls

A party with an **open, non-approved** KYC case (Pending, Submitted or Rejected) cannot be booked on a new shipment and cannot be billed on a new invoice, debit note or bill — the system blocks the action with a message naming the case status and telling you to complete it under KYC & compliance. A party that has never been put through KYC is **not** affected: this is deliberately backward-compatible, so existing customers and vendors keep working exactly as before until you choose to start a case for them. Once a case is **Approved**, the party is cleared again.

The party's own page shows its current KYC status as a badge, with a link to the open or most recent case, or a button to start one.

---

## 7. Rates / tariffs

Open **Rates / tariffs**. The **Sell rates** tab holds what you charge customers and agents; the **Buy rates** tab holds what carriers and vendors charge you. Press **+ New rate** to add one. A rate is defined by:

* the rate type (sell or buy) and, optionally, a **specific customer, agent or carrier** (leave blank for a general tariff),
* the port of loading and port of discharge (blank means any),
* cargo type (FCL, LCL or any) and container type,
* the charge code, the rate, the currency and the unit (per container, per TEU, per CBM, per ton, per BL, **per day** or lump sum),
* the dates it is valid, and remarks.

Tick **Currently valid only** to hide expired rates.

On an invoice, pressing **Fill from tariff** adds lines from the rates that match the shipment's route, cargo and containers. Always review the lines before posting; tariffs suggest, people decide.

---

## 8. Shipments: from booking to delivery

### The life of a shipment

```
Booked → Confirmed → Sailed → Arrived → Delivered → Closed
                 (and Cancelled, from Booked or Confirmed)
```

Each step is one button on the shipment page. The blue progress bar shows where the job is.

### Step by step

1. **Create the booking.** Go to **Shipments / bookings** → **+ New booking**. Fill in the customer, shipper, consignee and notify party (pick from parties or type text), the agent, carrier, ports, place of receipt and delivery, vessel and voyage, ETD and ETA, freight terms (Prepaid or Collect), incoterm, and the cargo description, marks, packages, weight and volume. Choose **FCL** or **LCL**. Press **Create booking**. The system assigns a booking number.
2. **Add containers** (FCL). On the shipment page, **+ Add container** offers only containers that are currently *Empty – available*. Enter the seal number, packages and weight for each. The container status changes to *Empty – allocated to booking*. Remove a container with the cross if you need to swap it (possible while the shipment is Booked or Confirmed).
3. **Print the booking confirmation** with the **Booking confirmation** button and send it to the customer.
4. **Confirm & issue HBL.** When the booking is firm, press **Confirm & issue HBL**. The house B/L number is created and the **Print HBL** button appears. Check the details before printing, because the B/L is a legal document.
5. **Mark sailed.** Press **Mark sailed** and enter the sailing date (it defaults to the ETD). Loaded containers are recorded as on board.
6. **Mark arrived.** Press **Mark arrived**, enter the arrival date and the **free days at destination**. Containers are recorded as discharged and the **detention clock starts** (see [section 10](#10-container-inventory-and-tracking)).
7. **Mark delivered** when the cargo is released to the consignee, then **Close job** when everything, including finance, is complete.

**Cancelling.** A booking that is Booked or Confirmed can be cancelled; its containers are released back to the empty pool. A cancelled booking can be re-opened as a booking.

**Editing.** Use **Edit** while the shipment is not Closed or Cancelled. The cargo type can only be changed while no containers are attached.

### On the shipment page

* **Parties, Routing & cargo, Containers** show the job details.
* **Finance card** (users with finance access): invoices, bills and the shipment's **profit** in base currency, plus a shortcut to raise a new document for this shipment.
* **Agent commission** shows whether the shipment is already on a commission statement.

### Finding shipments

The register filters by status, cargo type, agent, date range and free-text search (booking, HBL, customer, container). **Export Excel** downloads the filtered list.

---

## 9. Master BL / consolidation (LCL)

For LCL, several house shipments travel together under one master B/L.

1. Go to **Master BL / consolidation** → **+ New consolidation**. Enter the master B/L number, carrier, vessel, voyage, ports and dates.
2. Press **+ Add shipment** and choose the confirmed LCL house shipments to include.
3. When cargo is complete, use **Close for cargo**.
4. Press **Mark sailed** and later **Mark arrived** on the consolidation. The status of every house shipment and its container events move together. While a shipment sits on a consolidation you record sailing and arrival on the consolidation, not on the house shipment.
5. **Complete** the consolidation when finished. **Re-open** and **Cancel** are available while appropriate.

---

## 10. Container inventory and tracking

### What is stored

Every container has a number, type, ownership (**Own**, **Leased**, **COC** carrier-owned or **SOC** shipper-owned), owner, condition, and a **movement log**. The current status and location are always derived from the latest movement, and the same log lets the system show the inventory **as it was on any past date**.

Container numbers are checked against the international **ISO 6346** check digit, so a mistyped number is caught when you save it.

### Statuses

| Status | Meaning |
|---|---|
| Empty – available | In stock and can be booked |
| Empty – allocated to booking | Attached to a booking |
| Released to shipper for stuffing | Empty box at the shipper's premises |
| Laden – gated in at POL | Full box received at the port of loading |
| Laden – on board / in transit | Loaded on the vessel |
| Laden – discharged at POD | Landed at destination; **free-time clock running** |
| Laden – delivered to consignee | Delivered; free-time clock still running until empty return |
| Empty – returned to depot/line | Back in the pool; **clock stops and resets** |
| Damaged / under repair | Out of service |
| Off-hired / returned to owner | Left your fleet; no longer counted |

Shipment steps change these automatically (allocate → *allocated*, sail → *on board*, arrive → *discharged*). You log the remaining movements by hand.

### Everyday tasks

* **Add one container:** **+ Add container**. **Add many:** **Bulk add** (paste a list of container numbers, choose the type, ownership and starting status; a result dialog shows any numbers that were rejected and why).
* **Log a movement:** open the container and press **Log movement**, or tick several rows and press **Log movement for selected**. Choose the movement, date, location and (where relevant) the shipment and free days, then **Record movement**.
* **Find a box:** use the search box or the filters (status, type, location, "past free time").

### Free time (detention)

When you mark a shipment arrived you enter the number of free days. Each day after the free days run out, the container is **past free time**. The dashboard, the container list and the daily report all flag these boxes, and boxes that expire within two days. Logging *Empty – returned* (or *Empty – available*, or *Off-hired*) ends the clock.

### Daily inventory report

Open **Daily inventory report** to see, for any date:

* a summary of containers by type and location and by empty / laden status,
* the movements recorded that day,
* detention alerts (past or nearly past free time),
* idle empties.

Use **Previous day**, **Next day**, **Today** or the date box to move between days, **Print** for paper or PDF, and **Export Excel** to download.

---

## 11. Container enquiry and movement updates

Version 0.2 adds a fast way to answer "where is this container?" and to keep the inventory up to date without typing each box.

### Container enquiry

**Containers → Container enquiry.** Type or paste anything into the search box and press Enter:

* one or many **container numbers** (paste a whole list; they can be separated by spaces, commas or new lines),
* a **booking**, **HBL** or **master BL** number,
* a **vessel** name, or
* a **place** such as *Jebel Ali* to list everything currently at that depot.

The results show status, location, days in that status, booking / HBL, vessel, route, ETA and the free-time date. Click a container to open its **journey**: a step bar from *Empty released* through *Gated in*, *On board*, *Discharged*, *Delivered* to *Empty returned*, with the date and place of each step that has happened and the expected date of the next. Below it are the full movement history (who recorded each move), the current shipment and a **Log movement** button. When the search box is empty the page shows the latest movements across the fleet. **Share results** sends or downloads the list.

### Update the inventory from Excel

**Containers → Container inventory → Update from Excel** (also **Update movements → Upload Excel**). Use this when your depot, terminal or a leasing company sends you a stock list or movement report.

1. **Choose the file.** Drop an Excel (.xlsx) or CSV file on the box, or paste rows copied from Excel. You can download the **Excel template**, but you do not have to use it.
2. **Check.** The system reads the columns by their names (for example *Container No*, *Size*, *Depot status*, *Move date* — extra words are fine) and understands common movement words such as *gate in*, *gate out full*, *on board*, *discharged*, *delivered*, *empty return*, *available* and *damaged*. It then shows, row by row, what will happen: **New container**, **Movement**, **New location**, **No change** or **Error**, with the reason for any error (for example a wrong ISO 6346 check digit). If a column was not recognised, open *Columns we found in your file* and choose the right one. You can also set defaults for anything the file leaves out (container type, status, location, date) and choose whether containers not yet in the inventory are added.
3. **Save.** Nothing is written until you press the **Save** button. Loading the same file again changes nothing — only real differences are saved.

### Update movements (quick)

**Containers → Update movements.** Paste the container numbers, choose *what happened*, the date and the location, press **Check**, then **Save movements**. Use it for a gate-in, a delivery or a batch of empty returns. The bottom of the page lists the latest movements and can be limited to your own updates.

### Sharing

Every list has a **Share** button (see [section 19](#19-sharing-by-excel-pdf-and-e-mail)). The **Inventory report** can be downloaded as an Excel workbook (summary by type and location, the full container list, the day's movements, detention alerts and idle empties) from *Daily inventory report → Export Excel*.

---

## 12. Leased containers

**Equipment → Leased containers** keeps the contract terms for containers you lease in from a lessor, separately from the container inventory itself.

### The contract

**+ New lease** records: the **lessor**, the **lease type** (one-way or round-trip), the container type the lease covers, the **start date**, the **committed period** in days, the **rate per day during that committed period**, and the **rate per day after the committed period ends** (the daily holding cost once the committed time is used up), plus the **pickup location** and **drop-off location** and the currency.

Once created the lease gets a lease number (LSE-...). The lease page shows:

* which **phase** it is currently in — inside the committed period, or in the after-period daily phase — worked out from today's date (or the closing date, once closed) against the start date and committed period,
* the **cost to date**, split automatically between the committed-period rate and the after-period daily rate,
* the containers currently attached to it.

### Attaching and detaching containers

On the lease page, **Attach container** picks any container and marks it **Leased**, with the lessor as its owner. **Detach** (the cross next to a container) releases it from the lease without affecting its other inventory status. A container already on another lease cannot be attached to a second one.

### Closing a lease

**Close lease** records the end date and stops the after-period clock from running further; a closed lease can no longer be edited, and cannot be deleted while containers are still attached to it (detach them first).

---

## 13. Storage & detention: automatic tariff-based billing

**Equipment → Storage & detention** finds every container that is past its free time and works out what to bill, using the same **sell / PER_DAY** tariff lookup used elsewhere in the system (the most specific matching rate wins — by customer, route and container type).

* The list shows, for each overdue container, the booking/HBL it belongs to, how many days are unbilled, the applicable daily rate and the computed amount. A container with no linked shipment or no matching PER_DAY storage/detention tariff is flagged instead of an amount, so you know what to fix (link the shipment, or add a tariff for storage/detention/demurrage with unit "Per day").
* **Raise invoice** on one row, or tick several and **Raise invoices for selected**, creates a debit note for each container for the unbilled days and posts it as a draft in Finance.
* The system remembers which date range has already been billed for each container, so running this again only ever offers the days since the last invoice (or since free time expired, if it has never been billed) — you cannot double-bill a container.

Billing is blocked, the same as any other invoice, if the customer has an open, non-approved KYC case (see [section 6](#6-kyc--compliance)).

---

## 14. Bills of lading tab

**Shipments → Bills of lading** lists every bill of lading in one place, with search (BL, booking, shipper, consignee, container), status, agent and sailing-date filters and two quick filters: **Details missing** (BLs that still lack a consignee, vessel, description or similar) and **Agent-edited** (BLs an agent changed that your team has not yet reviewed).

* **View:** click a row for the full bill of lading — shipper, consignee, notify party, routing, vessel, cargo, containers with seals, and the activity trail.
* **Edit:** **Edit details** opens the form. Staff can edit while the shipment is open; you can also fill vessel, voyage, ports and dates in one step by choosing a sailing from the vessel schedule. **Seal numbers** can be edited per container.
* **Download:** **PDF** for one BL, or tick several rows and press **PDF of selected** for one combined file. **Excel** exports the BL, and the list itself can be shared as Excel or PDF.
* **Review agent changes:** when an agent edits a BL it is flagged. Open it and press **Mark reviewed** once you have checked the change.

---

## 15. Vessel schedules

**Shipments → Vessel schedules** holds the sailings you can book on. Bookings and master BLs can be filled from a sailing (vessel, voyage, ETD, ETA, cut-off, ports and carrier) so nobody retypes them.

### Load a schedule — two easy ways

Press **Load schedule**. The wizard has the same three steps as the inventory upload (Choose → Check → Done).

* **Excel / CSV file.** Upload the carrier's sailing schedule. Column names are recognised automatically (carrier, service, vessel, voyage, POL, POD, cut-off, ETD, ETA). Port and carrier names are matched to your master lists. If the file does not name the carrier, choose it once in the wizard.
* **From a web link.** Paste the link to the shipping line's schedule. It works when the link points to a **downloadable Excel / CSV file** or to a **web page that shows the schedule as a plain table**. Some carrier sites draw their schedule with JavaScript; if the system cannot read it, it tells you — use the site's *Download* button and upload the file instead. Tick **Remember this link** to keep it under **Saved web links**, where **Refresh now** re-reads it and a switch turns on **daily automatic refresh**.

Loading the same schedule again does not create duplicates: new sailings are added, unchanged ones are left alone and **changed dates** are highlighted.

### Date changes reach your bookings

When a carrier moves a sailing, the schedule page shows a **Date changes** alert listing the bookings and master BLs on that vessel. **Update bookings** applies the new ETD / ETA to all of them at once; **Ignore** keeps the old dates. Administrators can switch on **automatically update bookings and master BLs when a vessel's dates change** under *Setup → Company & settings → Automation*.

You can also **Add sailing** by hand, edit or delete lines, and share the schedule as Excel or PDF.

Vessels themselves (name, **flag**, IMO number, call sign, carrier and TEU capacity) are kept as their own master list under **Vessel → Vessels**; the next section uses it for slot management.

---

## 16. Vessel slot management, dead freight & carrier invoices

**Vessel → Slot management** tracks the slots you have committed to on a vessel/voyage against what you actually used, and reconciles that against what the carrier invoices you.

### Allocating a slot

**+ New slot allocation** records the vessel and voyage (matched to your bookings by name), the carrier, the route, the ETD, the **booked (committed) TEU** and the **slot cost per TEU**.

### Dead freight and usage

The slot page works out the **used TEU** automatically from every non-cancelled shipment booked on that vessel, voyage and route, and shows:

* **unused TEU** — booked minus used,
* **dead freight** — unused TEU × slot cost per TEU: what you pay the carrier for space you committed to but did not fill,
* **expected cost** — booked TEU × slot cost per TEU, i.e. what the carrier should invoice you for the committed slots.

### Carrier invoices and reconciliation

**+ Add invoice** records each invoice the carrier actually sends for the slot (invoice number, date, amount), and can tick **Also create a vendor bill for this carrier** to post it straight into Finance as a bill. The slot page totals every invoice recorded against it and shows the **reconciliation**: the variance between what was invoiced and the expected cost — **Reconciled** when they match, or flagged as the carrier having over- or under-billed you.

---

## 17. MRG — month-wise freight rates and slot cost

**Finance → MRG** keeps, month by month and lane by lane, what you **charge** (freight rate) and what the shipping line **charges you for the slot** (slot cost). The difference is your **margin per box**. Optionally record the **committed slots (MQC)** you promised the line, and the page compares them with the boxes you actually shipped that month.

* **Month view:** pick the year and a month. The 12 month buttons show the average margin of each month. The table shows lane, container type, freight, slot cost, margin per box (and %), committed slots against shipped, and the margin earned. The tiles above summarise the month.
* **Whole-year view:** a matrix of lanes against months for margin, freight, slot cost or shipped boxes, plus month totals. Amounts are converted to your base currency for totals.
* **Add rate:** one lane and container type for the month. A lane can be "any port" if the rate applies broadly.
* **Copy from another month** (roll-forward): starts a new month from the previous one, optionally with a percentage change, so you only adjust what moved.
* **Fill from tariff book:** creates the month's rows from the sell rates already in *Rates / tariffs*, so you only enter the slot cost.
* **Load from Excel:** the same three-step wizard. Columns such as *Month, POL, POD, Type, Freight, Slot cost, Carrier, MQC* are recognised (months may be written 2026-11, 11/2026 or Nov 2026).
* **Share / download** as Excel or PDF.

Roles: Sales and Administrators can change MRG; Management and Accounts can view it.

---

## 18. External agents: the agent portal

Your overseas or local **agents can sign in themselves** to update container movements location by location and to view and complete their own bills of lading. An agent login is a normal user with the role **Agent (external)**, tied to the agent company and to the locations that agent looks after.

### Setting up an agent login (administrator)

**Setup → Users & roles → New user.** Choose the role **Agent (external)**. Two extra fields appear:

* **Agent company** — the agent this person belongs to.
* **Locations this agent may update** — one per line or comma-separated, for example *Mombasa, Nairobi CFS*. The agent sees and updates containers whose location contains one of these words, plus containers on their own shipments.

### What an agent sees and can do

* **Dashboard** with the agent's own equipment, tracking, shipments and what needs attention (for example containers past free time at their locations).
* **Container enquiry, Container inventory and Update movements** — limited to their locations and their shipments. Logging a movement at any other place is refused with a clear message. They can upload their own Excel movement report with the same wizard.
* **Bills of lading** — their own shipments only. An agent can view, edit the BL details until the vessel sails, download PDF / Excel, and send a **New booking request**. After sailing the BL is locked and the agent is told to ask HUB LINE documentation to amend it. Every agent edit is flagged for your team to review.
* Agents cannot see invoices, rates, margins, other agents, users or the audit trail.

---

## 19. Sharing by Excel, PDF and e-mail

The **Share** button on the enquiry, movements, inventory, bills of lading, vessel schedules, MRG and ageing pages sends exactly what is on the screen (with the same filters).

* **Excel** and **PDF** download at once.
* **Share from your phone or computer:** where the device supports it, a **Share** tile opens the device's own sharing sheet (WhatsApp, e-mail app, and so on).
* **Send by e-mail from the system:** enter the recipients, subject and message, and choose Excel, PDF or both. This needs the mail server settings below.

### Mail server (administrator, once)

**Setup → Company & settings → Sharing by e-mail.** Enter the SMTP server, port, mail user name and password (ask your IT or e-mail provider — Office 365 and Gmail both work) and the "from" address. Then use **E-mail check → Send test e-mail**. Until this is set, the Share window offers downloads only and says so.

---

## 20. Automation: less manual work

* **Understands your files.** Column names, container types (for example *20'*, *40 HQ*), movement words and dates in many formats are recognised automatically; you correct only what the system flags.
* **Action centre.** The dashboard lists, most urgent first, what needs attention: containers past free time or about to be, bookings sailing within 3 days that are not confirmed, confirmed FCL shipments with no container, sailed shipments past their ETA, vessel date changes, BLs edited by agents, overdue receivables, draft invoices and commission waiting to be posted, agreements expired or expiring, idle empties and a missing MRG for the current month. Each line opens the right filtered page.
* **Daily inventory report by e-mail.** In *Company & settings → Automation* enter one or more addresses and the hour (in your time zone, Dubai = +4); the report is e-mailed every day. **Send today's inventory report now** tests it.
* **Vessel schedule links refresh daily** when you switch that on, and can update bookings automatically (see [section 15](#15-vessel-schedules)).
* **Agents update their own locations**, so the head office does not key in movements.

---

## 21. Agents and agency agreements

### Agents

**Agents** lists your overseas agents. **+ New agent** creates the party and its agent profile. The agent's page shows agreements, commission statements and their account balance, with a shortcut to a statement of account.

### Agreements

An **agency agreement** records the commercial relationship:

* agreement number, agent, start and end dates, notice period, and status (Draft, Active or Terminated; an active agreement shows as **Expired** automatically once its end date has passed),
* territory and whether it is exclusive,
* payment terms, commission currency and credit limit,
* the **clauses**, as editable text.

Steps:

1. **+ New agreement**, choose the agent and dates, then **Edit terms**.
2. **Insert standard clauses** loads a starter clause set filled in with the agreement's own details (parties, dates, territory, exclusivity, payment terms). Edit any clause, add your own with **+ Add clause**, and press **Save clauses**.
3. **Activate** the agreement when signed.
4. Print the agreement from its page.
5. Before it expires use **Renew** to create a renewal draft, or **Terminate** to end it early. The dashboard warns about agreements that expire within 60 days.

> The standard clauses are a **starting template**. Have your legal adviser review them before you use them.

---

## 22. Agency commission

### Rules

On an agreement, press **+ Add rule**. A rule says how the agent is paid:

| Basis | Commission is |
|---|---|
| Per TEU | rate × TEU on the shipment |
| Per container | rate × number of containers |
| Per CBM (LCL) | rate × cubic metres |
| Flat per HBL | one fixed amount per house B/L |
| % of ocean freight income | percentage of the shipment's ocean freight income |
| % of shipment profit | percentage of the shipment's profit (profit share) |

A rule can be limited to a port pair, a cargo type (FCL, LCL or any) and a validity period, and can have a **minimum** and **maximum** per shipment. When several rules match a shipment, the **most specific one wins**: port pair first, then cargo type, then the general rule.

### Statements

1. **Commission → + New statement** (or from the agent or agreement page). Choose the agent and the period, then **Calculate & create draft**.
2. The draft lists every eligible shipment with the rule applied and the amount. A shipment is eligible when it has **sailed or later**, its ETD is inside the period and the agreement dates, and it is not on another statement.
3. Review the draft. Use **Adjust** on a line to change its amount (you must give a reason), or the cross to **remove** a shipment (it can be picked up on a later statement). **Delete draft** discards the whole statement and frees its shipments.
4. **Approve & post to agent ledger** creates the commission document as a credit on the agent's account (you owe the agent) and locks the statement.
5. If a posted statement was wrong, **Cancel statement**. The agent credit is reversed and its shipments become available for a new statement. This only works while no payment or netting has been applied to it; remove those first.
6. **Export Excel** saves the statement for sending to the agent.

Commission owed to an agent can be settled by a payment, or **netted** against a debit note you issued to the same agent (see below).

---

## 23. Finance: invoices, bills, receipts and payments

### Document types

| Type | Number | Effect on the party's account |
|---|---|---|
| Invoice (INV) | INV- | Debit: the party owes you |
| Debit note (DN) | DN- | Debit |
| Credit note (CN) | CN- | Credit |
| Vendor bill (BILL) | BILL- | Credit: you owe the vendor |
| Commission statement (COMM) | COM- | Credit: you owe the agent |
| Receipt (RECEIPT) | RCT- | Credit: money received |
| Payment (PAYMENT) | PAY- | Debit: money paid |

### Raising an invoice, note or bill

1. **Invoices & notes → New**, choose the type. Or use **New invoice** on the dashboard or the shipment's finance card.
2. Pick the **shipment**; the customer is filled in from it (you can change it).
3. Add lines with **+ Add line** — choose a charge code, description, quantity, unit price and VAT rate — or press **Fill from tariff**.
4. Choose currency, document date and due date (calculated from the party's credit days by default).
5. **Save as draft** to keep working, or **Save & post** to finalise.

**Draft** documents can be edited and deleted. **Posted** documents cannot be edited: to correct one, cancel it and re-issue it, or issue a credit note. A document that has money allocated to it cannot be cancelled until the allocations are removed.

Printing: open a document and use the print option for a clean layout that you can save as PDF from the browser.

### Receipts and payments

On a posted invoice or debit note press **Record receipt**; on a bill or commission statement press **Record payment**; on a credit note press **Record refund**. You can also open **Receipts & payments** and press the new receipt (money in) or new payment (money out) button. Choose the party, currency and amount; the dialog lists that party's open documents and you apply the money across one or several of them. Whatever you do not apply stays **unapplied** (an on-account amount) and appears in the ageing under "Unapplied" until you apply it later. The page lists all money movements.

### Netting

When the same party owes you and is owed by you in the same currency (typically an agent), open a posted document and press **Net against another document**. Choose the opposite document and the amount. The two are settled against each other without any cash movement.

### Multi-currency

Each document is in its own currency. Reports convert to the base currency (AED by default) using the exchange rate effective on the document date. Settle each currency in its own currency: the system **does not post exchange gains or losses**.

---

## 24. Statement of account (SOA) and ageing

### Statement of account

Open **Statement of account**, choose a party, a date range, and the type:

* **Full ledger** — opening balance, every debit and credit in the period with a running balance, and the closing balance.
* **Open items only** — only documents that are still unpaid, which is what you usually send to a customer who asks "what do I still owe?".

The statement shows one section per currency. **Print** it or **Export Excel**. Available to Accounts, Management, Sales (for their agents and customers) and Administrators.

### Ageing

**Ageing** lists every party's open balance in these buckets: **not yet due, 1–30, 31–60, 61–90, over 90 days past due**, plus **unapplied** receipts and payments. Age is counted from the due date. Click a party to see its documents or its statement.

---

## 25. Reports: profit, sales performance and container history

* **Shipment register & profit (job-wise profitability)** — filter by date, status, agent and customer; shows TEU, CBM and (for users with finance access) income, expense and profit **per job (shipment)**. A **Profit** summary can be grouped **by agent, by customer, by trade lane, by month or by shipment**. **Export Excel** downloads the register.
* **Sales performance** — *Reports → Sales performance*. The same shipments grouped by agent, customer, trade lane or month, showing shipment count, TEU, CBM and revenue. This is open to the **Sales** role (and Transhipment) even though they do not have general finance access: it shows revenue and volume, never cost or profit, unless the viewer also has finance access, in which case expense and profit columns appear too.
* **Containers history** — *Equipment → Containers history*. Every recorded movement, for every container, fleet-wide: date, movement type, location, the booking/HBL it relates to, free days and who recorded it. Filter by date range, container number, movement type, location or user, and **Export Excel**.
* **Ageing** and **Daily inventory report** — see [section 24](#24-statement-of-account-soa-and-ageing) and [section 10](#10-container-inventory-and-tracking). Each commission statement can also be exported to Excel ([section 22](#22-agency-commission)).

**Profit** on a shipment is the posted income minus the posted costs (invoices and debit notes against bills and credit notes linked to that shipment), converted to base currency and **excluding VAT**. Draft documents are not counted, and commission is only included once its statement has been posted and linked to the shipment. Link every invoice and bill to its shipment so the figures are complete.

### Who created and last edited a job

Every shipment/booking, bill of lading, agency agreement and finance document shows, on its own page, **who created it** and (once changed) **who last edited it**, each with the date. Look for the **Record** card on the shipment, booking and bill of lading pages, and the equivalent line on an agreement or finance document's details card. This is separate from the full **Audit log** ([section 26](#26-administration-users-audit-log-backup)), which lists every change in order.

---

## 26. Administration: users, audit log, backup

### Users

**Setup → Users & roles**

* **New user:** username, full name, email, role, and a starting password. The user must change it at first sign-in. For an **Agent (external)** login also choose the agent company and list the locations the agent may update ([section 18](#18-external-agents-the-agent-portal)).
* **Edit** to change role or name, reset a password or **disable** a login. Disable rather than delete when someone leaves: their history stays in the audit log.
* Give people the least access they need. Use **Management** for read-only viewers.

### Company settings, e-mail and automation

**Setup → Company & settings** holds the company details printed on documents, accounting defaults, the **mail server** used for sharing by e-mail ([section 19](#19-sharing-by-excel-pdf-and-e-mail)) and the **automation** switches: automatic update of bookings when vessel dates change, the daily inventory report e-mail (recipients, hour and time zone). The **E-mail check** card at the bottom sends a test message and today's report on demand.

### Audit log

**Setup → Audit log** records every create, change, cancel, post, export and sign-in event with the time (UTC), the user, what was affected and the details. Administrators and Management can read it. It cannot be edited.

### Backup and restore

The whole system is a single database file.

* **Download a backup:** *Setup → Company & settings → Data & backup → Download database backup*. It saves a complete, consistent copy. Do this **daily** and keep copies somewhere other than the server (see DEPLOY.md for automated options).
* **Restore:** stop the application, replace the database file with the backup and start it again. Test a restore before you need one.

> A free hosting plan erases its disk when it restarts, so anything typed into a free demo will disappear. Use a server with a persistent disk for real work.

### Going live

Remove the demo data, use HTTPS, set a strong administrator password, create one login per person and set up daily backups. The full checklist is in [DEPLOY.md](../DEPLOY.md).

---

## 27. Accounting rules and assumptions

Please read these before relying on the numbers.

* **Sub-ledger only.** The system tracks parties, documents, allocations and profit. It does not keep a chart of accounts, journals or a trial balance. Export to your accounting package for statutory books.
* **Base currency** is AED, with USD pegged at 3.6725. Other rates are for you to maintain. The base currency is locked once documents exist.
* **VAT.** The starter charge codes apply 5% UAE VAT to local charges and 0% to ocean freight. This is only a starting point. Confirm how each charge should be treated with your accountant and current federal tax authority guidance, and edit the charge codes.
* **Posted means final.** Cancel and re-issue, or use a credit note.
* **No FX gain/loss** is calculated when a document in a foreign currency is settled.
* **Commission** uses ETD dates and status *sailed or later* to decide eligibility, and the most specific matching rule.
* **Legal templates.** The agency agreement clauses, the house B/L layout and its terms, and the invoice and SOA layouts are templates. Have them reviewed by your legal adviser and check the B/L against your registered form before issuing to customers.

---

## 28. Troubleshooting and FAQ

**I cannot see a menu item.** Your role does not include that area. Ask the administrator (see [section 3](#3-roles-and-what-each-can-do)).

**"Your role does not have write access" message.** Same reason; the action needs a different role.

**I am locked out.** After eight wrong attempts wait fifteen minutes, or ask the administrator to reset your password.

**The container number is rejected.** The check digit is wrong: recheck the number against the container. If the box uses a non-standard number, ask the administrator.

**A container is missing from the "Add container" list on a booking.** Only containers with status *Empty – available* are offered. Check its latest movement.

**I cannot cancel a document.** Remove its allocations first (open the receipt or payment, or the netting entry, that settled it).

**The invoice has no customer.** Choose the shipment first; the customer is filled in from it. Otherwise pick the customer manually.

**A shipment is missing from a commission statement.** It must be sailed or later, with an ETD inside the period and agreement dates, and not already on another statement, and an active rule must match.

**The Excel upload did not understand a column.** On the *Check* step open *Columns we found in your file* and pick the right column for each item. Only .xlsx, .csv, .tsv and .txt files are read; save an old .xls file as .xlsx first.

**Excel rows show "Check digit is wrong".** The container number has a typo. Correct it in the file and load it again; only real changes are saved, so reloading is safe. Tick *Accept wrong check digits* only for boxes you know use a non-standard number.

**"Location is outside your assigned locations" (agents).** An agent can only log movements at the places the administrator listed on their login. Ask the administrator to add the location.

**The vessel-schedule link says it cannot be read.** Some carrier websites draw the schedule with JavaScript. Use the site's **Download (Excel / CSV)** button and upload the file, or paste the address of the download itself. Links must be http or https and public; addresses inside a private network are refused for safety.

**Share by e-mail says e-mail is not set up.** An administrator must enter the mail server under *Setup → Company & settings → Sharing by e-mail*. Downloads work without it.

**The dashboard shows "This month's freight rate & slot cost are not set".** Open **MRG** and use **Copy from another month** or **Fill from tariff book**.

**The screen shows old data.** Reload the page. The system works on live data; there is no offline copy.

**The first page load after some time is slow (demo hosting).** Free hosts put the application to sleep when it is idle; the first request wakes it, which can take about a minute.

**Where did my demo data go?** Free hosting wipes the database whenever it restarts. That is expected for a demo.

**Does it work on a phone?** Yes. The layout adapts to tablets and phones, and light/dark theme follows your preference.

---

## 29. Glossary

| Term | Meaning |
|---|---|
| **NVOCC** | Non-vessel-operating common carrier: issues its own house B/Ls but buys space from shipping lines |
| **FCL / LCL** | Full container load / less than container load |
| **HBL / MBL** | House bill of lading (yours) / master bill of lading (carrier's) |
| **Consol** | Consolidation: several LCL house shipments under one master B/L |
| **TEU** | Twenty-foot equivalent unit: a 20-foot box is 1, a 40-foot box is 2 |
| **POL / POD** | Port of loading / port of discharge |
| **ETD / ETA** | Estimated time of departure / arrival |
| **Free time / detention** | Days the consignee may keep a container before charges start |
| **UN/LOCODE** | Five-letter port code, for example AEJEA |
| **ISO 6346** | International container numbering standard, ending in a check digit |
| **SOA** | Statement of account |
| **TRN** | Tax registration number |
| **Netting** | Settling a debit and a credit for the same party against each other |
| **Ageing** | Splitting unpaid balances by how long they are past due |
| **MRG** | Margin sheet: freight rate you charge, slot cost the line charges you, and the margin between them, month by month |
| **Slot cost** | What a shipping line charges you to carry one container on its vessel |
| **MQC** | Minimum quantity commitment: the number of slots you promised to use with a line |
| **Enquiry** | The search page that shows where a container is and where it has been |
| **Action centre** | The dashboard list of things that need attention today |
| **KYC** | Know Your Customer: verifying a customer's or vendor's identity, registration and compliance documents before trading with them |
| **Dead freight** | What you pay a carrier for slots you committed to but did not actually use |
| **Demurrage** | Charges for keeping a container at the port/terminal beyond free time, before gate-out (distinct from detention, which is after gate-out) |
| **Lessor** | The party that leases containers to you |
| **Transhipment** | A role for staff who manage vessel schedules, slot allocations, bookings, movements and bills of lading, without general finance access |

---

## 30. Known limits and roadmap

**Included since version 0.2:** container enquiry, Excel upload of inventory and movements, agent portal with location-scoped updates, bills of lading tab, vessel schedules (Excel and web link), MRG, sharing by Excel / PDF / e-mail, action centre and daily e-mailed inventory report.

**Included since version 0.4:** staff-assisted KYC/compliance cases with file or link document upload and administrator approval, which gates new bookings and billing for a non-approved party; a vessel master list with flag; vessel slot management with dead freight and carrier-invoice reconciliation; a dedicated leased-containers tab with lease-rate, after-period daily rate and one-way/round-trip terms; automatic tariff-based storage/detention billing; a **Transhipment** role; a sales performance report; a containers history report; and **created by / last edited by** shown on shipments, bills of lading, agreements and finance documents.

**Limits to be aware of**

* **Web links for schedules** read downloadable Excel / CSV files and plain HTML tables. Pages that build their table with JavaScript, need a login or block automated access cannot be read; use the download button on the carrier's site instead.
* **Excel uploads** accept .xlsx, .csv, .tsv and .txt (not the old .xls format).
* **E-mail** needs SMTP details; the system does not send mail on its own without them. On a free demo host that restarts, saved settings and links are lost with the data.
* **No live carrier tracking or EDI.** Container status comes from movements you or your agents record or upload.
* **Agents** update movements and BL details; invoicing and rates stay with your team.
* **KYC is staff-assisted, not self-service.** There is no public link for a customer or vendor to upload their own documents; your staff upload on their behalf. A party that has never been put through a KYC case is never blocked, so existing data is unaffected until you start a case for it.
* **Working in several tabs** means several ordinary browser tabs on the same session (each tab keeps its own screen); it is not an in-app multi-window workspace.

**Not yet included:** quotations and rate requests, carrier booking and tracking integrations (EDI / API), multi-branch or multi-company, document attachments, dangerous-goods and reefer details, FX revaluation, a public self-service KYC portal and an export to accounting packages. Tell your administrator which of these matters most so the next phase can be planned.
