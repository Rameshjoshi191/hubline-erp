'use strict';
// End-to-end test for the v0.4 feature set: KYC/compliance, vessel slot management & dead freight, leased
// containers, storage/detention auto-calc, the transhipment role, sales performance & container history reports,
// and created-by/last-edited-by on jobs.
const path = require('path');
const os = require('os');
const fs = require('fs');
const { execFileSync } = require('child_process');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'erp-newfeat-'));
process.env.DATA_DIR = tmp;
execFileSync('node', [path.join(__dirname, '..', 'src', 'seed-demo.js')], { env: process.env, stdio: 'pipe' });

const app = require('../src/server');
const { today, addDays } = require('../src/db');
const T = today();
const d = (n) => addDays(T, n);

let pass = 0, fail = 0;
function ok(cond, name) { if (cond) pass++; else { fail++; console.log('  FAIL: ' + name); } }
const eq = (a, b, name) => ok(Math.abs(a - b) < 0.006, `${name} (expected ${b}, got ${a})`);

(async () => {
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api`;

  function client() {
    let cookie = '';
    return async (method, url, body, opt = {}) => {
      const headers = { 'X-Requested-With': 'hubline-erp', cookie };
      let payload;
      if (Buffer.isBuffer(body)) { headers['Content-Type'] = 'application/octet-stream'; headers['X-Filename'] = encodeURIComponent(opt.filename || 'upload.pdf'); payload = body; }
      else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
      const res = await fetch(base + url, { method, headers, body: payload });
      if (url === '/login' && res.ok) cookie = res.headers.get('set-cookie').split(';')[0];
      if (opt.raw) return res;
      const buf = Buffer.from(await res.arrayBuffer());
      let j; try { j = JSON.parse(buf.toString('utf8')); } catch { j = null; }
      return { status: res.status, ok: res.ok, body: j };
    };
  }
  const login = async (u, p) => { const c = client(); const r = await c('POST', '/login', { username: u, password: p }); if (!r.ok) throw new Error('login ' + u); return c; };
  const admin = await login('admin', 'admin123');
  const ops = await login('ops', 'demo1234');
  const accounts = await login('accounts', 'demo1234');
  const sales = await login('sales', 'demo1234');

  const lk = (await admin('GET', '/lookups')).body;
  const noor = lk.parties.find((p) => p.name.startsWith('Al Noor'));
  const blueWave = lk.parties.find((p) => p.name.startsWith('Blue Wave'));
  const port = (c) => lk.ports.find((p) => p.code === c).id;
  const ctype = (c) => lk.container_types.find((p) => p.code === c).id;
  const charge = (c) => lk.charge_codes.find((p) => p.code === c).id;

  // ================================================================ created-by / modified-by on jobs
  console.log('Audit: created-by / modified-by');
  const ship = (await ops('POST', '/shipments', { cargo_type: 'FCL', customer_id: noor.id, pol_id: port('AEJEA'), pod_id: port('INNSA'), etd: d(5) })).body;
  let shipFull = (await ops('GET', `/shipments/${ship.id}`)).body;
  ok(shipFull.created_by_name === 'Omar (Operations)' && !shipFull.updated_by_name, 'new shipment shows creator, no editor yet');
  const docsUser = await login('docs', 'demo1234');
  ok((await docsUser('PUT', `/shipments/${ship.id}`, { cargo_type: 'FCL', customer_id: noor.id, remarks: 'edited by documentation' })).ok, 'another user edits the shipment');
  shipFull = (await ops('GET', `/shipments/${ship.id}`)).body;
  ok(shipFull.updated_by_name === 'Dina (Documentation)', 'shipment now shows who last edited it');

  // ================================================================ transhipment role & access matrix
  console.log('Transhipment role');
  ok((await admin('POST', '/users', { username: 'trans1', full_name: 'Tariq (Transhipment)', role: 'transhipment', password: 'demo1234' })).ok, 'admin creates a transhipment user');
  const trans = await login('trans1', 'demo1234');
  ok((await trans('POST', '/change-password', { current: 'demo1234', password: 'trans12345' })).ok, 'transhipment user completes the forced first password change');
  ok((await trans('GET', '/tariffs')).ok, 'transhipment has broad read access (tariffs)');
  ok((await trans('GET', '/documents')).ok, 'transhipment has broad read access (finance documents)');
  ok((await trans('GET', '/agreements')).ok, 'transhipment can read agreements');
  ok((await trans('GET', '/commissions')).ok, 'transhipment can read commission');
  ok((await trans('GET', '/mrg')).status !== 403, 'transhipment can read MRG');
  ok((await trans('POST', '/documents', {})).status === 403, 'transhipment cannot write finance documents');
  ok((await trans('POST', '/tariffs', {})).status === 403, 'transhipment cannot write tariffs');
  ok((await trans('POST', '/parties', { name: 'x', is_customer: 1 })).status === 403, 'transhipment cannot write parties');
  ok((await trans('POST', '/shipments', { cargo_type: 'FCL', customer_id: noor.id })).status !== 403, 'transhipment can write shipments');
  ok((await trans('POST', '/movements/quick', { numbers: 'MSKU1234565', event_type: 'ON_BOARD' })).status !== 403, 'transhipment can write container movements');
  ok((await trans('GET', '/bls')).ok, 'transhipment can read bills of lading');
  ok((await trans('GET', '/vessel-slots')).ok, 'transhipment can read slot management');
  ok((await trans('POST', '/vessel-slots', { vessel: 'MV TEST', voyage: '001W', booked_teu: 10, slot_cost_per_teu: 100 })).status !== 403, 'transhipment can write slot allocations');
  ok((await trans('POST', '/leases', {})).status === 403, 'transhipment cannot write leased containers');
  ok((await trans('GET', '/users')).status === 403, 'transhipment cannot manage users');

  // ================================================================ KYC / compliance
  console.log('KYC & compliance');
  ok((await trans('GET', '/kyc/cases')).ok, 'transhipment has staff-level KYC read access');
  const kyc = await login('sales', 'demo1234');
  const kcase = (await kyc('POST', '/kyc/cases', { party_id: noor.id, legal_name: 'Al Noor Trading LLC', reg_no: 'CN-1234', country: 'United Arab Emirates' })).body;
  ok(kcase.id, 'KYC case created for a customer');
  let party = (await kyc('GET', `/parties/${noor.id}`)).body;
  ok(party.kyc_status === 'PENDING', 'party kyc_status cached as PENDING');
  ok(!(await ops('POST', '/shipments', { cargo_type: 'FCL', customer_id: noor.id })).ok, 'booking is blocked while KYC is pending');
  ok(!(await kyc('POST', `/kyc/cases/${kcase.id}/submit`, {})).ok, 'cannot submit with no documents uploaded');
  ok((await kyc('POST', `/kyc/cases/${kcase.id}/documents/link`, { doc_type: 'TRADE_LICENSE', link_url: 'https://example.com/license.pdf' })).ok, 'staff adds a document link on the party\'s behalf');
  const fileDoc = await kyc('POST', `/kyc/cases/${kcase.id}/documents?doc_type=COMPLIANCE_FORM`, Buffer.from('%PDF-1.4 fake compliance form'), { filename: 'compliance.pdf' });
  ok(fileDoc.ok, 'staff uploads a PDF file on the party\'s behalf');
  ok((await kyc('POST', `/kyc/cases/${kcase.id}/submit`, {})).ok, 'case submitted for approval once documents exist');
  ok((await sales('POST', `/kyc/cases/${kcase.id}/approve`, {})).status === 403, 'only an administrator can approve - sales is blocked even though sales has kyc write');
  ok((await admin('POST', `/kyc/cases/${kcase.id}/approve`, {})).ok, 'administrator approves the KYC case');
  party = (await kyc('GET', `/parties/${noor.id}`)).body;
  ok(party.kyc_status === 'APPROVED', 'party kyc_status now APPROVED');
  ok((await ops('POST', '/shipments', { cargo_type: 'FCL', customer_id: noor.id })).ok, 'booking is allowed again once KYC is approved');
  const legacy = lk.parties.find((p) => p.name.startsWith('Gulf Fresh'));
  ok((await ops('POST', '/shipments', { cargo_type: 'FCL', customer_id: legacy.id })).ok, 'a party never put through KYC is not blocked (backward compatible)');

  const kcase2 = (await kyc('POST', '/kyc/cases', { party_id: legacy.id, legal_name: 'Gulf Fresh Foods FZE' })).body;
  await kyc('POST', `/kyc/cases/${kcase2.id}/documents/link`, { doc_type: 'OTHER', link_url: 'https://example.com/x.pdf' });
  await kyc('POST', `/kyc/cases/${kcase2.id}/submit`, {});
  ok((await admin('POST', `/kyc/cases/${kcase2.id}/reject`, { reason: 'Document illegible' })).ok, 'administrator rejects a case with a reason');
  party = (await kyc('GET', `/parties/${legacy.id}`)).body;
  ok(party.kyc_status === 'REJECTED', 'party kyc_status now REJECTED');
  ok(!(await ops('POST', '/shipments', { cargo_type: 'FCL', customer_id: legacy.id })).ok, 'booking is blocked once rejected');
  const reopened = (await kyc('POST', `/kyc/cases/${kcase2.id}/reopen`, {})).body;
  ok(reopened.id && reopened.id !== kcase2.id, 'rejected case can be reopened as a fresh attempt');

  // ================================================================ vessels & slot management
  console.log('Vessel: slot management, dead freight, carrier invoices, reconciliation');
  const vessel = (await ops('POST', '/vessels', { name: 'MV Hub Pioneer', flag: 'Panama', imo_no: '9123456', carrier_id: blueWave.id, teu_capacity: 5000 })).body;
  ok(vessel.id, 'vessel master created with flag');
  const slot = (await ops('POST', '/vessel-slots', { vessel: 'MV Hub Pioneer', voyage: '101W', carrier_id: blueWave.id, pol_id: port('AEJEA'), pod_id: port('INNSA'), booked_teu: 100, slot_cost_per_teu: 50, currency: 'USD' })).body;
  ok(slot.id, 'slot allocation created');
  const shipS = (await ops('POST', '/shipments', { cargo_type: 'FCL', customer_id: noor.id, vessel: 'MV Hub Pioneer', voyage: '101W', pol_id: port('AEJEA'), pod_id: port('INNSA') })).body;
  const empties = (await ops('GET', `/containers?status=EMPTY_AVAILABLE&type_id=${ctype('40HC')}`)).body.rows;
  if (empties[0]) await ops('POST', `/shipments/${shipS.id}/containers`, { container_id: empties[0].id });
  const slotDetail = (await ops('GET', `/vessel-slots/${slot.id}`)).body;
  ok(slotDetail.used_teu >= 0, 'slot detail reports used TEU from matching shipments');
  eq(slotDetail.dead_freight, Math.max(0, 100 - slotDetail.used_teu) * 50, 'dead freight = unused TEU x slot cost');
  const invResp = await ops('POST', `/vessel-slots/${slot.id}/invoices`, { invoice_no: 'BWL-9001', invoice_date: T, amount: 5200, currency: 'USD', create_bill: 1 });
  ok(invResp.ok && invResp.body.document_id, 'carrier slot invoice recorded, vendor bill created');
  const slotAfterInv = (await ops('GET', `/vessel-slots/${slot.id}`)).body;
  eq(slotAfterInv.invoiced_total, 5200, 'invoiced total reflects recorded carrier invoice');
  eq(slotAfterInv.variance, 5200 - slotAfterInv.expected_cost, 'reconciliation variance = invoiced - expected');
  ok(slotAfterInv.invoices[0].document_id, 'carrier invoice is linked to the vendor bill it created');

  // ================================================================ leased containers
  console.log('Leased containers');
  const lease = (await ops('POST', '/leases', { lessor_id: blueWave.id, lease_type: 'ONE_WAY', container_type_id: ctype('40HC'), start_date: d(-40), committed_period_days: 30, period_rate_per_day: 10, after_period_rate_per_day: 25, currency: 'USD', pickup_location: 'Jebel Ali', dropoff_location: 'Nhava Sheva' })).body;
  ok(lease.lease_no && /^LSE-/.test(lease.lease_no), 'lease created with a generated lease number');
  let leaseDetail = (await ops('GET', `/leases/${lease.id}`)).body;
  ok(leaseDetail.phase === 'AFTER_PERIOD', 'lease past its committed period is in the after-period phase');
  eq(leaseDetail.cost_to_date, 30 * 10 + (leaseDetail.days_elapsed - 30) * 25, 'lease cost splits committed-period rate and after-period daily rate');
  const anyContainer = (await ops('GET', '/containers')).body.rows[0];
  ok((await ops('POST', `/leases/${lease.id}/containers`, { container_id: anyContainer.id })).ok, 'container attached to the lease');
  leaseDetail = (await ops('GET', `/leases/${lease.id}`)).body;
  ok(leaseDetail.containers.length === 1 && leaseDetail.container_count === 1, 'lease shows the attached container');
  ok(!(await ops('DELETE', `/leases/${lease.id}`)).ok, 'lease with containers attached cannot be deleted');
  ok((await ops('DELETE', `/leases/${lease.id}/containers/${anyContainer.id}`)).ok, 'container detached from the lease');
  ok((await ops('POST', `/leases/${lease.id}/close`, { end_date: T })).ok, 'lease closed');
  ok(!(await ops('PUT', `/leases/${lease.id}`, { period_rate_per_day: 99 })).ok, 'a closed lease cannot be edited');

  // ================================================================ storage / detention auto-calc
  console.log('Storage & detention auto-calc');
  ok((await accounts('POST', '/tariffs', { rate_type: 'SELL', charge_code_id: charge('DET'), currency: 'USD', rate: 12, unit: 'PER_DAY' })).status === 403, 'accounts cannot write tariffs (sales/admin only)');
  await sales('POST', '/tariffs', { rate_type: 'SELL', charge_code_id: charge('DET'), currency: 'USD', rate: 12, unit: 'PER_DAY' });
  const pending = (await ops('GET', '/detention/pending')).body;
  ok(Array.isArray(pending), 'pending detention list returns an array');
  // pick one belonging to Al Noor, whose KYC was approved above (the Gulf Fresh case was deliberately left pending by the reopen test)
  const billable = pending.find((r) => !r.issue && r.amount > 0 && r.customer_id === noor.id);
  ok(billable, 'at least one overdue container now has a tariff rate and a billable amount');
  if (billable) {
    const before = billable.amount;
    const charged = await accounts('POST', '/detention/charge', { container_id: billable.container_id });
    ok(charged.ok && charged.body.document_id, 'debit note raised for overdue storage/detention');
    const docChk = (await accounts('GET', `/documents/${charged.body.document_id}`)).body;
    eq(docChk.total, before * 1.0, 'debit note total matches the computed detention amount (no VAT on DET)');
    const pendingAfter = (await ops('GET', '/detention/pending')).body;
    ok(!pendingAfter.some((r) => r.container_id === billable.container_id && r.from === billable.from), 'already-billed days are not offered again');
  }
  ok((await ops('POST', '/detention/charge', { container_id: billable ? billable.container_id : 1 })).status === 403, 'operations lacks finance write and cannot raise a detention invoice');
  ok(!(await accounts('POST', '/detention/charge', { container_id: 999999 })).ok, 'charging a container with nothing pending is rejected');

  // ================================================================ sales performance report
  console.log('Sales performance report');
  const spSales = (await sales('GET', '/reports/sales-performance?group=agent')).body;
  ok(spSales.show_cost === false, 'sales role does not see cost/profit on the sales performance report');
  ok(Array.isArray(spSales.rows) && spSales.rows.every((r) => r.income != null && r.expense === undefined), 'sales performance rows carry revenue but not expense for sales role');
  const spMgmt = (await admin('GET', '/reports/sales-performance?group=lane')).body;
  ok(spMgmt.show_cost === true && spMgmt.rows.every((r) => r.expense !== undefined), 'admin sees cost/profit on the sales performance report');
  ok((await ops('GET', '/reports/sales-performance')).status === 403, 'operations cannot read the sales performance report (mrg read required)');

  // ================================================================ containers history
  console.log('Containers history report');
  const hist = (await ops('GET', `/reports/container-history?from=${d(-120)}&to=${T}`)).body;
  ok(Array.isArray(hist) && hist.length > 0, 'container history lists movements fleet-wide');
  ok(hist.every((h) => h.event_date >= d(-120) && h.event_date <= T), 'container history respects the date filter');
  const histX = await ops('GET', `/reports/container-history?format=xlsx`, undefined, { raw: true });
  const histBuf = Buffer.from(await histX.arrayBuffer());
  ok(histX.status === 200 && histBuf.slice(0, 2).toString() === 'PK', 'container history exports a real .xlsx file');

  console.log(`\n${pass} passed, ${fail} failed`);
  server.close();
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('TEST CRASH:', e); process.exit(1); });
