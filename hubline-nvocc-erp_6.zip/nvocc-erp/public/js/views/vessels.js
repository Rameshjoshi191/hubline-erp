import { api, state, esc, $, on, qs, tbl, pageHead, money, num, date, badge, signed, formModal, confirmBox, toast, opts, can, kv, link, todayStr, go, debounce } from '../core.js';

// ------------------------------------------------------------------ vessels master
export async function vesselList(root) {
  const canW = can('slots', 'write');
  root.innerHTML = `${pageHead('Vessels', 'Vessel master data - name, flag and carrier, used across schedules and slot management', canW ? '<button class="btn primary" data-act="new">+ New vessel</button>' : '')}
    <div class="toolbar"><input type="text" class="search" placeholder="Search vessel, flag, IMO…" data-f="q"></div><div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const fields = () => [
    { name: 'name', label: 'Vessel name', required: true, span: 2 }, { name: 'flag', label: 'Flag', span: 2 },
    { name: 'imo_no', label: 'IMO no.' }, { name: 'call_sign', label: 'Call sign' },
    { name: 'carrier_id', label: 'Carrier / operator', type: 'combo', options: () => opts.parties('carrier'), span: 2 },
    { name: 'teu_capacity', label: 'TEU capacity', type: 'number', min: 0 }, { name: 'active', label: 'Active', type: 'checkbox' },
    { name: 'remarks', label: 'Remarks', span: 4 },
  ];
  let rows = [];
  const load = async (q = '') => {
    rows = await api('GET', '/vessels' + qs({ q }));
    out.innerHTML = tbl({ rows, empty: 'No vessels yet.', cols: [
      { label: 'Vessel', render: (v) => `<b>${esc(v.name)}</b>${v.active ? '' : ' ' + badge('Inactive', '')}` }, { label: 'Flag', render: (v) => esc(v.flag || '') },
      { label: 'IMO', render: (v) => esc(v.imo_no || '') }, { label: 'Carrier', render: (v) => esc(v.carrier_id ? (state.lk.parties.find((p) => p.id === v.carrier_id) || {}).name || '' : '') },
      { label: 'TEU capacity', num: true, render: (v) => v.teu_capacity ? num(v.teu_capacity) : '' },
      ...(canW ? [{ label: '', render: (v) => `<button class="btn sm ghost" data-edit="${v.id}">Edit</button><button class="btn sm ghost" data-del="${v.id}" title="Delete">&#10005;</button>` }] : [])] });
  };
  root.addEventListener('input', debounce((e) => { if (e.target.dataset.f) load(e.target.value).catch((x) => toast(x.message, 'bad')); }));
  on(root, 'click', '[data-act=new]', async () => { const r = await formModal({ title: 'New vessel', fields: fields(), values: { active: 1 }, onSubmit: (v) => api('POST', '/vessels', v) }); if (r) { toast('Vessel added', 'ok'); load(); } });
  on(root, 'click', '[data-edit]', async (_e, el) => { const v = rows.find((x) => String(x.id) === el.dataset.edit); const r = await formModal({ title: `Edit ${v.name}`, fields: fields(), values: v, onSubmit: (nv) => api('PUT', `/vessels/${v.id}`, nv) }); if (r) { toast('Saved', 'ok'); load(); } });
  on(root, 'click', '[data-del]', async (_e, el) => { if (await confirmBox('Delete this vessel?', { danger: true, ok: 'Delete' })) { try { await api('DELETE', `/vessels/${el.dataset.del}`); load(); } catch (e) { toast(e.message, 'bad'); } } });
  await load();
}

// ------------------------------------------------------------------ slot management
const slotFields = () => [
  { name: 'vessel', label: 'Vessel', required: true, span: 2 }, { name: 'voyage', label: 'Voyage', required: true, span: 2 },
  { name: 'carrier_id', label: 'Carrier', type: 'combo', options: () => opts.parties('carrier'), span: 2 }, { name: 'etd', label: 'ETD', type: 'date', span: 2 },
  { name: 'pol_id', label: 'Port of loading', type: 'combo', options: opts.ports, span: 2 }, { name: 'pod_id', label: 'Port of discharge', type: 'combo', options: opts.ports, span: 2 },
  { name: 'booked_teu', label: 'Booked (committed) TEU', type: 'number', required: true, min: 0, span: 2 }, { name: 'slot_cost_per_teu', label: 'Slot cost per TEU', type: 'number', required: true, min: 0, span: 2 },
  { name: 'currency', label: 'Currency', type: 'select', options: opts.currencies, noEmpty: true }, { name: 'remarks', label: 'Remarks', span: 3 },
];
const varianceBadge = (v) => Math.abs(v) < 0.5 ? badge('Reconciled', 'ok') : badge(v > 0 ? 'Carrier over-billed' : 'Under-billed', v > 0 ? 'warn' : 'bad');

export async function list(root, _p, query) {
  const canW = can('slots', 'write');
  const f = { q: query.q || '' };
  root.innerHTML = `${pageHead('Slot management', 'Booked vs. used slots per vessel/voyage, dead freight on unused slots, and reconciliation against carrier invoices', canW ? '<button class="btn primary" data-act="new">+ New slot allocation</button>' : '')}
    <div class="toolbar"><input type="text" class="search" placeholder="Search vessel, voyage, carrier…" data-f="q"></div><div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/vessel-slots' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'No slot allocations yet.', rowAttr: (r) => `data-go="#/slots/${r.id}"`, cols: [
      { label: 'Vessel / voyage', render: (r) => `<b>${esc(r.vessel)}</b> / ${esc(r.voyage)}${r.vessel_flag ? `<div class="muted small">Flag: ${esc(r.vessel_flag)}</div>` : ''}` },
      { label: 'Carrier', render: (r) => esc(r.carrier_name || '') }, { label: 'Route', render: (r) => r.pol_name || r.pod_name ? `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` : '' }, { label: 'ETD', render: (r) => date(r.etd) },
      { label: 'Booked TEU', num: true, key: 'booked_teu' }, { label: 'Used TEU', num: true, key: 'used_teu' },
      { label: 'Dead freight', num: true, render: (r) => r.dead_freight ? `<b class="neg">${money(r.dead_freight)}</b> ${esc(r.currency)}` : '' },
      { label: 'Invoiced', num: true, render: (r) => r.invoiced_total ? `${money(r.invoiced_total)} ${esc(r.currency)}` : '' }, { label: 'Reconciliation', render: (r) => varianceBadge(r.variance) }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { if (e.target.dataset.f) { f.q = e.target.value; reload(); } });
  on(root, 'click', '[data-act=new]', async () => { const r = await formModal({ title: 'New slot allocation', size: 'wide', fields: slotFields(), values: { currency: 'USD' }, onSubmit: (v) => api('POST', '/vessel-slots', v) }); if (r) { toast('Slot allocation created', 'ok'); go(`#/slots/${r.id}`); } });
  await load();
}

export async function detail(root, { id }) {
  const s = await api('GET', `/vessel-slots/${id}`);
  const canW = can('slots', 'write');
  root.innerHTML = `${pageHead(`${esc(s.vessel)} / ${esc(s.voyage)}`, `${esc(s.carrier_name || 'No carrier set')}${s.vessel_flag ? ` &middot; Flag: ${esc(s.vessel_flag)}` : ''}`, canW ? '<button class="btn" data-act="edit">Edit</button><button class="btn danger" data-act="del">Delete</button>' : '', '<a href="#/slots">Slot management</a> /')}
    <div class="grid g4" style="margin-bottom:14px">
      <div class="card stat"><div class="k">Booked TEU</div><div class="v">${num(s.booked_teu)}</div></div>
      <div class="card stat"><div class="k">Used TEU</div><div class="v">${num(s.used_teu)}</div></div>
      <div class="card stat"><div class="k">Dead freight</div><div class="v ${s.dead_freight ? 'neg' : ''}">${money(s.dead_freight)} ${esc(s.currency)}</div></div>
      <div class="card stat"><div class="k">Reconciliation</div><div class="v">${varianceBadge(s.variance)}</div></div></div>
    <div class="card"><div class="card-h"><h2>Slot details</h2></div><div class="card-b">${kv([['Route', s.pol_name || s.pod_name ? `${esc(s.pol_name || '?')} &rarr; ${esc(s.pod_name || '?')}` : ''], ['ETD', date(s.etd)],
      ['Slot cost per TEU', `${money(s.slot_cost_per_teu)} ${esc(s.currency)}`], ['Expected cost (booked &times; rate)', `${money(s.expected_cost)} ${esc(s.currency)}`],
      ['Unused TEU', num(s.unused_teu)], ['Remarks', esc(s.remarks)]])}</div></div>
    <div class="card"><div class="card-h"><h2>Carrier slot invoices</h2>${canW ? '<button class="btn sm primary" data-act="inv">+ Add invoice</button>' : ''}</div>
      ${tbl({ rows: s.invoices, compact: true, empty: 'No carrier invoices recorded yet.', cols: [
        { label: 'Invoice no.', render: (i) => esc(i.invoice_no || '') }, { label: 'Date', render: (i) => date(i.invoice_date) }, { label: 'Amount', num: true, render: (i) => `${money(i.amount)} ${esc(i.currency)}` },
        { label: 'Bill', render: (i) => i.document_id ? link('#/documents/' + i.document_id, 'View bill') : '' }, { label: 'Remarks', render: (i) => esc(i.remarks || '') },
        ...(canW ? [{ label: '', render: (i) => `<button class="btn sm ghost" data-delinv="${i.id}" title="Remove">&#10005;</button>` }] : [])] })}
      <div class="card-b" style="border-top:1px solid var(--line)">Total invoiced: <b>${money(s.invoiced_total)} ${esc(s.currency)}</b> vs. expected ${money(s.expected_cost)} ${esc(s.currency)} &rarr; variance ${signed(s.variance)} ${esc(s.currency)}</div></div>`;
  const refresh = () => go(`#/slots/${id}`);
  on(root, 'click', '[data-act=edit]', async () => { const r = await formModal({ title: 'Edit slot allocation', size: 'wide', fields: slotFields(), values: s, onSubmit: (v) => api('PUT', `/vessel-slots/${id}`, v) }); if (r) { toast('Saved', 'ok'); refresh(); } });
  on(root, 'click', '[data-act=del]', async () => { if (await confirmBox('Delete this slot allocation?', { danger: true, ok: 'Delete' })) { try { await api('DELETE', `/vessel-slots/${id}`); go('#/slots'); } catch (e) { toast(e.message, 'bad'); } } });
  on(root, 'click', '[data-act=inv]', async () => {
    const r = await formModal({ title: 'Add carrier slot invoice', fields: [
      { name: 'invoice_no', label: 'Carrier invoice no.', span: 2 }, { name: 'invoice_date', label: 'Date', type: 'date', span: 2 },
      { name: 'amount', label: 'Amount', type: 'number', required: true, min: 0, span: 2 }, { name: 'currency', label: 'Currency', type: 'select', options: opts.currencies, noEmpty: true, span: 2 },
      ...(s.carrier_id ? [{ name: 'create_bill', label: 'Also create a vendor bill for this carrier', type: 'checkbox', span: 4 }] : []),
      { name: 'remarks', label: 'Remarks', span: 4 }], values: { invoice_date: todayStr(), currency: s.currency }, onSubmit: (v) => api('POST', `/vessel-slots/${id}/invoices`, v) });
    if (r) { toast('Invoice recorded', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-delinv]', async (_e, el) => { if (await confirmBox('Remove this invoice?', { danger: true, ok: 'Remove' })) { try { await api('DELETE', `/vessel-slots/${id}/invoices/${el.dataset.delinv}`); refresh(); } catch (e) { toast(e.message, 'bad'); } } });
}
