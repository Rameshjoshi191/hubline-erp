// Per-module dashboards: a focused landing page for each left-nav module, in the same calm-panel style as the main dashboard.
import { api, esc, money, int, num, date, can, pageHead, docBadge, shipBadge, link } from '../core.js';
import { icon } from '../icons.js';
import { actionCentre, equipmentCard, trackingCard, receivablesCard, pipeline, PIPE } from './dashboard.js';

const guideBtn = (m) => `<a class="btn" href="#/guide/${m}">${icon('book', 16)} User guide</a>`;
const kpi = (ic, tone, k, v, s, href, cls = '') => `<a href="${href}" class="card kpi"><div class="tile ${tone}">${icon(ic, 22)}</div><div><div class="k">${k}</div><div class="v ${cls}">${v}</div><div class="s">${s}</div></div></a>`;
const row = (href, main, sub, right) => `<a class="rowline lnk" href="${href}"><span><b>${esc(main)}</b>${sub ? ` <span class="muted small">${esc(sub)}</span>` : ''}</span><span class="small">${right}</span></a>`;

export async function finance(root) {
  const d = await api('GET', '/dashboard/finance');
  root.innerHTML = `${pageHead('Finance dashboard', `${esc(d.base_currency)} figures &middot; ${date(d.today)}`,
    `${can('mrg', 'write') ? `<a class="btn" href="#/mrg">${icon('trend', 16)} MRG</a>` : ''}${can('finance', 'write') ? `<a class="btn primary" href="#/documents?new=1">${icon('plus', 16)} New invoice</a>` : ''}${guideBtn('finance')}`)}
    ${actionCentre(d.actions, 'Needs attention')}
    <div class="dash3">
      ${receivablesCard(d.receivables, d.base_currency)}
      <div class="card panel"><div class="card-h"><h2>${icon('invoice', 16)} Documents</h2><a class="btn sm" href="#/documents">All documents</a></div><div class="card-b">
        ${d.doc_stats.length ? d.doc_stats.map((s) => `<div class="rowline"><span>${esc(s.doc_type)}</span><span><b>${int(s.n)}</b>${s.draft ? ` <span class="muted small">${int(s.draft)} draft</span>` : ''}</span></div>`).join('') : '<div class="muted small">No documents yet.</div>'}
        <div class="sub-h">Latest</div>
        ${d.recent_documents.length ? d.recent_documents.map((x) => row(`#/documents/${x.id}`, x.doc_no || '(unposted)', x.party_name, `${money(x.total)} ${esc(x.currency)} ${docBadge(x.status)}`)).join('') : '<div class="muted small">Nothing posted yet.</div>'}
      </div></div>
      <div class="card panel"><div class="card-h"><h2>${icon('wallet', 16)} Receipts &amp; commission</h2><a class="btn sm" href="#/payments">Payments</a></div><div class="card-b">
        <div class="sub-h">Latest receipts / payments</div>
        ${d.recent_payments.length ? d.recent_payments.map((p) => `<div class="rowline"><span><b>${esc(p.party_name)}</b> <span class="muted small">${p.direction === 'RECEIPT' ? 'Receipt' : 'Payment'}</span></span><span class="small">${date(p.pay_date)} &middot; ${money(p.amount)} ${esc(p.currency)}</span></div>`).join('') : '<div class="muted small">No postings yet.</div>'}
        <div class="sub-h">Agency commission</div>
        ${d.commission.length ? d.commission.map((c) => `<div class="rowline"><span>${esc(c.status[0] + c.status.slice(1).toLowerCase())}</span><span><b>${int(c.n)}</b> <span class="muted small">${money(c.total)} ${esc(d.base_currency)}</span></span></div>`).join('') : '<div class="muted small">No statements yet.</div>'}
        ${!d.mrg_set ? `<a class="chipline warn" href="#/mrg">${icon('alert', 15)} This month's MRG rate is not set</a>` : ''}
      </div></div>
    </div>`;
}

export async function operations(root) {
  const d = await api('GET', '/dashboard/operations');
  const st = Object.fromEntries(d.shipments_by_status.map((x) => [x.status, x.n]));
  const open = PIPE.reduce((a, [k]) => a + (st[k] || 0), 0);
  const delta = d.this_month.teu - d.last_month.teu;
  root.innerHTML = `${pageHead('Operations dashboard', date(d.today),
    `${can('shipments', 'write') ? `<a class="btn primary" href="#/shipments?new=1">${icon('plus', 16)} New booking</a>` : ''}<a class="btn" href="#/consols">${icon('layers', 16)} Consolidations</a>${guideBtn('operations')}`)}
    <div class="grid g4" style="margin-bottom:16px">
      ${kpi('package', 'blue', 'Open shipments', int(open), `${int(st.BOOKED || 0)} booked &middot; ${int(st.CONFIRMED || 0)} confirmed`, '#/shipments?open=1')}
      ${kpi('ship', 'teal', 'TEU this month', num(d.this_month.teu), `${int(d.this_month.n)} shipments &middot; ${delta >= 0 ? '+' : ''}${num(delta)} vs last month`, '#/reports')}
      ${kpi('layers', 'purple', 'Open consolidations', int(d.consols_open), 'master BL / LCL', '#/consols')}
      ${kpi('alert', st.SAILED ? 'amber' : 'green', 'At sea now', int(st.SAILED || 0), `${int(st.ARRIVED || 0)} arrived, awaiting delivery`, '#/shipments?status=SAILED')}
    </div>
    ${actionCentre(d.actions, 'Needs attention')}
    ${pipeline(st, 'Shipment pipeline', '#/shipments')}
    <div class="card panel"><div class="card-h"><h2>${icon('package', 16)} Latest bookings</h2><a class="btn sm" href="#/shipments">All shipments</a></div><div class="card-b">
      ${d.recent.length ? d.recent.map((x) => row(`#/shipments/${x.id}`, x.hbl_no || x.booking_no, x.customer_name, shipBadge(x.status))).join('') : '<div class="muted small">No bookings yet.</div>'}
    </div></div>`;
}

export async function documentation(root) {
  const d = await api('GET', '/dashboard/documentation');
  const byStatus = Object.fromEntries(d.by_status.map((x) => [x.status, x.n]));
  const total = Object.values(byStatus).reduce((a, b) => a + b, 0);
  root.innerHTML = `${pageHead('Documentation dashboard', date(d.today),
    `${can('bl', 'write') ? `<a class="btn primary" href="#/bls?new=1">${icon('plus', 16)} New booking / HBL</a>` : ''}<a class="btn" href="#/bls">${icon('contract', 16)} Bills of lading</a>${guideBtn('documentation')}`)}
    ${actionCentre(d.actions, 'Needs attention')}
    <div class="dash3 two-col">
      <div class="card panel"><div class="card-h"><h2>${icon('contract', 16)} Bills of lading</h2><a class="btn sm" href="#/bls">Open all</a></div><div class="card-b">
        <div class="big"><b>${int(total)}</b><span>${d.role === 'agent' ? 'your bookings' : 'bookings on file'} &middot; <b>${int(d.issued_this_month)}</b> created this month</span></div>
        ${Object.keys(byStatus).length ? Object.entries(byStatus).map(([k, n]) => `<div class="rowline"><span>${shipBadge(k)}</span><b>${int(n)}</b></div>`).join('') : ''}
      </div></div>
      <div class="card panel"><div class="card-h"><h2>${icon('list', 16)} Latest</h2></div><div class="card-b">
        ${d.recent.length ? d.recent.map((x) => row(`#/bls/${x.id}`, x.hbl_no || x.booking_no, x.customer_name, shipBadge(x.status))).join('') : '<div class="muted small">No bookings yet.</div>'}
      </div></div>
    </div>`;
}

export async function equipment(root) {
  const d = await api('GET', '/dashboard/equipment');
  const agent = d.role === 'agent';
  root.innerHTML = `${pageHead('Equipment dashboard', date(d.today),
    `<a class="btn" href="#/track">${icon('search', 16)} Container enquiry</a>${can('movements', 'write') ? `<a class="btn" href="#/movements">${icon('bolt', 16)} Update movements</a>` : ''}${!agent && can('reports', 'read') ? `<a class="btn" href="#/inventory-report">${icon('report', 16)} Inventory report</a>` : ''}${guideBtn('equipment')}`)}
    ${actionCentre(d.actions, 'Needs attention')}
    <div class="dash3 two-col">${equipmentCard(d.equipment, agent)}${trackingCard(d.tracking, true)}</div>
    ${d.overdue_containers.length ? `<div class="card panel"><div class="card-h"><h2>${icon('alert', 16)} Past free time</h2><a class="btn sm" href="#/containers?overdue=1">All</a></div><div class="card-b">
      ${d.overdue_containers.map((c) => row(`#/track/${c.id}`, c.container_no, c.location, `<span class="neg">${-c.free_days_left} day(s) over</span>`)).join('')}
    </div></div>` : ''}`;
}

export async function trade(root) {
  const d = await api('GET', '/dashboard/trade');
  const byStatus = Object.fromEntries(d.agreements_by_status.map((x) => [x.status, x.n]));
  root.innerHTML = `${pageHead('Trade dashboard', date(d.today),
    `<a class="btn" href="#/agents">${icon('users', 16)} Agents</a>${can('agreements', 'write') ? `<a class="btn primary" href="#/agreements?new=1">${icon('plus', 16)} New agreement</a>` : ''}${guideBtn('trade')}`)}
    ${actionCentre(d.actions, 'Needs attention')}
    <div class="grid g4" style="margin-bottom:16px">
      ${kpi('users', 'blue', 'Active agents', int(d.active_agents), 'overseas / local', '#/agents')}
      ${kpi('building', 'teal', 'Active customers', int(d.active_customers), '', '#/parties')}
      ${kpi('tag', 'purple', 'Active tariffs', int(d.active_tariffs), 'sell / buy rates', '#/tariffs')}
      ${kpi('contract', byStatus.EXPIRED ? 'red' : 'green', 'Agreements expired', int(byStatus.EXPIRED || 0), `${int(byStatus.ACTIVE || 0)} active`, '#/agreements', byStatus.EXPIRED ? 'neg' : '')}
    </div>
    <div class="dash3 two-col">
      <div class="card panel"><div class="card-h"><h2>${icon('clock', 16)} Expiring within 60 days</h2><a class="btn sm" href="#/agreements">All agreements</a></div><div class="card-b">
        ${d.expiring_soon.length ? d.expiring_soon.map((a) => row(`#/agreements/${a.id}`, a.agreement_no, a.agent_name, date(a.end_date))).join('') : '<div class="muted small">Nothing expiring soon.</div>'}
      </div></div>
      <div class="card panel"><div class="card-h"><h2>${icon('percent', 16)} Top agents by commission</h2><a class="btn sm" href="#/commissions">Commission</a></div><div class="card-b">
        ${d.top_agents.length ? d.top_agents.map((a) => `<div class="rowline"><span>${link('#/agents/' + a.id, a.name)}</span><span><b>${money(a.total)}</b> <span class="muted small">${int(a.n)} statement(s)</span></span></div>`).join('') : '<div class="muted small">No posted commission yet.</div>'}
      </div></div>
    </div>`;
}

export async function vessel(root) {
  const d = await api('GET', '/dashboard/vessel');
  root.innerHTML = `${pageHead('Vessel dashboard', date(d.today),
    `${can('schedules', 'write') ? `<a class="btn primary" href="#/schedules?new=1">${icon('plus', 16)} Add sailing</a>` : ''}<a class="btn" href="#/schedules">${icon('ship', 16)} All schedules</a>${guideBtn('vessel')}`)}
    ${actionCentre(d.actions, 'Needs attention')}
    <div class="dash3 two-col">
      <div class="card panel"><div class="card-h"><h2>${icon('ship', 16)} Upcoming sailings</h2><a class="btn sm" href="#/schedules">All</a></div><div class="card-b">
        <div class="big"><b>${int(d.upcoming.length)}</b><span>on the near-term list &middot; <b>${int(d.added_7d)}</b> added in the last 7 days</span></div>
        ${d.upcoming.length ? d.upcoming.map((v) => row(`#/schedules`, `${v.vessel}${v.voyage ? ' ' + v.voyage : ''}`, `${v.pol_name || ''} &rarr; ${v.pod_name || ''}`.replace(/&rarr;/, '→'), date(v.etd))).join('') : '<div class="muted small">No upcoming sailings loaded. Load one from Vessel schedules.</div>'}
      </div></div>
      ${d.sources.length ? `<div class="card panel"><div class="card-h"><h2>${icon('link', 16)} Saved web links</h2><a class="btn sm" href="#/schedules">Manage</a></div><div class="card-b">
        ${d.sources.map((s) => `<div class="rowline"><span><b>${esc(s.name)}</b>${s.auto_refresh ? ' <span class="badge ok">auto</span>' : ''}</span><span class="small muted">${s.last_run ? date(s.last_run.slice(0, 10)) : 'never run'}${s.last_status === 'ERROR' ? ' <span class="neg">error</span>' : ''}</span></div>`).join('')}
      </div></div>` : `<div class="card panel"><div class="card-h"><h2>${icon('info', 16)} Tip</h2></div><div class="card-b"><p class="muted" style="margin:0">Load vessel schedules from a carrier's Excel file or web link under <a href="#/schedules">Vessel schedules</a>.</p></div></div>`}
    </div>`;
}
