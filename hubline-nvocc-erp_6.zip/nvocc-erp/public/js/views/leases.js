import { api, esc, $, on, qs, tbl, pageHead, money, num, date, badge, formModal, confirmBox, toast, opts, can, kv, go, todayStr, debounce } from '../core.js';

const LEASE_TYPE = { ONE_WAY: 'One-way', ROUND_TRIP: 'Round-trip' };
const statusBadge = (s) => s === 'CLOSED' ? badge('Closed', '') : badge('Active', 'ok');
const phaseBadge = (p) => p === 'COMMITTED' ? badge('Committed period', 'info') : badge('After-period (daily)', 'warn');

const leaseFields = () => [
  { name: 'lessor_id', label: 'Lessor', type: 'combo', required: true, options: () => opts.parties('vendor'), span: 2 },
  { name: 'lease_type', label: 'Lease type', type: 'select', noEmpty: true, options: Object.entries(LEASE_TYPE).map(([v, l]) => [v, l]), span: 2 },
  { name: 'container_type_id', label: 'Container type', type: 'combo', options: opts.types, span: 2 },
  { name: 'start_date', label: 'Lease start date', type: 'date', required: true, span: 2 },
  { name: 'committed_period_days', label: 'Committed period (days)', type: 'number', required: true, min: 0, span: 2 },
  { name: 'currency', label: 'Currency', type: 'select', options: opts.currencies, noEmpty: true, span: 2 },
  { name: 'period_rate_per_day', label: 'Rate per day during committed period', type: 'number', required: true, min: 0, span: 2 },
  { name: 'after_period_rate_per_day', label: 'Rate per day after committed period', type: 'number', required: true, min: 0, span: 2 },
  { name: 'pickup_location', label: 'Pickup location', span: 2 }, { name: 'dropoff_location', label: 'Drop-off location', span: 2 },
  { name: 'remarks', label: 'Remarks', span: 4 },
];

export async function list(root, _p, query) {
  const canW = can('leases', 'write');
  const f = { q: query.q || '', status: query.status || '' };
  root.innerHTML = `${pageHead('Leased containers', 'Lease contract terms per lessor - committed-period rate, the daily rate that applies after it, one-way vs. round-trip, and pickup / drop-off locations', canW ? '<button class="btn primary" data-act="new">+ New lease</button>' : '')}
    <div class="toolbar"><input type="text" class="search" placeholder="Search lease no. or lessor…" data-f="q" value="${esc(f.q)}">
      <select data-f="status"><option value="">All</option><option value="ACTIVE" ${f.status === 'ACTIVE' ? 'selected' : ''}>Active</option><option value="CLOSED" ${f.status === 'CLOSED' ? 'selected' : ''}>Closed</option></select></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/leases' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'No leases yet.', rowAttr: (r) => `data-go="#/leases/${r.id}"`, cols: [
      { label: 'Lease no.', render: (r) => `<b>${esc(r.lease_no)}</b>` }, { label: 'Lessor', render: (r) => esc(r.lessor_name) },
      { label: 'Type', render: (r) => esc(LEASE_TYPE[r.lease_type] || r.lease_type) }, { label: 'Container type', render: (r) => esc(r.container_type_code || 'Any') },
      { label: 'Start', render: (r) => date(r.start_date) }, { label: 'Containers', num: true, key: 'container_count' },
      { label: 'Phase', render: (r) => phaseBadge(r.phase) }, { label: 'Cost to date', num: true, render: (r) => `${money(r.cost_to_date)} ${esc(r.currency)}` },
      { label: 'Status', render: (r) => statusBadge(r.status) }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  root.addEventListener('change', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  on(root, 'click', '[data-act=new]', async () => {
    const r = await formModal({ title: 'New container lease', size: 'wide', fields: leaseFields(), values: { lease_type: 'ONE_WAY', currency: 'USD', start_date: todayStr(), committed_period_days: 0 }, onSubmit: (v) => api('POST', '/leases', v) });
    if (r) { toast('Lease created', 'ok'); go(`#/leases/${r.id}`); }
  });
  await load();
}

export async function detail(root, { id }) {
  const l = await api('GET', `/leases/${id}`);
  const canW = can('leases', 'write') && l.status !== 'CLOSED';
  const actions = [];
  if (canW) actions.push('<button class="btn" data-act="edit">Edit</button>', '<button class="btn" data-act="attach">Attach container</button>', '<button class="btn danger" data-act="close">Close lease</button>');
  root.innerHTML = `${pageHead(`${esc(l.lease_no)} ${statusBadge(l.status)}`, `${esc(l.lessor_name)} &middot; ${esc(LEASE_TYPE[l.lease_type] || l.lease_type)} lease`, actions.join(''), '<a href="#/leases">Leased containers</a> /')}
    <div class="grid g4" style="margin-bottom:14px">
      <div class="card stat"><div class="k">Phase</div><div class="v">${phaseBadge(l.phase)}</div></div>
      <div class="card stat"><div class="k">Committed period ends</div><div class="v">${date(l.period_end)}</div></div>
      <div class="card stat"><div class="k">Days elapsed</div><div class="v">${num(l.days_elapsed)}</div></div>
      <div class="card stat"><div class="k">Cost to date</div><div class="v">${money(l.cost_to_date)} ${esc(l.currency)}</div></div></div>
    <div class="card"><div class="card-h"><h2>Contract terms</h2></div><div class="card-b">${kv([
      ['Container type', esc(l.container_type_code || 'Any')], ['Start date', date(l.start_date)], ['Committed period', `${num(l.committed_period_days)} day(s)`],
      ['Rate during committed period', `${money(l.period_rate_per_day)} ${esc(l.currency)} / day`], ['Rate after committed period', `${money(l.after_period_rate_per_day)} ${esc(l.currency)} / day`],
      ['Pickup location', esc(l.pickup_location)], ['Drop-off location', esc(l.dropoff_location)],
      ...(l.status === 'CLOSED' ? [['Closed on', date(l.end_date)]] : []),
      ['Remarks', esc(l.remarks)], ['Created by', l.created_by_name ? `${esc(l.created_by_name)} <span class="muted small">${date(l.created_at)}</span>` : '']])}</div></div>
    <div class="card"><div class="card-h"><h2>Containers on this lease</h2></div>
      ${tbl({ rows: l.containers, compact: true, click: true, empty: 'No containers attached yet.', rowAttr: (c) => `data-go="#/containers/${c.id}"`, cols: [
        { label: 'Container no.', render: (c) => `<b>${esc(c.container_no)}</b>` }, { label: 'Type', render: (c) => esc(c.type_code) }, { label: 'Status', render: (c) => esc(c.status) }, { label: 'Location', render: (c) => esc(c.location || '') },
        ...(canW ? [{ label: '', render: (c) => `<button class="btn sm ghost" data-detach="${c.id}" title="Detach">&#10005;</button>` }] : [])] })}</div>`;
  const refresh = () => go(`#/leases/${id}`);
  on(root, 'click', '[data-act=edit]', async () => {
    const r = await formModal({ title: 'Edit lease', size: 'wide', fields: leaseFields(), values: l, onSubmit: (v) => api('PUT', `/leases/${id}`, v) });
    if (r) { toast('Saved', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-act=attach]', async () => {
    const avail = (await api('GET', '/containers')).rows.map((c) => [c.id, `${c.container_no} - ${c.type_code} - ${c.status_label}${c.location ? ' @ ' + c.location : ''}`]);
    const r = await formModal({ title: 'Attach a container to this lease', fields: [
      { name: 'container_id', label: 'Container', type: 'combo', required: true, options: () => avail, span: 4, hint: 'containers already on another lease will be rejected' }],
      onSubmit: (v) => api('POST', `/leases/${id}/containers`, v) });
    if (r) { toast('Container attached', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-act=close]', async () => {
    const r = await formModal({ title: 'Close this lease', size: 'narrow', fields: [{ name: 'end_date', label: 'End date', type: 'date', required: true }], values: { end_date: todayStr() }, onSubmit: (v) => api('POST', `/leases/${id}/close`, v) });
    if (r) { toast('Lease closed', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-detach]', async (_e, el) => { if (await confirmBox('Detach this container from the lease?', { ok: 'Detach' })) { try { await api('DELETE', `/leases/${id}/containers/${el.dataset.detach}`); refresh(); } catch (e) { toast(e.message, 'bad'); } } });
}
