import { api, upload, state, esc, $, on, qs, tbl, pageHead, date, dt, badge, formModal, confirmBox, toast, can, kv, go, debounce } from '../core.js';
import { icon } from '../icons.js';

const STATUS = { PENDING: ['Pending', 'warn'], SUBMITTED: ['Submitted - awaiting approval', 'info'], APPROVED: ['Approved', 'ok'], REJECTED: ['Rejected', 'bad'] };
const statusBadge = (s) => { const [t, c] = STATUS[s] || [s, '']; return badge(t, c); };
const DOC_TYPES = [['TRADE_LICENSE', 'Trade licence'], ['PASSPORT', 'Passport / ID'], ['COMPLIANCE_FORM', 'Compliance form'], ['OTHER', 'Other']];
const partyOptsCustVend = () => state.lk.parties.filter((p) => p.is_customer || p.is_vendor).map((p) => [p.id, `${p.name} [${p.code}]`]);

export async function list(root, _p, query) {
  const f = { status: query.status || '', q: '' };
  const canW = can('kyc', 'write');
  root.innerHTML = `${pageHead('KYC &amp; compliance', 'Create a case for a customer or vendor, upload their documents on their behalf, and have an administrator approve it before new jobs are booked for them', canW ? '<button class="btn primary" data-act="new">+ New KYC case</button>' : '')}
    <div class="toolbar"><input type="text" class="search" placeholder="Search party…" data-f="q">
      <select data-f="status"><option value="">All statuses</option>${Object.keys(STATUS).map((s) => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${STATUS[s][0]}</option>`).join('')}</select></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/kyc/cases' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'No KYC cases yet.', rowAttr: (r) => `data-go="#/kyc/${r.id}"`, cols: [
      { label: 'Party', render: (r) => `<b>${esc(r.party_name)}</b><div class="muted small mono">${esc(r.party_code)}</div>` },
      { label: 'Legal name', render: (r) => esc(r.legal_name || '') }, { label: 'Documents', num: true, key: 'document_count' },
      { label: 'Created', render: (r) => `${date(r.created_at)}<div class="muted small">${esc(r.created_by_name || '')}</div>` }, { label: 'Status', render: (r) => statusBadge(r.status) }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  on(root, 'click', '[data-act=new]', async () => {
    const r = await formModal({ title: 'New KYC case', fields: [
      { name: 'party_id', label: 'Customer / vendor', type: 'combo', required: true, options: partyOptsCustVend, span: 4 },
      { name: 'legal_name', label: 'Registered legal name', span: 2 }, { name: 'reg_no', label: 'Trade / registration no.', span: 2 },
      { name: 'tax_no', label: 'Tax / VAT no.', span: 2 }, { name: 'country', label: 'Country', span: 2 },
      { name: 'compliance_notes', label: 'Compliance notes', type: 'textarea', rows: 3, span: 4 }], onSubmit: (v) => api('POST', '/kyc/cases', v) });
    if (r) { toast('KYC case created', 'ok'); go(`#/kyc/${r.id}`); }
  });
  await load();
}

export async function detail(root, { id }) {
  const c = await api('GET', `/kyc/cases/${id}`);
  const canW = can('kyc', 'write'), isAdmin = state.me.role === 'admin';
  const editable = ['PENDING', 'SUBMITTED'].includes(c.status);
  const actions = [];
  if (canW && editable) actions.push('<button class="btn" data-act="edit">Edit details</button>');
  if (canW && c.status === 'PENDING') actions.push('<button class="btn primary" data-act="submit">Submit for approval</button>');
  if (isAdmin && c.status === 'SUBMITTED') actions.push('<button class="btn primary" data-act="approve">Approve</button>', '<button class="btn danger" data-act="reject">Reject</button>');
  if (canW && c.status === 'REJECTED') actions.push('<button class="btn" data-act="reopen">Reopen (start a new attempt)</button>');
  root.innerHTML = `${pageHead(`${esc(c.party_name)} ${statusBadge(c.status)}`, `${esc(c.party_code)} &middot; KYC / compliance case`, actions.join(''), '<a href="#/kyc">KYC &amp; compliance</a> /')}
    ${c.status === 'REJECTED' && c.reject_reason ? `<div class="alert bad"><b>Rejected:</b> ${esc(c.reject_reason)}</div>` : ''}
    ${c.status === 'APPROVED' ? '<div class="alert ok">Approved - this party is cleared for new bookings and invoicing.</div>' : ''}
    <div class="split"><div>
      <div class="card"><div class="card-h"><h2>Documents</h2>${canW && editable ? `<button class="btn sm" data-act="upload">${icon('upload', 14)} Upload file</button><button class="btn sm" data-act="link">${icon('link', 14)} Add link</button>` : ''}</div>
        ${tbl({ rows: c.documents, compact: true, empty: 'No documents uploaded yet.', cols: [
          { label: 'Type', render: (d) => esc((DOC_TYPES.find(([v]) => v === d.doc_type) || [, d.doc_type])[1]) },
          { label: 'File / link', render: (d) => d.method === 'FILE' ? `<a href="/api/kyc/documents/${d.id}/download" target="_blank">${esc(d.filename || 'download')}</a>` : `<a href="${esc(d.link_url)}" target="_blank" rel="noopener">${esc(d.link_url)}</a>` },
          { label: 'Uploaded', render: (d) => `${dt(d.uploaded_at)}<div class="muted small">${esc(d.uploaded_by_name || '')}</div>` },
          { label: 'Remarks', render: (d) => esc(d.remarks || '') },
          ...(canW && editable ? [{ label: '', render: (d) => `<button class="btn sm ghost" data-deldoc="${d.id}" title="Remove">&#10005;</button>` }] : [])] })}</div>
    </div><div>
      <div class="card"><div class="card-h"><h2>Compliance form</h2></div><div class="card-b">${kv([['Legal name', esc(c.legal_name)], ['Registration no.', esc(c.reg_no)], ['Tax / VAT no.', esc(c.tax_no)], ['Country', esc(c.country)], ['Notes', esc(c.compliance_notes)],
        ['Created by', c.created_by_name ? `${esc(c.created_by_name)} <span class="muted small">${date(c.created_at)}</span>` : ''],
        ['Submitted by', c.submitted_by_name ? `${esc(c.submitted_by_name)} <span class="muted small">${date(c.submitted_at)}</span>` : ''],
        ['Reviewed by', c.reviewed_by_name ? `${esc(c.reviewed_by_name)} <span class="muted small">${date(c.reviewed_at)}</span>` : '']])}</div></div>
      <div class="card"><div class="card-b"><a class="btn" href="#/parties/${c.party_id}">Open party record</a></div></div>
    </div></div>`;
  const refresh = () => go(`#/kyc/${id}`);
  on(root, 'click', '[data-act=edit]', async () => {
    const r = await formModal({ title: 'Edit compliance details', values: c, fields: [
      { name: 'legal_name', label: 'Registered legal name', span: 2 }, { name: 'reg_no', label: 'Trade / registration no.', span: 2 },
      { name: 'tax_no', label: 'Tax / VAT no.', span: 2 }, { name: 'country', label: 'Country', span: 2 },
      { name: 'compliance_notes', label: 'Compliance notes', type: 'textarea', rows: 3, span: 4 }], onSubmit: (v) => api('PUT', `/kyc/cases/${id}`, v) });
    if (r) { toast('Saved', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-act=upload]', async () => {
    const h = document.createElement('input'); h.type = 'file'; h.accept = '.pdf,.jpg,.jpeg,.png';
    h.onchange = async () => {
      const file = h.files[0]; if (!file) return;
      let docType = 'OTHER';
      const picked = await formModal({ title: `Upload - ${file.name}`, size: 'narrow', fields: [{ name: 'doc_type', label: 'Document type', type: 'select', noEmpty: true, options: DOC_TYPES, span: 4 }], values: { doc_type: 'TRADE_LICENSE' },
        onSubmit: (v) => { docType = v.doc_type; return true; } });
      if (!picked) return;
      try { const buf = await file.arrayBuffer(); await upload(`/kyc/cases/${id}/documents?doc_type=${docType}`, buf, file.name); toast('Document uploaded', 'ok'); refresh(); }
      catch (e) { toast(e.message, 'bad'); }
    };
    h.click();
  });
  on(root, 'click', '[data-act=link]', async () => {
    const r = await formModal({ title: 'Add document link', fields: [
      { name: 'doc_type', label: 'Document type', type: 'select', noEmpty: true, options: DOC_TYPES, span: 2 },
      { name: 'link_url', label: 'Link (PDF / drive link)', span: 2, required: true }, { name: 'remarks', label: 'Remarks', span: 4 }],
      values: { doc_type: 'TRADE_LICENSE' }, onSubmit: (v) => api('POST', `/kyc/cases/${id}/documents/link`, v) });
    if (r) { toast('Link added', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-deldoc]', async (_e, el) => { if (await confirmBox('Remove this document?', { danger: true, ok: 'Remove' })) { try { await api('DELETE', `/kyc/documents/${el.dataset.deldoc}`); refresh(); } catch (e) { toast(e.message, 'bad'); } } });
  on(root, 'click', '[data-act=submit]', async () => { if (await confirmBox('Submit this case for approval? Make sure the compliance form and documents are complete.', { ok: 'Submit' })) { try { await api('POST', `/kyc/cases/${id}/submit`); toast('Submitted for approval', 'ok'); refresh(); } catch (e) { toast(e.message, 'bad'); } } });
  on(root, 'click', '[data-act=approve]', async () => { if (await confirmBox(`Approve KYC for ${c.party_name}? New bookings and invoicing will be allowed for this party.`, { ok: 'Approve' })) { try { await api('POST', `/kyc/cases/${id}/approve`); toast('Approved', 'ok'); refresh(); } catch (e) { toast(e.message, 'bad'); } } });
  on(root, 'click', '[data-act=reject]', async () => {
    const r = await formModal({ title: `Reject KYC - ${c.party_name}`, size: 'narrow', submitLabel: 'Reject', fields: [{ name: 'reason', label: 'Reason', required: true, type: 'textarea', rows: 3, span: 4 }], onSubmit: (v) => api('POST', `/kyc/cases/${id}/reject`, v) });
    if (r) { toast('Case rejected', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-act=reopen]', async () => { try { const r = await api('POST', `/kyc/cases/${id}/reopen`); toast('New case started', 'ok'); go(`#/kyc/${r.id}`); } catch (e) { toast(e.message, 'bad'); } });
}
