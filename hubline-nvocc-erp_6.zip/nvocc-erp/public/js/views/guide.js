// In-app user guide: one page per module, reachable from the left nav or from the "User guide" button on each module's dashboard.
import { esc, pageHead } from '../core.js';
import { icon } from '../icons.js';

const MODULES = [
  ['finance', 'coins', 'Finance'],
  ['operations', 'package', 'Operations'],
  ['documentation', 'contract', 'Documentation'],
  ['equipment', 'container', 'Equipment'],
  ['trade', 'users', 'Trade'],
  ['vessel', 'ship', 'Vessel'],
];

const CONTENT = {
  finance: () => `<h2>${icon('coins', 20)} Finance</h2><p class="lead">Invoices, bills, receipts, payments, agency commission and the month-wise freight / slot cost (MRG) - everything that moves money.</p>

  <h3>Raising an invoice, debit note or bill</h3>
  <ol>
    <li><b>Invoices &amp; notes &rarr; New</b> (or <b>New invoice</b> on the Finance dashboard or a shipment's Finance card), then choose the document type.</li>
    <li>Pick the <b>shipment</b> - the customer fills in from it, and you can still change it.</li>
    <li>Add lines with <b>+ Add line</b> (charge code, description, quantity, unit price, VAT rate), or press <b>Fill from tariff</b> to pull the rate book.</li>
    <li>Choose currency, document date and due date (defaults from the party's credit days).</li>
    <li><b>Save as draft</b> to keep working, or <b>Save &amp; post</b> to finalise it.</li>
  </ol>
  <p>A <b>draft</b> can be edited or deleted. A <b>posted</b> document cannot be edited - cancel and re-issue it, or raise a credit note instead. A document with money already allocated to it cannot be cancelled until that allocation is removed.</p>

  <table class="statuses"><tr><th>Document</th><th>Effect on the party's account</th></tr>
    <tr><td>Invoice (INV) / Debit note (DN)</td><td>Debit - the party owes you</td></tr>
    <tr><td>Credit note (CN)</td><td>Credit - reduces what they owe</td></tr>
    <tr><td>Vendor bill (BILL)</td><td>Credit - you owe the vendor</td></tr>
    <tr><td>Commission statement (COMM)</td><td>Credit - you owe the agent</td></tr>
    <tr><td>Receipt / Payment</td><td>Settles money in / out against open documents</td></tr></table>

  <h3>Receipts, payments and netting</h3>
  <p>On a posted invoice or debit note press <b>Record receipt</b>; on a bill or commission statement press <b>Record payment</b>; on a credit note press <b>Record refund</b> - or open <b>Receipts &amp; payments</b> directly. Choose the party, currency and amount, then apply it across one or several open documents; whatever is left over sits as <b>unapplied</b> until you use it. When the same party owes you and is owed by you in the same currency, open a posted document and press <b>Net against another document</b> to settle both without any cash movement.</p>

  <h3>Statement of account &amp; ageing</h3>
  <p><b>Statement of account</b> gives a full ledger or an open-items-only statement for one party, by currency. <b>Ageing</b> buckets every open balance as not yet due, 1-30, 31-60, 61-90 and over 90 days past due, plus unapplied money - click a party to drill in.</p>

  <h3>MRG - month-wise freight &amp; slot cost</h3>
  <p><b>Finance &rarr; MRG</b> keeps, lane by lane and month by month, what you charge (freight) against what the carrier charges you for the slot - the difference is your margin per box. Use <b>Copy from another month</b> to roll a month forward, <b>Fill from tariff book</b> to seed freight rates from Rates / tariffs, or <b>Load from Excel</b>. Sales and Administrators can change it; Management and Accounts can view it.</p>

  <h3>Agency commission</h3>
  <p>A statement is calculated from an agent's agreement rules (per TEU, per container, per CBM, flat per HBL, or a percentage of freight or profit). <b>Commission &rarr; + New statement</b>, choose the agent and period, <b>Calculate &amp; create draft</b>, review the lines, then <b>Approve &amp; post to agent ledger</b>. A posted statement can be reversed with <b>Cancel statement</b> as long as nothing has been paid or netted against it yet.</p>
  <p class="tip">${icon('info', 15)} All amounts convert to your base currency for totals and reports using the exchange rate on the document date - settle each currency in its own currency, since the system does not post exchange gains or losses.</p>

  <h3>Sales performance report</h3>
  <p><b>Reports &rarr; Sales performance</b> groups shipments by agent, customer, trade lane or month and shows shipment count, TEU, CBM and revenue. It is open to the Sales role even without general finance access - it never shows cost or profit unless the viewer also has finance access.</p>
  <p class="tip">${icon('info', 15)} A party with an open, unapproved KYC case cannot be billed - raising an invoice, debit note or bill for it is blocked with a message telling you to complete and approve the case first (see the Trade guide).</p>`,

  operations: () => `<h2>${icon('package', 20)} Operations</h2><p class="lead">Shipments / bookings and master BL consolidations - the day-to-day life of a job from booking to delivery.</p>

  <h3>The life of a shipment</h3>
  <p>Booked &rarr; Confirmed &rarr; Sailed &rarr; Arrived &rarr; Delivered &rarr; Closed (and Cancelled, from Booked or Confirmed). Each step is one button on the shipment page, and the blue progress bar shows where the job stands.</p>

  <h3>Step by step</h3>
  <ol>
    <li><b>Create the booking.</b> Shipments / bookings &rarr; <b>+ New booking</b>. Fill in customer, shipper, consignee, notify party, agent, carrier, ports, vessel / voyage, ETD / ETA, freight terms, incoterm and the cargo details, choose FCL or LCL, then <b>Create booking</b>.</li>
    <li><b>Add containers</b> (FCL only) - <b>+ Add container</b> offers boxes that are currently empty and available.</li>
    <li><b>Confirm &amp; issue HBL</b> once the booking is firm - this creates the house B/L number.</li>
    <li><b>Mark sailed</b>, then <b>Mark arrived</b> (enter the free days at destination - this starts the detention clock), then <b>Mark delivered</b> and finally <b>Close job</b>.</li>
  </ol>
  <p>A Booked or Confirmed job can be <b>cancelled</b> (its containers return to the empty pool); use <b>Edit</b> while the shipment is still open. The shipment's <b>Finance card</b> shows its invoices, bills and profit; <b>Agent commission</b> shows whether it is already on a statement. A <b>Record</b> card shows who created the booking and who last edited it, each with the date.</p>
  <p class="tip">${icon('info', 15)} A customer with an open, unapproved KYC case cannot be booked - the error names the case status; complete and approve it under Trade &rarr; KYC &amp; compliance first.</p>

  <h3>Master BL / consolidation (LCL)</h3>
  <ol>
    <li>Master BL / consolidation &rarr; <b>+ New consolidation</b> - master B/L number, carrier, vessel, voyage, ports and dates.</li>
    <li><b>+ Add shipment</b> to attach the confirmed LCL house shipments travelling together.</li>
    <li><b>Close for cargo</b>, then <b>Mark sailed</b> and later <b>Mark arrived</b> - every house shipment and its container events move together.</li>
    <li><b>Complete</b> the consolidation when finished (<b>Re-open</b> and <b>Cancel</b> are available while appropriate).</li>
  </ol>
  <p class="tip">${icon('info', 15)} Finding a job fast: the shipment register filters by status, cargo type, agent, date range and free text (booking, HBL, customer, container), and <b>Export Excel</b> downloads whatever you have filtered.</p>`,

  documentation: () => `<h2>${icon('contract', 20)} Documentation</h2><p class="lead">The Bills of lading tab - every HBL in one place, reviewed, printed and shared.</p>

  <h3>Finding a bill of lading</h3>
  <p><b>Bills of lading</b> lists every BL with search (BL, booking, shipper, consignee, container), status, agent and sailing-date filters, plus two quick filters: <b>Details missing</b> (still lacks a consignee, vessel, description or similar) and <b>Agent-edited</b> (changed by an agent and not yet reviewed by your team).</p>

  <h3>View, edit and download</h3>
  <ul>
    <li><b>View</b> - click a row for the full bill: shipper, consignee, notify party, routing, vessel, cargo, containers with seals, and the activity trail.</li>
    <li><b>Edit</b> - <b>Edit details</b> while the shipment is open; fill vessel, voyage, ports and dates in one step by choosing a sailing from the vessel schedule.</li>
    <li><b>Download</b> - <b>PDF</b> for one BL, or tick several rows and <b>PDF of selected</b> for a combined file; <b>Excel</b> exports the BL, and the list itself can be shared as Excel or PDF.</li>
  </ul>

  <h3>Reviewing an agent's changes</h3>
  <p>When an external agent edits a BL (shipper, consignee, cargo details) it is flagged for your team. Open it and press <b>Mark reviewed</b> once you have checked the change - this clears it from everyone's "needs attention" list.</p>
  <p>A <b>Record</b> card on the BL page shows who created the underlying booking and who last edited it, separate from the full activity trail.</p>
  <p class="tip">${icon('info', 15)} Agents see only their own bookings here and can fill in missing BL details themselves (see the Trade guide for how an agent login is set up), which is usually faster than chasing them by e-mail.</p>`,

  equipment: () => `<h2>${icon('container', 20)} Equipment</h2><p class="lead">Container inventory, tracking, movement updates and the daily inventory report.</p>

  <h3>What is stored</h3>
  <p>Every container has a number (checked against the ISO 6346 check digit), type, ownership (Own, Leased, COC carrier-owned or SOC shipper-owned), owner and condition, plus a full <b>movement log</b>. The current status and location are always derived from the latest movement, so the inventory can also be shown as it stood on any past date.</p>

  <table class="statuses"><tr><th>Status</th><th>Meaning</th></tr>
    <tr><td>Empty - available</td><td>In stock, can be booked</td></tr>
    <tr><td>Empty - allocated to booking</td><td>Attached to a booking</td></tr>
    <tr><td>Laden - gated in / on board / discharged</td><td>Moving with the shipment</td></tr>
    <tr><td>Laden - discharged at POD</td><td>Landed at destination - free-time clock running</td></tr>
    <tr><td>Empty - returned to depot/line</td><td>Back in the pool - clock stops and resets</td></tr>
    <tr><td>Damaged / off-hired</td><td>Out of service or left the fleet</td></tr></table>

  <h3>Container enquiry - "where is this box?"</h3>
  <p>Type or paste container numbers, a booking / HBL / master BL number, a vessel name, or a place (e.g. <i>Jebel Ali</i>) into the search box. Click a result to see its journey - a step bar from Empty released through to Empty returned - and its full movement history, with a <b>Log movement</b> button.</p>

  <h3>Keeping the inventory current</h3>
  <ul>
    <li><b>Update movements</b> (quick) - paste container numbers, choose what happened, the date and location, <b>Check</b>, then <b>Save movements</b>. This is what an agent login uses to report movements at their own depot or port.</li>
    <li><b>Update from Excel</b> - drop a depot or leasing company's stock list or movement report; the system reads the columns by name, shows what will change row by row, and nothing is saved until you press <b>Save</b>.</li>
    <li><b>Bulk add</b> - paste a list of new container numbers with a starting type, ownership and status.</li>
  </ul>

  <h3>Free time and the daily report</h3>
  <p>When a shipment is marked arrived you enter the free days; after they run out the container is <b>past free time</b> and flagged on the dashboard, the container list and the daily report, along with boxes expiring within two days. <b>Daily inventory report</b> gives, for any date, a summary by type / location / status, that day's movements, detention alerts and idle empties - step through dates and <b>Export Excel</b> to download.</p>
  <p class="tip">${icon('info', 15)} Logging <i>Empty - returned</i>, <i>Empty - available</i> or <i>Off-hired</i> is what stops the detention clock.</p>

  <h3>Leased containers</h3>
  <p><b>Leased containers</b> keeps the contract behind a leased-in box, separately from the inventory itself: the lessor, lease type (one-way or round-trip), the rate per day during the <b>committed period</b>, the rate per day <b>after</b> that period, pickup and drop-off locations. <b>Attach container</b> / <b>Detach</b> link containers to the lease; the lease page shows its current phase and the cost run up so far, split automatically between the two rates. <b>Close lease</b> once the box is returned.</p>

  <h3>Storage &amp; detention - automatic billing</h3>
  <p><b>Storage &amp; detention</b> finds every container past its free time and computes the charge from your tariff book (a sell, per-day rate on Storage, Detention or Demurrage) - showing the unbilled days, the rate and the amount. <b>Raise invoice</b> on one row, or select several and <b>Raise invoices for selected</b>, creates a draft debit note for each. Already-billed days are tracked automatically, so running it again only offers the days since the last invoice.</p>

  <h3>Containers history</h3>
  <p><b>Containers history</b> lists every recorded movement, for every container, fleet-wide - filter by date, container number, movement type, location or who recorded it, and <b>Export Excel</b>.</p>`,

  trade: () => `<h2>${icon('users', 20)} Trade</h2><p class="lead">Agents, agency agreements, customers / vendors and the rate book (tariffs).</p>

  <h3>Agents and agreements</h3>
  <p><b>Agents</b> lists your overseas agents; each agent's page shows its agreements, commission statements and account balance. An <b>agency agreement</b> records the commercial relationship - start / end dates, notice period, territory, exclusivity, payment terms, credit limit, and editable clauses.</p>
  <ol>
    <li><b>+ New agreement</b>, choose the agent and dates, then <b>Edit terms</b>.</li>
    <li><b>Insert standard clauses</b> loads a starter template filled in with the agreement's own details - review it with your legal adviser before use, then <b>Save clauses</b>.</li>
    <li><b>Activate</b> once signed. An active agreement shows as <b>Expired</b> automatically once its end date passes.</li>
    <li>Before it expires, <b>Renew</b> to create a renewal draft, or <b>Terminate</b> to end it early - the dashboard warns about agreements expiring within 60 days.</li>
  </ol>

  <h3>Commission rules</h3>
  <p>On an agreement, <b>+ Add rule</b> sets how the agent earns commission: per TEU, per container, per CBM (LCL), a flat amount per HBL, or a percentage of ocean freight income or of shipment profit. A rule can be limited to a port pair, cargo type and validity period, with a minimum and maximum; when several rules match, the most specific one wins (port pair, then cargo type, then the general rule).</p>

  <h3>Customers, vendors &amp; the rate book</h3>
  <p><b>Customers &amp; parties</b> holds every customer, agent, vendor and carrier in one directory, with contact details, credit terms and currency. <b>Rates / tariffs</b> holds your sell rates (to customers / agents) and buy rates (from carriers / vendors) by port pair, container type and charge code - used to fill invoice lines and to seed MRG freight rates.</p>

  <h3>KYC &amp; compliance</h3>
  <p>Before you need to control a customer's or vendor's compliance, open <b>KYC &amp; compliance &rarr; + New KYC case</b> and choose the party. Your staff - not the party themselves - <b>upload a file</b> (trade licence, ID, the filled compliance form) or <b>add a link</b> to one, then <b>Submit for approval</b>. An <b>administrator</b> (only) then <b>Approves</b> or <b>Rejects</b> it, with a reason if rejected; a rejected case can be <b>Reopened</b> as a fresh attempt.</p>
  <p class="tip">${icon('info', 15)} A party with an open, unapproved case (Pending, Submitted or Rejected) cannot be booked on a new shipment or billed on a new document, until the case is Approved. A party never put through KYC is not affected - this will not disrupt your existing customers and vendors.</p>

  <h3>Setting up an external agent login</h3>
  <p>An agent can sign in to update their own container movements and complete their own BLs. <b>Setup &rarr; Users &amp; roles &rarr; New user</b>, role <b>Agent (external)</b>, then set the <b>agent company</b> and the <b>locations</b> they may update (one per line, e.g. <i>Mombasa, Nairobi CFS</i>) - the agent then sees containers at those locations plus containers on their own shipments.</p>
  <p class="tip">${icon('info', 15)} Commission owed to an agent is settled by a payment, or netted against a debit note raised on the same agent - see the Finance guide.</p>`,

  vessel: () => `<h2>${icon('ship', 20)} Vessel</h2><p class="lead">Vessel schedules - the sailings you can book on, kept current automatically.</p>

  <h3>Loading a schedule</h3>
  <p>Press <b>Load schedule</b> under Vessel schedules; the same three-step wizard (Choose &rarr; Check &rarr; Done) used across the system.</p>
  <ul>
    <li><b>Excel / CSV file</b> - upload the carrier's sailing list; columns (carrier, service, vessel, voyage, POL, POD, cut-off, ETD, ETA) are recognised automatically and ports / carriers matched to your master lists.</li>
    <li><b>From a web link</b> - paste the carrier's schedule page or a direct file link. Tick <b>Remember this link</b> to save it under Saved web links, where <b>Refresh now</b> re-reads it on demand and a switch turns on daily automatic refresh.</li>
  </ul>
  <p>Loading the same schedule again never creates duplicates - new sailings are added, unchanged ones are left alone, and changed dates are highlighted.</p>

  <h3>When a sailing's dates change</h3>
  <p>The schedule page shows a <b>Date changes</b> alert naming every booking and master BL on that vessel. <b>Update bookings</b> applies the new ETD / ETA to all of them at once; <b>Ignore</b> keeps the old dates. An administrator can switch on automatic updates under <b>Setup &rarr; Company &amp; settings &rarr; Automation</b> so this happens without anyone clicking through.</p>

  <h3>Using a schedule when booking</h3>
  <p>On a shipment or master BL, filling vessel, voyage, ETD, ETA, cut-off and ports from a saved sailing takes one click instead of retyping them - open the booking form and choose the sailing from the list.</p>
  <p class="tip">${icon('info', 15)} You can also <b>Add sailing</b> by hand, edit or delete a line, and share the whole schedule as Excel or PDF.</p>

  <h3>Vessels master &amp; slot management</h3>
  <p><b>Vessels</b> keeps your own master list of vessel name, <b>flag</b>, IMO number, call sign, carrier and TEU capacity. <b>Slot management</b> tracks the TEU you committed to on a vessel / voyage against what you actually used: it works out <b>used TEU</b> from your bookings on that sailing automatically, and shows <b>dead freight</b> (unused TEU &times; slot cost) and the <b>expected cost</b> of the slots you committed to.</p>
  <p><b>+ Add invoice</b> on a slot records what the carrier actually invoiced for it (optionally posting a vendor bill in one step), and the page <b>reconciles</b> the total invoiced against the expected cost - reconciled, or flagged as the carrier over- or under-billing you.</p>`,
};

export async function page(root, params) {
  const sel = MODULES.some((m) => m[0] === params.module) ? params.module : null;
  root.innerHTML = `${pageHead('User guide', 'Step-by-step help for each part of HUB LINE ERP.')}
    <div class="guide">
      <nav class="guide-nav">${MODULES.map(([key, ic, label]) => `<a href="#/guide/${key}" class="${sel === key ? 'on' : ''}">${icon(ic, 17)}<span>${esc(label)}</span></a>`).join('')}</nav>
      <div class="guide-body card"><div class="card-b">${sel ? CONTENT[sel]() : overview()}</div></div>
    </div>`;
}

function overview() {
  return `<h2>${icon('book', 20)} Getting started</h2><p class="lead">Pick a module on the left for step-by-step instructions. A short tour:</p>
    <ul>${MODULES.map(([key, ic, label]) => `<li><a href="#/guide/${key}">${icon(ic, 15)} <b>${esc(label)}</b></a> - ${TAGLINE[key]}</li>`).join('')}</ul>
    <p class="tip">${icon('info', 15)} Every module also has its own "<b>Dashboard</b>" page in the left nav with live numbers and a <b>User guide</b> shortcut back to its own page here.</p>`;
}
const TAGLINE = {
  finance: 'invoices, receipts, payments, commission, ageing, MRG freight / slot cost and sales performance.',
  operations: 'shipments / bookings from Booked through to Closed, and master BL consolidations.',
  documentation: 'the bills of lading tab - view, edit, print and review.',
  equipment: 'container inventory, tracking, movements, leased containers, storage / detention auto-billing and the daily report.',
  trade: 'agents, agency agreements, commission rules, customers, KYC &amp; compliance and the rate book.',
  vessel: 'vessel master data, schedules, slot management and dead freight / carrier-invoice reconciliation.',
};
