import { api, esc, $, on, qs, tbl, pageHead, money, num, date, badge, link, confirmBox, toast, can, todayStr, debounce } from '../core.js';

export async function list(root, _p, query) {
  const canW = can('finance', 'write');
  const f = { as_of: query.as_of || todayStr() };
  root.innerHTML = `${pageHead('Storage &amp; detention', 'Containers past their free time, auto-calculated from the storage / detention tariff - already-billed days are tracked so each run only bills the new days', canW ? '<button class="btn primary" data-act="bulk">Raise invoices for selected</button>' : '')}
    <div class="toolbar"><label class="muted small">As at <input type="date" data-f="as_of" value="${esc(f.as_of)}"></label><span class="muted small" data-count></span></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  let rows = [];
  const load = async () => {
    rows = await api('GET', '/detention/pending' + qs(f));
    $('[data-count]', root).textContent = `${rows.length} container(s) overdue`;
    out.innerHTML = tbl({ rows, empty: 'No containers are currently overdue on free time.', cols: [
      ...(canW ? [{ label: 'Sel.', render: (r) => r.issue ? '' : `<input type="checkbox" data-sel="${r.container_id}">` }] : []),
      { label: 'Container', render: (r) => `<b>${esc(r.container_no)}</b><div class="muted small">${esc(r.type_code)}</div>` },
      { label: 'Booking / HBL', render: (r) => r.shipment_id ? `${link('#/shipments/' + r.shipment_id, r.booking_no || '')}<div class="muted small">${esc(r.hbl_no || '')}</div>` : '' },
      { label: 'Location', render: (r) => esc(r.location || '') }, { label: 'Free until', render: (r) => date(r.free_until) },
      { label: 'Period billed', render: (r) => `${date(r.from)} &rarr; ${date(r.to)}` }, { label: 'Days', num: true, key: 'days' },
      { label: 'Rate / day', num: true, render: (r) => r.rate != null ? `${money(r.rate)} ${esc(r.currency)}` : '' },
      { label: 'Amount', num: true, render: (r) => r.amount != null ? `<b>${money(r.amount)} ${esc(r.currency)}</b>` : '' },
      { label: '', render: (r) => r.issue ? badge(r.issue, 'bad') : (canW ? `<button class="btn sm primary" data-charge="${r.container_id}">Raise invoice</button>` : '') }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('change', (e) => { if (e.target.dataset.f) { f[e.target.dataset.f] = e.target.value; reload(); } });
  on(root, 'click', '[data-charge]', async (_e, el) => {
    if (!(await confirmBox('Raise a debit note for this container\'s overdue storage / detention?', { ok: 'Raise invoice' }))) return;
    try { await api('POST', '/detention/charge', { container_id: el.dataset.charge, as_of: f.as_of }); toast('Invoice raised', 'ok'); load(); } catch (e) { toast(e.message, 'bad'); }
  });
  on(root, 'click', '[data-act=bulk]', async () => {
    const ids = [...root.querySelectorAll('[data-sel]:checked')].map((c) => c.dataset.sel);
    if (!ids.length) { toast('Select at least one container first.', 'bad'); return; }
    if (!(await confirmBox(`Raise debit notes for ${ids.length} container(s)?`, { ok: 'Raise invoices' }))) return;
    try {
      const r = await api('POST', '/detention/charge-bulk', { container_ids: ids, as_of: f.as_of });
      toast(`${r.created.length} invoice(s) raised${r.skipped.length ? `, ${r.skipped.length} skipped` : ''}`, r.created.length ? 'ok' : 'bad'); load();
    } catch (e) { toast(e.message, 'bad'); }
  });
  await load();
}
