import { api, state, esc, $, on, qs, tbl, pageHead, money, num, date, shipBadge, badge, toast, opts, can, link, signed, todayStr, addDaysStr, download, debounce } from '../core.js';

export async function reports(root) {
  const fin = can('finance', 'read');
  const y = todayStr().slice(0, 4);
  const f = { from: `${y}-01-01`, to: todayStr(), agent_id: '', customer_id: '', status: '', group: 'agent' };
  root.innerHTML = `${pageHead('Shipment register & profit', 'Every shipment in the period, with income, expense and profit from posted documents', '<button class="btn primary" data-x>Export register to Excel</button>')}
    <div class="toolbar"><label class="muted small">Sailing from <input type="date" data-f="from" value="${f.from}"></label><label class="muted small">to <input type="date" data-f="to" value="${f.to}"></label>
      <select data-f="agent_id"><option value="">All agents</option>${opts.parties('agent').map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="customer_id"><option value="">All customers</option>${opts.parties('customer').map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="status"><option value="">Any status</option>${['BOOKED', 'CONFIRMED', 'SAILED', 'ARRIVED', 'DELIVERED', 'CLOSED', 'CANCELLED'].map((s) => `<option>${s}</option>`).join('')}</select></div>
    ${fin ? '<div class="card"><div class="card-h"><h2>Profit</h2><select data-f="group" style="width:auto"><option value="agent">by agent</option><option value="customer">by customer</option><option value="lane">by trade lane</option><option value="month">by month</option><option value="shipment">by shipment</option></select></div><div data-profit></div></div>' : ''}
    <div class="card"><div class="card-h"><h2>Shipments</h2><span class="muted small" data-count></span></div><div data-out></div></div>`;
  const load = async () => {
    const rows = await api('GET', '/reports/shipments' + qs(f));
    $('[data-count]', root).textContent = `${rows.length} shipments, ${num(rows.reduce((a, r) => a + r.teu, 0))} TEU`;
    $('[data-out]', root).innerHTML = tbl({ rows, click: true, empty: 'No shipments in this period.', rowAttr: (r) => `data-go="#/shipments/${r.id}"`, cols: [
      { label: 'Booking / HBL', render: (r) => `<b>${esc(r.booking_no)}</b><div class="muted small">${esc(r.hbl_no || '')}</div>` }, { label: 'ETD', render: (r) => date(r.etd) },
      { label: 'Customer', render: (r) => esc(r.customer_name || '') }, { label: 'Agent', render: (r) => esc(r.agent_name || '') }, { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` },
      { label: 'Cargo', render: (r) => badge(r.cargo_type) }, { label: 'TEU', num: true, render: (r) => num(r.teu) }, { label: 'CBM', num: true, render: (r) => num(r.cbm) },
      ...(fin ? [{ label: 'Income', num: true, render: (r) => money(r.income) }, { label: 'Expense', num: true, render: (r) => money(r.expense) }, { label: 'Profit', num: true, render: (r) => signed(r.profit) }] : []), { label: 'Status', render: (r) => shipBadge(r.status) }],
      foot: fin ? `<tr><td colspan="6">Total</td><td class="num">${num(rows.reduce((a, r) => a + r.teu, 0))}</td><td class="num"></td><td class="num">${money(rows.reduce((a, r) => a + r.income, 0))}</td><td class="num">${money(rows.reduce((a, r) => a + r.expense, 0))}</td><td class="num">${signed(rows.reduce((a, r) => a + r.profit, 0))}</td><td></td></tr>` : undefined });
    if (fin) {
      const p = await api('GET', '/reports/profit' + qs(f));
      $('[data-profit]', root).innerHTML = tbl({ rows: p.rows, empty: 'No data.', cols: [{ label: p.group[0].toUpperCase() + p.group.slice(1), render: (r) => `<b>${esc(r.name)}</b>` }, { label: 'Shipments', num: true, key: 'shipments' }, { label: 'TEU', num: true, render: (r) => num(r.teu) },
        { label: `Income (${esc(p.base_currency)})`, num: true, render: (r) => money(r.income) }, { label: 'Expense', num: true, render: (r) => money(r.expense) }, { label: 'Profit', num: true, render: (r) => `<b>${signed(r.profit)}</b>` }, { label: 'Margin', num: true, render: (r) => r.margin == null ? '' : num(r.margin) + '%' }] });
    }
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')), 200);
  root.addEventListener('change', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  on(root, 'click', '[data-x]', () => download('/reports/shipments' + qs({ ...f, format: 'xlsx' })));
  await load();
}

// ================================================================ sales performance
export async function salesPerformance(root, _p, query) {
  const y = todayStr().slice(0, 4);
  const f = { from: query.from || `${y}-01-01`, to: query.to || todayStr(), agent_id: '', customer_id: '', group: query.group || 'agent' };
  root.innerHTML = `${pageHead('Sales performance', 'Shipment volumes and revenue by agent, customer, trade lane or month - open to the sales role regardless of finance access')}
    <div class="toolbar"><label class="muted small">Sailing from <input type="date" data-f="from" value="${f.from}"></label><label class="muted small">to <input type="date" data-f="to" value="${f.to}"></label>
      <select data-f="agent_id"><option value="">All agents</option>${opts.parties('agent').map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="customer_id"><option value="">All customers</option>${opts.parties('customer').map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select>
      <select data-f="group"><option value="agent">by agent</option><option value="customer">by customer</option><option value="lane">by trade lane</option><option value="month">by month</option></select></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const r = await api('GET', '/reports/sales-performance' + qs(f));
    out.innerHTML = tbl({ rows: r.rows, empty: 'No data for this period.', cols: [
      { label: r.group[0].toUpperCase() + r.group.slice(1), render: (x) => `<b>${esc(x.name)}</b>` }, { label: 'Shipments', num: true, key: 'shipments' },
      { label: 'TEU', num: true, render: (x) => num(x.teu) }, { label: 'CBM', num: true, render: (x) => num(x.cbm) },
      { label: `Revenue (${esc(r.base_currency)})`, num: true, render: (x) => money(x.income) },
      ...(r.show_cost ? [{ label: 'Expense', num: true, render: (x) => money(x.expense) }, { label: 'Profit', num: true, render: (x) => signed(x.profit) }] : [])],
      foot: `<tr><td>Total</td><td class="num">${num(r.rows.reduce((a, x) => a + x.shipments, 0))}</td><td class="num">${num(r.rows.reduce((a, x) => a + x.teu, 0))}</td><td class="num">${num(r.rows.reduce((a, x) => a + x.cbm, 0))}</td><td class="num">${money(r.rows.reduce((a, x) => a + x.income, 0))}</td>${r.show_cost ? `<td class="num">${money(r.rows.reduce((a, x) => a + x.expense, 0))}</td><td class="num">${signed(r.rows.reduce((a, x) => a + x.profit, 0))}</td>` : ''}</tr>` });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')), 200);
  root.addEventListener('change', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  await load();
}

// ================================================================ containers history
const MOVE_TYPES = ['EMPTY_AVAILABLE', 'ALLOCATED', 'RELEASED_SHIPPER', 'GATED_IN_FULL', 'ON_BOARD', 'DISCHARGED', 'DELIVERED_FULL', 'EMPTY_RETURNED', 'DAMAGED', 'OFF_HIRED'];
export async function containerHistory(root, _p, query) {
  const y = todayStr().slice(0, 4);
  const f = { from: query.from || `${y}-01-01`, to: query.to || todayStr(), container_no: query.container_no || '', event_type: query.event_type || '', location: query.location || '' };
  root.innerHTML = `${pageHead('Containers history', 'Every recorded movement for every container, fleet-wide - gate in/out, load/discharge, stuffing/devanning, damage and repair', '<button class="btn primary" data-x>Export to Excel</button>')}
    <div class="toolbar"><label class="muted small">From <input type="date" data-f="from" value="${f.from}"></label><label class="muted small">to <input type="date" data-f="to" value="${f.to}"></label>
      <input type="text" class="search" placeholder="Container no…" data-f="container_no" value="${esc(f.container_no)}"> <input type="text" class="search" placeholder="Location…" data-f="location" value="${esc(f.location)}">
      <select data-f="event_type"><option value="">Any movement</option>${MOVE_TYPES.map((t) => `<option value="${t}" ${f.event_type === t ? 'selected' : ''}>${esc((state.lk.container_status[t] || {}).label || t)}</option>`).join('')}</select></div>
    <div class="card"><div class="card-h"><h2>Movements</h2><span class="muted small" data-count></span></div><div data-out></div></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/reports/container-history' + qs(f));
    $('[data-count]', root).textContent = `${rows.length} movement(s)${rows.length === 3000 ? ' (showing most recent 3000)' : ''}`;
    out.innerHTML = tbl({ rows, empty: 'No movements match this filter.', cols: [
      { label: 'Date', render: (r) => date(r.event_date) }, { label: 'Container', render: (r) => `<b>${esc(r.container_no)}</b> <span class="muted small">${esc(r.type_code)}</span>` },
      { label: 'Movement', render: (r) => badge(r.label) }, { label: 'Location', render: (r) => esc(r.location || '') },
      { label: 'Booking / HBL', render: (r) => esc(r.booking_no || r.consol_no || '') }, { label: 'Free days', num: true, render: (r) => r.free_days != null ? num(r.free_days) : '' },
      { label: 'Remarks', render: (r) => esc(r.remarks || '') }, { label: 'Recorded by', render: (r) => esc(r.user_name || r.username || '') }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')), 200);
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  root.addEventListener('change', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  on(root, 'click', '[data-x]', () => download('/reports/container-history' + qs({ ...f, format: 'xlsx' })));
  await load();
}
