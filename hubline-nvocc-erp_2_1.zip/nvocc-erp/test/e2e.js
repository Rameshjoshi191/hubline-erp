'use strict';
// End-to-end test: seeds a throw-away database with the demo data, then checks business rules through the HTTP API.
const path = require('path');
const os = require('os');
const fs = require('fs');
const { execFileSync } = require('child_process');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'erp-e2e-'));
process.env.DATA_DIR = tmp;
execFileSync('node', [path.join(__dirname, '..', 'src', 'seed-demo.js')], { env: process.env, stdio: 'pipe' });

const app = require('../src/server');
const { db, today, addDays } = require('../src/db');
const T = today();
const d = (n) => addDays(T, n);

let pass = 0, fail = 0;
const failures = [];
function ok(cond, name) { if (cond) pass++; else { fail++; failures.push(name); console.log('  FAIL: ' + name); } }
const eq = (a, b, name) => ok(Math.abs(a - b) < 0.006, `${name} (expected ${b}, got ${a})`);

(async () => {
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api`;

  function client() {
    let cookie = '';
    const c = async (method, url, body, raw) => {
      const res = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'hubline-erp', cookie }, body: body ? JSON.stringify(body) : undefined });
      if (url === '/login' && res.ok) cookie = res.headers.get('set-cookie').split(';')[0];
      if (raw) return res;
      const t = await res.text(); let j; try { j = JSON.parse(t); } catch { j = t; }
      return { status: res.status, ok: res.ok, body: j };
    };
    return c;
  }
  const login = async (u, p) => { const c = client(); const r = await c('POST', '/login', { username: u, password: p }); if (!r.ok) throw new Error('login ' + u); return c; };
  const admin = await login('admin', 'admin123');
  const ops = await login('ops', 'demo1234');
  const docs = await login('docs', 'demo1234');
  const accounts = await login('accounts', 'demo1234');
  const sales = await login('sales', 'demo1234');
  const manager = await login('manager', 'demo1234');

  console.log('Security');
  { const c = client(); const r = await c('POST', '/login', { username: 'admin', password: 'wrong' }); ok(r.status === 401, 'wrong password rejected'); }
  { const res = await fetch(base + '/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'admin123' }) }); ok(res.status === 403, 'request without CSRF header blocked'); }
  { const res = await fetch(base + '/shipments'); ok(res.status === 401, 'unauthenticated API call blocked'); }
  ok((await ops('GET', '/documents')).status === 403, 'operations cannot read finance documents');
  ok((await docs('POST', '/documents', {})).status === 403, 'documentation cannot create finance documents');
  ok((await accounts('POST', '/containers', { container_no: 'X' })).status === 403, 'accounts cannot add containers');
  ok((await manager('POST', '/parties', { name: 'x', is_customer: 1 })).status === 403, 'management is read-only');
  ok((await manager('GET', '/shipments')).ok, 'management can read shipments');
  ok((await ops('GET', '/users')).status === 403, 'operations cannot list users');
  ok((await sales('GET', '/soa?party_id=1')).ok, 'sales can read SOA');
  ok((await ops('GET', '/soa?party_id=1')).status === 403, 'operations cannot read SOA');

  { const res = await fetch(base.replace('/api', '') + '/healthz'); ok(res.ok && (await res.json()).ok === true, 'health check answers without login'); }
  ok((await ops('GET', '/backup')).status === 403, 'only an administrator can download a backup');
  { const res = await admin('GET', '/backup', undefined, true); const buf = Buffer.from(await res.arrayBuffer());
    ok(res.ok && buf.slice(0, 15).toString() === 'SQLite format 3' && /attachment/.test(res.headers.get('content-disposition') || ''), 'administrator can download a valid database backup'); }

  const lk = (await admin('GET', '/lookups')).body;
  const customers = lk.parties.filter((p) => p.is_customer);
  const cType = (c) => lk.container_types.find((t) => t.code === c).id;
  const chg = (c) => lk.charge_codes.find((t) => t.code === c).id;
  const line = (code, desc, qty, rate, vat = 0) => ({ charge_code_id: chg(code), description: desc, qty, rate, vat_rate: vat });

  console.log('Finance: documents, allocations, SOA');
  const cu = (await admin('POST', '/parties', { name: 'Test Customer LLC', is_customer: 1, currency: 'USD', credit_days: 30 })).body;
  const inv = (await accounts('POST', '/documents', { doc_type: 'INV', party_id: cu.id, currency: 'USD', doc_date: d(-60), lines: [line('OF', 'Freight', 1, 1000)] })).body;
  ok(inv.id && inv.doc_no === null, 'draft invoice has no number yet');
  ok((await accounts('PUT', `/documents/${inv.id}`, { party_id: cu.id, currency: 'USD', doc_date: d(-60), lines: [line('OF', 'Freight', 1, 1000), line('DOC', 'Docs', 1, 100, 5)] })).ok, 'draft can be edited');
  const posted = await accounts('POST', `/documents/${inv.id}/post`);
  ok(posted.ok && /^INV-\d{4}-\d{5}$/.test(posted.body.doc_no), 'posting assigns a sequential number: ' + posted.body.doc_no);
  ok(!(await accounts('PUT', `/documents/${inv.id}`, { party_id: cu.id, currency: 'USD', lines: [line('OF', 'x', 1, 1)] })).ok, 'posted document cannot be edited');
  let doc = (await accounts('GET', `/documents/${inv.id}`)).body;
  eq(doc.total, 1105, 'invoice total incl 5% VAT on the 100 line');
  const cn = (await accounts('POST', '/documents', { doc_type: 'CN', party_id: cu.id, currency: 'USD', doc_date: d(-30), post: true, lines: [line('OF', 'Rate correction', 1, 200)] })).body;
  const rc = await accounts('POST', '/payments', { direction: 'RECEIPT', party_id: cu.id, currency: 'USD', amount: 300, pay_date: d(-10), method: 'Cheque', reference: 'CH-1' });
  ok(rc.ok, 'receipt on account recorded');
  eq((await accounts('GET', `/documents/${inv.id}`)).body.outstanding, 1105, 'unallocated receipt does not reduce the invoice');
  ok(!(await accounts('POST', '/payments', { direction: 'RECEIPT', party_id: cu.id, currency: 'USD', amount: 100, allocations: [{ doc_id: inv.id, amount: 500 }] })).ok, 'cannot allocate more than the receipt');
  ok(!(await accounts('POST', '/payments', { direction: 'RECEIPT', party_id: cu.id, currency: 'EUR', amount: 100, allocations: [{ doc_id: inv.id, amount: 100 }] })).ok, 'cannot settle a USD invoice with EUR');
  ok(!(await accounts('POST', '/payments', { direction: 'PAYMENT', party_id: cu.id, currency: 'USD', amount: 100, allocations: [{ doc_id: inv.id, amount: 100 }] })).ok, 'a payment cannot settle an invoice');
  const a1 = await accounts('POST', `/payments/${rc.body.id}/allocate`, { allocations: [{ doc_id: inv.id, amount: 300 }] });
  ok(a1.ok, 'apply receipt to invoice');
  ok(!(await accounts('POST', `/payments/${rc.body.id}/allocate`, { allocations: [{ doc_id: inv.id, amount: 1 }] })).ok, 'receipt fully used cannot be over-applied');
  ok((await accounts('POST', '/allocations/net', { from_doc_id: cn.id, to_doc_id: inv.id, amount: 200 })).ok, 'credit note netted against invoice');
  ok(!(await accounts('POST', `/documents/${inv.id}/cancel`, {})).ok, 'invoice with allocations cannot be cancelled');
  eq((await accounts('GET', `/documents/${inv.id}`)).body.outstanding, 605, 'outstanding = 1105 - 300 - 200');
  const soa = (await accounts('GET', `/soa?party_id=${cu.id}&from=${d(-90)}&to=${T}`)).body;
  const usd = soa.currencies.find((c) => c.currency === 'USD');
  eq(usd.closing, 605, 'ledger SOA closing balance (1105 - 200 - 300)');
  eq(usd.total_debit, 1105, 'SOA total debit'); eq(usd.total_credit, 500, 'SOA total credit');
  const soaOpen = (await accounts('GET', `/soa?party_id=${cu.id}&to=${T}&mode=open`)).body.currencies.find((c) => c.currency === 'USD');
  eq(soaOpen.closing, 605, 'open-item SOA closing balance');
  eq(soaOpen.ageing.d31_60 + soaOpen.ageing.d1_30 + soaOpen.ageing.d61_90 + soaOpen.ageing.not_due + soaOpen.ageing.d90_plus + soaOpen.ageing.unapplied, 605, 'ageing buckets add up to the balance');
  // opening balance when the SOA starts after the transactions
  const soaLate = (await accounts('GET', `/soa?party_id=${cu.id}&from=${d(-5)}&to=${T}`)).body.currencies.find((c) => c.currency === 'USD');
  eq(soaLate.opening, 605, 'SOA opening balance carries earlier transactions');
  // cancel receipt reopens the invoice
  ok((await accounts('POST', `/payments/${rc.body.id}/cancel`, {})).ok, 'cancel receipt');
  eq((await accounts('GET', `/documents/${inv.id}`)).body.outstanding, 905, 'cancelling the receipt reopens the invoice');
  ok((await accounts('GET', `/soa?party_id=${cu.id}&format=xlsx`, null, true)).headers.get('content-type').includes('spreadsheetml'), 'SOA exports to Excel');

  console.log('Shipments & containers');
  const emptyBox = (await ops('GET', `/containers?status=EMPTY_AVAILABLE&type_id=${cType('40HC')}`)).body.rows[0];
  const shipA = (await ops('POST', '/shipments', { cargo_type: 'FCL', customer_id: cu.id, pol_id: lk.ports[0].id, pod_id: lk.ports[1].id, etd: d(10) })).body;
  ok(!(await ops('POST', `/shipments/${shipA.id}/status`, { status: 'CONFIRMED' })).ok, 'cannot confirm without shipper/consignee');
  ok((await ops('POST', `/shipments/${shipA.id}/containers`, { container_id: emptyBox.id })).ok, 'allocate empty container to booking');
  const shipB = (await ops('POST', '/shipments', { cargo_type: 'FCL', customer_id: cu.id })).body;
  const dup = await ops('POST', `/shipments/${shipB.id}/containers`, { container_id: emptyBox.id });
  ok(!dup.ok && /not empty|already allocated/i.test(dup.body.error), 'container cannot be double-allocated: ' + dup.body.error);
  const laden = (await ops('GET', '/containers?status=ON_BOARD')).body.rows[0];
  ok(laden && !(await ops('POST', `/shipments/${shipB.id}/containers`, { container_id: laden.id })).ok, 'laden container cannot be allocated');
  ok((await ops('DELETE', `/shipments/${shipA.id}/containers/${emptyBox.id}`)).ok, 'remove container from booking');
  eq((await ops('GET', `/containers/${emptyBox.id}`)).body.status === 'EMPTY_AVAILABLE' ? 1 : 0, 1, 'released container is available again');
  ok(!(await ops('POST', '/containers', { container_no: 'MSKU0000000', type_id: cType('20GP') })).ok, 'invalid ISO 6346 number rejected');
  { const b = (await ops('POST', '/containers/bulk', { numbers: 'ABC', type_id: cType('20GP') })).body; ok(b.invalid.length === 1 && b.created.length === 0, 'bulk add reports invalid numbers'); }
  const seeded = (await ops('GET', '/shipments')).body;
  const arrivedFcl = seeded.find((s) => s.status === 'ARRIVED' && s.cargo_type === 'FCL');
  ok(!(await ops('POST', `/shipments/${arrivedFcl.id}/status`, { status: 'CANCELLED' })).ok, 'arrived shipment cannot be cancelled');
  const withInv = seeded.find((s) => s.status === 'SAILED');
  ok(!(await ops('DELETE', `/shipments/${withInv.id}`)).ok, 'confirmed shipment cannot be deleted');
  ok(!(await ops('POST', `/shipments/${withInv.id}/status`, { status: 'DELIVERED' })).ok, 'sailed shipment cannot skip to delivered');

  console.log('Container inventory report');
  const rep = (await ops('GET', `/reports/container-inventory?date=${T}`)).body;
  const list = (await ops('GET', '/containers')).body.rows;
  ok(rep.rows.length === list.length, 'report closing count equals inventory list');
  ok(rep.totals.closing === rep.totals.opening + rep.totals.in - rep.totals.out, 'closing = opening + in - out');
  ok(rep.totals.empty + rep.totals.laden + rep.totals.out_of_service === rep.totals.closing, 'empty + laden + out of service = total');
  ok(rep.detention.some((c) => c.free_days_left < 0), 'detention alert lists containers past free time');
  const past = (await ops('GET', `/reports/container-inventory?date=${d(-75)}`)).body;
  ok(past.rows.length > 0 && past.rows.length <= rep.rows.length, 'as-of report for a past date works');
  const x = await ops('GET', `/reports/container-inventory?date=${T}&format=xlsx`, null, true);
  const buf = Buffer.from(await x.arrayBuffer());
  ok(x.status === 200 && buf.slice(0, 2).toString() === 'PK' && buf.length > 3000, 'inventory report exports a real .xlsx file');

  console.log('Agents, agreements & commission');
  const mum = (await sales('GET', '/agents')).body.find((a) => a.name.startsWith('Mumbai'));
  ok(mum && mum.active_agreement, 'agent list shows active agreement');
  const stmts = (await accounts('GET', '/commissions')).body;
  const mst = stmts.find((s) => s.agent_id === mum.id);
  eq(mst.total, 682, 'Mumbai commission = 50% of profit (373 + 309)');
  ok(mst.status === 'POSTED' && mst.document_id, 'statement posted to the agent ledger');
  const detail = (await accounts('GET', `/commissions/${mst.id}`)).body;
  ok(detail.lines.length === 2, 'statement has one line per shipment');
  const again = (await accounts('POST', '/commissions/preview', { agent_id: mum.id, agreement_id: mst.agreement_id, from: d(-120), to: d(-1) })).body;
  ok(again.lines.length === 0, 'commissioned shipments are not offered again');
  ok(!(await accounts('POST', `/commissions/${mst.id}/post`)).ok, 'cannot post a statement twice');
  const agentSoa = (await accounts('GET', `/soa?party_id=${mum.id}&from=${d(-120)}&to=${T}`)).body.currencies.find((c) => c.currency === 'USD');
  ok(agentSoa.rows.some((r) => r.type === 'COMM' && Math.abs(r.credit - 682) < 0.01), 'commission appears as a credit on the agent SOA');
  ok((await accounts('POST', `/commissions/${mst.id}/cancel`)).ok, 'posted statement can be cancelled when unpaid');
  const reprev = (await accounts('POST', '/commissions/preview', { agent_id: mum.id, agreement_id: mst.agreement_id, from: d(-120), to: d(-1) })).body;
  ok(reprev.lines.length === 2, 'cancelling frees the shipments for commissioning again');
  eq(reprev.total, 682, 'recomputed commission is the same');
  const nbo = (await sales('GET', '/agents')).body.find((a) => a.name.startsWith('Nairobi'));
  const nboSt = stmts.find((s) => s.agent_id === nbo.id);
  // LCL: 14.5+9.2+6.8 = 30.5 CBM * 2 USD = 61
  eq(nboSt.total, 61, 'Nairobi LCL commission = USD 2 per CBM x 30.5 CBM');
  const shaSt = stmts.find((s) => s.agent_id === (lk.parties.find((p) => p.name.startsWith('Shanghai')).id));
  eq(shaSt.total, 15, 'Shanghai FCL commission = USD 15 per TEU x 1 TEU');
  const ag = (await sales('GET', `/agreements`)).body;
  ok(ag.some((a) => a.effective_status === 'ACTIVE') && ag.length === 3, 'agreements list');
  const dash = (await manager('GET', '/dashboard')).body;
  ok(dash.agreements.expiring.length === 1, 'dashboard flags the agreement expiring within 60 days');
  ok(!(await sales('POST', `/agreements/${ag[0].id}/standard-clauses`, {})).ok, 'standard clauses are not added twice');
  const renew = await sales('POST', `/agreements/${ag.find((a) => a.agent_name.startsWith('Nairobi')).id}/renew`, { years: 1 });
  ok(renew.ok, 'agreement renewal creates a draft');
  const rn = (await sales('GET', `/agreements/${renew.body.id}`)).body;
  ok(rn.status === 'DRAFT' && rn.rules.length === 2 && rn.clauses.length > 5, 'renewal copies rules and clauses');

  console.log('Tariff lookup & invoice suggestion');
  const s1 = seeded.find((s) => s.consignee_text !== undefined && s.cargo_type === 'FCL' && s.pod_name === 'Nhava Sheva (JNPT)' && s.container_count === 2);
  const sug = (await accounts('GET', `/documents/suggest?shipment_id=${s1.id}&currency=USD`)).body;
  const of = sug.find((l) => l.description.startsWith('Ocean freight'));
  ok(of && of.qty === 2 && of.rate === 550, 'suggested ocean freight = 2 x USD 550 from the tariff');

  console.log('Users & audit');
  const nu = await admin('POST', '/users', { username: 'temp.user', full_name: 'Temp', role: 'operations', password: 'short' });
  ok(!nu.ok, 'weak initial password rejected');
  ok((await admin('POST', '/users', { username: 'temp.user', full_name: 'Temp', role: 'operations', password: 'LongEnough1' })).ok, 'admin creates a user');
  const tu = await login('temp.user', 'LongEnough1');
  ok((await tu('GET', '/shipments')).status === 403, 'new user must change password before working');
  ok((await tu('POST', '/change-password', { current: 'LongEnough1', password: 'AnotherOne22' })).ok, 'user changes password');
  ok((await tu('GET', '/shipments')).ok, 'access after password change');
  ok((await admin('GET', '/audit')).body.length > 20, 'audit log records activity');

  server.close();
  console.log(`\n${pass} passed, ${fail} failed`);
  fs.rmSync(tmp, { recursive: true, force: true });
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('TEST CRASH:', e); process.exit(2); });
