'use strict';
// Loads realistic DEMO data through the same API the web app uses (so it doubles as an end-to-end test).
// Usage: npm run seed:demo      (only on an empty database)
const { db, addDays, today } = require('./db');
const { hash } = require('./auth');
const L = require('./logic');
const app = require('./server');

const ADMIN_PW = process.env.ADMIN_PASSWORD || 'admin123';   // set both on a public host so the demo logins are not guessable
const DEMO_PW = process.env.DEMO_PASSWORD || 'demo1234';
const T = today();
const d = (n) => addDays(T, n);

async function main() {
  if (db.prepare('SELECT COUNT(*) n FROM parties').get().n) {
    console.error('This database already has data. Seed the demo into an empty database only (delete data/nvocc.db first).');
    process.exit(1);
  }
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}/api`;

  // demo users (one per role) - passwords are for DEMO only
  db.prepare("UPDATE users SET password_hash=?, must_change_pw=0 WHERE username='admin'").run(hash(ADMIN_PW));
  const users = [['ops', 'Omar (Operations)', 'operations'], ['docs', 'Dina (Documentation)', 'documentation'], ['accounts', 'Amir (Accounts)', 'accounts'],
    ['sales', 'Sara (Sales / Agents)', 'sales'], ['manager', 'Mohammed (Management)', 'management']];
  for (const [u, n, r] of users) db.prepare('INSERT INTO users(username,full_name,role,password_hash,must_change_pw) VALUES(?,?,?,?,0)').run(u, n, r, hash(DEMO_PW));

  let cookie = '';
  async function api(method, path, body, expectFail) {
    const res = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'hubline-erp', cookie }, body: body ? JSON.stringify(body) : undefined });
    const text = await res.text();
    let json; try { json = JSON.parse(text); } catch { json = text; }
    if (path === '/login') cookie = res.headers.get('set-cookie').split(';')[0];
    if (!res.ok && !expectFail) throw new Error(`${method} ${path} -> ${res.status} ${JSON.stringify(json)}`);
    if (res.ok && expectFail) throw new Error(`${method} ${path} should have failed but returned ${res.status}`);
    return json;
  }
  await api('POST', '/login', { username: 'admin', password: ADMIN_PW });

  const lk = await api('GET', '/lookups');
  const port = (c) => lk.ports.find((p) => p.code === c).id;
  const ctype = (c) => lk.container_types.find((p) => p.code === c).id;
  const charge = (c) => lk.charge_codes.find((p) => p.code === c).id;

  // ---------------- exchange rates (DEMO rates - update under Setup > Exchange rates)
  for (const [c, r] of [['EUR', 4.0], ['GBP', 4.65], ['INR', 0.0435], ['CNY', 0.51], ['KES', 0.0285]]) await api('POST', '/exchange-rates', { currency: c, rate: r, effective_date: '2026-01-01' });

  // ---------------- parties
  const mk = async (o) => (await api('POST', '/parties', o)).id;
  const cust = {
    noor: await mk({ name: 'Al Noor Trading LLC', is_customer: 1, country: 'United Arab Emirates', city: 'Dubai', address: 'Al Quoz Industrial 3, Dubai', contact_person: 'Yusuf Al Noor', email: 'accounts@alnoor.example', phone: '+971 4 555 0101', tax_no: '100234567800003', credit_days: 30, currency: 'USD' }),
    fresh: await mk({ name: 'Gulf Fresh Foods FZE', is_customer: 1, country: 'United Arab Emirates', city: 'Sharjah', address: 'SAIF Zone, Sharjah', contact_person: 'Priya Nair', email: 'ops@gulffresh.example', phone: '+971 6 555 0102', credit_days: 45, currency: 'USD' }),
    auto: await mk({ name: 'Emirates Auto Parts LLC', is_customer: 1, country: 'United Arab Emirates', city: 'Sharjah', address: 'Industrial Area 5, Sharjah', contact_person: 'Hassan Ali', email: 'finance@emiratesauto.example', credit_days: 30, currency: 'AED' }),
  };
  const agent = {
    sha: await mk({ name: 'Shanghai Star Logistics Co. Ltd', is_agent: 1, is_customer: 0, country: 'China', city: 'Shanghai', address: '88 Zhongshan Rd, Shanghai', contact_person: 'Li Wei', email: 'li.wei@shstar.example', agent_type: 'ORIGIN', agent_network: 'Independent', agent_territory: 'East China', agent_since: '2022-03-01', credit_days: 30, currency: 'USD' }),
    mum: await mk({ name: 'Mumbai Freight Partners Pvt Ltd', is_agent: 1, country: 'India', city: 'Mumbai', address: 'Nariman Point, Mumbai', contact_person: 'Rahul Mehta', email: 'rahul@mfp.example', agent_type: 'BOTH', agent_network: 'Independent', agent_territory: 'West India', agent_since: '2021-06-15', credit_days: 30, currency: 'USD' }),
    nbo: await mk({ name: 'Nairobi Cargo Link Ltd', is_agent: 1, country: 'Kenya', city: 'Nairobi', address: 'Mombasa Rd, Nairobi', contact_person: 'Grace Wanjiru', email: 'grace@cargolink.example', agent_type: 'DESTINATION', agent_territory: 'Kenya, Uganda', agent_since: '2024-01-10', credit_days: 45, currency: 'USD' }),
  };
  const carrier = {
    bw: await mk({ name: 'Blue Wave Container Lines', is_carrier: 1, is_vendor: 1, country: 'Singapore', credit_days: 30, currency: 'USD' }),
    os: await mk({ name: 'Orient Star Shipping', is_carrier: 1, is_vendor: 1, country: 'Singapore', credit_days: 30, currency: 'USD' }),
  };
  const vendor = {
    depot: await mk({ name: 'Jebel Ali Container Depot LLC', is_vendor: 1, country: 'United Arab Emirates', credit_days: 30, currency: 'AED' }),
    truck: await mk({ name: 'Rapid Trucking LLC', is_vendor: 1, country: 'United Arab Emirates', credit_days: 15, currency: 'AED' }),
  };

  // ---------------- agency agreements
  async function agreement(agentId, o, rules) {
    const a = await api('POST', '/agreements', { agent_id: agentId, status: 'ACTIVE', currency: 'USD', payment_terms_days: 30, notice_days: 60, auto_renew: 1, ...o });
    await api('POST', `/agreements/${a.id}/standard-clauses`, {});
    for (const r of rules) await api('POST', `/agreements/${a.id}/rules`, { currency: 'USD', ...r });
    return a;
  }
  const agr = {
    sha: await agreement(agent.sha, { title: 'Agency agreement - China origin', start_date: '2026-01-01', end_date: '2026-12-31', signed_date: '2025-12-15', territory: 'East China (Shanghai, Ningbo)', exclusivity: 'Non-exclusive', governing_law: 'Laws of the Emirate of Dubai and UAE federal laws', credit_limit: 15000,
      commission_summary: 'USD 15 per TEU on FCL cargo; 40% profit share on LCL cargo.' },
    [{ name: 'FCL - USD 15 per TEU', basis: 'PER_TEU', rate: 15, cargo_type: 'FCL' }, { name: 'LCL - 40% profit share', basis: 'PERCENT_PROFIT', rate: 40, cargo_type: 'LCL' }]),
    mum: await agreement(agent.mum, { title: 'Agency agreement - India (profit share)', start_date: '2026-01-01', end_date: '2027-06-30', signed_date: '2025-12-20', territory: 'West India (Nhava Sheva, Mundra)', exclusivity: 'Exclusive for Nhava Sheva', governing_law: 'Laws of the Emirate of Dubai', credit_limit: 25000,
      commission_summary: '50% of net profit on every shipment nominated by the Agent, with a minimum of USD 25 per shipment.' },
    [{ name: 'All cargo - 50% profit share (min USD 25)', basis: 'PERCENT_PROFIT', rate: 50, min_amount: 25 }]),
    nbo: await agreement(agent.nbo, { title: 'Agency agreement - East Africa', start_date: d(-335), end_date: d(30), signed_date: d(-340), territory: 'Kenya and Uganda', exclusivity: 'Non-exclusive', governing_law: 'Laws of the Emirate of Dubai', payment_terms_days: 45, credit_limit: 10000,
      commission_summary: 'USD 25 per container on FCL; USD 2 per CBM on LCL.' },
    [{ name: 'FCL - USD 25 per container', basis: 'PER_CONTAINER', rate: 25, cargo_type: 'FCL' }, { name: 'LCL - USD 2 per CBM', basis: 'PER_CBM', rate: 2, cargo_type: 'LCL' }]),
  };

  // ---------------- tariffs
  const lanes = [['AEJEA', 'INNSA', 350, 550], ['AEJEA', 'CNSHA', 520, 780], ['AEJEA', 'KEMBA', 1250, 1980]];
  for (const [o, dst, r20, r40] of lanes) {
    for (const [ct, rate] of [['20GP', r20], ['40HC', r40]]) {
      await api('POST', '/tariffs', { rate_type: 'SELL', pol_id: port(o), pod_id: port(dst), cargo_type: 'FCL', container_type_id: ctype(ct), charge_code_id: charge('OF'), currency: 'USD', rate, unit: 'PER_CONTAINER', valid_from: '2026-01-01', valid_to: '2026-12-31' });
      await api('POST', '/tariffs', { rate_type: 'BUY', party_id: carrier.bw, pol_id: port(o), pod_id: port(dst), cargo_type: 'FCL', container_type_id: ctype(ct), charge_code_id: charge('OF'), currency: 'USD', rate: Math.round(rate * 0.82), unit: 'PER_CONTAINER', valid_from: '2026-01-01', valid_to: '2026-12-31' });
    }
    await api('POST', '/tariffs', { rate_type: 'SELL', pol_id: port(o), pod_id: port(dst), cargo_type: 'LCL', charge_code_id: charge('LCL-FRT'), currency: 'USD', rate: 38, unit: 'PER_CBM', valid_from: '2026-01-01', valid_to: '2026-12-31' });
  }
  await api('POST', '/tariffs', { rate_type: 'SELL', pol_id: port('AEJEA'), cargo_type: 'ANY', charge_code_id: charge('THC-O'), currency: 'AED', rate: 1100, unit: 'PER_CONTAINER', remarks: 'Origin THC per container' });
  await api('POST', '/tariffs', { rate_type: 'SELL', cargo_type: 'ANY', charge_code_id: charge('DOC'), currency: 'AED', rate: 250, unit: 'PER_BL' });

  // ---------------- container inventory
  const cn = (prefix, serial) => { const first = prefix + String(serial).padStart(6, '0'); return first + L.iso6346CheckDigit(first); };
  const range = (prefix, from, n) => Array.from({ length: n }, (_, i) => cn(prefix, from + i)).join('\n');
  const bulk = (numbers, type, ownership, owner, location, status = 'EMPTY_AVAILABLE', date = d(-70)) => api('POST', '/containers/bulk', { numbers, type_id: ctype(type), ownership, owner_id: owner || '', location, status, date });
  await bulk(range('HLSU', 100001, 10), '20GP', 'OWN', '', 'Jebel Ali Depot');
  await bulk(range('HLSU', 200001, 12), '40HC', 'OWN', '', 'Jebel Ali Depot');
  await bulk(range('BWCU', 300001, 6), '40HC', 'COC', carrier.bw, 'Jebel Ali Depot');
  await bulk(range('HLSU', 400001, 4), '20RF', 'LEASED', vendor.depot, 'Sharjah Depot');
  await bulk(range('OSTU', 500001, 4), '20GP', 'SOC', '', 'Jebel Ali Depot');
  // a few bad ones to prove validation
  const wrongNo = 'HLSU123456' + ((L.iso6346CheckDigit('HLSU123456') + 1) % 10);
  const bad = await api('POST', '/containers', { container_no: wrongNo, type_id: ctype('20GP') }, true);
  if (!/check-digit/.test(bad.error)) throw new Error('ISO 6346 validation did not trigger');

  const pick = async (type, n, location = 'Jebel Ali Depot') => {
    const r = await api('GET', `/containers?status=EMPTY_AVAILABLE&type_id=${ctype(type)}&location=${encodeURIComponent(location)}`);
    return r.rows.slice(0, n);
  };

  // ---------------- shipments
  async function shipment(o) {
    const s = await api('POST', '/shipments', {
      cargo_type: o.cargo || 'FCL', customer_id: o.customer, shipper_id: o.customer, consignee_text: o.consignee, notify_text: o.consignee,
      agent_id: o.agent, carrier_id: o.carrier || carrier.bw, pol_id: port(o.pol), pod_id: port(o.pod), place_of_delivery: o.placeDel || '',
      vessel: o.vessel, voyage: o.voyage, etd: o.etd, eta: o.eta, freight_terms: o.terms || 'PREPAID', incoterm: o.incoterm || 'CIF',
      commodity: o.commodity, marks: 'AS PER INVOICE', packages: o.packages, package_type: o.pkgType || 'CARTONS', gross_weight: o.weight, cbm: o.cbm,
    });
    for (const c of o.containers || []) await api('POST', `/shipments/${s.id}/containers`, { container_id: c.id, seal_no: 'SL' + Math.floor(100000 + Math.random() * 899999), packages: o.packages && Math.round(o.packages / o.containers.length), weight_kg: o.weight && Math.round(o.weight / o.containers.length), date: o.allocDate });
    return s;
  }
  const inv = async (s, party, lines, o = {}) => (await api('POST', '/documents', { doc_type: o.type || 'INV', party_id: party, shipment_id: s.id, currency: o.currency || 'USD', doc_date: o.date, lines, post: o.post !== false, party_ref: o.ref, narration: o.narration })).id;
  const line = (code, desc, qty, rate, vat = 0) => ({ charge_code_id: charge(code), description: desc, qty, rate, vat_rate: vat });

  // S1: India, 2 x 40HC, fully completed and paid
  const c1 = await pick('40HC', 2);
  const s1 = await shipment({ customer: cust.noor, agent: agent.mum, pol: 'AEJEA', pod: 'INNSA', consignee: 'Sharma Imports Pvt Ltd, Mumbai', vessel: 'BLUE HORIZON', voyage: '026E', etd: d(-75), eta: d(-60), commodity: 'Ceramic tiles', packages: 2400, weight: 46000, containers: c1, allocDate: d(-80) });
  await api('POST', `/shipments/${s1.id}/status`, { status: 'CONFIRMED' });
  await api('POST', `/shipments/${s1.id}/status`, { status: 'SAILED' });
  await api('POST', `/shipments/${s1.id}/status`, { status: 'ARRIVED', date: d(-60), free_days: 7 });
  await api('POST', `/shipments/${s1.id}/status`, { status: 'DELIVERED', date: d(-58) });
  for (const c of c1) await api('POST', `/containers/${c.id}/events`, { event_type: 'EMPTY_RETURNED', event_date: d(-55), location: 'Nhava Sheva Depot', remarks: 'Empty returned' });
  await api('POST', `/shipments/${s1.id}/status`, { status: 'CLOSED' });
  const i1 = await inv(s1, cust.noor, [line('OF', 'Ocean freight JEA-NSA 40HC', 2, 550), line('THC-O', 'Origin THC', 2, 300, 5), line('DOC', 'Documentation fee', 1, 68, 5)], { date: d(-74), narration: 'Freight JEA-NSA' });
  const b1 = await inv(s1, carrier.bw, [line('OF', 'Ocean freight 40HC (buy)', 2, 451)], { type: 'BILL', date: d(-72), ref: 'BW-88213' });
  const b1b = await inv(s1, agent.mum, [line('DO', 'Destination charges NSA (agent)', 1, 120)], { type: 'BILL', date: d(-58), ref: 'MFP/0451' });
  await api('POST', '/payments', { direction: 'RECEIPT', party_id: cust.noor, pay_date: d(-50), method: 'Bank transfer', currency: 'USD', amount: 1200, reference: 'TT-55120', allocations: [{ doc_id: i1, amount: 1200 }] });
  const i1doc = await api('GET', `/documents/${i1}`);
  await api('POST', '/payments', { direction: 'RECEIPT', party_id: cust.noor, pay_date: d(-40), method: 'Bank transfer', currency: 'USD', amount: i1doc.outstanding, reference: 'TT-55890', allocations: [{ doc_id: i1, amount: i1doc.outstanding }] });
  await api('POST', '/payments', { direction: 'PAYMENT', party_id: carrier.bw, pay_date: d(-45), method: 'Bank transfer', currency: 'USD', amount: 902, reference: 'OUT-1187', allocations: [{ doc_id: b1, amount: 902 }] });

  // S2: China, 20GP, discharged, free time expired (detention alert), unpaid invoice past due
  const c2 = await pick('20GP', 2);
  const s2 = await shipment({ customer: cust.fresh, agent: agent.sha, pol: 'CNSHA', pod: 'AEJEA', consignee: 'Gulf Fresh Foods FZE, Sharjah', vessel: 'ORIENT PEARL', voyage: '031W', etd: d(-50), eta: d(-30), commodity: 'Frozen vegetables (dry pack)', packages: 1800, weight: 21500, containers: [c2[0]], allocDate: d(-55), terms: 'COLLECT', incoterm: 'FOB' });
  await api('POST', `/shipments/${s2.id}/status`, { status: 'CONFIRMED' });
  await api('POST', `/shipments/${s2.id}/status`, { status: 'SAILED' });
  await api('POST', `/shipments/${s2.id}/status`, { status: 'ARRIVED', date: d(-30), free_days: 7 });
  await inv(s2, cust.fresh, [line('OF', 'Ocean freight CNSHA-JEA 20GP', 1, 520), line('THC-D', 'Destination THC', 1, 90, 5), line('DO', 'Delivery order fee', 1, 40, 5)], { date: d(-29) });
  await inv(s2, carrier.os, [line('OF', 'Ocean freight 20GP (buy)', 1, 425)], { type: 'BILL', date: d(-45), ref: 'OS-77120' });
  await inv(s2, agent.sha, [line('AGT-HDL', 'Origin handling (agent)', 1, 85)], { type: 'BILL', date: d(-48), ref: 'SS-0912' });

  // S3: Kenya LCL consolidation (3 shipments in one 20GP), arrived
  const c3 = await pick('20GP', 1);
  const k1 = await api('POST', '/consols', { mbl_no: 'BWL-MBL-77103', carrier_id: carrier.bw, vessel: 'BLUE HORIZON', voyage: '028E', pol_id: port('AEJEA'), pod_id: port('KEMBA'), etd: d(-35), eta: d(-15), cutoff_date: d(-40) });
  const lcl = [[cust.noor, 'Ceramic sanitary ware', 14.5, 5200, 300], [cust.auto, 'Auto spare parts', 9.2, 2100, 120], [cust.fresh, 'Packaged foodstuff', 6.8, 3100, 210]];
  const lclShips = [];
  for (const [cu, com, cbm, wt, pk] of lcl) {
    const s = await shipment({ cargo: 'LCL', customer: cu, agent: agent.nbo, pol: 'AEJEA', pod: 'KEMBA', consignee: 'East Africa Distributors Ltd, Nairobi', vessel: 'BLUE HORIZON', voyage: '028E', etd: d(-35), eta: d(-15), commodity: com, packages: pk, weight: wt, cbm });
    lclShips.push(s);
    await api('POST', `/consols/${k1.id}/shipments`, { shipment_id: s.id, date: d(-38) });
    await api('POST', `/shipments/${s.id}/status`, { status: 'CONFIRMED' });
  }
  for (const s of lclShips) await api('POST', `/shipments/${s.id}/containers`, { container_id: c3[0].id, cbm: 0, date: d(-38) });
  await api('POST', `/consols/${k1.id}/status`, { status: 'SAILED' });
  await api('POST', `/consols/${k1.id}/status`, { status: 'ARRIVED', date: d(-15), free_days: 10 });
  for (const [i, s] of lclShips.entries()) {
    await inv(s, lcl[i][0], [line('LCL-FRT', 'LCL freight JEA-MBA', lcl[i][2], 38), line('DOC', 'Documentation fee', 1, 68, 5)], { date: d(-34) });
    await inv(s, carrier.bw, [line('LCL-FRT', 'LCL freight share (buy)', lcl[i][2], 29)], { type: 'BILL', date: d(-30), ref: 'BW-LCL-' + i });
  }
  await api('POST', `/shipments/${lclShips[0].id}/status`, { status: 'DELIVERED', date: d(-10) });

  // S4: India FCL on board, ETA in future
  const c4 = await pick('40HC', 1);
  const s4 = await shipment({ customer: cust.auto, agent: agent.mum, pol: 'AEJEA', pod: 'INNSA', consignee: 'Patel Motors Pvt Ltd, Ahmedabad', vessel: 'ORIENT PEARL', voyage: '033E', etd: d(-6), eta: d(4), commodity: 'Used automotive parts', packages: 900, weight: 19800, containers: c4, allocDate: d(-9) });
  await api('POST', `/shipments/${s4.id}/status`, { status: 'CONFIRMED' });
  await api('POST', `/shipments/${s4.id}/status`, { status: 'SAILED' });
  await inv(s4, cust.auto, [line('OF', 'Ocean freight JEA-NSA 40HC', 1, 550), line('DOC', 'Documentation fee', 1, 68, 5)], { date: d(-5), currency: 'USD' });

  // S5: China FCL confirmed, sails soon (container allocated)
  const c5 = await pick('20GP', 1);
  const s5 = await shipment({ customer: cust.noor, agent: agent.sha, pol: 'AEJEA', pod: 'CNSHA', consignee: 'Shanghai Trading Co', vessel: 'BLUE HORIZON', voyage: '030E', etd: d(5), eta: d(24), commodity: 'Polypropylene granules', packages: 800, pkgType: 'BAGS', weight: 20000, containers: c5 });
  await api('POST', `/shipments/${s5.id}/status`, { status: 'CONFIRMED' });

  // S6: booking only
  await shipment({ customer: cust.fresh, agent: agent.nbo, pol: 'AEJEA', pod: 'KEMBA', consignee: 'Kenya Fresh Ltd', vessel: 'TBA', etd: d(12), commodity: 'Dates', packages: 1200, weight: 18000, containers: [] });

  // cancelled booking (to show status)
  const sx = await shipment({ customer: cust.noor, agent: agent.mum, pol: 'AEJEA', pod: 'INNSA', consignee: 'Test Consignee', etd: d(-20), commodity: 'Cancelled test', containers: [] });
  await api('POST', `/shipments/${sx.id}/status`, { status: 'CANCELLED' });

  // extra container moves for a lively inventory report
  const spare = await pick('20GP', 3);
  await api('POST', '/container-events/bulk', { container_ids: spare.slice(0, 2).map((c) => c.id), event_type: 'RELEASED_SHIPPER', event_date: d(-1), location: 'Al Quoz - customer premises', remarks: 'Released for stuffing' });
  const dmg = await pick('40HC', 1);
  await api('POST', `/containers/${dmg[0].id}/events`, { event_type: 'DAMAGED', event_date: d(-2), location: 'Jebel Ali Depot', remarks: 'Door panel damage - awaiting survey' });
  const reefer = await pick('20RF', 1, 'Sharjah Depot');
  await api('POST', `/containers/${reefer[0].id}/events`, { event_type: 'DELIVERED_FULL', event_date: d(-3), location: 'Gulf Fresh cold store', free_days: 5, remarks: 'Full out for cold store' });
  await api('POST', '/containers', { container_no: cn('HLSU', 600001), type_id: ctype('40HC'), ownership: 'OWN', location: 'Jebel Ali Depot', status: 'EMPTY_AVAILABLE', date: T });

  // ---------------- agent ledger extras: debit note to agent; net a bill against it
  const dn = await api('POST', '/documents', { doc_type: 'DN', party_id: agent.mum, currency: 'USD', doc_date: d(-30), narration: 'Recharge - detention on MFPU shipment', lines: [line('DET', 'Detention recharge', 3, 45)], post: true });
  await api('POST', '/allocations/net', { from_doc_id: (await api('GET', `/documents?type=BILL&party_id=${agent.mum}`))[0].id, to_doc_id: dn.id, amount: 100 }).catch(() => {});

  // ---------------- commission statements
  const p1 = await api('POST', '/commissions/preview', { agent_id: agent.mum, agreement_id: agr.mum.id, from: d(-120), to: d(-1) });
  if (!p1.lines.length) throw new Error('Expected commission lines for Mumbai agent');
  const st1 = await api('POST', '/commissions', { agent_id: agent.mum, agreement_id: agr.mum.id, from: d(-120), to: d(-1) });
  await api('POST', `/commissions/${st1.id}/post`, {});
  await api('POST', '/commissions', { agent_id: agent.nbo, agreement_id: agr.nbo.id, from: d(-120), to: d(-1) });
  await api('POST', '/commissions', { agent_id: agent.sha, agreement_id: agr.sha.id, from: d(-120), to: d(-1) });

  // ---------------- sanity checks
  const soa = await api('GET', `/soa?party_id=${cust.noor}&from=${d(-120)}&to=${T}`);
  const dash = await api('GET', '/dashboard');
  console.log('\nDemo data loaded.');
  console.log(`  Shipments: ${dash.shipments_by_status.map((x) => `${x.status}=${x.n}`).join(', ')}`);
  console.log(`  Containers in inventory: ${dash.containers.total} (overdue on free time: ${dash.containers.overdue})`);
  console.log(`  Receivable ${dash.finance.receivable} ${dash.base_currency}, payable ${dash.finance.payable} ${dash.base_currency}`);
  console.log(`  Al Noor SOA currencies: ${soa.currencies.map((c) => c.currency + ' closing ' + c.closing).join(', ')}`);
  console.log(process.env.ADMIN_PASSWORD || process.env.DEMO_PASSWORD
    ? '\nDemo users created: admin, ops, docs, accounts, sales, manager (passwords from ADMIN_PASSWORD / DEMO_PASSWORD)\n'
    : '\nSign-in (DEMO passwords):  admin / admin123   ops, docs, accounts, sales, manager / demo1234\n');
  server.close();
  process.exit(0);
}
main().catch((e) => { console.error('\nSEED FAILED:', e.message); process.exit(1); });
