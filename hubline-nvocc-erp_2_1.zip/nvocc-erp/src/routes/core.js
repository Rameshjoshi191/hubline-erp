'use strict';
const express = require('express');
const { db, audit, allSettings, setSetting, getSetting } = require('../db');
const A = require('../auth');
const { bad, extract, insertRow, updateRow, diff } = require('../util');
const L = require('../logic');

const r = express.Router();

// ---------------------------------------------------------------- auth
r.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) bad('Enter your username and password.');
  if (A.tooManyAttempts(req, username)) bad('Too many failed attempts. Please wait 15 minutes and try again.', 429);
  const u = db.prepare('SELECT * FROM users WHERE lower(username)=lower(?)').get(String(username).trim());
  if (!u || !u.active || !A.verify(String(password), u.password_hash)) {
    A.recordFailure(req, username);
    audit(null, 'LOGIN_FAILED', 'user', username);
    bad('Incorrect username or password.', 401);
  }
  A.clearFailures(req, username);
  const token = A.createSession(u.id);
  res.cookie('sid', token, { httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === '1', maxAge: 12 * 3600 * 1000 });
  audit(u, 'LOGIN', 'user', u.id);
  res.json(meFor(u));
});

r.post('/logout', (req, res) => {
  const token = req.cookies && req.cookies.sid;
  if (token) db.prepare('DELETE FROM sessions WHERE token=?').run(token);
  res.clearCookie('sid');
  res.json({ ok: true });
});

const meFor = (u) => ({
  id: u.id, username: u.username, full_name: u.full_name, role: u.role, role_label: A.ROLES[u.role],
  must_change_pw: !!u.must_change_pw, perms: A.permsFor(u.role),
});

r.get('/me', A.requireLogin, (req, res) => res.json(meFor(req.user)));

r.post('/change-password', A.requireLogin, (req, res) => {
  const { current, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!A.verify(String(current || ''), u.password_hash)) bad('Current password is incorrect.');
  if (!password || String(password).length < 8) bad('New password must be at least 8 characters.');
  if (password === current) bad('New password must be different from the current one.');
  db.prepare('UPDATE users SET password_hash=?, must_change_pw=0 WHERE id=?').run(A.hash(String(password)), u.id);
  audit(req.user, 'CHANGE_PASSWORD', 'user', u.id);
  res.json({ ok: true });
});

// ---------------------------------------------------------------- lookups (one call to fill every dropdown)
r.get('/lookups', A.requireLogin, (req, res) => {
  const s = allSettings();
  res.json({
    ports: db.prepare('SELECT id,code,name,country FROM ports WHERE active=1 ORDER BY name').all(),
    container_types: db.prepare('SELECT id,code,description,size_ft,teu,is_reefer FROM container_types WHERE active=1 ORDER BY size_ft,code').all(),
    charge_codes: db.prepare('SELECT id,code,name,category,side,vat_rate FROM charge_codes WHERE active=1 ORDER BY code').all(),
    currencies: db.prepare(`SELECT c.code,c.name,(SELECT rate FROM exchange_rates e WHERE e.currency=c.code ORDER BY effective_date DESC LIMIT 1) AS rate
      FROM currencies c WHERE c.active=1 ORDER BY c.code`).all(),
    parties: db.prepare(`SELECT id,code,name,is_customer,is_agent,is_vendor,is_carrier,currency,credit_days,country,address,active FROM parties WHERE active=1 ORDER BY name`).all(),
    container_status: L.CONTAINER_STATUS,
    commission_basis: L.COMM_BASIS,
    doc_labels: L.DOC_LABEL,
    roles: A.ROLES,
    settings: {
      company_name: s.company_name || '', company_address: s.company_address || '', company_phone: s.company_phone || '',
      company_email: s.company_email || '', company_tax_no: s.company_tax_no || '', company_bank: s.company_bank || '',
      base_currency: s.base_currency || 'AED', default_vat: s.default_vat || '5', invoice_footer: s.invoice_footer || '',
      hbl_terms: s.hbl_terms || '', default_free_days: s.default_free_days || '',
    },
  });
});

// ---------------------------------------------------------------- users (admin)
r.get('/users', A.need('users', 'read'), (req, res) => {
  res.json(db.prepare('SELECT id,username,full_name,email,role,active,must_change_pw,created_at FROM users ORDER BY username').all());
});
const USER_FIELDS = [
  { name: 'username', required: true, label: 'Username' }, { name: 'full_name', required: true, label: 'Full name' },
  { name: 'email' }, { name: 'role', required: true, label: 'Role' }, { name: 'active', type: 'bool', def: 1 },
];
r.post('/users', A.need('users', 'write'), (req, res) => {
  const v = extract(req.body, USER_FIELDS);
  if (!A.ROLES[v.role]) bad('Unknown role.');
  if (!/^[A-Za-z0-9._-]{3,32}$/.test(v.username)) bad('Username must be 3-32 characters: letters, numbers, dot, dash, underscore.');
  const pw = String((req.body || {}).password || '');
  if (pw.length < 8) bad('Initial password must be at least 8 characters.');
  if (db.prepare('SELECT 1 FROM users WHERE lower(username)=lower(?)').get(v.username)) bad('That username already exists.', 409);
  const id = insertRow('users', { ...v, password_hash: A.hash(pw), must_change_pw: 1 });
  audit(req.user, 'CREATE', 'user', id, { username: v.username, role: v.role });
  res.json({ id });
});
r.put('/users/:id', A.need('users', 'write'), (req, res) => {
  const cur = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!cur) bad('User not found', 404);
  const v = extract(req.body, USER_FIELDS.filter((f) => f.name !== 'username'), { partial: true });
  if (v.role && !A.ROLES[v.role]) bad('Unknown role.');
  const willBeAdmin = (v.role || cur.role) === 'admin' && (v.active === undefined ? cur.active : v.active);
  if (cur.role === 'admin' && !willBeAdmin) {
    const others = db.prepare("SELECT COUNT(*) n FROM users WHERE role='admin' AND active=1 AND id<>?").get(cur.id).n;
    if (!others) bad('There must be at least one active administrator.');
  }
  if (req.body.password) {
    if (String(req.body.password).length < 8) bad('Password must be at least 8 characters.');
    v.password_hash = A.hash(String(req.body.password)); v.must_change_pw = 1;
    db.prepare('DELETE FROM sessions WHERE user_id=?').run(cur.id);
  }
  if (v.active === 0) db.prepare('DELETE FROM sessions WHERE user_id=?').run(cur.id);
  updateRow('users', cur.id, v);
  const { password_hash, ...safe } = v;
  audit(req.user, 'UPDATE', 'user', cur.id, { ...diff(cur, safe), password_reset: !!req.body.password });
  res.json({ ok: true });
});

// ---------------------------------------------------------------- settings
const SETTING_KEYS = ['company_name', 'company_address', 'company_phone', 'company_email', 'company_tax_no', 'company_bank',
  'base_currency', 'default_vat', 'invoice_footer', 'hbl_terms', 'default_free_days'];
r.get('/settings', A.need('settings', 'read'), (req, res) => res.json(allSettings()));
r.put('/settings', A.need('settings', 'write'), (req, res) => {
  const b = req.body || {};
  if (b.base_currency && b.base_currency !== getSetting('base_currency')) {
    const used = db.prepare("SELECT COUNT(*) n FROM documents WHERE status='POSTED'").get().n;
    if (used) bad('The base currency cannot be changed after documents have been posted.');
    if (!db.prepare('SELECT 1 FROM currencies WHERE code=?').get(b.base_currency)) bad('Add the currency first under Exchange rates.');
  }
  for (const k of SETTING_KEYS) if (k in b) setSetting(k, b[k]);
  audit(req.user, 'UPDATE', 'settings', null, Object.keys(b).filter((k) => SETTING_KEYS.includes(k)));
  res.json({ ok: true });
});

// ---------------------------------------------------------------- database backup (administrator)
// A consistent snapshot of the whole database, safe to take while the system is in use.
r.get('/backup', A.need('settings', 'write'), async (req, res, next) => {
  const os = require('os'), fs = require('fs'), path = require('path');
  const tmp = path.join(os.tmpdir(), `hubline-backup-${process.pid}-${Date.now()}.db`);
  try {
    await db.backup(tmp);
    audit(req.user, 'EXPORT', 'database', null, { backup: true });
    const stamp = new Date().toISOString().slice(0, 19).replace(/[-:T]/g, '');
    res.download(tmp, `hubline-backup-${stamp}.db`, () => fs.unlink(tmp, () => {}));
  } catch (e) { fs.unlink(tmp, () => {}); next(e); }
});

// ---------------------------------------------------------------- audit log
r.get('/audit', A.need('audit', 'read'), (req, res) => {
  const where = [], p = {};
  if (req.query.entity) { where.push('entity=@e'); p.e = req.query.entity; }
  if (req.query.user) { where.push('username=@u'); p.u = req.query.user; }
  if (req.query.q) { where.push('(detail LIKE @q OR entity_id LIKE @q)'); p.q = `%${req.query.q}%`; }
  res.json(db.prepare(`SELECT * FROM audit_log ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC LIMIT 300`).all(p));
});

module.exports = r;
