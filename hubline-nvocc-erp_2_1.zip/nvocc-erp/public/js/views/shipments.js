import { api, state, esc, $, on, qs, tbl, pageHead, money, num, int, date, shipBadge, consolBadge, docBadge, badge, formModal, confirmBox, toast, opts, can, kv, link, signed, docType, todayStr, debounce, go, download } from '../core.js';

const CARGO = [['FCL', 'FCL - full container'], ['LCL', 'LCL - consolidated']];
const STEPS = ['BOOKED', 'CONFIRMED', 'SAILED', 'ARRIVED', 'DELIVERED', 'CLOSED'];

export const shipmentFields = () => [
  { section: 'Booking' },
  { name: 'cargo_type', label: 'Cargo', type: 'select', options: CARGO, noEmpty: true, span: 1 },
  { name: 'customer_id', label: 'Billing customer', type: 'combo', options: () => opts.parties('customer'), span: 2, required: true },
  { name: 'agent_id', label: 'Agent (nominating)', type: 'combo', options: () => opts.parties('agent'), span: 1 },
  { name: 'shipper_id', label: 'Shipper', type: 'combo', options: () => opts.parties(), span: 2 },
  { name: 'consignee_id', label: 'Consignee', type: 'combo', options: () => opts.parties(), span: 2 },
  { name: 'shipper_text', label: 'Shipper (if not in list)', type: 'textarea', rows: 2, span: 2, hint: 'name & address as it must print on the BL' },
  { name: 'consignee_text', label: 'Consignee (if not in list)', type: 'textarea', rows: 2, span: 2 },
  { name: 'notify_id', label: 'Notify party', type: 'combo', options: () => opts.parties(), span: 2 },
  { name: 'notify_text', label: 'Notify (if not in list)', type: 'textarea', rows: 2, span: 2 },
  { section: 'Routing' },
  { name: 'pol_id', label: 'Port of loading', type: 'combo', options: opts.ports, span: 2 },
  { name: 'pod_id', label: 'Port of discharge', type: 'combo', options: opts.ports, span: 2 },
  { name: 'place_of_receipt', label: 'Place of receipt' }, { name: 'place_of_delivery', label: 'Place of delivery' },
  { name: 'carrier_id', label: 'Carrier / shipping line', type: 'combo', options: () => opts.parties('carrier') },
  { name: 'freight_terms', label: 'Freight', type: 'select', options: [['PREPAID', 'Prepaid'], ['COLLECT', 'Collect']], noEmpty: true },
  { name: 'vessel', label: 'Vessel' }, { name: 'voyage', label: 'Voyage' },
  { name: 'etd', label: 'ETD', type: 'date' }, { name: 'eta', label: 'ETA', type: 'date' },
  { name: 'incoterm', label: 'Incoterm', placeholder: 'FOB, CIF, EXW…' },
  { section: 'Cargo' },
  { name: 'commodity', label: 'Description of goods', span: 3 }, { name: 'package_type', label: 'Package type', placeholder: 'CARTONS' },
  { name: 'packages', label: 'No. of packages', type: 'number', min: 0 }, { name: 'gross_weight', label: 'Gross weight (kg)', type: 'number', min: 0 },
  { name: 'cbm', label: 'Volume (CBM)', type: 'number', min: 0 }, { name: 'marks', label: 'Marks & numbers' },
  { name: 'remarks', label: 'Internal remarks', type: 'textarea', span: 4, rows: 2 },
];

export async function list(root, _p, query) {
  const f = { q: '', status: query.status || '', cargo_type: '', agent_id: query.agent_id || '', from: '', to: '', open: query.open || '' };
  const canWrite = can('shipments', 'write');
  const fin = can('finance', 'read');
  root.innerHTML = `${pageHead('Shipments / bookings', 'Bookings, house bills of lading and their containers', canWrite ? '<button class="btn primary" data-act="new">+ New booking</button><a class="btn" href="#/consols">Master BL / consolidation</a>' : '')}
    <div class="toolbar no-print">
      <input type="text" class="search" placeholder="Search booking, HBL, container, customer, agent…" data-f="q">
      <select data-f="status"><option value="">All statuses</option>${['BOOKED', 'CONFIRMED', 'SAILED', 'ARRIVED', 'DELIVERED', 'CLOSED', 'CANCELLED'].map((s) => `<option value="${s}" ${f.status === s ? 'selected' : ''}>${s[0] + s.slice(1).toLowerCase()}</option>`).join('')}</select>
      <select data-f="cargo_type"><option value="">FCL &amp; LCL</option><option>FCL</option><option>LCL</option></select>
      <select data-f="agent_id"><option value="">All agents</option>${opts.parties('agent').map(([v, l]) => `<option value="${v}" ${String(v) === String(f.agent_id) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>
      <label class="muted small">Sailing from <input type="date" data-f="from"></label><label class="muted small">to <input type="date" data-f="to"></label>
      <span class="grow"></span><button class="btn" data-act="export">Export Excel</button></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  async function load() {
    const rows = await api('GET', '/shipments' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'No shipments match these filters.', rowAttr: (r) => `data-go="#/shipments/${r.id}"`,
      cols: [
        { label: 'Booking / HBL', render: (r) => `<b>${esc(r.booking_no)}</b><div class="muted small">${esc(r.hbl_no || 'HBL not issued')}</div>` },
        { label: 'Customer', render: (r) => `${esc(r.customer_name || '')}<div class="muted small">${esc(r.commodity || '')}</div>` },
        { label: 'Agent', render: (r) => esc(r.agent_name || '') },
        { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}<div class="muted small">${esc([r.vessel, r.voyage].filter(Boolean).join(' / '))}</div>` },
        { label: 'ETD', render: (r) => date(r.etd) }, { label: 'Cargo', render: (r) => badge(r.cargo_type) },
        { label: 'Cont. / TEU', num: true, render: (r) => `${r.container_count} / ${num(r.teu)}` },
        ...(fin ? [{ label: 'Profit', num: true, render: (r) => signed(r.profit) }] : []),
        { label: 'Status', render: (r) => shipBadge(r.status) }] });
    if (rows.length >= 500) out.insertAdjacentHTML('beforeend', '<div class="muted small" style="padding:8px 12px">Showing the latest 500 - narrow the filters to see more.</div>');
  }
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')), 250);
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  on(root, 'click', '[data-act=new]', async () => {
    const r = await formModal({ title: 'New booking', size: 'wide', fields: shipmentFields(), values: { cargo_type: 'FCL', freight_terms: 'PREPAID' }, submitLabel: 'Create booking', onSubmit: (v) => api('POST', '/shipments', v) });
    if (r) { toast(`Booking ${r.booking_no} created`, 'ok'); go(`#/shipments/${r.id}`); }
  });
  on(root, 'click', '[data-act=export]', () => download('/reports/shipments' + qs({ ...f, format: 'xlsx' })));
  await load();
  if (query.q) { const el = $('[data-f=q]', root); el.value = query.q; f.q = query.q; load(); }
  if (query.new && canWrite) setTimeout(() => { const b = $('[data-act=new]', root); if (b) b.click(); }, 0);
}

export async function detail(root, { id }) {
  const s = await api('GET', `/shipments/${id}`);
  const canWrite = can('shipments', 'write'), fin = can('finance', 'read');
  const editable = !['CLOSED', 'CANCELLED'].includes(s.status);
  const idx = STEPS.indexOf(s.status);
  const onConsol = !!s.consol_id;

  const nextActions = [];
  if (canWrite) {
    if (s.status === 'BOOKED') nextActions.push('<button class="btn primary" data-st="CONFIRMED">Confirm &amp; issue HBL</button>');
    if (s.status === 'CONFIRMED' && !onConsol) nextActions.push('<button class="btn primary" data-st="SAILED">Mark sailed</button>');
    if (s.status === 'SAILED' && !onConsol) nextActions.push('<button class="btn primary" data-st="ARRIVED">Mark arrived</button>');
    if (s.status === 'ARRIVED') nextActions.push('<button class="btn primary" data-st="DELIVERED">Mark delivered</button>');
    if (s.status === 'DELIVERED') nextActions.push('<button class="btn primary" data-st="CLOSED">Close job</button>');
    if (s.status === 'CANCELLED') nextActions.push('<button class="btn" data-st="BOOKED">Re-open as booking</button>');
    if (['BOOKED', 'CONFIRMED'].includes(s.status)) nextActions.push('<button class="btn danger" data-st="CANCELLED">Cancel</button>');
    if (editable) nextActions.push('<button class="btn" data-act="edit">Edit</button>');
  }
  const party = (id, name, text) => (name ? link(`#/parties/${id}`, name) : text ? `<span style="white-space:pre-line">${esc(text)}</span>` : '');
  const containers = tbl({ rows: s.containers, compact: true, empty: 'No containers allocated yet.',
    cols: [{ label: 'Container', render: (c) => `${link(`#/containers/${c.container_id}`, c.container_no)}<div class="muted small">${esc(c.status_label || '')}</div>` },
      { label: 'Type / seal', render: (c) => `${esc(c.type_code || '')}<div class="muted small">${esc(c.seal_no || '')}</div>` },
      { label: 'Pkgs', num: true, render: (c) => int(c.packages) }, { label: 'kg', num: true, render: (c) => int(c.weight_kg) },
      ...(canWrite && ['BOOKED', 'CONFIRMED'].includes(s.status) ? [{ label: '', render: (c) => `<button class="btn sm ghost" data-rm="${c.container_id}" title="Remove">&#10005;</button>` }] : [])] });

  root.innerHTML = `${pageHead(`${esc(s.booking_no)} ${shipBadge(s.status)}`, `${esc(s.hbl_no ? 'HBL ' + s.hbl_no : 'HBL not yet issued')}${s.mbl_no ? ' &middot; MBL ' + esc(s.mbl_no) : ''}`,
    `${nextActions.join('')}<a class="btn" href="#/print/booking/${s.id}">Booking confirmation</a>${s.hbl_no ? `<a class="btn" href="#/print/hbl/${s.id}">Print HBL</a>` : ''}`, '<a href="#/shipments">Shipments</a> /')}
    ${s.status === 'CANCELLED' ? '' : `<div class="steps">${STEPS.map((x, i) => `<span class="${i < idx ? 'done' : i === idx ? 'now' : ''}">${x[0] + x.slice(1).toLowerCase()}</span>`).join('')}</div>`}
    ${onConsol && ['CONFIRMED', 'SAILED'].includes(s.status) ? `<div class="alert info">This shipment is on master BL ${link(`#/consols/${s.consol_id}`, s.consol_no)}. Sailing and arrival are recorded for the whole consolidation there.</div>` : ''}
    <div class="split"><div>
      <div class="card"><div class="card-h"><h2>Parties</h2></div><div class="card-b">${kv([
        ['Billing customer', party(s.customer_id, s.customer_name)], ['Shipper', party(s.shipper_id, s.shipper_name, s.shipper_text)],
        ['Consignee', party(s.consignee_id, s.consignee_name, s.consignee_text)], ['Notify', party(s.notify_id, s.notify_name, s.notify_text)],
        ['Agent', s.agent_id ? link(`#/agents/${s.agent_id}`, s.agent_name) : ''], ['Carrier', s.carrier_name]])}</div></div>
      <div class="card"><div class="card-h"><h2>Routing &amp; cargo</h2></div><div class="card-b grid g2">
        ${kv([['Cargo', badge(s.cargo_type)], ['Port of loading', s.pol_name], ['Port of discharge', s.pod_name], ['Place of receipt', esc(s.place_of_receipt)], ['Place of delivery', esc(s.place_of_delivery)],
          ['Vessel / voyage', esc([s.vessel, s.voyage].filter(Boolean).join(' / '))], ['ETD', date(s.etd)], ['ETA', date(s.eta)], ['Freight', esc(s.freight_terms)], ['Incoterm', esc(s.incoterm)]])}
        ${kv([['Goods', esc(s.commodity)], ['Marks', esc(s.marks)], ['Packages', s.packages != null ? `${int(s.packages)} ${esc(s.package_type || '')}` : ''], ['Gross weight', s.gross_weight != null ? num(s.gross_weight) + ' kg' : ''], ['Volume', s.cbm != null ? num(s.cbm) + ' CBM' : ''], ['Remarks', esc(s.remarks)]])}</div></div>
    </div><div>
      <div class="card"><div class="card-h"><h2>Containers</h2>${canWrite && ['BOOKED', 'CONFIRMED'].includes(s.status) && can('containers', 'read') ? '<button class="btn sm" data-act="addcont">+ Add container</button>' : ''}</div>${containers}</div>
      ${fin ? financeCard(s) : ''}
      <div class="card"><div class="card-h"><h2>Agent commission</h2></div><div class="card-b">${s.commission ? `Included in statement <b>${esc(s.commission.stmt_no)}</b> (${esc(s.commission.status.toLowerCase())}): ${money(s.commission.commission_amount)} ${esc(s.commission.currency)}` : s.agent_id ? '<span class="muted">Not yet on a commission statement.</span>' : '<span class="muted">No agent nominated.</span>'}</div></div>
    </div></div>`;

  async function act(fn, okMsg) { try { await fn(); if (okMsg) toast(okMsg, 'ok'); go(`#/shipments/${id}`); } catch (e) { toast(e.message, 'bad'); } }
  on(root, 'click', '[data-st]', async (_e, el) => {
    const st = el.dataset.st;
    if (st === 'CANCELLED') { if (!(await confirmBox('Cancel this booking? Its containers will be released.', { danger: true, ok: 'Cancel booking' }))) return; return act(() => api('POST', `/shipments/${id}/status`, { status: st }), 'Shipment cancelled'); }
    if (st === 'SAILED' || st === 'ARRIVED' || st === 'DELIVERED') {
      const dlabel = { SAILED: 'Sailing date', ARRIVED: 'Arrival date', DELIVERED: 'Delivery date' }[st];
      const dflt = st === 'SAILED' ? s.etd : st === 'ARRIVED' ? s.eta : todayStr();
      const fields = [{ name: 'date', label: dlabel, type: 'date', required: true }];
      if (st === 'ARRIVED') fields.push({ name: 'free_days', label: 'Free days at destination', type: 'number', hint: 'starts the detention clock', min: 0 });
      const r = await formModal({ title: `Mark ${st.toLowerCase()}`, size: 'narrow', fields, values: { date: dflt || todayStr(), free_days: state.lk.settings.default_free_days || '' }, submitLabel: 'Confirm',
        intro: st === 'SAILED' ? '<p class="muted">Loaded containers will be recorded as on board.</p>' : st === 'ARRIVED' ? '<p class="muted">Containers will be recorded as discharged and the free-time clock starts.</p>' : '',
        onSubmit: (v) => api('POST', `/shipments/${id}/status`, v) });
      if (r) { toast(`Marked ${st.toLowerCase()}`, 'ok'); go(`#/shipments/${id}`); }
      return;
    }
    act(() => api('POST', `/shipments/${id}/status`, { status: st }), st === 'CONFIRMED' ? 'Booking confirmed - HBL issued' : 'Updated');
  });
  on(root, 'click', '[data-act=edit]', async () => {
    const r = await formModal({ title: `Edit ${s.booking_no}`, size: 'wide', fields: shipmentFields().filter((f) => f.name !== 'cargo_type' || !s.containers.length), values: s, onSubmit: (v) => api('PUT', `/shipments/${id}`, v) });
    if (r) { toast('Saved', 'ok'); go(`#/shipments/${id}`); }
  });
  on(root, 'click', '[data-act=addcont]', async () => {
    const empties = (await api('GET', '/containers?group=EMPTY')).rows.filter((c) => c.status === 'EMPTY_AVAILABLE');
    const lcl = s.cargo_type === 'LCL' && s.consol_id ? (await api('GET', '/containers')).rows.filter((c) => c.consol_id === s.consol_id && c.group !== 'EMPTY') : [];
    const all = [...empties, ...lcl];
    const r = await formModal({ title: 'Add container', size: '', submitLabel: 'Add',
      fields: [{ name: 'container_id', label: 'Container', type: 'combo', required: true, options: () => all.map((c) => [c.id, `${c.container_no} - ${c.type_code} - ${c.status_label}${c.location ? ' @ ' + c.location : ''}`]), span: 4, hint: 'empty containers only' },
        { name: 'seal_no', label: 'Seal no.', span: 2 }, { name: 'packages', label: 'Packages', type: 'number', span: 1 }, { name: 'weight_kg', label: 'Weight (kg)', type: 'number', span: 1 }, { name: 'cbm', label: 'CBM', type: 'number', span: 1 }],
      onSubmit: (v) => api('POST', `/shipments/${id}/containers`, v) });
    if (r) { toast('Container added', 'ok'); go(`#/shipments/${id}`); }
  });
  on(root, 'click', '[data-rm]', async (_e, el) => { if (await confirmBox('Remove this container from the shipment?')) act(() => api('DELETE', `/shipments/${id}/containers/${el.dataset.rm}`), 'Container removed'); });
}

function financeCard(s) {
  const p = s.profit || { income: 0, expense: 0, profit: 0 };
  const canW = can('finance', 'write');
  return `<div class="card"><div class="card-h"><h2>Charges &amp; documents</h2>${canW ? `<a class="btn sm" href="#/documents/new?shipment_id=${s.id}&type=INV">+ Invoice</a><a class="btn sm" href="#/documents/new?shipment_id=${s.id}&type=BILL">+ Bill</a>` : ''}</div>
    ${tbl({ rows: s.documents || [], compact: true, empty: 'No invoices or bills yet.', cols: [
      { label: 'Document', render: (d) => link(`#/documents/${d.id}`, d.doc_no || 'Draft') + `<div class="muted small">${esc(docType(d.doc_type))} &middot; ${esc(d.party_name)}</div>` },
      { label: 'Total', num: true, render: (d) => `${money(d.total)} <span class="muted small">${esc(d.currency)}</span>` }, { label: 'Status', render: (d) => docBadge(d.status) }] })}
    <div class="card-b" style="border-top:1px solid var(--line)"><div class="grid g3">
      <div><div class="muted small">Income</div><b>${money(p.income)}</b></div><div><div class="muted small">Expense</div><b>${money(p.expense)}</b></div>
      <div><div class="muted small">Profit</div><b>${signed(p.profit)}</b></div></div><div class="muted small" style="margin-top:6px">${esc(s.base_currency)}, posted documents excluding VAT</div></div></div>`;
}
