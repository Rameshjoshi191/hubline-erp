import { api, esc, money, int, num, date, tbl, shipBadge, link, can, state } from '../core.js';
import { icon } from '../icons.js';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const PIPE = [['BOOKED', 'Booked', '#3b82f6'], ['CONFIRMED', 'Confirmed', '#6366f1'], ['SAILED', 'At sea', '#f59e0b'], ['ARRIVED', 'Arrived', '#f97316'], ['DELIVERED', 'Delivered', '#10b981']];

const donut = (parts, centre, label) => {
  const total = parts.reduce((a, p) => a + p.v, 0);
  const R = 58, C = 2 * Math.PI * R; let off = 0;
  const arcs = total ? parts.filter((p) => p.v > 0).map((p) => {
    const len = (p.v / total) * C; const el = `<circle cx="74" cy="74" r="${R}" fill="none" stroke="${p.c}" stroke-width="18" stroke-dasharray="${Math.max(len - 2, 0.1)} ${C}" stroke-dashoffset="${-off}"/>`; off += len; return el;
  }).join('') : '';
  return `<div class="donut"><svg viewBox="0 0 148 148"><circle cx="74" cy="74" r="${R}" fill="none" stroke="var(--grey-bg)" stroke-width="18"/>${arcs}</svg><div class="mid"><b>${esc(centre)}</b><span>${esc(label)}</span></div></div>`;
};

export async function dashboard(root) {
  const d = await api('GET', '/dashboard');
  const st = Object.fromEntries(d.shipments_by_status.map((x) => [x.status, x.n]));
  const open = PIPE.reduce((a, [k]) => a + (st[k] || 0), 0);
  const cur = d.base_currency;
  const delta = d.this_month.teu - d.last_month.teu;
  const maxTeu = Math.max(1, ...d.monthly.map((m) => m.teu));
  const hour = new Date().getHours();
  const first = (state.me.full_name || '').split(/\s+/)[0];
  const hello = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  const kpi = (ic, tone, k, v, s = '', href = '', cls = '') => `<${href ? `a href="${href}"` : 'div'} class="card kpi"><div class="tile ${tone}">${icon(ic, 22)}</div><div><div class="k">${k}</div><div class="v ${cls}">${v}</div><div class="s">${s}</div></div></${href ? 'a' : 'div'}>`;
  const actions = [
    can('shipments', 'write') ? '<a class="btn primary" href="#/shipments?new=1">' + icon('plus', 16) + ' New booking</a>' : '',
    can('finance', 'write') ? '<a class="btn" href="#/documents/new?type=INV">' + icon('invoice', 16) + ' New invoice</a>' : '',
    can('reports', 'read') ? '<a class="btn" href="#/inventory-report">' + icon('report', 16) + ' Daily inventory report</a>' : '',
  ].join('');
  const c = d.containers;

  root.innerHTML = `<div class="hero"><div class="grow"><h1>${hello}, ${esc(first)}</h1><p>${esc(state.lk.settings.company_name)} &middot; ${date(d.today)} &middot; ${int(open)} open shipment${open === 1 ? '' : 's'}, ${int(c.total)} containers in inventory${c.overdue ? `, <b>${int(c.overdue)} past free time</b>` : ''}</p></div><div class="pill-row">${actions}</div></div>

  <div class="grid g4" style="margin-bottom:16px">
    ${kpi('package', 'blue', 'Open shipments', int(open), `${st.BOOKED || 0} booked &middot; ${st.CONFIRMED || 0} confirmed &middot; ${st.SAILED || 0} at sea`, '#/shipments')}
    ${kpi('ship', 'teal', 'TEU this month', num(d.this_month.teu), `${d.this_month.n} shipments &middot; ${delta >= 0 ? '+' : ''}${num(delta)} vs last month`, '#/reports')}
    ${kpi('container', 'purple', 'Containers in inventory', int(c.total), `${c.empty} empty &middot; ${c.laden} laden &middot; ${c.out_of_service} out of service`, '#/containers')}
    ${kpi('alert', c.overdue ? 'red' : 'green', 'Past free time', int(c.overdue), `${c.expiring} more expire within 2 days`, '#/containers?overdue=1', c.overdue ? 'neg' : '')}
  </div>
  ${d.finance ? `<div class="grid g4" style="margin-bottom:16px">
    ${kpi('trend', 'green', 'Receivable', money(d.finance.receivable), `${cur} equivalent, open debit items`, '#/ageing')}
    ${kpi('clock', d.finance.overdue_receivable > 0 ? 'red' : 'green', 'Overdue receivable', money(d.finance.overdue_receivable), `${cur} equivalent past due date`, '#/ageing', d.finance.overdue_receivable > 0 ? 'neg' : '')}
    ${kpi('wallet', 'amber', 'Payable', money(d.finance.payable), `${cur} equivalent, bills &amp; commission owed`, '#/documents?side=payable')}
    ${kpi('pen', 'blue', 'Awaiting posting', int(d.finance.draft_documents + d.finance.draft_commissions), `${d.finance.draft_documents} draft documents &middot; ${d.finance.draft_commissions} draft commission statements`, '#/documents?status=DRAFT')}
  </div>` : ''}

  <div class="grid g2" style="margin-bottom:16px">
    <div class="card"><div class="card-h"><h2>Shipment pipeline</h2><a class="btn sm" href="#/shipments">View all</a></div><div class="card-b">
      ${open ? `<div class="pipe">${PIPE.map(([k, , col]) => (st[k] ? `<i style="flex:${st[k]};background:${col}" title="${st[k]}"></i>` : '')).join('')}</div>` : '<div class="muted">No open shipments.</div>'}
      <div class="pipe-legend">${PIPE.map(([k, l, col]) => `<div><b>${int(st[k] || 0)}</b><i style="background:${col}"></i>${l}</div>`).join('')}</div></div></div>
    <div class="card"><div class="card-h"><h2>Container fleet</h2><a class="btn sm" href="#/containers">Inventory</a></div><div class="card-b">
      <div class="donut-wrap">${donut([{ v: c.empty, c: '#10b981' }, { v: c.laden, c: '#3b82f6' }, { v: c.out_of_service, c: '#ef4444' }], int(c.total), 'containers')}
        <div class="legend"><div><i style="background:#10b981"></i>Empty<b>${int(c.empty)}</b></div><div><i style="background:#3b82f6"></i>Laden<b>${int(c.laden)}</b></div><div><i style="background:#ef4444"></i>Out of service<b>${int(c.out_of_service)}</b></div>
          <div><i style="background:#f59e0b"></i>Past free time<b>${int(c.overdue)}</b></div></div></div></div></div>
  </div>

  <div class="split">
    <div>
      <div class="card"><div class="card-h"><h2>Monthly volume (TEU)</h2><span class="muted small">last 6 months, by sailing date</span></div>
        <div class="card-b"><div class="bars">${d.monthly.map((m) => `<div class="b"><em>${num(m.teu)}</em><i style="height:${Math.max(3, Math.round((m.teu / maxTeu) * 120))}px" title="${m.n} shipments"></i></div>`).join('')}</div>
          <div class="bar-x">${d.monthly.map((m) => `<span>${MONTHS[Number(m.month.slice(5)) - 1]}</span>`).join('')}</div></div></div>
      <div class="card"><div class="card-h"><h2>Recent shipments</h2><a class="btn sm" href="#/shipments">All shipments</a></div>
        ${tbl({ rows: d.recent_shipments, click: true, rowAttr: (r) => `data-go="#/shipments/${r.id}"`,
          cols: [{ label: 'Booking', render: (r) => `<b class="nowrap">${esc(r.booking_no)}</b><div class="muted small">${esc(r.hbl_no || 'no HBL yet')}</div>` },
            { label: 'Customer', render: (r) => esc(r.customer_name || '') }, { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` },
            { label: 'ETD', render: (r) => date(r.etd) }, { label: 'Status', render: (r) => shipBadge(r.status) }] })}</div>
    </div>
    <div>
      <div class="card"><div class="card-h"><h2>Containers past free time</h2></div>
        ${d.overdue_containers.length ? tbl({ compact: true, rows: d.overdue_containers, cols: [
          { label: 'Container', render: (r) => link(`#/containers/${r.id}`, r.container_no) }, { label: 'Location', render: (r) => esc(r.location || '') },
          { label: 'Days over', num: true, render: (r) => `<span class="neg">${-r.free_days_left}</span>` }] }) : '<div class="empty">No containers are past their free time.</div>'}</div>
      ${d.agreements ? `<div class="card"><div class="card-h"><h2>Agency agreements</h2></div><div class="card-b">
        ${d.agreements.expired.map((a) => `<div class="alert bad"><b>${esc(a.agent_name)}</b> &mdash; ${esc(a.agreement_no)} expired ${date(a.end_date)} ${link('#/agreements/' + a.id, 'Open')}</div>`).join('')}
        ${d.agreements.expiring.map((a) => `<div class="alert warn"><b>${esc(a.agent_name)}</b> &mdash; ${esc(a.agreement_no)} expires ${date(a.end_date)} ${link('#/agreements/' + a.id, 'Open')}</div>`).join('')}
        ${!d.agreements.expired.length && !d.agreements.expiring.length ? '<div class="muted">No agreements expire in the next 60 days.</div>' : ''}</div></div>` : ''}
    </div>
  </div>`;
}
