import { api, download, state, esc, $, on, qs, tbl, pageHead, money, num, date, dt, badge, formModal, confirmBox, toast, opts, can, loadLookups, go, debounce, todayStr, kv, formHtml, readForm } from '../core.js';

const SECTIONS = {
  company: 'Company & settings', users: 'Users & roles', ports: 'Ports', 'container-types': 'Container types', charges: 'Charge codes', currencies: 'Currencies & rates', audit: 'Audit log',
};

export async function setup(root, { section }) {
  const map = { company, users, ports, 'container-types': containerTypes, charges, currencies, audit };
  if (!map[section]) { root.innerHTML = '<div class="empty">Unknown setup page.</div>'; return; }
  await map[section](root);
}

// -------------------------------------------------------------- simple master CRUD (ports, container types, charge codes)
async function simpleMaster(root, { title, sub, endpoint, cols, fields, newValues = {}, noun }) {
  const canW = can('masters', 'write');
  root.innerHTML = `${pageHead(title, sub, canW ? `<button class="btn primary" data-new>+ New ${noun}</button>` : '')}<div class="toolbar"><input type="text" class="search" placeholder="Search…" data-q></div><div class="card" data-out></div>`;
  let rows = [];
  const load = async (q = '') => {
    rows = await api('GET', `/${endpoint}${qs({ q })}`);
    $('[data-out]', root).innerHTML = tbl({ rows, empty: 'Nothing here yet.', cols: [...cols, { label: 'Status', render: (r) => (r.active ? badge('Active', 'ok') : badge('Inactive', '')) },
      ...(canW ? [{ label: '', render: (r) => `<button class="btn sm ghost" data-edit="${r.id}">Edit</button><button class="btn sm ghost" data-del="${r.id}" title="Delete">&#10005;</button>` }] : [])] });
  };
  const refreshLookups = async () => { await loadLookups(); };
  root.addEventListener('input', debounce((e) => { if (e.target.matches('[data-q]')) load(e.target.value).catch((x) => toast(x.message, 'bad')); }));
  on(root, 'click', '[data-new]', async () => { const r = await formModal({ title: `New ${noun}`, fields, values: { active: 1, ...newValues }, onSubmit: (v) => api('POST', `/${endpoint}`, v) }); if (r) { await refreshLookups(); toast('Added', 'ok'); load(); } });
  on(root, 'click', '[data-edit]', async (_e, el) => { const row = rows.find((x) => String(x.id) === el.dataset.edit); const r = await formModal({ title: `Edit ${noun}`, fields, values: row, onSubmit: (v) => api('PUT', `/${endpoint}/${row.id}`, v) }); if (r) { await refreshLookups(); toast('Saved', 'ok'); load(); } });
  on(root, 'click', '[data-del]', async (_e, el) => { if (await confirmBox(`Delete this ${noun}? If it is already used you will be asked to mark it inactive instead.`, { danger: true, ok: 'Delete' })) { try { await api('DELETE', `/${endpoint}/${el.dataset.del}`); await refreshLookups(); load(); } catch (e) { toast(e.message, 'bad'); } } });
  await load();
}
const ports = (root) => simpleMaster(root, { title: 'Ports', sub: 'UN/LOCODE port list used in bookings, tariffs and commission rules', endpoint: 'ports', noun: 'port',
  cols: [{ label: 'Code', render: (r) => `<span class="mono"><b>${esc(r.code)}</b></span>` }, { label: 'Port', key: 'name' }, { label: 'Country', key: 'country' }],
  fields: [{ name: 'code', label: 'UN/LOCODE', required: true, span: 1, hint: 'e.g. AEJEA' }, { name: 'name', label: 'Port name', required: true, span: 2 }, { name: 'country', label: 'Country', span: 1 }, { name: 'active', label: 'Active', type: 'checkbox' }] });
const containerTypes = (root) => simpleMaster(root, { title: 'Container types', sub: 'Sizes and TEU factors used in inventory, tariffs and commission', endpoint: 'container-types', noun: 'container type',
  cols: [{ label: 'Code', render: (r) => `<b>${esc(r.code)}</b>` }, { label: 'Description', key: 'description' }, { label: 'Size (ft)', num: true, key: 'size_ft' }, { label: 'TEU', num: true, key: 'teu' }, { label: 'Reefer', render: (r) => (r.is_reefer ? 'Yes' : '') }],
  fields: [{ name: 'code', label: 'Code', required: true }, { name: 'description', label: 'Description', span: 3 }, { name: 'size_ft', label: 'Size (ft)', type: 'number', required: true }, { name: 'teu', label: 'TEU factor', type: 'number', required: true }, { name: 'is_reefer', label: 'Reefer', type: 'checkbox' }, { name: 'active', label: 'Active', type: 'checkbox' }], newValues: { size_ft: 20, teu: 1 } });
const charges = (root) => simpleMaster(root, { title: 'Charge codes', sub: 'Standard charges for invoices and bills. The default VAT rate pre-fills document lines - confirm the correct treatment with your accountant.', endpoint: 'charge-codes', noun: 'charge code',
  cols: [{ label: 'Code', render: (r) => `<b>${esc(r.code)}</b>` }, { label: 'Name', key: 'name' }, { label: 'Category', key: 'category' }, { label: 'Side', key: 'side' }, { label: 'Default VAT %', num: true, render: (r) => num(r.vat_rate) }],
  fields: [{ name: 'code', label: 'Code', required: true }, { name: 'name', label: 'Name', required: true, span: 3 }, { name: 'category', label: 'Category', type: 'select', noEmpty: true, options: [['FREIGHT', 'Freight (used for freight-based commission)'], ['ORIGIN', 'Origin'], ['DESTINATION', 'Destination'], ['DOC', 'Documentation'], ['OTHER', 'Other']], span: 2 },
    { name: 'side', label: 'Used on', type: 'select', noEmpty: true, options: [['BOTH', 'Invoices & bills'], ['INCOME', 'Invoices'], ['EXPENSE', 'Bills']] }, { name: 'vat_rate', label: 'Default VAT %', type: 'number', min: 0, max: 100 }, { name: 'active', label: 'Active', type: 'checkbox' }], newValues: { category: 'OTHER', side: 'BOTH', vat_rate: 0 } });

// -------------------------------------------------------------- currencies & exchange rates
async function currencies(root) {
  const canW = can('masters', 'write');
  const base = state.lk.settings.base_currency;
  root.innerHTML = `${pageHead('Currencies & exchange rates', `Base (accounting) currency is <b>${esc(base)}</b>. A rate is how many ${esc(base)} one unit of the currency is worth. The latest rate on or before a document's date is used when it is posted.`, canW ? '<button class="btn primary" data-rate>+ Set rate</button><button class="btn" data-cur>+ New currency</button>' : '')}
    <div class="split"><div class="card"><div class="card-h"><h2>Currencies</h2></div><div data-cur-out></div></div><div class="card"><div class="card-h"><h2>Rate history</h2></div><div data-hist></div></div></div>`;
  const load = async () => {
    const cur = await api('GET', '/currencies'), hist = await api('GET', '/exchange-rates');
    $('[data-cur-out]', root).innerHTML = tbl({ rows: cur, compact: true, cols: [{ label: 'Code', render: (c) => `<b>${esc(c.code)}</b>` }, { label: 'Name', key: 'name' }, { label: `Latest rate (${esc(base)})`, num: true, render: (c) => c.rate ? `${num(c.rate)}<div class="muted small">${date(c.rate_date)}</div>` : '<span class="badge warn">no rate</span>' }] });
    $('[data-hist]', root).innerHTML = tbl({ rows: hist, compact: true, empty: 'No rates.', cols: [{ label: 'Effective', render: (h) => date(h.effective_date) }, { label: 'Currency', key: 'currency' }, { label: 'Rate', num: true, render: (h) => num(h.rate) }, ...(canW ? [{ label: '', render: (h) => h.currency === base ? '' : `<button class="btn sm ghost" data-delrate="${h.id}">&#10005;</button>` }] : [])] });
  };
  on(root, 'click', '[data-rate]', async () => { const r = await formModal({ title: 'Set exchange rate', size: 'narrow', fields: [{ name: 'currency', label: 'Currency', type: 'select', noEmpty: true, options: () => opts.currencies().filter(([v]) => v !== base), span: 2 }, { name: 'rate', label: `Rate (${base} per 1 unit)`, type: 'number', required: true, min: 0, step: 'any', span: 2 }, { name: 'effective_date', label: 'Effective from', type: 'date', span: 4 }], values: { effective_date: todayStr() }, onSubmit: (v) => api('POST', '/exchange-rates', v) }); if (r) { await loadLookups(); toast('Rate saved', 'ok'); load(); } });
  on(root, 'click', '[data-cur]', async () => { const r = await formModal({ title: 'New currency', size: 'narrow', fields: [{ name: 'code', label: 'ISO code', required: true, span: 1, placeholder: 'GBP' }, { name: 'name', label: 'Name', span: 3 }], onSubmit: (v) => api('POST', '/currencies', v) }); if (r) { await loadLookups(); toast('Currency added - now set its rate', 'ok'); load(); } });
  on(root, 'click', '[data-delrate]', async (_e, el) => { if (await confirmBox('Delete this rate? Posted documents keep the rate they were posted with.', { danger: true, ok: 'Delete' })) { await api('DELETE', `/exchange-rates/${el.dataset.delrate}`); await loadLookups(); load(); } });
  await load();
}

// -------------------------------------------------------------- company settings
async function company(root) {
  const s = await api('GET', '/settings');
  const canW = can('settings', 'write');
  const fields = [
    { section: 'Company (printed on documents)' },
    { name: 'company_name', label: 'Company name', span: 2, required: true }, { name: 'company_tax_no', label: 'Tax registration no. (TRN)', span: 2 },
    { name: 'company_address', label: 'Address', type: 'textarea', rows: 2, span: 2 }, { name: 'company_phone', label: 'Phone' }, { name: 'company_email', label: 'Email' },
    { name: 'company_bank', label: 'Bank details for remittance', type: 'textarea', rows: 3, span: 4, hint: 'printed on invoices' },
    { section: 'Accounting' },
    { name: 'base_currency', label: 'Base currency', type: 'select', options: opts.currencies, noEmpty: true, hint: 'locked once documents are posted' }, { name: 'default_vat', label: 'Standard VAT %', type: 'number', min: 0, max: 100 },
    { name: 'default_free_days', label: 'Default free days at destination', type: 'number', min: 0, hint: 'pre-fills the arrival dialog' },
    { section: 'Document text' },
    { name: 'invoice_footer', label: 'Invoice footer', type: 'textarea', rows: 2, span: 4 }, { name: 'hbl_terms', label: 'HBL terms & conditions text', type: 'textarea', rows: 4, span: 4, hint: 'printed on the house bill of lading - use your registered BL terms' },
  ];
  root.innerHTML = `${pageHead('Company & settings', 'Details printed on invoices, statements and bills of lading')}<div class="card"><div class="card-b"><div data-form></div>${canW ? '<div class="toolbar" style="margin-top:14px"><button class="btn primary" data-save>Save settings</button></div>' : ''}</div></div>`;
  $('[data-form]', root).innerHTML = formHtml(fields.map((f) => (canW ? f : { ...f, disabled: true })), s);
  on(root, 'click', '[data-save]', async () => { try { await api('PUT', '/settings', readForm(root, fields)); await loadLookups(); toast('Settings saved', 'ok'); } catch (e) { toast(e.message, 'bad'); } });
  if (canW) {
    root.insertAdjacentHTML('beforeend', `<div class="card"><div class="card-h"><h2>Data &amp; backup</h2></div><div class="card-b">
      <p style="margin-top:0">Download a complete copy of the database (all bookings, containers, agents, invoices and users). Keep backups somewhere safe and take one regularly - especially before updating the system.</p>
      <button class="btn" data-backup>Download database backup</button></div></div>`);
    on(root, 'click', '[data-backup]', () => download('/backup'));
  }
}

// -------------------------------------------------------------- users
async function users(root) {
  const canW = can('users', 'write');
  root.innerHTML = `${pageHead('Users & roles', 'Who can sign in and what each role may do', canW ? '<button class="btn primary" data-new>+ New user</button>' : '')}
    <div class="card"><div class="card-h"><h2>Role permissions</h2></div><div class="tbl-wrap"><table class="t compact"><thead><tr><th>Role</th><th>Can do</th></tr></thead><tbody>
      <tr><td><b>Administrator</b></td><td>Everything, including users, settings and the audit log</td></tr>
      <tr><td><b>Management</b></td><td>Read-only view of all operations, agents, finance, reports and the audit log</td></tr>
      <tr><td><b>Operations</b></td><td>Bookings, consolidations, container inventory and movements; can add parties and master data. Does not see invoices, statements or profit</td></tr>
      <tr><td><b>Documentation</b></td><td>Bookings and bills of lading; adds parties; read-only containers</td></tr>
      <tr><td><b>Accounts</b></td><td>Invoices, bills, receipts, payments, statements, ageing and agency commission; read-only operations and agreements</td></tr>
      <tr><td><b>Sales / agent liaison</b></td><td>Customers, agents, agency agreements, commission rules and tariffs; creates bookings; reads statements and commission</td></tr></tbody></table></div></div>
    <div class="card"><div class="card-h"><h2>Users</h2></div><div data-out></div></div>`;
  let rows = [];
  const roleOpts = () => Object.entries(state.lk.roles);
  const load = async () => {
    rows = await api('GET', '/users');
    $('[data-out]', root).innerHTML = tbl({ rows, cols: [{ label: 'Username', render: (u) => `<b>${esc(u.username)}</b>` }, { label: 'Name', key: 'full_name' }, { label: 'Email', key: 'email' }, { label: 'Role', render: (u) => esc(state.lk.roles[u.role] || u.role) },
      { label: 'Status', render: (u) => (u.active ? badge('Active', 'ok') : badge('Disabled', 'bad')) + (u.must_change_pw ? ' ' + badge('must change password', 'warn') : '') }, ...(canW ? [{ label: '', render: (u) => `<button class="btn sm ghost" data-edit="${u.id}">Edit</button>` }] : [])] });
  };
  on(root, 'click', '[data-new]', async () => { const r = await formModal({ title: 'New user', fields: [{ name: 'username', label: 'Username', required: true, span: 2, autocomplete: 'off' }, { name: 'full_name', label: 'Full name', required: true, span: 2 }, { name: 'email', label: 'Email', type: 'email', span: 2 }, { name: 'role', label: 'Role', type: 'select', options: roleOpts, noEmpty: true, span: 2 }, { name: 'password', label: 'Initial password', type: 'password', required: true, span: 4, hint: 'at least 8 characters - the user must change it at first sign-in', autocomplete: 'new-password' }], values: { role: 'operations' }, onSubmit: (v) => api('POST', '/users', v) }); if (r) { toast('User created', 'ok'); load(); } });
  on(root, 'click', '[data-edit]', async (_e, el) => { const u = rows.find((x) => String(x.id) === el.dataset.edit); const r = await formModal({ title: `Edit ${u.username}`, fields: [{ name: 'full_name', label: 'Full name', required: true, span: 2 }, { name: 'email', label: 'Email', type: 'email', span: 2 }, { name: 'role', label: 'Role', type: 'select', options: roleOpts, noEmpty: true, span: 2 }, { name: 'active', label: 'Active (can sign in)', type: 'checkbox', span: 2 }, { name: 'password', label: 'Reset password', type: 'password', span: 4, hint: 'leave blank to keep the current one; the user must change a reset password', autocomplete: 'new-password' }], values: u, onSubmit: (v) => { if (!v.password) delete v.password; return api('PUT', `/users/${u.id}`, v); } }); if (r) { toast('Saved', 'ok'); load(); } });
  await load();
}

// -------------------------------------------------------------- audit
async function audit(root) {
  const f = { q: '', entity: '' };
  root.innerHTML = `${pageHead('Audit log', 'Who did what, and when (latest 300 events)')}<div class="toolbar"><input type="text" class="search" placeholder="Search detail or record id…" data-f="q">
    <select data-f="entity"><option value="">All records</option>${['shipment', 'consol', 'container', 'document', 'payment', 'allocation', 'commission', 'agreement', 'commission_rule', 'party', 'tariff', 'user', 'settings', 'exchange_rate'].map((e) => `<option>${e}</option>`).join('')}</select></div><div class="card" data-out></div>`;
  const load = async () => {
    const rows = await api('GET', '/audit' + qs(f));
    $('[data-out]', root).innerHTML = tbl({ rows, compact: true, empty: 'No events.', cols: [{ label: 'When (UTC)', render: (r) => `<span class="nowrap small">${dt(r.ts)}</span>` }, { label: 'User', key: 'username' }, { label: 'Action', render: (r) => badge(r.action, '') }, { label: 'Record', render: (r) => `${esc(r.entity)} ${esc(r.entity_id || '')}` }, { label: 'Detail', render: (r) => `<span class="small mono" style="word-break:break-all">${esc(r.detail || '')}</span>` }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  await load();
}
