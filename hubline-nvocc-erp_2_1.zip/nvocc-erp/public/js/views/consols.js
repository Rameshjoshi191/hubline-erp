import { api, esc, $, on, qs, tbl, pageHead, num, int, date, shipBadge, consolBadge, formModal, confirmBox, toast, opts, can, kv, link, todayStr, go, state, debounce } from '../core.js';

const fields = () => [
  { name: 'mbl_no', label: 'Master BL no.', span: 2 }, { name: 'carrier_id', label: 'Carrier / line', type: 'combo', options: () => opts.parties('carrier'), span: 2 },
  { name: 'vessel', label: 'Vessel', span: 2 }, { name: 'voyage', label: 'Voyage', span: 2 },
  { name: 'pol_id', label: 'Port of loading', type: 'combo', options: opts.ports, span: 2 }, { name: 'pod_id', label: 'Port of discharge', type: 'combo', options: opts.ports, span: 2 },
  { name: 'cutoff_date', label: 'Cargo cut-off', type: 'date' }, { name: 'etd', label: 'ETD', type: 'date' }, { name: 'eta', label: 'ETA', type: 'date' },
  { name: 'remarks', label: 'Remarks', type: 'textarea', rows: 2, span: 4 },
];

export async function list(root, _p, query) {
  const f = { q: '', status: query.status || '', open: '' };
  const canW = can('shipments', 'write');
  root.innerHTML = `${pageHead('Master BL / consolidation', 'Group house shipments onto one master bill of lading and vessel voyage', canW ? '<button class="btn primary" data-act="new">+ New consolidation</button>' : '')}
    <div class="toolbar"><input type="text" class="search" placeholder="Search consol no., MBL, vessel, carrier…" data-f="q">
      <select data-f="status"><option value="">All statuses</option>${['PLANNED', 'CLOSED', 'SAILED', 'ARRIVED', 'COMPLETED', 'CANCELLED'].map((s) => `<option value="${s}">${s[0] + s.slice(1).toLowerCase()}</option>`).join('')}</select></div>
    <div class="card" data-out></div>`;
  const out = $('[data-out]', root);
  const load = async () => {
    const rows = await api('GET', '/consols' + qs(f));
    out.innerHTML = tbl({ rows, click: true, empty: 'No consolidations yet.', rowAttr: (r) => `data-go="#/consols/${r.id}"`, cols: [
      { label: 'Consol / MBL', render: (r) => `<b>${esc(r.consol_no)}</b><div class="muted small">${esc(r.mbl_no || 'MBL not entered')}</div>` },
      { label: 'Carrier', render: (r) => esc(r.carrier_name || '') }, { label: 'Vessel / voyage', render: (r) => esc([r.vessel, r.voyage].filter(Boolean).join(' / ')) },
      { label: 'Route', render: (r) => `${esc(r.pol_name || '?')} &rarr; ${esc(r.pod_name || '?')}` }, { label: 'ETD', render: (r) => date(r.etd) }, { label: 'ETA', render: (r) => date(r.eta) },
      { label: 'Shipments', num: true, render: (r) => r.shipment_count }, { label: 'CBM', num: true, render: (r) => num(r.total_cbm) }, { label: 'Status', render: (r) => consolBadge(r.status) }] });
  };
  const reload = debounce(() => load().catch((e) => toast(e.message, 'bad')));
  root.addEventListener('input', (e) => { const k = e.target.dataset.f; if (k) { f[k] = e.target.value; reload(); } });
  on(root, 'click', '[data-act=new]', async () => {
    const r = await formModal({ title: 'New consolidation', size: 'wide', fields: fields(), onSubmit: (v) => api('POST', '/consols', v) });
    if (r) { toast(`${r.consol_no} created`, 'ok'); go(`#/consols/${r.id}`); }
  });
  await load();
}

export async function detail(root, { id }) {
  const k = await api('GET', `/consols/${id}`);
  const canW = can('shipments', 'write');
  const pre = ['PLANNED', 'CLOSED'].includes(k.status);
  const actions = [];
  if (canW) {
    if (k.status === 'PLANNED') actions.push('<button class="btn" data-st="CLOSED">Close for cargo</button>');
    if (pre) actions.push('<button class="btn primary" data-st="SAILED">Mark sailed</button>');
    if (k.status === 'SAILED') actions.push('<button class="btn primary" data-st="ARRIVED">Mark arrived</button>');
    if (k.status === 'ARRIVED') actions.push('<button class="btn primary" data-st="COMPLETED">Complete</button>');
    if (k.status === 'CLOSED') actions.push('<button class="btn" data-st="PLANNED">Re-open</button>');
    if (pre && !k.shipments.length) actions.push('<button class="btn danger" data-st="CANCELLED">Cancel</button>');
    if (!['COMPLETED', 'CANCELLED'].includes(k.status)) actions.push('<button class="btn" data-act="edit">Edit</button>');
    if (pre) actions.push('<button class="btn" data-act="add">+ Add shipment</button>');
  }
  root.innerHTML = `${pageHead(`${esc(k.consol_no)} ${consolBadge(k.status)}`, `MBL ${esc(k.mbl_no || 'not entered')} &middot; ${esc(k.carrier_name || 'no carrier')}`, actions.join(''), '<a href="#/consols">Consolidations</a> /')}
    <div class="grid g2" style="margin-bottom:16px"><div class="card"><div class="card-h"><h2>Voyage</h2></div><div class="card-b">${kv([['Vessel / voyage', esc([k.vessel, k.voyage].filter(Boolean).join(' / '))],
      ['Route', `${esc(k.pol_name || '?')} &rarr; ${esc(k.pod_name || '?')}`], ['Cargo cut-off', date(k.cutoff_date)], ['ETD', date(k.etd)], ['ETA', date(k.eta)], ['Remarks', esc(k.remarks)]])}</div></div>
      <div class="card"><div class="card-h"><h2>Load summary</h2></div><div class="card-b grid g2">
        <div><div class="muted small">House shipments</div><div class="stat"><div class="v">${k.shipments.length}</div></div></div><div><div class="muted small">Containers / TEU</div><div class="stat"><div class="v">${k.containers.length} / ${num(k.totals.teu)}</div></div></div>
        <div><div class="muted small">Volume</div><b>${num(k.totals.cbm)} CBM</b></div><div><div class="muted small">Weight / packages</div><b>${int(k.totals.weight)} kg / ${int(k.totals.packages)}</b></div></div></div></div>
    <div class="card"><div class="card-h"><h2>House shipments</h2></div>${tbl({ rows: k.shipments, click: true, empty: 'No shipments on this master BL yet.', rowAttr: (r) => `data-go="#/shipments/${r.id}"`, cols: [
      { label: 'Booking / HBL', render: (r) => `<b>${esc(r.booking_no)}</b><div class="muted small">${esc(r.hbl_no || 'HBL not issued')}</div>` }, { label: 'Customer', render: (r) => esc(r.customer_name || '') },
      { label: 'Consignee', render: (r) => esc(r.consignee_name || '') }, { label: 'Agent', render: (r) => esc(r.agent_name || '') }, { label: 'Goods', render: (r) => esc(r.commodity || '') },
      { label: 'Pkgs', num: true, render: (r) => int(r.packages) }, { label: 'kg', num: true, render: (r) => int(r.gross_weight) }, { label: 'CBM', num: true, render: (r) => num(r.cbm) },
      { label: 'Status', render: (r) => shipBadge(r.status) },
      ...(canW && pre ? [{ label: '', render: (r) => `<button class="btn sm ghost" data-rm="${r.id}" title="Remove from consolidation">&#10005;</button>` }] : [])] })}</div>
    <div class="card"><div class="card-h"><h2>Containers</h2></div>${tbl({ rows: k.containers, compact: true, empty: 'No containers allocated to the shipments yet.', cols: [
      { label: 'Container', render: (c) => link(`#/containers/${c.id}`, c.container_no) }, { label: 'Type', key: 'type_code' }, { label: 'Status', render: (c) => esc(c.status_label) }, { label: 'Location', render: (c) => esc(c.location || '') }] })}</div>`;

  const refresh = () => go(`#/consols/${id}`);
  on(root, 'click', '[data-st]', async (_e, el) => {
    const st = el.dataset.st;
    if (st === 'CANCELLED' && !(await confirmBox('Cancel this consolidation?', { danger: true, ok: 'Cancel it' }))) return;
    if (st === 'SAILED' || st === 'ARRIVED') {
      const r = await formModal({ title: st === 'SAILED' ? 'Vessel sailed' : 'Vessel arrived', size: 'narrow', submitLabel: 'Confirm',
        intro: `<p class="muted">${st === 'SAILED' ? `All ${k.shipments.length} confirmed house shipments will be marked sailed and their containers recorded on board.` : 'House shipments are marked arrived, containers discharged, and the free-time clock starts.'}</p>`,
        fields: [{ name: 'date', label: st === 'SAILED' ? 'Sailing date' : 'Arrival date', type: 'date', required: true }, ...(st === 'ARRIVED' ? [{ name: 'free_days', label: 'Free days at destination', type: 'number', min: 0 }] : [])],
        values: { date: (st === 'SAILED' ? k.etd : k.eta) || todayStr(), free_days: state.lk.settings.default_free_days || '' }, onSubmit: (v) => api('POST', `/consols/${id}/status`, { status: st, ...v }) });
      if (r) { toast('Updated', 'ok'); refresh(); }
      return;
    }
    try { await api('POST', `/consols/${id}/status`, { status: st }); toast('Updated', 'ok'); refresh(); } catch (e) { toast(e.message, 'bad'); }
  });
  on(root, 'click', '[data-act=edit]', async () => { const r = await formModal({ title: `Edit ${k.consol_no}`, size: 'wide', fields: fields(), values: k, onSubmit: (v) => api('PUT', `/consols/${id}`, v) }); if (r) { toast('Saved', 'ok'); refresh(); } });
  on(root, 'click', '[data-act=add]', async () => {
    const all = await api('GET', '/shipments?open=1');
    const cand = all.filter((s) => ['BOOKED', 'CONFIRMED'].includes(s.status) && !s.consol_id && (!k.pol_id || !s.pol_id || s.pol_id === k.pol_id) && (!k.pod_id || !s.pod_id || s.pod_id === k.pod_id));
    const r = await formModal({ title: 'Add shipment to consolidation', size: '', submitLabel: 'Add', intro: `<p class="muted">Only booked or confirmed shipments on the same route that are not yet on a master BL are listed (${cand.length}).</p>`,
      fields: [{ name: 'shipment_id', label: 'Shipment', type: 'combo', required: true, span: 4, options: () => cand.map((s) => [s.id, `${s.booking_no} - ${s.customer_name || '?'} - ${s.pol_name || '?'} > ${s.pod_name || '?'} (${s.cargo_type})`]) }],
      onSubmit: (v) => api('POST', `/consols/${id}/shipments`, v) });
    if (r) { toast('Shipment added', 'ok'); refresh(); }
  });
  on(root, 'click', '[data-rm]', async (_e, el) => { if (await confirmBox('Remove this shipment from the consolidation?')) { try { await api('DELETE', `/consols/${id}/shipments/${el.dataset.rm}`); refresh(); } catch (e) { toast(e.message, 'bad'); } } });
}
