// Shared helpers: API client, formatting, modal/forms/tables, lookups
export const state = { me: null, lk: null };

export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
export const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

// ------------------------------------------------------------------ API
export async function api(method, url, body) {
  let res;
  try {
    res = await fetch('/api' + url, { method, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'hubline-erp' }, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch (e) { throw new Error('Cannot reach the server. Check your connection and try again.'); }
  let data = null;
  const text = await res.text();
  try { data = text ? JSON.parse(text) : null; } catch { data = null; }
  if (!res.ok) {
    if (res.status === 401 && url !== '/login') window.dispatchEvent(new Event('auth-lost'));
    if (res.status === 403 && data && data.code === 'MUST_CHANGE_PW') window.dispatchEvent(new Event('must-change-pw'));
    const err = new Error((data && data.error) || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}
export const qs = (o) => { const p = new URLSearchParams(); for (const [k, v] of Object.entries(o || {})) if (v !== '' && v != null && v !== false) p.set(k, v); const s = p.toString(); return s ? '?' + s : ''; };
export const download = (url) => { window.location.href = '/api' + url; };

export async function loadLookups() { state.lk = await api('GET', '/lookups'); return state.lk; }
export const can = (mod, kind = 'read') => !!(state.me && state.me.perms[mod] && state.me.perms[mod][kind]);

// ------------------------------------------------------------------ formatting
const nf = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nf0 = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
const nf3 = new Intl.NumberFormat('en-US', { maximumFractionDigits: 3 });
export const money = (n) => (n === null || n === undefined || n === '' ? '' : nf.format(Number(n)));
export const num = (n) => (n === null || n === undefined || n === '' ? '' : nf3.format(Number(n)));
export const int = (n) => (n === null || n === undefined || n === '' ? '' : nf0.format(Number(n)));
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const date = (s) => { if (!s) return ''; const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s); return m ? `${Number(m[3])} ${MON[Number(m[2]) - 1]} ${m[1]}` : esc(s); };
export const dt = (s) => (s ? date(s) + ' ' + String(s).slice(11, 16) : '');
export const todayStr = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
export const addDaysStr = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
export const signed = (n, cur) => { const v = Number(n || 0); return `<span class="${v < 0 ? 'neg' : ''}">${v < 0 ? '(' + money(-v) + ')' : money(v)}${cur ? ' ' + esc(cur) : ''}</span>`; };

export function badge(text, kind = '') { return `<span class="badge ${kind}">${esc(text)}</span>`; }
const B = (map) => (k) => { const [t, c] = map[k] || [k, '']; return badge(t, c); };
export const shipBadge = B({ BOOKED: ['Booked', 'info'], CONFIRMED: ['Confirmed', 'info'], SAILED: ['Sailed', 'warn'], ARRIVED: ['Arrived', 'warn'], DELIVERED: ['Delivered', 'ok'], CLOSED: ['Closed', ''], CANCELLED: ['Cancelled', 'bad'] });
export const consolBadge = B({ PLANNED: ['Planned', 'info'], CLOSED: ['Closed for cargo', 'info'], SAILED: ['Sailed', 'warn'], ARRIVED: ['Arrived', 'warn'], COMPLETED: ['Completed', 'ok'], CANCELLED: ['Cancelled', 'bad'] });
export const docBadge = B({ DRAFT: ['Draft', 'warn'], POSTED: ['Posted', 'ok'], CANCELLED: ['Cancelled', 'bad'] });
export const agrBadge = B({ DRAFT: ['Draft', 'warn'], ACTIVE: ['Active', 'ok'], EXPIRED: ['Expired', 'bad'], TERMINATED: ['Terminated', ''] });
export const stmtBadge = B({ DRAFT: ['Draft', 'warn'], POSTED: ['Posted', 'ok'], CANCELLED: ['Cancelled', 'bad'] });
export const groupBadge = (g, label) => badge(label, { EMPTY: 'ok', LADEN: 'info', OUT_OF_SERVICE: 'bad', CLOSED: '' }[g] || '');
export const docType = (t) => (state.lk && state.lk.doc_labels[t]) || t;
export const yesno = (v) => (v ? 'Yes' : 'No');

// ------------------------------------------------------------------ lookup option lists
export const opts = {
  ports: () => state.lk.ports.map((p) => [p.id, `${p.name} (${p.code})`]),
  parties: (role) => state.lk.parties.filter((p) => !role || p['is_' + role]).map((p) => [p.id, `${p.name} [${p.code}]`]),
  types: () => state.lk.container_types.map((t) => [t.id, `${t.code} - ${t.description || ''}`]),
  charges: () => state.lk.charge_codes.map((c) => [c.id, `${c.code} - ${c.name}`]),
  currencies: () => state.lk.currencies.map((c) => [c.code, c.code]),
};
export const partyName = (id) => { const p = state.lk.parties.find((x) => x.id === Number(id)); return p ? p.name : ''; };

// ------------------------------------------------------------------ toast
export function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + kind; el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), kind === 'bad' ? 7000 : 3500);
}

// ------------------------------------------------------------------ modal
export function openModal({ title, body, footer = '', size = '', onMount }) {
  const ov = document.createElement('div');
  ov.className = 'overlay';
  ov.innerHTML = `<div class="dialog ${size}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="dialog-h"><h2>${esc(title)}</h2><button class="btn ghost sm" data-close aria-label="Close">&#10005;</button></div>
    <div class="dialog-b">${body}</div>${footer ? `<div class="dialog-f">${footer}</div>` : ''}</div>`;
  document.body.appendChild(ov);
  const prevOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
  const h = { el: ov, dialog: ov.firstElementChild, resolveClose: null };
  h.$ = (s) => $(s, ov); h.$$ = (s) => $$(s, ov);
  h.close = (val) => { document.removeEventListener('keydown', esc_); ov.remove(); document.body.style.overflow = prevOverflow; if (h.resolveClose) h.resolveClose(val === undefined ? null : val); };
  const esc_ = (e) => { if (e.key === 'Escape' && document.body.lastElementChild === ov) h.close(null); };
  document.addEventListener('keydown', esc_);
  ov.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) h.close(null); });
  h.done = new Promise((r) => { h.resolveClose = r; });
  if (onMount) onMount(h);
  const first = $('input:not([type=hidden]):not([disabled]), select, textarea', ov); if (first) first.focus();
  return h;
}

export async function confirmBox(message, { title = 'Please confirm', ok = 'Yes, continue', danger = false } = {}) {
  const h = openModal({ title, size: 'narrow', body: `<p style="margin:0">${esc(message)}</p>`,
    footer: `<button class="btn" data-close>Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" data-ok>${esc(ok)}</button>` });
  h.$('[data-ok]').addEventListener('click', () => h.close(true));
  h.$('[data-ok]').focus();
  return (await h.done) === true;
}

// ------------------------------------------------------------------ form builder
let uid = 0;
export function fieldHtml(f, value, formId) {
  if (f.section) return `<div class="form-h">${esc(f.section)}</div>`;
  const span = f.span ? ' s' + f.span : '';
  const id = `${formId}_${f.name}`;
  const v = value === undefined || value === null ? (f.def ?? '') : value;
  const label = `<span>${esc(f.label || f.name)}${f.required ? ' <b class="req">*</b>' : ''}${f.hint ? ` <em class="hint">${esc(f.hint)}</em>` : ''}</span>`;
  const dis = f.disabled ? ' disabled' : '';
  switch (f.type) {
    case 'textarea': return `<label class="f${span}">${label}<textarea id="${id}" name="${f.name}" rows="${f.rows || 3}"${dis}>${esc(v)}</textarea></label>`;
    case 'checkbox': return `<label class="chk${span}"><input type="checkbox" id="${id}" name="${f.name}" ${Number(v) || v === true ? 'checked' : ''}${dis}> <span>${esc(f.label)}</span></label>`;
    case 'select': {
      const o = (typeof f.options === 'function' ? f.options() : f.options) || [];
      return `<label class="f${span}">${label}<select id="${id}" name="${f.name}"${dis}>${f.noEmpty ? '' : `<option value="">${esc(f.empty || '—')}</option>`}${o.map(([val, text]) => `<option value="${esc(val)}" ${String(val) === String(v) ? 'selected' : ''}>${esc(text)}</option>`).join('')}</select></label>`;
    }
    case 'combo': {
      const o = (typeof f.options === 'function' ? f.options() : f.options) || [];
      const cur = o.find(([val]) => String(val) === String(v));
      return `<label class="f${span}">${label}<input type="text" id="${id}" name="${f.name}" list="${id}_dl" autocomplete="off" value="${esc(cur ? cur[1] : '')}" placeholder="${esc(f.placeholder || 'Type to search…')}"${dis}>
        <datalist id="${id}_dl">${o.map(([, text]) => `<option value="${esc(text)}"></option>`).join('')}</datalist></label>`;
    }
    default: {
      const type = ['number', 'date', 'password', 'email'].includes(f.type) ? f.type : 'text';
      return `<label class="f${span}">${label}<input type="${type}" id="${id}" name="${f.name}" value="${esc(v)}"${f.step ? ` step="${f.step}"` : type === 'number' ? ' step="any"' : ''}${f.min !== undefined ? ` min="${f.min}"` : ''}${f.max !== undefined ? ` max="${f.max}"` : ''}${f.placeholder ? ` placeholder="${esc(f.placeholder)}"` : ''}${f.autocomplete ? ` autocomplete="${f.autocomplete}"` : ''}${dis}></label>`;
    }
  }
}
export function formHtml(fields, values = {}, formId = 'f' + ++uid) {
  return `<div class="form-grid" data-form="${formId}">${fields.map((f) => fieldHtml(f, values[f.name], formId)).join('')}</div>`;
}
export function readForm(root, fields) {
  const out = {};
  for (const f of fields) {
    if (f.section || f.disabled) continue;
    const el = root.querySelector(`[name="${f.name}"]`);
    if (!el) continue;
    if (f.type === 'checkbox') out[f.name] = el.checked ? 1 : 0;
    else if (f.type === 'combo') {
      const o = (typeof f.options === 'function' ? f.options() : f.options) || [];
      const txt = el.value.trim();
      if (!txt) out[f.name] = '';
      else { const m = o.find(([, t]) => t === txt); if (!m) throw new Error(`${f.label || f.name}: please choose one of the suggestions from the list.`); out[f.name] = m[0]; }
    } else out[f.name] = el.value;
  }
  return out;
}
// Opens a form dialog; resolves with whatever onSubmit returns (truthy) or null if cancelled.
export function formModal({ title, fields, values = {}, submitLabel = 'Save', size = '', intro = '', onSubmit, extraFooter = '' }) {
  const formId = 'f' + ++uid;
  const h = openModal({
    title, size,
    body: `<div class="alert bad hidden" data-err></div>${intro}<form novalidate>${formHtml(fields, values, formId)}</form>`,
    footer: `${extraFooter}<button class="btn" data-close type="button">Cancel</button><button class="btn primary" data-submit type="button">${esc(submitLabel)}</button>`,
  });
  const err = h.$('[data-err]');
  const submit = async () => {
    err.classList.add('hidden');
    const btn = h.$('[data-submit]');
    try {
      const v = readForm(h.el, fields);
      btn.disabled = true;
      const r = await onSubmit(v, h);
      if (r !== false) h.close(r === undefined ? true : r);
    } catch (e) { err.textContent = e.message; err.classList.remove('hidden'); err.scrollIntoView({ block: 'nearest' }); }
    finally { btn.disabled = false; }
  };
  h.$('[data-submit]').addEventListener('click', submit);
  h.$('form').addEventListener('submit', (e) => { e.preventDefault(); submit(); });
  h.$('form').addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') { e.preventDefault(); submit(); } });
  return h.done;
}

// ------------------------------------------------------------------ table
// cols: [{ label, key, render:(row)=>html, num, cls, foot }]
export function tbl({ cols, rows, rowAttr, click = false, empty = 'Nothing to show yet.', foot, compact = false, cls = '' }) {
  if (!rows.length) return `<div class="empty">${esc(empty)}</div>`;
  const head = cols.map((c) => `<th class="${c.num ? 'num' : ''} ${c.cls || ''}">${esc(c.label)}</th>`).join('');
  const body = rows.map((r) => `<tr class="${click ? 'click' : ''}" ${rowAttr ? rowAttr(r) : ''}>${cols.map((c) => `<td class="${c.num ? 'num' : ''} ${c.cls || ''}">${c.render ? c.render(r) : esc(r[c.key])}</td>`).join('')}</tr>`).join('');
  return `<div class="tbl-wrap"><table class="t ${compact ? 'compact' : ''} ${cls}"><thead><tr>${head}</tr></thead><tbody>${body}</tbody>${foot ? `<tfoot>${foot}</tfoot>` : ''}</table></div>`;
}

export function on(root, evt, selector, handler) {
  root.addEventListener(evt, (e) => { const el = e.target.closest(selector); if (el && root.contains(el)) handler(e, el); });
}
export const pageHead = (title, sub = '', actions = '', crumbs = '') => `<div class="page-head"><div class="grow">${crumbs ? `<div class="crumbs">${crumbs}</div>` : ''}<h1>${title}</h1>${sub ? `<p>${sub}</p>` : ''}</div><div class="pill-row no-print">${actions}</div></div>`;
export const go = (hash) => { if (location.hash === hash) window.dispatchEvent(new HashChangeEvent('hashchange')); else location.hash = hash; };
export const kv = (pairs) => `<dl class="kv">${pairs.filter(Boolean).map(([k, v]) => `<dt>${esc(k)}</dt><dd>${v === undefined || v === null || v === '' ? '<span class="muted">—</span>' : v}</dd>`).join('')}</dl>`;
export const link = (href, text) => `<a href="${href}">${esc(text)}</a>`;
export const balancesHtml = (b) => { const e = Object.entries(b || {}).filter(([, v]) => Math.abs(v) > 0.004); return e.length ? e.map(([c, v]) => `<div class="nowrap">${signed(v)} <span class="muted small">${esc(c)}</span></div>`).join('') : '<span class="muted">—</span>'; };
