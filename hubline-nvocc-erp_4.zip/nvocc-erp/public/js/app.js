import { api, state, esc, $, $$, loadLookups, can, toast, on } from './core.js';
import { icon, logoMark, shipScene, containerBillboard } from './icons.js';

// ---- theme (light / dark / follow system), remembered per browser
const THEME_KEY = 'hubline-theme';
const getTheme = () => { try { return localStorage.getItem(THEME_KEY) || ''; } catch { return ''; } };
const applyTheme = (t) => { if (t) document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme; };
const isDark = () => (document.documentElement.dataset.theme ? document.documentElement.dataset.theme === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches);
applyTheme(getTheme());

// [label, href, permission ('module' or 'module:write'), icon, who] - who: 'staff' = hidden from external agents, 'agent' = shown to agents only
const NAV = [
  ['Overview', [['Dashboard', '#/dashboard', 'dashboard', 'dashboard']]],
  ['Containers', [
    ['Container enquiry', '#/track', 'containers', 'search'], ['Update movements', '#/movements', 'movements:write', 'bolt'],
    ['Container inventory', '#/containers', 'containers', 'container'], ['Daily inventory report', '#/inventory-report', 'reports', 'report', 'staff']]],
  ['Shipments', [
    ['Bills of lading', '#/bls', 'bl', 'contract'], ['Shipments / bookings', '#/shipments', 'shipments', 'package', 'staff'], ['Master BL / consolidation', '#/consols', 'shipments', 'layers', 'staff'],
    ['Vessel schedules', '#/schedules', 'schedules', 'ship']]],
  ['Agents & customers', [
    ['Agents', '#/agents', 'agreements', 'users'], ['Agency agreements', '#/agreements', 'agreements', 'contract'], ['Agency commission', '#/commissions', 'commission', 'percent'],
    ['Customers & parties', '#/parties', 'parties', 'building'], ['Rates / tariffs', '#/tariffs', 'tariffs', 'tag']]],
  ['Finance', [
    ['MRG - freight & margin', '#/mrg', 'mrg', 'trend'], ['Invoices & notes', '#/documents', 'finance', 'invoice'], ['Receipts & payments', '#/payments', 'finance', 'wallet'],
    ['Statement of account', '#/soa', 'soa', 'ledger'], ['Ageing', '#/ageing', 'finance', 'clock']]],
  ['Reports', [['Shipment register & profit', '#/reports', 'reports', 'chart']]],
  ['Setup', [
    ['Company & settings', '#/setup/company', 'settings', 'settings'], ['Users & roles', '#/setup/users', 'users', 'user'], ['Ports', '#/setup/ports', 'masters', 'anchor'],
    ['Container types', '#/setup/container-types', 'masters', 'container'], ['Charge codes', '#/setup/charges', 'masters', 'list'], ['Currencies & rates', '#/setup/currencies', 'masters', 'globe'],
    ['Audit log', '#/setup/audit', 'audit', 'shield']]],
];
const allowed = (perm) => { if (!perm) return true; const [m, k = 'read'] = perm.split(':'); return can(m, k); };

// pattern -> [permission, module, export]
const ROUTES = [
  ['dashboard', 'dashboard', './views/dashboard.js', 'dashboard'],
  ['track', 'containers', './views/track.js', 'enquiry'], ['track/:id', 'containers', './views/track.js', 'detail'],
  ['movements', 'movements:write', './views/movements.js', 'movements'],
  ['bls', 'bl', './views/bl.js', 'list'], ['bls/:id', 'bl', './views/bl.js', 'detail'],
  ['schedules', 'schedules', './views/schedules.js', 'list'],
  ['mrg', 'mrg', './views/mrg.js', 'page'],
  ['shipments', 'shipments', './views/shipments.js', 'list'], ['shipments/:id', 'shipments', './views/shipments.js', 'detail'],
  ['consols', 'shipments', './views/consols.js', 'list'], ['consols/:id', 'shipments', './views/consols.js', 'detail'],
  ['containers', 'containers', './views/containers.js', 'list'], ['containers/:id', 'containers', './views/containers.js', 'detail'],
  ['inventory-report', 'reports', './views/containers.js', 'report'],
  ['parties', 'parties', './views/parties.js', 'list'], ['parties/:id', 'parties', './views/parties.js', 'detail'],
  ['agents', 'agreements', './views/agents.js', 'list'], ['agents/:id', 'agreements', './views/agents.js', 'detail'],
  ['agreements', 'agreements', './views/agents.js', 'agreements'], ['agreements/:id', 'agreements', './views/agents.js', 'agreement'],
  ['commissions', 'commission', './views/commission.js', 'list'], ['commissions/:id', 'commission', './views/commission.js', 'detail'],
  ['tariffs', 'tariffs', './views/tariffs.js', 'list'],
  ['documents', 'finance', './views/finance.js', 'documents'], ['documents/:id', 'finance', './views/finance.js', 'doc'],
  ['payments', 'finance', './views/finance.js', 'payments'], ['soa', 'soa', './views/finance.js', 'soa'], ['ageing', 'finance', './views/finance.js', 'ageing'],
  ['reports', 'reports', './views/reports.js', 'reports'],
  ['setup/:section', null, './views/setup.js', 'setup'],
];
const PRINT_ROUTES = ['print/:kind/:id'];

const app = $('#app');

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [path, q] = raw.split('?');
  return { path: path || 'dashboard', query: Object.fromEntries(new URLSearchParams(q || '')) };
}
function match(pattern, path) {
  const a = pattern.split('/'), b = path.split('/');
  if (a.length !== b.length) return null;
  const params = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(':')) params[a[i].slice(1)] = decodeURIComponent(b[i]);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

// ---------------------------------------------------------------- login & password change
function showLogin(msg = '') {
  state.me = null;
  app.innerHTML = `<div class="login">
    <section class="login-art">${shipScene()}
      <div class="hero-art">${containerBillboard('/img/logo.png', esc(state.lk && state.lk.settings ? state.lk.settings.company_name : 'HUB LINE SHIPPING LLC'))}</div>
      <div><h2>Run your NVOCC from one clear, connected workspace.</h2>
        <ul><li>${icon('package', 18)} Bookings, house B/Ls and master consolidations</li><li>${icon('container', 18)} Live container inventory and free-time tracking</li>
          <li>${icon('percent', 18)} Agent agreements, commission and statements of account</li><li>${icon('invoice', 18)} Invoicing, receipts and ageing in any currency</li></ul></div>
    </section>
    <section class="login-form"><div class="card"><form class="lform" novalidate>
      <div class="mark"><img src="/img/logo.png" alt="HUB LINE SHIPPING LLC"><span>ERP</span></div>
      <div><h1>Welcome back</h1><div class="muted">Sign in to continue to your workspace.</div></div>
      <div class="alert bad ${msg ? '' : 'hidden'}" data-err>${esc(msg)}</div>
      <label class="f"><span>Username</span><input type="text" name="username" autocomplete="username" autofocus></label>
      <label class="f"><span>Password</span><input type="password" name="password" autocomplete="current-password"></label>
      <button class="btn primary" style="width:100%;min-height:40px" type="submit">Sign in</button>
      <div class="foot">NVOCC operations, agents &amp; accounts</div></form></div></section></div>`;
  const form = $('form', app), err = $('[data-err]', app);
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); err.classList.add('hidden');
    const btn = $('button', form); btn.disabled = true;
    try {
      await api('POST', '/login', { username: form.username.value, password: form.password.value });
      await boot();
    } catch (ex) { err.textContent = ex.message; err.classList.remove('hidden'); btn.disabled = false; }
  });
}
function showChangePassword(forced = true) {
  app.innerHTML = `<div class="login simple"><div class="card"><form class="lform" novalidate>
    <div class="mark" style="display:flex;align-items:center;gap:10px;font-weight:700;margin-bottom:6px">${logoMark(32)}<span>HUB LINE ERP</span></div>
    <div><h1>Choose a new password</h1><div class="muted">${forced ? 'For security you must set your own password before continuing.' : ''}</div></div>
    <div class="alert bad hidden" data-err></div>
    <label class="f"><span>Current password</span><input type="password" name="current" autocomplete="current-password" autofocus></label>
    <label class="f"><span>New password <em class="hint">(at least 8 characters)</em></span><input type="password" name="password" autocomplete="new-password"></label>
    <label class="f"><span>Repeat new password</span><input type="password" name="again" autocomplete="new-password"></label>
    <button class="btn primary" style="width:100%;min-height:40px" type="submit">Save password</button>${forced ? '' : '<a class="btn" style="width:100%" href="#/dashboard" data-cancel-pw>Cancel</a>'}</form></div></div>`;
  const form = $('form', app), err = $('[data-err]', app);
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); err.classList.add('hidden');
    if (form.password.value !== form.again.value) { err.textContent = 'The two new passwords do not match.'; err.classList.remove('hidden'); return; }
    try { await api('POST', '/change-password', { current: form.current.value, password: form.password.value }); toast('Password changed', 'ok'); await boot(); }
    catch (ex) { err.textContent = ex.message; err.classList.remove('hidden'); }
  });
}
window.addEventListener('auth-lost', () => showLogin('Your session has ended. Please sign in again.'));
window.addEventListener('must-change-pw', () => showChangePassword(true));

// ---------------------------------------------------------------- shell
function renderShell() {
  const me = state.me;
  const co = state.lk.settings.company_name || 'HUB LINE';
  const nav = NAV.map(([h, items]) => {
    const vis = items.filter(([, , perm, , who]) => allowed(perm) && !(who === 'staff' && me.is_agent) && !(who === 'agent' && !me.is_agent));
    return vis.length ? `<div class="nav-h">${esc(h)}</div><div class="nav">${vis.map(([l, href, , ic]) => `<a href="${href}" data-nav="${href}">${icon(ic, 18)}<span>${esc(l)}</span></a>`).join('')}</div>` : '';
  }).join('');
  const initials = me.full_name.split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  const showSearch = can('shipments', 'read') || can('containers', 'read');
  app.innerHTML = `<div class="shell"><aside class="side" id="side">
      <div class="brand"><div class="plate"><img src="/img/logo.png" alt="${esc(co)}"></div><span class="tag">NVOCC ERP</span></div>${nav}
      <div class="side-foot">NVOCC ERP &middot; v0.2</div></aside>
    <div class="main"><header class="top"><button class="iconbtn menu-btn" data-menu aria-label="Menu">${icon('menu', 20)}</button>
      ${showSearch ? `<form class="gsearch" data-gsearch role="search">${icon('search', 16)}<input type="text" name="q" placeholder="Search container no., booking, HBL, vessel…" autocomplete="off" aria-label="Search"></form>` : ''}<div class="grow"></div>
      <button class="iconbtn" data-act="theme" title="Switch light / dark theme" aria-label="Switch theme">${icon(isDark() ? 'sun' : 'moon', 18)}</button>
      <button class="iconbtn" data-act="pw" title="Change password" aria-label="Change password">${icon('key', 18)}</button>
      <div class="userchip"><span class="av">${esc(initials)}</span><div><div><b>${esc(me.full_name)}</b></div><div class="muted small">${esc(me.role_label)}</div></div></div>
      <button class="iconbtn" data-act="logout" title="Sign out" aria-label="Sign out">${icon('logout', 18)}</button></header>
      <main class="page" id="page"></main></div></div>`;
}
// delegated once (the shell is re-rendered, #app is not)
on(app, 'click', '[data-menu]', () => $('#side').classList.toggle('open'));
on(app, 'click', '.nav a', () => $('#side').classList.remove('open'));
on(app, 'click', '[data-act=logout]', async () => { await api('POST', '/logout'); showLogin(); });
on(app, 'click', '[data-act=pw]', () => showChangePassword(false));
on(app, 'click', '[data-cancel-pw]', (e) => { e.preventDefault(); boot(); });
on(app, 'click', '[data-act=theme]', (_e, el) => { const t = isDark() ? 'light' : 'dark'; applyTheme(t); try { localStorage.setItem(THEME_KEY, t); } catch { /* private mode */ } el.innerHTML = icon(isDark() ? 'sun' : 'moon', 18); });
// global search: container numbers go to the inventory, anything else to the shipment register
app.addEventListener('submit', (e) => {
  const f = e.target.closest('[data-gsearch]'); if (!f) return;
  e.preventDefault();
  const q = f.q.value.trim(); if (!q) return;
  const isBox = /^[A-Za-z]{4}\d{6,7}$/.test(q.replace(/[\s-]/g, ''));
  const target = isBox || !can('shipments', 'read') ? '#/track?q=' : state.me.is_agent ? '#/bls?q=' : '#/shipments?q=';
  location.hash = target + encodeURIComponent(q);
});
// clickable table rows: <tr data-go="#/route"> (inline handlers are blocked by the CSP)
on(app, 'click', '[data-go]', (e, el) => { if (!e.target.closest('a, button, input, select, label')) location.hash = el.dataset.go; });

let renderToken = 0;
async function route() {
  if (!state.me) return;
  const { path, query } = parseHash();
  const token = ++renderToken;
  // a dialog left open must not survive navigation (e.g. browser Back)
  document.querySelectorAll('body > .overlay').forEach((o) => o.remove()); document.body.style.overflow = '';
  // printable documents render without the shell
  const pm = match('print/:kind/:id', path);
  if (pm) {
    app.innerHTML = '<div class="boot">Preparing document…</div>';
    try { const mod = await import('./views/print.js'); if (token === renderToken) await mod.render(app, pm, query); }
    catch (e) { app.innerHTML = `<div class="page"><div class="alert bad">${esc(e.message)}</div><a class="btn" href="#/dashboard">Back</a></div>`; }
    return;
  }
  if (!$('#page')) renderShell();
  const page = $('#page');
  $$('.nav a').forEach((a) => a.classList.toggle('on', path === a.dataset.nav.slice(2) || path.startsWith(a.dataset.nav.slice(2) + '/')));
  for (const [pattern, perm, file, exp] of ROUTES) {
    const params = match(pattern, path);
    if (!params) continue;
    if (perm && !allowed(perm)) { page.innerHTML = '<div class="alert bad">Your role does not have access to this area.</div>'; return; }
    page.innerHTML = '<div class="boot">Loading…</div>';
    try {
      const mod = await import(file);
      if (token !== renderToken) return;
      const root = document.createElement('div');
      await mod[exp](root, params, query);
      if (token !== renderToken) return;
      page.replaceChildren(root);
      window.scrollTo(0, 0);
    } catch (e) {
      if (token !== renderToken) return;
      console.error(e);
      page.innerHTML = `<div class="alert bad">${esc(e.message || 'Something went wrong.')}</div><button class="btn" data-retry>Try again</button>`;
      $('[data-retry]', page).addEventListener('click', route);
    }
    return;
  }
  page.innerHTML = '<div class="empty">That page does not exist. <a href="#/dashboard">Go to the dashboard</a>.</div>';
}

async function boot() {
  try {
    state.me = await api('GET', '/me');
  } catch (e) { return showLogin(); }
  if (state.me.must_change_pw) return showChangePassword(true);
  await loadLookups();
  document.title = (state.lk.settings.company_name || 'HUB LINE') + ' - ERP';
  app.innerHTML = '';
  if (!location.hash || location.hash === '#') location.hash = '#/dashboard';
  route();
}
window.addEventListener('hashchange', route);
boot();
